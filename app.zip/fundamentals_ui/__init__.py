# ==============================================================================
#                        CASSIO MURAKAMI - FEM SOLVER
#                          Project: Fundamentals UI
#                             Title: __init__.py
# ==============================================================================
"""
The look the two applications share, below both of them (user's decision, 2026-10-29: two applications, the
dependency one way): the colours (theme.py), the base style of a QApplication (base_style.py), the controls that
answer the hand (controls.py) and the Python source as both show it (code.py). It is versioned with Numerical
Fundamentals: CAE Fundamentals receives a change to it with a new tag. It imports neither cae_fundamentals, cae_lab nor numerical_fundamentals
(tests/test_dependency_direction.py). Nothing is imported here.
"""
