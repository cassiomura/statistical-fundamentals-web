# ==============================================================================
#                        CASSIO MURAKAMI - FEM SOLVER
#                          Project: Fundamentals UI
#                              Title: theme.py
# ==============================================================================
"""
The colours of the product: those of the LAB (the pre-processing laboratory), the face of the whole application.
Every wing builds its own Theme from these (gui/style.py, numerical_fundamentals/gui/style.py and palette.py). Plain
data, no Qt: scripts, figures and tests read it without a display.

Colours that carry a meaning stay with their wing: verified / known difference / error, the hues of the curves of
the Numerical laboratories, the colours of the code.
"""
# The LAB, as its prototype defines them
SURFACE = "#151B24"         # the screen: panels, pages, figures
RAISED = "#202833"          # inputs, buttons, chips
TEXT = "#EDF2F7"
SECONDARY = "#AAB8C8"       # labels, secondary text
ACCENT = "#63C7D2"          # where the window is, links, the main command
AMBER = "#EFC75B"           # forces, an invalid entry
BORDER = "#303B49"          # separators
FIELD_BORDER = "#445469"    # the border of an input
HOVER = "#2C3B49"           # a control under the pointer
SELECTED = "#23424B"        # a chosen row, a checked button
DISABLED = "#788593"

# Derived here (the LAB has a single screen tone): same hue, other depths
DEEP = "#10151C"            # the product bar, the Numerical chapter bar, under the panels
BLOCK = "#1A212B"           # a block on the screen: the steps of the Benchmark
ACCENT_HOVER = "#8AD6DE"    # the accent under the pointer
ON_ACCENT = "#0E1418"       # text on the accent
PROSE = "#D5DDE6"           # long reading: a softer white
VIEW_TOP = "#1C2430"        # the 3D view of the window: a gradient from the top...
VIEW_BOTTOM = DEEP          # ...to the bottom
VIEW_UNDEFORMED = "#8A98A8" # the undeformed outline in the 3D view

# The scene of the LAB (cae_lab/gui/scene_view.py): the pieces by material, their edges and nodes, the axes, moments
SCENE_GRID = "#25303E"
SCENE_EDGE = "#7A9BB1"
SCENE_NODE = "#B4CBD7"
STEEL = "#2F5B7E"           # Structural Steel: blue (lit by the orientation of each face)
STEEL_SELECTED = "#3485AA"
ALUMINUM = "#307852"        # aluminum: green
ALUMINUM_SELECTED = "#37996C"
STEEL_LINE = "#4685AA"      # a beam drawn as a line
ALUMINUM_LINE = "#399970"
AXIS_X = "#E59393"
AXIS_Y = "#8DC7AE"
AXIS_Z = "#8BB6E3"
MOMENT = "#D3A3E8"          # a nodal moment (forces are AMBER; the preview of a join is AMBER, translucent)
CONTOUR_COLOURS = ("#0000FF", "#0080FF", "#00FFFF", "#00FF80", "#00FF00",
                   "#80FF00", "#FFFF00", "#FF8000", "#FF0000")  # Mechanical Rainbow: minimum to maximum
TRACK = "#222B35"           # the dark track of a segmented control (fundamentals_ui/controls.py)
PILL = "#36424F"            # its chosen segment, a lighter material on the track
READY = "#8DC7AE"           # a step done, a check passed (the stage bar, the checklists)
CARD = "#1D242D"            # a card of the bench selector
BUTTON_BORDER = "#3B4B5C"   # the border of a LAB button
CHECK_BORDER = "#63768B"    # the border of a check box and of a tooltip in the LAB
CAUSE_BAND = "#26241C"      # an amber-tinted block: the cause of a difference, the notice of an edited bench
CAUSE_BORDER = "#4A4128"    # its border

def contrast(foreground: str, background: str) -> float:
    """WCAG contrast ratio between two #RRGGBB colours (4.5 is the minimum for text)."""
    def luminance(colour: str) -> float:
        channels = [int(colour[index:index + 2], 16) / 255 for index in (1, 3, 5)]
        linear = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in channels]
        return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]
    lighter, darker = sorted((luminance(foreground), luminance(background)), reverse=True)
    return (lighter + 0.05) / (darker + 0.05)
# Element Guide matrix signs and natural-coordinate directions.
MATRIX_POSITIVE = "#4CC3D1"
MATRIX_NEGATIVE = "#F0A050"
MATRIX_NEGATIVE_TEXT = "#F3C08E"
PENALTY = "#F0A050"          # the penalty stiffness C on the diagonal (the Solver's theory column)
NATURAL_AXIS_COLOURS = ("#FF9F6E", "#8FD18B", "#8AB4FF")
