# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: bridge.py
# ==============================================================================
"""
The web version's Python side, without Qt: what the window (statistical_fundamentals/gui/) does with the laboratories,
played for a page in a browser. It runs in Pyodide, in a Web Worker (web/shell/worker.js), on the same package the
desktop window runs: the cores, explorers/, benches.py, cover.py, palette.py and i18n/. Nothing of gui/ is shipped (it
imports Qt): what the web needs of it is ported here in plain Python, behaviour for behaviour, and the names keep the
window's so that the two can be read side by side:

    Bridge      gui/main_window.MainWindow   the cover, the mode, the language, each mode's studies and stars
    Bench       gui/bench_view.BenchView     one bench: its three steps and the study that joins them, the game's judge
    Step        gui/lab_views.LabView        one laboratory at work: its settings, the frames, the mouse, the figure

The page asks by one call, Bridge.handle(request), a request being plain JSON: {"op": ..., "size": ..., ...}. The
answer is (text, pixels, meta): the view as JSON text (what the column, the bar, the strip and the cover show, every
text in the language on screen, every number computed by the laboratories), the figure as raw RGBA pixels (or None when
the picture on the page is still the right one), and the pixels' geometry. The figure is drawn by the laboratory itself
(Lab.draw) on a matplotlib Figure with an Agg canvas, at the size the page gives it in CSS pixels times the device's
pixel ratio: the figure's dpi is 100 times that ratio, so explorers/lab.size measures it in CSS pixels, the layout pixels
of the labs, and the fonts keep their size on a dense screen (the gotcha of the desktop's dpi). A phone in portrait asks
for one panel only: the figure is laid out by the labs' own narrow plan (explorers/panels.arrangement, the stack) and the
rows of that panel are cut out of it (crops).

The pointer: the page sends a press, a move, a release in CSS pixels of the whole figure; they become matplotlib mouse
events on the canvas (device pixels from the bottom, as the Qt canvas gives them), processed by the canvas's callbacks
(the 3D view turns itself, as on the desktop) and given to the lab's hit, grab and drag as LabView does. A touch has no
hover: a tap shows what lies under it (the design ringed) until the next tap.

The game is the window's: a step opens on what it was handed (Lab.opening), the cost of a study is its N and every
distinct x* validated on that experiment (Bench.paid, given to the labs as Lab.paid from Lab.charged, kept in the
bench's snapshot through Restore, a language and a visit), the cover keeps the worth of the study that earned the best
stars (Bench.best), and on the first win every step is shown again (what a student's lab hid opens). The foot's line
says why the filled button cannot be pressed (Lab.missing) or, when it can, where to go next (Lab.hint). A step that
leaves the screen stops its frames and says no cue until it is back (away); the forward command stops the frames first
and hands the result read after that. A press or a drag that changed the settings asks for the cue "drag" once, on
release; a key that changed them, for the cue of that key ("enter" and "space" place a point of a free sample).

The frames of a construction are played by the page's clock: while a motion plays, the view says how long the frame
stays and carries a token; the page asks for the next frame with it, and any other request stops the motion first (the
token then no longer matches). What the desktop keeps in QSettings (the language, the mode, the student's stars) is
given back to the page as `persist`, which keeps it in localStorage and gives it back at the next start (boot).
"""
import io
import json
import math
import traceback

import numpy as np
from matplotlib.backend_bases import MouseButton, MouseEvent
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from statistical_fundamentals import __version__, cover, i18n, palette
from statistical_fundamentals.benches import BENCHES, STEPS
from statistical_fundamentals.explorers import lab_for
from statistical_fundamentals.explorers.base import minus
from statistical_fundamentals.explorers.game import MODES, MOST, STUDENT, TEACHER
from statistical_fundamentals.explorers.lab import TRANSPORT, Action, Lab
from statistical_fundamentals.explorers.panels import BELOW, arrangement
from statistical_fundamentals.explorers.study import CURRENT, DONE, LOCKED, Study, advanced, changed, enabled, shown, states
from statistical_fundamentals.i18n import LANGUAGES, get_text

FIRST_MODE = STUDENT            # the mode of the first run, the desktop's (gui/main_window.FIRST_MODE): the game is the product
LAST = len(STEPS) - 1           # the step whose state completes the bench (Lab.finished)
FULL_STAR, HOLLOW_STAR = "★", "☆"     # the stars of the status line: filled, hollow (never colour alone)
LAYOUT_DPI = 100                # explorers/lab.LAYOUT_DPI: a figure's dpi is this times the device's pixel ratio
LEAST_WIDTH = 120               # CSS pixels: the narrowest figure drawn
MOST_RATIO = 2.0                # the device's pixel ratio is taken up to this (a phone at 3 draws at 2)
PANELS = ("plane", "space", "third")            # the panels of a stacked figure, from its top: what a phone shows one at a time
ROLE_COLORS = {cover.REFERENCE: palette.SLATE, cover.ANSWER: palette.BLUE, cover.SECOND: palette.GOLD,
               cover.GUIDE: palette.DARK_GREY, cover.AXIS: palette.GREY}            # gui/cover.ROLE_COLORS
ROLE_WIDTHS = {cover.REFERENCE: 2.8, cover.ANSWER: 2.4, cover.SECOND: 2.2, cover.GUIDE: 1.0, cover.AXIS: 1.2}

def star_line(stars: int) -> str:
    """The stars as the status line writes them: "★★☆" (gui/bench_view.star_line)."""
    return FULL_STAR * stars + HOLLOW_STAR * (MOST - stars)

def whole_inches(pixels: float, dpi: float) -> float:
    """A length in inches that gives back at least `pixels` at `dpi` (gui/widgets.whole_inches): 820 pixels at 100 dpi
    are 8.2 inches, and 8.2 x 100 is 819.99..., which matplotlib truncates to 819."""
    inches = pixels / dpi
    while inches * dpi < pixels:
        inches = math.nextafter(inches, math.inf)
    return inches

def position(control, value) -> int:
    """The index of a value among a control's values, or of the nearest one (gui/lab_views.position)."""
    if value in control.values:
        return control.values.index(value)
    return min(range(len(control.values)), key=lambda i: abs(control.values[i] - value))

def step_tip(step: int, state: str, worth: tuple | None = None) -> str:
    """What a pill says of its step: its number and name, its state, why it is locked, and what it is worth
    (gui/main_window.step_tip)."""
    key = STEPS[step]
    name = get_text(f"step.{key}.title")
    if state == LOCKED:
        return get_text(f"step.tip.locked.{key}", number=step + 1, name=name)
    kind = "current" if state == CURRENT else "done" if state == DONE else "open"
    tip = get_text(f"step.tip.{kind}", number=step + 1, name=name)
    return f"{tip}\n{worth[0]}" if worth else tip

def stored_stars(value) -> int:
    """The stars kept for a bench (an int, or its text): 0 to MOST, 0 for nothing (gui/main_window.stored_stars)."""
    try:
        return min(max(int(value), 0), MOST)
    except (TypeError, ValueError):
        return 0

def worth_said(study: Study, step: int) -> bool:
    """Whether what a step is worth is said (gui/bench_view.worth_said): its result was handed on, or, for the last
    step, the input it works on is still the one handed."""
    return study.handed[min(step, len(STEPS) - 2)] is not None

def worth(bench: str, snapshot: dict | None, mode: str = TEACHER) -> tuple:
    """What each step of a bench's study is worth, from its snapshot, said again in the language on screen when it was
    said in another one (gui/bench_view.worth)."""
    if not snapshot:
        return ()
    language, said = snapshot.get("worth", ("", ()))
    if language == i18n.current_language():
        return said
    study, labs, found = snapshot["study"], snapshot.get("labs", {}), []
    for step, key in enumerate(STEPS):
        if key not in labs or not worth_said(study, step):
            found.append(None)
            continue
        if step == LAST and snapshot.get("best") is not None:     # what the completing study was worth
            found.append(snapshot["best"])
            continue
        lab = lab_for(key, bench, mode)
        lab.paid = snapshot.get("paid", {})
        try:
            text, kind = lab.summary(lab.state(labs[key]["settings"]))
        except (ArithmeticError, ValueError):
            text, kind = "", "plain"
        found.append((text, kind) if text else None)
    return tuple(found)

def reading_key(step: str, state) -> str:
    """The reading of the code panel for what the step shows (gui/lab_code.reading_for): the sampling or the method
    on screen, or the metamodel; "" when there is none."""
    if state is None:
        return ""
    if step in ("doe", "optimization"):
        return state.method
    return state.model if step == "metamodel" else ""

def crops(width: float, height: float) -> dict | None:
    """The rows of each panel of a stacked figure (explorers/panels.stack), in CSS pixels from its top: the design space
    with its tick labels, the formula and the 3D view, the third panel with its head; None when the figure is not
    stacked (it is shown whole)."""
    plan = arrangement(width, height, pair="space", fill=True)
    if plan.kind != "stack":
        return None
    first = height - (plan.plane[1] - BELOW)                  # under the design space's tick labels: the formula's block
    second = height - plan.heads["check"][1]                    # the top of the third panel's head
    bounds = (0.0, first, second, height)
    return {name: (round(bounds[i]), round(bounds[i + 1])) for i, name in enumerate(PANELS)}

class Canvas(FigureCanvasAgg):
    """The Agg canvas of a step's figure. matplotlib's draw_idle draws at once on Agg (the 3D view calls it at every move
    of the mouse); here it only says the picture must be drawn again: the bridge draws once per request."""
    wanted = False

    def draw_idle(self, *args, **kwargs) -> None:
        self.wanted = True

# ------------------------------------------------------------------------------
# One laboratory at work (gui/lab_views.LabView, without the widgets)
# ------------------------------------------------------------------------------
class Step:
    """A laboratory of a step: its settings and what it received, its state, the frames that play, the pointer on its
    figure, and the figure itself (one per step, as each LabView has its canvas: the labs reuse their axes)."""

    def __init__(self, bridge: "Bridge", lab: Lab, snapshot: dict | None = None, handed=None, title: str = "", purpose: str = ""):
        self.bridge = bridge
        self.lab = lab
        self.title, self.purpose = title, purpose
        if snapshot:
            self.settings = dict(snapshot["settings"])
            self.handed = snapshot.get("handed")                # what the step before handed (Lab.receive), or None
            if handed is not None and handed != self.handed:
                self.handed = handed
                self.settings = lab.receive(dict(self.settings), handed)
        else:                                                   # the first settings on what was handed (Lab.opening)
            self.handed = handed
            self.settings = lab.opening(handed)
        self.away = False                                       # off screen since it was shown: no frame, no cue
        self.dragged = False                                    # the press under way changed the settings (a cue on release)
        self.on_cue = None                                      # the bench's: a cue of this lab (LabView.cue)
        self.filled = next((action for action in lab.actions if action.forward or action.primary), None)
        self.worth: tuple[str, str] = ("", "plain")
        self.held: dict | None = None
        self.hovered = None
        self.handle = None
        self.state = None
        self.motion: str | None = None
        self.playing: str | None = None
        self.token = 0                                          # the frames' token: a new one at every start and halt
        self.status = ""
        self.status_kind = "warning"                            # the status line's colour: "warning" or "ok" (set_status)
        self.alert = ("", False)
        self.on_change = None                                   # the bench's: a laboratory changed (LabView.changed)
        self.figure = Figure()
        self.canvas = Canvas(self.figure)
        self.stale = True                                       # the figure waits for a draw
        self.drawn = None                                       # the size and density it was drawn at
        self.draws = 0                                          # how many pictures it made: a new one is sent to the page
        self.pressed = False
        self.refresh()

    # ------------------------------------------------------------------ the controls
    def control(self, key: str):
        return next(c for c in self.lab.controls if c.key == key)

    def nearest(self, key: str, value):
        control = self.control(key)
        return control.values[position(control, value)]

    def changed(self) -> None:
        if self.on_change is not None:
            self.on_change()

    def choose(self, key: str, value) -> None:
        """A control moved to `value`: the settings follow (Lab.adjust), unless the value is the one they hold or one
        the lab keeps locked."""
        if self.settings.get(key) == value or self.lab.locked(key, value, self.settings):
            return
        self.halt()
        old = self.settings.get(key)
        self.settings = self.lab.adjust(dict(self.settings) | {key: value}, key, old)
        self.refresh()

    def set_value(self, key: str, value) -> None:
        """A quick pick: the field or the slider moves, and with it the settings."""
        control = self.control(key)
        target = value if control.typed else control.values[position(control, value)]
        if self.settings.get(key) == target:
            self.refresh()
        else:
            self.choose(key, target)

    def slider_top(self, control) -> int:
        top = self.lab.limit(control.key, self.settings)
        return len(control.values) - 1 if top is None else top

    def step(self, delta: int) -> bool:
        """The first slider on show one value further; False when none is on show."""
        for control in self.lab.controls:
            if control.check or control.buttons or control.typed or not self.lab.shown(control, self.settings):
                continue
            index = position(control, self.settings[control.key])
            index = max(0, min(index + delta, self.slider_top(control)))
            self.choose(control.key, control.values[index])
            return True
        return False

    def reset(self) -> None:
        """Restore: the step's first settings, with what it received kept; "apply" when it changed something."""
        self.halt()
        before = self.settings
        self.settings = self.lab.opening(self.handed)               # no competition run for nothing (Lab.opening)
        self.refresh()
        if self.settings != before and not self.away:
            self.cue("apply")

    def receive(self, handed) -> None:
        """The result the step before handed, taken in (Lab.receive)."""
        self.halt()
        self.handed = handed
        self.settings = self.lab.receive(dict(self.settings), handed)
        self.refresh()

    def act(self, key: str) -> None:
        """A command of the lab (LabView.act): View code, a motion started, paused or hurried, or a plain command."""
        if self.state is None:
            return
        if self.lab.link(key, self.state):
            self.halt()
            self.bridge.code_open = True
            return
        motion = next((a.motion for a in self.lab.actions if a.key == key), "")
        if motion == "run" and self.motion == "run":
            self.halt()
            self.refresh()
        elif motion == "step" and self.motion is not None and not self.lab.at_rest(self.settings):
            self.halt()
            self.finish_step()
            self.say(key)
        elif motion:
            self.halt()
            settings = self.lab.rewind(key, self.state, dict(self.settings))
            if settings != self.settings:
                self.settings = settings
                self.state = self.lab.state(settings)
            self.play(motion, key)
        else:
            self.halt()
            self.settings = self.lab.act(key, self.state, dict(self.settings))
            self.refresh()
            self.say(key)

    def set_status(self, text: str, kind: str = "warning") -> None:
        """The status line over the filled button: a result discarded (warning) or the bench complete (ok)."""
        self.status, self.status_kind = text, kind

    def cue(self, cue: str) -> None:
        if self.on_cue is not None:
            self.on_cue(cue)
        else:
            self.bridge.cues.append(cue)

    def say(self, key: str) -> None:
        """The sound of the command `key` just carried out (Lab.cue); none from a view gone off screen (away)."""
        if self.state is not None and not self.away:
            cue = self.lab.cue(key, self.state)
            if cue:
                self.cue(cue)

    # ------------------------------------------------------------------ frames
    def play(self, motion: str, key: str = "") -> None:
        if motion == "step" and not self.bridge.motion_allowed:
            self.finish_step()
            self.say(key)
            return
        self.motion, self.playing = motion, key
        self.token += 1
        self.next_frame()

    def frame(self, token: int) -> None:
        """The page's clock asks for the next frame: only of the motion it was given (any change since stopped it)."""
        if self.motion is not None and token == self.token:
            self.next_frame()

    def next_frame(self) -> None:
        key = self.playing
        if not self.bridge.motion_allowed:
            self.finish_step()
            if self.lab.advance(self.state, self.settings) is None:
                self.halt()
                self.refresh()
                self.say(key)
            return
        settings = self.lab.advance(self.state, self.settings)
        if settings is None:
            self.halt()
            self.refresh()
            self.say(key)
            return
        self.settings = settings
        ended = self.motion == "step" and self.lab.at_rest(settings)
        if ended:
            self.halt()
        self.refresh()
        if ended:
            self.say(key)

    def finish_step(self) -> None:
        for _frame in range(64):
            settings = self.lab.advance(self.state, self.settings)
            if settings is None:
                break
            self.settings = settings
            self.state = self.lab.state(settings)
            if self.lab.at_rest(settings):
                break
        self.refresh()

    def halt(self) -> None:
        if self.motion is not None:
            self.token += 1
        self.motion, self.playing = None, None

    def stop(self) -> None:
        """The frames that play stopped where they are (LabView.stop): the view leaves the screen, or its result is
        about to be handed. Nothing when no frame plays."""
        if self.motion is None:
            return
        self.halt()
        self.refresh()

    # ------------------------------------------------------------------ state
    def snapshot(self) -> dict:
        return {"settings": dict(self.settings), "handed": self.handed}

    def output(self):
        return None if self.state is None else self.lab.output(self.state)

    def unlocked(self, settings: dict) -> dict:
        """The settings with no value the lab keeps locked (LabView.unlocked)."""
        for control in self.lab.controls:
            value = settings.get(control.key)
            if not control.buttons or value not in control.values or not self.lab.locked(control.key, value, settings):
                continue
            held = (self.held or {}).get(control.key)
            kept = next((other for other in (held, control.values[control.initial], *control.values)
                         if other in control.values and not self.lab.locked(control.key, other, settings)), value)
            settings = settings | {control.key: kept}
        return settings

    def refresh(self) -> None:
        """A new state for the settings (LabView.refresh): what the column, the strip and the figure show."""
        self.settings = self.unlocked(self.settings)
        self.held = dict(self.settings)
        try:
            self.state = self.lab.state(self.settings)
        except (ArithmeticError, ValueError) as error:
            self.state = None
            self.worth = ("", "plain")
            self.alert = (get_text("explorer.cannot", error=error), True)
            self.changed()
            return
        self.hovered = None
        alert = self.lab.alert(self.state)
        self.alert = (alert or self.lab.notice(self.state), bool(alert))
        self.worth = self.lab.summary(self.state)
        self.stale = True
        self.changed()

    # ------------------------------------------------------------------ the 3D view's angle
    def axes_3d(self) -> list:
        return [ax for ax in self.figure.axes if ax.name == "3d"]

    def angle(self) -> tuple[float, float]:
        axes = self.axes_3d()
        return (float(axes[0].elev), float(axes[0].azim)) if axes else tuple(self.lab.view)

    def turn(self, angle) -> None:
        angle = tuple(float(a) for a in angle)
        if angle == self.angle():
            return
        self.lab.view = angle
        axes = self.axes_3d()
        for ax in axes:
            ax.view_init(*angle)
        if axes:
            self.canvas.wanted = True

    # ------------------------------------------------------------------ the pointer and the keys
    def event(self, name: str, x: float, y: float, button=None) -> MouseEvent:
        """A matplotlib mouse event at CSS pixels (x, y) from the figure's top left: device pixels from its bottom."""
        ratio = self.figure.dpi / LAYOUT_DPI
        height = self.figure.bbox.height
        return MouseEvent(name, self.canvas, x * ratio, height - y * ratio, button=button)

    def set_hovered(self, hovered) -> None:
        if hovered != self.hovered:
            self.hovered = hovered
            self.stale = True

    def pointer(self, kind: str, x: float, y: float, touch: bool) -> None:
        """A press, a move, a release or the pointer leaving the figure (LabView.on_press, on_move, on_release), the 3D
        view turned by matplotlib itself."""
        if self.drawn is None:
            return
        if kind == "leave":
            if not self.pressed:
                self.set_hovered(None)
            return
        if kind == "down":
            event = self.event("button_press_event", x, y, MouseButton.LEFT)
            self.pressed = True
            if self.state is not None and touch:
                self.set_hovered(self.lab.hit(self.figure, self.state, event))
            self.canvas.callbacks.process(event.name, event)
            if self.state is None or event.inaxes is None:
                return
            self.handle = self.lab.grab(self.figure, self.state, event)
            self.dragged = False
            if self.handle is not None:
                self.move(event)
        elif kind == "move":
            event = self.event("motion_notify_event", x, y, MouseButton.LEFT if self.pressed else None)
            self.canvas.callbacks.process(event.name, event)
            self.move(event, hover=not touch)
        elif kind == "up":
            event = self.event("button_release_event", x, y, MouseButton.LEFT)
            self.canvas.callbacks.process(event.name, event)
            self.pressed = False
            self.handle = None
            if self.dragged:
                self.dragged = False
                self.say("drag")

    def move(self, event, hover: bool = True) -> None:
        if self.state is None:
            return
        if self.handle is not None:
            if event.inaxes is None:
                return
            settings = self.lab.drag(self.figure, self.state, self.handle, event, dict(self.settings))
            if settings is not None:
                self.dragged = self.dragged or settings != self.settings
                self.halt()
                self.settings = settings
                self.refresh()
                self.hovered = self.handle
            return
        if hover and not self.pressed:
            self.set_hovered(self.lab.hit(self.figure, self.state, event))

    def press(self, key: str) -> None:
        """An arrow key on the figure: the lab's (Lab.press), else the first slider."""
        settings = self.lab.press(key, self.state, dict(self.settings)) if self.state is not None else None
        if settings is not None:
            changed = settings != self.settings
            self.halt()
            self.settings = settings
            self.refresh()
            if changed:                                         # the key that did it names the cue (Lab.cue)
                self.say(key)
        elif key in ("left", "right"):
            self.step(1 if key == "right" else -1)

    def cursor(self) -> str:
        if self.handle is not None and self.lab.grabbable(self.hovered):
            return "grabbing"
        if self.lab.grabbable(self.hovered):
            return "grab"
        return "pointer" if self.lab.clickable(self.hovered) else ""

    # ------------------------------------------------------------------ the figure
    def render(self, width: float, height: float | None, ratio: float, panel: str | None) -> tuple:
        """The figure at `width` x `height` CSS pixels (None: as tall as the lab needs, a phone's stack), drawn by the
        lab when anything changed, at `ratio` device pixels per CSS pixel; the pixels of one panel when the figure is
        stacked and a panel is asked for. (pixels, meta): pixels None while the state cannot be drawn."""
        wide = max(int(round(width)), LEAST_WIDTH)
        least = int(self.lab.height_for(wide))
        tall = least if height is None else max(int(round(height)), least)
        ratio = min(max(float(ratio), 1.0), MOST_RATIO)
        size = (wide, tall, ratio)
        if size != self.drawn:
            dpi = LAYOUT_DPI * ratio
            self.figure.set_dpi(dpi)
            self.figure.set_size_inches(whole_inches(round(wide * ratio), dpi), whole_inches(round(tall * ratio), dpi), forward=False)
            self.stale = True
        if self.state is None:
            return None, {"width": wide, "height": tall}
        if self.stale or size != self.drawn:
            self.lab.draw(self.figure, self.state, self.hovered)
            self.canvas.draw()
            self.draws += 1
        elif self.canvas.wanted:
            self.canvas.draw()
            self.draws += 1
        self.stale, self.canvas.wanted, self.drawn = False, False, size
        pixels = np.asarray(self.canvas.buffer_rgba())
        cut = crops(wide, tall)
        top, bottom = 0, tall
        if cut is not None and panel in cut:
            top, bottom = cut[panel]
            pixels = pixels[round(top * ratio):round(bottom * ratio)]
        meta = {"width": wide, "height": tall, "ratio": ratio, "top": top, "bottom": bottom, "pixel_width": int(pixels.shape[1]),
                "pixel_height": int(pixels.shape[0]), "panels": list(cut) if cut is not None else [], "draws": self.draws}
        return pixels, meta

    # ------------------------------------------------------------------ what the page shows
    def gives_line(self, control) -> bool:
        values = control.values if control.buttons else (self.settings.get(control.key),)
        return any(self.lab.formula(control.key, self.settings | {control.key: value})[1] for value in values)

    def controls_view(self) -> list:
        """Each control as the column draws it (LabView.column_control, show_controls)."""
        found = []
        for control in self.lab.controls:
            value = self.settings.get(control.key, control.values[control.initial])
            item = {"key": control.key, "label": control.label, "tip": control.tip, "alone": control.alone,
                    "visible": bool(self.lab.shown(control, self.settings))}
            if control.check:
                item |= {"kind": "check", "checked": bool(value)}
            elif control.buttons:
                item |= {"kind": "buttons", "names": list(control.names), "index": control.values.index(value),
                         "locked": [self.lab.locked(control.key, v, self.settings) for v in control.values]}
            elif control.typed:
                item |= {"kind": "typed", "symbol": control.symbol, "least": control.values[0], "most": control.values[-1],
                         "value": value, "empty": control.empty, "placeholder": get_text("lab.field_empty"),
                         "field_tip": get_text("lab.field_tip", least=control.values[0], most=control.values[-1])}
            else:
                top = self.slider_top(control)
                item |= {"kind": "slider", "index": min(position(control, value), max(top, 0)), "top": top,
                         "text": self.lab.showing(control.key, self.settings) or control.show(value), "fine_tip": get_text("lab.fine_tip")}
            if control.shortcuts:
                item["shortcuts"] = [{"text": f"{v:g}", "checked": value is not None and f"{value:g}" == f"{v:g}",
                                      "tip": get_text("lab.shortcut_tip", value=v)} for v in control.shortcuts]
            if self.gives_line(control):
                item["line"] = minus(self.lab.formula(control.key, self.settings)[1])
            found.append(item)
        return found

    def command(self, action: Action) -> dict:
        """A command as the column draws it, for the state on screen (LabView.show_commands)."""
        state = self.state
        playing = action.motion == "run" and self.motion == "run" and self.playing in (action.key, None)
        label = action.playing_label if playing and action.playing_label else action.label
        item = {"key": action.key, "visible": bool(self.lab.offered(action.key, self.settings)),
                "enabled": bool(state is not None and self.lab.enabled(action.key, state)) or playing,
                "tip": action.tip, "toggle": action.toggle, "checked": bool(action.toggle and self.settings.get(action.key))}
        if action.featured and action is not self.filled:
            item |= {"label": label, "detail": minus(self.lab.naming(action.key, state)) if state is not None else ""}
        elif action.icon and action is not self.filled:
            item |= {"label": label, "icon": action.playing_icon if playing and action.playing_icon else action.icon}
        elif action.opens:
            item |= {"label": get_text("panel.view_code"), "tip": action.tip}
        else:
            named = self.lab.naming(action.key, state) if state is not None else ""
            item |= {"label": label if playing and action.playing_label else named or action.label}
        return item

    def view(self) -> dict:
        """The column, the strip and the figure's words, as the workbench shows them (LabView)."""
        lab, state = self.lab, self.state
        heading, rows = lab.received(state) if state is not None else ("", ())
        card = {"heading": heading, "rows": [[minus(row[0]), minus(row[1]), row[2] if len(row) > 2 else "plain"] for row in rows]}
        featured, transport, chips, links = [], [], [], []
        for action in lab.actions:
            item = self.command(action)
            if action.top:
                links.append(item)
            elif action is self.filled:
                continue
            elif action.featured:
                featured.append(item)
            elif action.icon:
                transport.append(item)
            else:
                chips.append(item)
        filled, missing = None, ""
        if self.filled is not None:
            filled = self.command(self.filled) | {"forward": self.filled.forward}
            ready = self.output() is not None if self.filled.forward else state is not None and lab.enabled(self.filled.key, state)
            missing = "" if ready else lab.missing(state) if state is not None else get_text("lab.missing_state")
            filled["enabled"] = bool(ready)
            filled["tip"] = self.filled.tip if ready or not missing else missing
            missing = minus(lab.hint(state) if ready else missing)    # ready: where to go next (Lab.hint), if anywhere
        metrics = []
        if state is not None and not lab.metrics_in_figure(state):
            for metric in lab.metrics(state):
                metrics.append({"title": minus(metric.title), "value": minus(metric.value), "kind": metric.kind, "tip": minus(metric.tip),
                                "color": metric.color, "detail": minus(metric.detail), "detail_kind": metric.detail_kind})
        table = lab.table(state, self.hovered) if state is not None else None
        text, warning = self.alert
        return {"title": self.title, "purpose": self.purpose, "card": card, "featured": featured, "controls": self.controls_view(),
                "transport": transport, "stage": minus(lab.naming(TRANSPORT, state)) if transport and state is not None else "",
                "chips": chips, "links": links, "filled": filled, "missing": missing, "status": self.status,
                "status_kind": self.status_kind,
                "restore": {"shown": bool(lab.restore), "label": get_text("lab.reset"), "tip": get_text("lab.reset_tip")},
                "metrics": metrics, "alert": {"text": ("▲  " if warning else "") + minus(text), "warning": warning} if text else None,
                "lead": minus(lab.lead(state)) if state is not None else "", "figure_tip": lab.tip or get_text("lab.figure_tip"),
                "table": {"columns": list(table.columns), "rows": [list(r) for r in table.rows], "total": list(table.total),
                          "chosen": table.chosen} if table is not None else None,
                "playing": {"token": self.token, "ms": int(lab.frame_time(self.settings))} if self.motion is not None else None,
                "cursor": self.cursor(), "computed": state is not None}

# ------------------------------------------------------------------------------
# A bench: its three steps and its study (gui/bench_view.BenchView)
# ------------------------------------------------------------------------------
class Bench:
    def __init__(self, bridge: "Bridge", bench, snapshot: dict | None = None, mode: str = TEACHER, stars: int = 0):
        self.bridge = bridge
        self.bench = bench
        self.mode = mode
        self.stars = stars
        self.won_now = False
        snapshot = snapshot or {}
        self.paid: dict = dict(snapshot.get("paid", {}))         # what the study paid for and no setting keeps (Lab.charged)
        self.best = snapshot.get("best")                         # the last step's worth when it earned the best stars
        self.study: Study = snapshot.get("study", Study())
        self.saved: dict = dict(snapshot.get("labs", {}))
        self.discarded: set[int] = set(snapshot.get("discarded", ()))
        self.saved_worth = worth(bench.key, snapshot, mode)
        self.language = i18n.current_language()
        self.views: dict[int, Step] = {}
        self.on_screen: int | None = None
        self.enter(self.study.step, snapshot.get("view"))

    def current(self) -> Step:
        return self.views[self.study.step]

    def step_key(self) -> str:
        return STEPS[self.study.step]

    def states(self) -> tuple:
        return states(self.study)

    def view(self, step: int, handed=None, angle=None) -> Step:
        if step not in self.views:
            key = STEPS[step]
            lab = lab_for(key, self.bench.key, self.mode)
            lab.won = self.stars > 0
            lab.paid = self.paid                                # before its first state: what was already paid for
            if angle is not None:
                lab.view = tuple(angle)
            view = Step(self.bridge, lab, self.saved.get(key), handed, get_text(f"step.{key}.title"), get_text(f"step.{key}.purpose"))
            view.on_change = lambda step=step: self.lab_changed(step)
            view.on_cue = lambda cue, step=step: self.lab_cue(cue, step)
            self.say_status(step, view)
            self.views[step] = view
        return self.views[step]

    def status_text(self, step: int) -> str:
        if step in self.discarded:
            return get_text(f"step.discarded.{STEPS[step]}")
        if step == LAST and self.stars:
            following = self.opened()
            if following is not None:
                return get_text("bench.complete_opened", stars=star_line(self.stars), bench=following.title)
            return get_text("bench.complete", stars=star_line(self.stars))
        return ""

    def say_status(self, step: int, view: Step | None = None) -> None:
        """A step's status line in its colour: what was discarded in the warning's, the bench complete in the ok one."""
        view = view or self.views.get(step)
        if view is not None:
            view.set_status(self.status_text(step), "warning" if step in self.discarded else "ok")

    def opened(self):
        keys = list(BENCHES)
        place = keys.index(self.bench.key) if self.bench.key in keys else len(keys)
        return BENCHES[keys[place + 1]] if self.mode == STUDENT and place + 1 < len(keys) else None

    def show_step(self, step: int) -> None:
        if step == self.study.step or not enabled(self.study, step):
            return
        self.study = shown(self.study, step)
        self.enter(step)
        self.bridge.cues.append("navigate")

    def advance(self, step: int) -> None:
        view = self.views.get(step)
        if view is not None and step == self.study.step:
            view.stop()                                         # a competition that plays never crowns behind the reader
        output = view.output() if view is not None and step == self.study.step else None
        if output is None:
            return
        self.study = advanced(self.study, output)
        self.discarded.discard(step)
        view.set_status("")
        self.enter(self.study.step)
        if self.study.step != step:
            self.bridge.cues.append("advance")

    def enter(self, step: int, angle=None) -> None:
        left = self.views.get(self.on_screen) if self.on_screen is not None else None
        if left is not None:
            angle = left.angle()
            if step != self.on_screen:
                left.stop()                                     # the step left plays nothing behind the reader
                left.away = True
        handed = self.study.handed[step - 1] if step > 0 else None
        view = self.view(step, handed, angle)
        if handed is not None and view.handed != handed:
            view.receive(handed)
        view.away = False
        self.on_screen = step
        if angle is not None:
            view.turn(angle)
        if step == LAST:
            self.judge()

    def lab_changed(self, step: int) -> None:
        if step != self.study.step:
            return
        self.won_now = False
        self.study, discarded = changed(self.study, self.views[step].output())
        if discarded:
            self.discarded.add(step)
            self.say_status(step)
            self.bridge.cues.append("discard")
        if step == LAST:
            self.judge()

    def lab_cue(self, cue: str, step: int | None = None) -> None:
        """A laboratory's cue: only the step on screen's; not the "better" of the validation that completed the bench."""
        if step is not None and step != self.study.step:
            return
        if cue == "better" and self.won_now:
            return
        self.bridge.cues.append(cue)

    def stop(self) -> None:
        """The frames of every step stop where they are (the cover is shown), and none says a cue until shown again."""
        for view in self.views.values():
            view.stop()
            view.away = True

    def charge(self, view: Step) -> None:
        """What the last step's state paid for that its settings will not keep (Lab.charged: a validation, by its
        experiment), kept in `paid` when it is not there yet and given to every laboratory (BenchView.charge)."""
        try:
            charge = view.lab.charged(view.state)
        except (ArithmeticError, ValueError):
            charge = None
        if charge is None:
            return
        key, item = charge
        known = self.paid.get(key, ())
        if item in known:
            return
        self.paid = self.paid | {key: (*known, item)}           # a new dict: a lab's is never mutated
        for each in self.views.values():
            each.lab.paid = self.paid

    def judge(self) -> None:
        view = self.views.get(LAST)
        if view is None or view.state is None:
            return
        self.charge(view)
        try:
            found = int(view.lab.finished(view.state))
        except (ArithmeticError, ValueError):
            found = 0
        if found <= self.stars:
            return
        first = self.stars == 0
        self.stars = found
        self.best = view.worth if view.worth[0] else self.best
        for each in self.views.values():
            each.lab.won = True
        self.say_status(LAST)
        if first:                                               # what the labs kept until the bench was won opens
            for each in self.views.values():
                each.refresh()
        self.won_now = True
        self.bridge.cues.append("achieved")
        self.bridge.bench_achieved(self.bench.key, found)

    def summaries(self) -> tuple:
        found = []
        for step in range(len(STEPS)):
            view = self.views.get(step)
            if not worth_said(self.study, step):
                found.append(None)
            elif step == LAST and self.best is not None:        # complete: what the completing study was worth
                found.append(self.best)
            elif view is None:
                found.append(self.saved_worth[step] if step < len(self.saved_worth) else None)
            else:
                found.append(view.worth if view.worth[0] else None)
        return tuple(found)

    def snapshot(self) -> dict:
        labs = dict(self.saved) | {STEPS[step]: view.snapshot() for step, view in self.views.items()}
        return {"study": self.study, "labs": labs, "view": self.current().angle(), "discarded": tuple(sorted(self.discarded)),
                "worth": (self.language, self.summaries()), "paid": self.paid, "best": self.best}

# ------------------------------------------------------------------------------
# The application (gui/main_window.MainWindow, without the window)
# ------------------------------------------------------------------------------
class Bridge:
    """The cover and the benches, each mode's studies and stars, the language: what the page asks, answered."""

    def __init__(self):
        self.mode = FIRST_MODE
        self.bench = next(iter(BENCHES))
        self.studies: dict[str, dict[str, dict]] = {each: {} for each in MODES}
        self.stars: dict[str, dict[str, int]] = {TEACHER: {}, STUDENT: {}}
        self.page: Bench | None = None
        self.page_key: str | None = None
        self.on_cover = True
        self.code_open = False
        self.motion_allowed = True
        self.cues: list[str] = []
        self.sent = None                                         # what the page shows of the figure: (step, draws, panel)

    @property
    def lab_states(self) -> dict:
        return self.studies[self.mode]

    # ------------------------------------------------------------------ the page's one call
    def handle(self, request: str):
        """Answer a request of the page (JSON text): (the view as JSON text, the figure's pixels or None, their meta as
        JSON text). An error that nothing handled goes back in the view, with its traceback, and the page goes on."""
        asked = json.loads(request)
        self.cues = []
        error = ""
        try:
            self.carry_out(asked)
        except Exception:                                       # the window's report_error: shown, and the page goes on
            error = traceback.format_exc()
        pixels, meta = None, {}
        try:
            pixels, meta = self.picture(asked.get("size"), bool(asked.get("force")))
        except Exception:
            error = error or traceback.format_exc()
        view = self.view()
        view["error"] = error
        return json.dumps(view, ensure_ascii=False), pixels, json.dumps(meta)

    def carry_out(self, asked: dict) -> None:
        op = asked.get("op")
        step = self.page.current() if self.page is not None and not self.on_cover else None
        if op == "boot":
            self.boot(asked.get("saved") or {}, asked.get("language"), asked.get("motion", True))
        elif op == "mode":
            self.choose_mode(asked["mode"])
        elif op == "language":
            self.set_language(asked["language"])
        elif op == "open":
            self.open_bench(asked["bench"])
        elif op == "home":
            self.go_home()
        elif op == "restart":
            self.restart_student()
        elif op == "code":
            self.code_open = bool(asked.get("open"))
        elif self.page is None or step is None:
            return
        elif op == "step":
            self.page.show_step(int(asked["index"]))
        elif op == "control":
            control = step.control(asked["key"])
            if control.check:
                step.choose(control.key, bool(asked["value"]))
            elif control.typed:
                number = asked.get("value")
                step.choose(control.key, None if number is None else step.nearest(control.key, float(number)))
            else:
                index = int(asked["value"])
                if 0 <= index < len(control.values):
                    step.choose(control.key, control.values[index])
        elif op == "pick":
            control = step.control(asked["key"])
            step.set_value(control.key, control.shortcuts[int(asked["index"])])
        elif op == "action":
            action = next((a for a in step.lab.actions if a.key == asked["key"]), None)
            if action is not None and action.forward:
                self.page.advance(self.page.study.step)
            elif action is not None:
                step.act(action.key)
        elif op == "restore":
            step.reset()
        elif op == "frame":
            step.frame(int(asked.get("token", -1)))
        elif op == "pointer":
            step.pointer(asked["kind"], float(asked.get("x", 0)), float(asked.get("y", 0)), bool(asked.get("touch")))
        elif op == "key":
            step.press(asked["key"])

    # ------------------------------------------------------------------ settings kept by the page
    def boot(self, saved: dict, language: str | None, motion: bool) -> None:
        """The first request: what the page kept (the mode, the language, the student's stars), or the first run's (the
        mode FIRST_MODE, the language the browser asked for)."""
        mode = saved.get("mode")
        self.mode = mode if mode in MODES else FIRST_MODE
        chosen = saved.get("language") or language
        i18n.set_language(chosen if chosen in LANGUAGES else i18n.DEFAULT_LANGUAGE)
        stars = saved.get("stars") or {}
        self.stars[STUDENT] = {key: stored_stars(stars.get(key)) for key in BENCHES if stored_stars(stars.get(key))}
        self.motion_allowed = bool(motion)
        self.show_cover()

    def persist(self) -> dict:
        return {"mode": self.mode, "language": i18n.current_language(), "stars": dict(self.stars[STUDENT])}

    # ------------------------------------------------------------------ the game
    def open_benches(self) -> dict:
        if self.mode != STUDENT:
            return {}
        keys, stars = list(BENCHES), self.stars[STUDENT]
        return {key: keys[place - 1] for place, key in enumerate(keys) if place and not stars.get(keys[place - 1])}

    def is_open(self, bench: str) -> bool:
        return bench not in self.open_benches()

    def choose_mode(self, mode: str) -> None:
        if mode not in MODES or mode == self.mode:
            return
        self.save_page_state()
        self.drop_page()
        self.mode = mode
        self.show_cover()

    def drop_page(self) -> None:
        self.page = None
        self.page_key = None

    def bench_achieved(self, bench: str, stars: int) -> None:
        if stars > self.stars[self.mode].get(bench, 0):
            self.stars[self.mode][bench] = stars

    def restart_student(self) -> None:
        """The cover's quiet command, confirmed by the page: the student's stars and studies forgotten."""
        if self.mode == STUDENT:
            self.drop_page()
        self.stars[STUDENT] = {}
        self.studies[STUDENT] = {}
        self.bench = next(iter(BENCHES))
        self.show_cover()

    # ------------------------------------------------------------------ language and navigation
    def set_language(self, language: str) -> None:
        if language not in LANGUAGES or language == i18n.current_language():
            return
        i18n.set_language(language)
        if self.on_cover:
            return
        self.save_page_state()
        self.page = None
        self.select_bench(self.bench)

    def go_home(self) -> None:
        if self.on_cover:
            return
        self.show_cover()
        self.cues.append("navigate")

    def open_bench(self, bench: str) -> None:
        if bench not in BENCHES or not self.is_open(bench):
            return
        self.select_bench(bench)
        self.cues.append("navigate")

    def show_cover(self) -> None:
        if self.page is not None:
            self.page.stop()                                     # nothing plays behind the cover (BenchView.stop)
        self.save_page_state()
        self.code_open = False
        self.on_cover = True
        for key in BENCHES:
            snapshot = self.lab_states.get(key)
            if snapshot:
                snapshot["worth"] = (i18n.current_language(), worth(key, snapshot, self.mode))

    def select_bench(self, bench: str) -> None:
        self.save_page_state()
        self.on_cover = False
        if bench != self.page_key or self.page is None:
            self.bench = bench
            self.code_open = False
            self.page_key = bench
            self.page = Bench(self, BENCHES[bench], self.lab_states.get(bench), mode=self.mode, stars=self.stars[self.mode].get(bench, 0))

    def save_page_state(self) -> None:
        if self.page is None or self.page_key is None:
            return
        self.lab_states[self.page_key] = self.page.snapshot()

    # ------------------------------------------------------------------ what the page shows
    def picture(self, size: dict | None, force: bool = False) -> tuple:
        """The figure of the step on screen at the page's size, or None when the page already shows it."""
        if self.on_cover or self.page is None or not size:
            self.sent = None
            return None, {}
        step = self.page.current()
        panel = size.get("panel")
        pixels, meta = step.render(size.get("width", 800), size.get("height"), size.get("ratio", 1.0), panel)
        sent = (id(step), meta.get("draws"), panel, meta.get("width"), meta.get("height"), meta.get("ratio"))
        if pixels is not None and sent == self.sent and not force:
            return None, meta | {"same": True}
        self.sent = sent if pixels is not None else None
        if pixels is not None:
            pixels = np.ascontiguousarray(pixels)
        return pixels, meta

    def png(self, width: float, height: float | None, ratio: float = 1.0, panel: str | None = None) -> bytes:
        """The figure of the step on screen as a PNG (b"" on the cover, or while it cannot be drawn): the pixels the
        page is sent, encoded; for a check, a capture, or a page that would rather have an image file."""
        if self.on_cover or self.page is None:
            return b""
        pixels, _meta = self.page.current().render(width, height, ratio, panel)
        if pixels is None:
            return b""
        from matplotlib.image import imsave
        stream = io.BytesIO()
        imsave(stream, np.ascontiguousarray(pixels), format="png")
        return stream.getvalue()

    def cover_view(self) -> dict:
        locks = self.open_benches()
        cards = []
        stars = self.stars[self.mode]
        short = [get_text(f"step.{key}.short") for key in STEPS]
        for place, (key, bench) in enumerate(BENCHES.items(), start=1):
            snapshot = self.lab_states.get(key)
            said = worth(key, snapshot, self.mode)
            study = snapshot["study"] if snapshot else Study()
            track = states(study)
            picture = cover.picture(key, designs=self.mode == TEACHER)
            marks = [{"kind": mark.kind, "role": mark.role, "color": ROLE_COLORS[mark.role], "width": ROLE_WIDTHS[mark.role],
                      "dashed": mark.dashed, "hollow": mark.hollow, "points": [[round(x, 4), round(y, 4)] for x, y in mark.points]}
                     for mark in picture.marks]
            count = stars.get(key, 0)
            cards.append({"key": key, "number": bench.label.zfill(2), "digit": str(place), "title": bench.title,
                          "challenge": get_text(f"bench.{key}.challenge"), "stars": count,
                          "stars_text": get_text("stars.count", count=count, most=MOST) if count else "",
                          "locked": key in locks,
                          "lock_tip": get_text("cover.locked_tip", bench=BENCHES[locks[key]].title) if key in locks else "",
                          "open_tip": get_text("cover.open_tip", key=place),
                          "track": [{"state": state, "name": name, "worth": list(said[i]) if i < len(said) and said[i] else None,
                                     "tip": get_text(f"cover.track.{state}", name=name)}
                                    for i, (state, name) in enumerate(zip(track, short, strict=True))],
                          "picture": {"window": list(picture.window), "marks": marks}})
        return {"title": get_text("cover.title"), "purpose": get_text("cover.purpose"), "lead": get_text("cover.lead"),
                "mode_label": get_text("mode.label"), "modes": [{"key": m, "name": get_text(f"mode.name.{m}")} for m in (STUDENT, TEACHER)],
                "mode_line": get_text(f"mode.line.{self.mode}"), "restart": self.mode == STUDENT and bool(stars),
                "restart_texts": {k: get_text(f"restart.{k}") for k in ("command", "tip", "title", "text", "confirm", "cancel")},
                "cards": cards, "last": self.bench}

    def bench_view(self) -> dict:
        page = self.page
        found, said = page.states(), page.summaries()
        step = page.current()
        stars = self.stars[self.mode].get(self.bench, 0)
        pills = [{"state": state, "name": get_text(f"step.{key}.title"), "short": get_text(f"step.{key}.short"),
                  "tip": step_tip(index, state, worth_of)}
                 for index, (key, state, worth_of) in enumerate(zip(STEPS, found, said, strict=True))]
        bench = BENCHES[self.bench]
        return {"key": self.bench, "name": f"{bench.label}  {bench.title}", "stars": stars,
                "stars_text": get_text("stars.count", count=stars, most=MOST) if stars else "", "pills": pills,
                "step": page.study.step, "step_key": page.step_key(), "lab": step.view(),
                "code": {"open": self.code_open, "reading": reading_key(page.step_key(), step.state)}}

    def view(self) -> dict:
        view = {"version": __version__, "language": i18n.current_language(), "languages": [[k, v] for k, v in LANGUAGES.items()],
                "mode": self.mode, "screen": "cover" if self.on_cover or self.page is None else "bench", "cues": list(self.cues),
                "persist": self.persist(), "most": MOST,
                "bar": {"home": get_text("cover.button"), "home_tip": get_text("cover.button_tip"), "steps": get_text("app.steps"),
                        "language": get_text("app.language"), "sound_on": get_text("app.sound_on"), "sound_off": get_text("app.sound_off"),
                        "app": get_text("cover.title")}}
        if view["screen"] == "cover":
            view["cover"] = self.cover_view()
        else:
            view["bench"] = self.bench_view()
        return view
