# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: bridge.py
# ==============================================================================
"""
The web version's Python side, without Qt: what the window (statistical_fundamentals/gui/) does with the laboratories,
played for a page in a browser. It runs in Pyodide, in a Web Worker (web/shell/worker.js), on the same package the
desktop window runs: the cores, explorers/, benches.py, cover.py, palette.py and i18n/. Nothing of gui/ is shipped (it
imports Qt): what the web needs of it is ported here in plain Python, behaviour for behaviour, and the names keep the
window's so that the two can be read side by side:

    Bridge      gui/main_window.MainWindow   the cover, the mode, the language, each mode's studies and benches passed
    Bench       gui/bench_view.BenchView     one bench: its three steps and the study that joins them, the game's judge
    Step        gui/lab_views.LabView        one laboratory at work: its settings, the frames, the mouse, the figure
    Holder      gui/blocks.BlockCard         one block of a step's column: its own figure, drawn by the laboratory

The page asks by one call, Bridge.handle(request), a request being plain JSON: {"op": ..., "size": ..., ...}. The
answer is (text, pixels, meta, blocks): the view as JSON text (what the column, the bar and the cover show, every text in
the language on screen, every number computed by the laboratories), the figure as raw RGBA pixels (or None when the
picture on the page is still the right one), the pixels' geometry as JSON text, and the pixels of the step's blocks
whose picture changed, a list of (key, RGBA pixels). The figure is drawn by the laboratory itself (Lab.draw) on a
matplotlib Figure with an Agg canvas, at the size the page gives it in CSS pixels times the device's pixel ratio: the
figure's dpi is 100 times that ratio, so explorers/lab.size measures it in CSS pixels, the layout pixels of the labs,
and the fonts keep their size on a dense screen (the gotcha of the desktop's dpi).

Two arrangements. The DESKTOP's workbench is COLUMNED as the window is (Lab.columned, Lab.hero): the step's own panel
stands in the column as its blocks (Lab.blocks; each a Holder: a Figure and an Agg canvas per block key per step, drawn
by Lab.draw_block only when the lab says it changed or its size did), the figure's right column is one card, a beam
takes its band over the figure where it has the room, and there is no strip and no measure beside the figure. A size
with a height and no `fit` is the desktop's (size "columned" says it outright when given). A PHONE (in portrait or in
landscape: a size with `fit`, or with no height) is not columned and keeps its three panels: the figure is laid out by
the labs' own narrow plan (explorers/panels.arrangement, the stack) and the rows of one panel are cut out of it (crops).
It gives the room of the figure's box (size "fit"), and the design space is drawn at the widest stack whose rows of it
fit (fitted_widths), the 3D view and the third panel as wide as the box, scrolled in it when taller (SCROLLED, meta
"scrolls": the labs' narrow layout makes them taller than wide, and a fit to the height would halve their text): panels
of one width are crops of one drawing, a switch to a panel of another width is one render, and the box (meta "box")
holds any of them, so it keeps one size. In landscape the page also says how wide a column of the measures at the
figure's side would be and how high their line under it ("aside", "below"), and the bridge says which leaves the panels
larger (meta "beside").

What the column shows is said as the window draws it (LabView): each option of a control of buttons with its icon
(Control.icons, by value), a command's mark (Action.mark), a command that stands in the row of a typed control
(Action.beside: sent inside that control's item, not among the chips), a command that names controls among its places
(Action.beside "order radius theta": a copy on the label's line of the last of them shown, the control's `on_line`, the
chip's `placed`), the strong measure (Metric.strong), the card of what the step works on with each row's kind and tip
and the bench's problem for the slot's room (bench "slot": gui/lab_views.CardSlot), and what the window draws in the
view's band over the figure, not in the column (a bench of more than two inputs: the controls of explorers/section.KEYS
and the chip section.CHIP, each item's "band" true; every slider of such a bench read on release, "tracking" false and
the texts of its values for the drag). The view's truth (CARRIED: the pair on the axes, the slice held) goes with the
reader from a step to the next and is kept in the bench's snapshot and through Restore, as the 3D angle is
(Step.section, carry: never a change of the study); so is "Show f" (Lab.revealed: offered on a simulation to a teacher,
to a student once the bench is passed; the chip's box in the figure's plan, Plan.reveal).

The pointer: the page sends a press, a move, a release in CSS pixels of the whole figure; they become matplotlib mouse
events on the canvas (device pixels from the bottom, as the Qt canvas gives them), processed by the canvas's callbacks
(the 3D view turns itself, as on the desktop) and given to the lab as LabView's on_press, on_move, on_release and
on_leave do: its hit, grab and drag, and on a bench drawn the place under the pointer (Lab.point, Lab.pointer), the
ranges of the beam's band (Lab.ranged, a press there a Drawn: Lab.aim, Lab.holds, Lab.slid) and the cross-beam pointed at
(live.Pointing.pointed_beam, lit_beam). A move that changes only the place paints the lab's live layer (explorers/
live.Layer, on the Agg canvas: its restore_region and the artists drawn into the renderer's buffer, which is the buffer
sent; Agg's blit is a no-op) and never draws the figure whole. A drag tells the lab it is under way (Lab.dragging), and
its release gives a bench of more than two inputs its view's truth back (adjust of HELD). A touch has no hover: a tap
shows what lies under it (the design ringed) until the next tap. The mouse over a block is what the lab finds there
(Lab.hit_block: the design under the mouse of the whole view), a press there what it does (Lab.press_block), and a
table longer than its block scrolls (Lab.scrolled, Lab.scroll_to).

The game is the window's: a step opens on what it was handed (Lab.opening), the cost of a study is its N and every
distinct x* validated on that experiment (Bench.paid, given to the labs as Lab.paid from Lab.charges, kept in the
bench's snapshot through Restore, a language and a visit). A bench is passed or not (no stars): the last step's
verdict (Lab.finished: None, True or False) is its status line, "✗ Bench not complete" for a validated result on
screen that does not complete it (even on a bench passed before), else "✓ Bench complete" once passed, the badges
sticky (gui/bench_view.verdict_line); the line's tooltip is what the lab says the study lacks (Lab.hint, status_tip),
and the filled button that cannot be pressed says why in its tooltip alone (Lab.missing): no grey line. While the
validated result on screen completes a bench passed, the foot's filled command is the bench's ("Next bench →", or "Back
to the cover" on the last: Bench.onward_text, the view's `next`, op "onward"), the lab's own outlined above it. The
cover keeps the worth of the study that first passed it (Bench.best), and on the first pass every step is shown again
(what a student's lab hid opens); a validation's cue is said as the verdict ("passed", "missed"; none for the first
pass, "achieved" says it), and the cover a student's pass opened a bench to is heard as "unlock". The page shows the
four benches of benches.BENCHES. A step that leaves the screen stops its frames, forgets the pointer and says no cue
until it is back (leave, away); the forward command stops the frames first and hands the result read after that. A
press or a drag that changed the settings asks for the cue "drag" once, on release; a key that changed them, for the
cue of that key ("enter" and "space" place a point of a free sample).

The frames of a construction are played by the page's clock: while a motion plays, the view says how long the frame
stays and carries a token; the page asks for the next frame with it, and any other request stops the motion first (the
token then no longer matches). What the desktop keeps in QSettings (the language, the mode, the benches the student
passed) is given back to the page as `persist`, which keeps it in localStorage and gives it back at the next start
(boot; an older page's count of stars above 0 reads as passed).
"""
import io
import json
import math
import traceback
from dataclasses import dataclass

import numpy as np
from matplotlib.backend_bases import MouseButton, MouseEvent
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure

from statistical_fundamentals import __version__, cover, i18n, palette
from statistical_fundamentals.benches import BENCHES, STEPS
from statistical_fundamentals.explorers import lab_for, live, responses
from statistical_fundamentals.explorers.base import minus
from statistical_fundamentals.explorers.game import MODES, STUDENT, TEACHER
from statistical_fundamentals.explorers.lab import TRANSPORT, Action, Lab
from statistical_fundamentals.explorers.panels import BELOW, BLOCK_TONE, STACK_WIDTH, arrangement
from statistical_fundamentals.explorers.responses import has_formula
from statistical_fundamentals.explorers.section import CARRIED, CHIP, HELD
from statistical_fundamentals.explorers.section import KEYS as VIEW_KEYS
from statistical_fundamentals.explorers.study import CURRENT, DONE, LOCKED, Study, advanced, changed, enabled, shown, states
from statistical_fundamentals.functions import RESPONSES, many
from statistical_fundamentals.i18n import LANGUAGES, get_text

FIRST_MODE = STUDENT            # the mode of the first run, the desktop's (gui/main_window.FIRST_MODE): the game is the product
LAST = len(STEPS) - 1           # the step whose state completes the bench (Lab.finished)
PASSED_MARK, FAILED_MARK = "✓", "✗"   # the verdict's marks before its words (gui/bench_view: never colour alone)
VALIDATION = frozenset({"better", "worse", "passed", "missed"})     # a lab's cues of a validation (gui/bench_view.VALIDATION)
LAYOUT_DPI = 100                # explorers/lab.LAYOUT_DPI: a figure's dpi is this times the device's pixel ratio
LEAST_WIDTH = 120               # CSS pixels: the narrowest figure drawn
MOST_RATIO = 2.0                # the device's pixel ratio is taken up to this (a phone at 3 draws at 2)
PANELS = ("plane", "space", "third")            # the panels of a stacked figure, from its top: what a phone shows one at a time
FIT_STEP = 8                    # CSS pixels: the coarse step of fitted_widths' walk down from the widest figure
FIT_LEAST = 241                 # CSS pixels: a phone's panel is never drawn narrower (shown scaled down instead): the labs'
                                # narrow layout (explorers/panels.NARROW) holds every text whole from this width up
SCROLLED = ("space", "third")   # a phone's panels drawn as wide as the box and scrolled in it when taller (the plane is
                                # fitted to the box's height instead: a tap there places a point, never scrolls)
WHOLE = ("corner", "row")       # the labs' arrangements that show the three panels at once (a phone may take them: fitting)
CARD_ROWS = 4                   # the most rows a received card of a bench of one response holds (gui/lab_views.CARD_ROWS)
BLOCK_WIDTH = 248               # CSS pixels: a block's figure in the column (gui/blocks.CONTENT_WIDTH: 272 - 2 x 12)
ROLE_COLORS = {cover.REFERENCE: palette.SLATE, cover.ANSWER: palette.BLUE, cover.SECOND: palette.GOLD,
               cover.GUIDE: palette.DARK_GREY, cover.AXIS: palette.GREY}            # gui/cover.ROLE_COLORS
ROLE_WIDTHS = {cover.REFERENCE: 2.8, cover.ANSWER: 2.4, cover.SECOND: 2.2, cover.GUIDE: 1.0, cover.AXIS: 1.2}

def verdict_line(passed: bool, opened: str = "") -> str:
    """What the last step's status line says of the verdict (gui/bench_view.verdict_line)."""
    if not passed:
        return f"{FAILED_MARK} {get_text('bench.failed')}"
    text = get_text("bench.passed_opened", bench=opened) if opened else get_text("bench.passed")
    return f"{PASSED_MARK} {text}"

def whole_inches(pixels: float, dpi: float) -> float:
    """A length in inches that gives back at least `pixels` at `dpi` (gui/widgets.whole_inches): 820 pixels at 100 dpi
    are 8.2 inches, and 8.2 x 100 is 819.99..., which matplotlib truncates to 819."""
    inches = pixels / dpi
    while inches * dpi < pixels:
        inches = math.nextafter(inches, math.inf)
    return inches

def density(ratio) -> float:
    """The device's pixel ratio a figure is drawn at: the page's, from 1 up to MOST_RATIO."""
    return min(max(float(ratio), 1.0), MOST_RATIO)

def set_size(figure: Figure, width: int, height: int, ratio: float) -> None:
    """A figure of `width` x `height` CSS pixels at `ratio` device pixels per CSS pixel: its dpi LAYOUT_DPI times the
    ratio, its size in whole device pixels (whole_inches)."""
    dpi = LAYOUT_DPI * ratio
    figure.set_dpi(dpi)
    figure.set_size_inches(whole_inches(round(width * ratio), dpi), whole_inches(round(height * ratio), dpi), forward=False)

def mouse_event(canvas, name: str, x: float, y: float, button=None) -> MouseEvent:
    """A matplotlib mouse event at CSS pixels (x, y) from the top left of the canvas's figure: device pixels from its
    bottom, as the Qt canvas gives them."""
    ratio = canvas.figure.dpi / LAYOUT_DPI
    return MouseEvent(name, canvas, x * ratio, canvas.figure.bbox.height - y * ratio, button=button)

def position(control, value) -> int:
    """The index of a value among a control's values, or of the nearest one (gui/lab_views.position)."""
    if value in control.values:
        return control.values.index(value)
    return min(range(len(control.values)), key=lambda i: abs(control.values[i] - value))

def problem_of(function: str) -> tuple:
    """The rows of a bench's problem (its first step's card, explorers/doe.SamplingLab.problem), which the card's slot
    keeps room for in the bench's three steps (gui/lab_views.problem_of); () for a lab of no bench."""
    if function not in RESPONSES:
        return ()
    return lab_for("doe", function).problem()

def card_rows(function: str) -> int:
    """The most rows a received card of a bench's later steps holds (gui/lab_views.card_rows): CARD_ROWS, one more on a
    bench of several responses; five for a lab of no bench."""
    if function not in RESPONSES:
        return CARD_ROWS + 1
    return CARD_ROWS + (1 if many(function) else 0)

def sliders_on_release(lab: Lab) -> bool:
    """A lab of a bench of more than two inputs: its sliders are read once released (gui/lab_views.many), their text
    following the drag."""
    return lab.function in RESPONSES and RESPONSES[lab.function].d > 2

def step_tip(step: int, state: str, worth: tuple | None = None) -> str:
    """What a pill says of its step: its number and name, its state, why it is locked, and what it is worth
    (gui/main_window.step_tip)."""
    key = STEPS[step]
    name = get_text(f"step.{key}.title")
    if state == LOCKED:
        return get_text(f"step.tip.locked.{key}", number=step + 1, name=name)
    kind = "current" if state == CURRENT else "done" if state == DONE else "open"
    tip = get_text(f"step.tip.{kind}", number=step + 1, name=name)
    return f"{tip}\n{worth[0]}" if worth else tip

def stored_passed(value) -> bool:
    """Whether the page kept a bench as passed: true, or an older page's count of stars above 0
    (gui/main_window.stored_passed)."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().lower() in ("true", "false"):
        return value.strip().lower() == "true"
    try:
        return int(value) > 0
    except (TypeError, ValueError):
        return False

def worth_said(study: Study, step: int) -> bool:
    """Whether what a step is worth is said (gui/bench_view.worth_said): its result was handed on, or, for the last
    step, the input it works on is still the one handed."""
    return study.handed[min(step, len(STEPS) - 2)] is not None

def worth(bench: str, snapshot: dict | None, mode: str = TEACHER, passed: bool = False) -> tuple:
    """What each step of a bench's study is worth, from its snapshot, said again in the language on screen when it was
    said in another one (gui/bench_view.worth), by labs that show f as the bench showed it ("Show f": revealed, where it
    is offered, a student's once `passed`)."""
    if not snapshot:
        return ()
    language, said = snapshot.get("worth", ("", ()))
    if language == i18n.current_language():
        return said
    study, labs, found = snapshot["study"], snapshot.get("labs", {}), []
    for step, key in enumerate(STEPS):
        if key not in labs or not worth_said(study, step):
            found.append(None)
            continue
        if step == LAST and snapshot.get("best") is not None:     # what the completing study was worth
            found.append(snapshot["best"])
            continue
        lab = lab_for(key, bench, mode)
        lab.paid = snapshot.get("paid", {})
        lab.won = bool(passed)
        lab.revealed = bool(snapshot.get("revealed")) and (mode == TEACHER or bool(passed))
        try:
            text, kind = lab.summary(lab.state(labs[key]["settings"]))
        except (ArithmeticError, ValueError):
            text, kind = "", "plain"
        found.append((text, kind) if text else None)
    return tuple(found)

def reading_key(step: str, state) -> str:
    """The reading of the code panel for what the step shows (gui/lab_code.reading_for): the sampling or the method
    on screen, or the metamodel; "" when there is none."""
    if state is None:
        return ""
    if step in ("doe", "optimization"):
        return state.method
    return state.model if step == "metamodel" else ""

def crops(width: float, height: float, drawing: float | None = None) -> dict | None:
    """The rows of each panel of a stacked figure (explorers/panels.stack), in CSS pixels from its top: the design space
    with its tick labels, the formula and the 3D view, the third panel with its head; None when the figure is not
    stacked (it is shown whole). `drawing`: the lab's caption block (Lab.drawing, explorers/caption.py: the beam's
    drawing is taller than a formula), so that the rows are those of the plan the lab drew. A phone's figure only: the
    columned desktop's is never cut."""
    plan = arrangement(width, height, pair="space", fill=True, drawing=drawing, hero=False)     # a phone: no band
    if plan.kind != "stack":
        return None
    first = height - (plan.plane[1] - BELOW)                  # under the design space's tick labels: the 3D view's card
    second = height - plan.heads["check"][1]                    # the top of the third panel's head
    bounds = (0.0, first, second, height)
    return {name: (round(bounds[i]), round(bounds[i + 1])) for i, name in enumerate(PANELS)}

def panel_heights(height_for, width: int, drawing: float | None = None) -> dict:
    """The height of each panel of the stack `width` CSS pixels wide and as tall as it needs (`height_for`, the lab's),
    in CSS pixels: the rows crops cuts out of it (`drawing`: the lab's, crops')."""
    cut = crops(width, height_for(width), drawing)
    return {name: bottom - top for name, (top, bottom) in cut.items()}

def fitted_widths(height_for, width: float, fit: float, drawing: float | None = None) -> dict:
    """For each panel, the widest stack, at most `width` CSS pixels (and narrower than STACK_WIDTH, where the panels
    stop being stacked), whose rows of that panel are at most `fit` high: a phone gives the room of its figure's box and
    each panel is drawn as large as IT fits there, with no render to try. The heights grow with the width but not
    everywhere (the 3D view loses its formula's second line where one line has room, and the squares stop at
    STACK_SIDE), so the search walks down from the widest by FIT_STEP until every panel fits, then takes the widest pixel
    of the step above each one that fits. It stops at FIT_LEAST (or the width given, if narrower): narrower, a panel's
    titles and ticks no longer fit its own drawing, so a panel too tall there is drawn FIT_LEAST wide and the page shows
    it whole, scaled down to the box (fitted_box). `drawing`: the lab's (crops)."""
    most = max(min(int(round(width)), STACK_WIDTH - 1), LEAST_WIDTH)
    least = min(FIT_LEAST, most)
    heights = {}

    def high(wide: int) -> dict:
        if wide not in heights:
            heights[wide] = panel_heights(height_for, wide, drawing)
        return heights[wide]
    found, wide = {}, most
    while len(found) < len(PANELS):
        found |= {name: wide for name, tall in high(wide).items() if name not in found and tall <= fit}
        if wide == least:
            break
        wide = max(wide - FIT_STEP, least)
    widths = {}
    for name in PANELS:
        fits = found.get(name, least)
        if name in found:
            fits = next((up for up in range(min(fits + FIT_STEP - 1, most), fits, -1) if high(up)[name] <= fit), fits)
        widths[name] = fits
    return widths

def fitted_box(height_for, widths: dict, fit: float, drawing: float | None = None) -> tuple[int, int]:
    """The figure's box of a phone, the same whichever panel it shows: as wide as the widest panel and as tall as the
    tallest, each at its own width (fitted_widths), and never taller than `fit` (a panel taller than that is shown
    scaled down to it; `drawing`: the lab's, crops')."""
    tallest = max(panel_heights(height_for, wide, drawing)[name] for name, wide in widths.items())
    return max(widths.values()), min(tallest, int(fit))

def columned_size(size: dict) -> bool:
    """Whether the page's size is the desktop's workbench, columned as the window (D1 of the web's alpha contract):
    `columned` when the page says it, else a size with a height and no `fit` (a phone gives `fit`, or no height)."""
    if "columned" in size:
        return bool(size["columned"])
    return size.get("height") is not None and not size.get("fit")

class Canvas(FigureCanvasAgg):
    """The Agg canvas of a step's figure. matplotlib's draw_idle draws at once on Agg (the 3D view calls it at every move
    of the mouse); here it only says the picture must be drawn again: the bridge draws once per request."""
    wanted = False

    def draw_idle(self, *args, **kwargs) -> None:
        self.wanted = True

@dataclass
class Drawn:
    """A press over a range of the beam's band (gui/lab_views.Drawn): the input whose range it is; whether the view
    holds that input (its slider then goes to the place on the press and at the release: `slid`); what the lab's grab
    took at that place of the design space (None: the step has no press there)."""
    k: int
    held: bool
    taken: object = None
    slid: bool = False

class Holder:
    """One block of a step's column (gui/blocks.BlockCard without the card): its own figure in the block's tone and
    its Agg canvas, the size and density it was drawn at, how many pictures it made, and whether the lab must be asked
    to draw it again (a scroll)."""

    def __init__(self):
        self.figure = Figure()
        self.figure.set_facecolor(BLOCK_TONE)
        self.canvas = FigureCanvasAgg(self.figure)
        self.drawn: tuple | None = None
        self.draws = 0
        self.wanted = True
        self.hit = None                                         # what the mouse is over in it (Lab.hit_block's last)

    def event(self, name: str, x: float, y: float, button=None) -> MouseEvent:
        """A matplotlib mouse event at CSS pixels (x, y) from the block's top left (mouse_event)."""
        return mouse_event(self.canvas, name, x, y, button)

# ------------------------------------------------------------------------------
# One laboratory at work (gui/lab_views.LabView, without the widgets)
# ------------------------------------------------------------------------------
class Step:
    """A laboratory of a step: its settings and what it received, its state, the frames that play, the pointer on its
    figure, and the figure itself (one per step, as each LabView has its canvas: the labs reuse their axes), with its
    blocks' figures when it is columned."""

    def __init__(self, bridge: "Bridge", lab: Lab, snapshot: dict | None = None, handed=None, title: str = "", purpose: str = "",
                 carried: dict | None = None):
        self.bridge = bridge
        self.lab = lab
        self.title, self.purpose = title, purpose
        if snapshot:
            self.settings = dict(snapshot["settings"])
            self.handed = snapshot.get("handed")                # what the step before handed (Lab.receive), or None
            if handed is not None and handed != self.handed:
                self.handed = handed
                self.settings = lab.receive(dict(self.settings), handed)
        else:                                                   # the first settings on what was handed (Lab.opening)
            self.handed = handed
            self.settings = lab.opening(handed)
        if carried:                                             # the view of the step left (a bench of four inputs)
            self.settings = self.carried(self.settings, carried)
        self.away = False                                       # off screen since it was shown: no frame, no cue
        self.dragged = False                                    # the press under way changed the settings (a cue on release)
        self.ranging = False                                    # the pointer over a range of the beam's band (its cursor)
        self.on_cue = None                                      # the bench's: a cue of this lab (LabView.cue)
        self.on_reveal = None                                   # the bench's: "Show f" turned on or off (LabView.revealing)
        self.filled = next((action for action in lab.actions if action.forward or action.primary), None)
        self.worth: tuple[str, str] = ("", "plain")
        self.held: dict | None = None
        self.hovered = None
        self.handle = None
        self.state = None
        self.motion: str | None = None
        self.playing: str | None = None
        self.token = 0                                          # the frames' token: a new one at every start and halt
        self.status = ""
        self.status_kind = "warning"                            # the status line's colour: "warning" or "ok" (set_status)
        self.next: tuple[str, str] = ("", "")                   # the bench's command of a bench passed and its tip (set_next)
        self.alert = ("", False)
        self.on_change = None                                   # the bench's: a laboratory changed (LabView.changed)
        self.figure = Figure()
        self.canvas = Canvas(self.figure)
        if lab.drawing is not None:                             # a bench drawn: what follows the pointer is painted over
            lab.layer = live.Layer(self.canvas)                 # a kept background (explorers/live.py), into Agg's buffer
        self.stale = True                                       # the figure waits for a draw
        self.drawn = None                                       # the size and density it was drawn at
        self.draws = 0                                          # how many pictures it made: a new one is sent to the page
        self.pressed = False
        self.holders: dict[str, Holder] = {}                    # the blocks' figures, by key (gui/blocks.BlockStack.cards)
        self.blocks_wanted = True                               # every block drawn again (a full draw's turn)
        self.live_wanted = False                                # the live blocks drawn again (the pointer moved: trace)
        self.refresh()

    # ------------------------------------------------------------------ the controls
    def control(self, key: str):
        return next(c for c in self.lab.controls if c.key == key)

    def nearest(self, key: str, value):
        control = self.control(key)
        return control.values[position(control, value)]

    def changed(self) -> None:
        if self.on_change is not None:
            self.on_change()

    def choose(self, key: str, value) -> None:
        """A control moved to `value`: the settings follow (Lab.adjust), unless the value is the one they hold or one
        the lab keeps locked."""
        if self.settings.get(key) == value or self.lab.locked(key, value, self.settings):
            return
        self.halt()
        old = self.settings.get(key)
        self.settings = self.lab.adjust(dict(self.settings) | {key: value}, key, old)
        self.refresh()

    def set_value(self, key: str, value) -> None:
        """A quick pick: the field or the slider moves, and with it the settings."""
        control = self.control(key)
        target = value if control.typed else control.values[position(control, value)]
        if self.settings.get(key) == target:
            self.refresh()
        else:
            self.choose(key, target)

    def slider_top(self, control) -> int:
        top = self.lab.limit(control.key, self.settings)
        return len(control.values) - 1 if top is None else top

    def step(self, delta: int) -> bool:
        """The first slider on show one value further, never one of the view's (LabView.step); False when none is on
        show."""
        for control in self.lab.controls:
            if control.check or control.buttons or control.typed or control.key in VIEW_KEYS or not self.lab.shown(control, self.settings):
                continue
            index = position(control, self.settings[control.key])
            index = max(0, min(index + delta, self.slider_top(control)))
            self.choose(control.key, control.values[index])
            return True
        return False

    def reset(self) -> None:
        """Restore: the step's first settings, with what it received kept and the view on screen kept (LabView.reset);
        "apply" when it changed something."""
        self.halt()
        before = self.settings
        self.settings = self.carried(self.lab.opening(self.handed), self.section())   # no competition run for nothing
        self.refresh()
        if self.settings != before and not self.away:
            self.cue("apply")

    def receive(self, handed) -> None:
        """The result the step before handed, taken in (Lab.receive)."""
        self.halt()
        self.handed = handed
        self.settings = self.lab.receive(dict(self.settings), handed)
        self.refresh()

    def act(self, key: str) -> None:
        """A command of the lab (LabView.act): View code, a motion started, paused or hurried, or a plain command."""
        if self.state is None:
            return
        if self.lab.link(key, self.state):
            self.halt()
            self.bridge.code_open = True
            return
        motion = next((a.motion for a in self.lab.actions if a.key == key), "")
        if motion == "run" and self.motion == "run":
            self.halt()
            self.refresh()
        elif motion == "step" and self.motion is not None and not self.lab.at_rest(self.settings):
            self.halt()
            self.finish_step()
            self.say(key)
        elif motion:
            self.halt()
            settings = self.lab.rewind(key, self.state, dict(self.settings))
            if settings != self.settings:
                self.settings = settings
                self.state = self.lab.state(settings)
            self.play(motion, key)
        else:
            self.halt()
            self.settings = self.lab.act(key, self.state, dict(self.settings))
            self.refresh()
            self.say(key)

    def set_status(self, text: str, kind: str = "warning") -> None:
        """The status line over the filled button: a result discarded (warning) or the bench complete (ok)."""
        self.status, self.status_kind = text, kind

    def set_next(self, text: str, tip: str = "") -> None:
        """The bench's command of a bench passed (LabView.set_next): "Next bench →" or "Back to the cover", its tip; ""
        for none. Shown, it is the foot's filled command, the lab's own outlined above it."""
        self.next = (text, tip if text else "")

    def cue(self, cue: str) -> None:
        if self.on_cue is not None:
            self.on_cue(cue)
        else:
            self.bridge.cues.append(cue)

    def say(self, key: str) -> None:
        """The sound of the command `key` just carried out (Lab.cue); none from a view gone off screen (away)."""
        if self.state is not None and not self.away:
            cue = self.lab.cue(key, self.state)
            if cue:
                self.cue(cue)

    # ------------------------------------------------------------------ frames
    def play(self, motion: str, key: str = "") -> None:
        if motion == "step" and not self.bridge.motion_allowed:
            self.finish_step()
            self.say(key)
            return
        self.motion, self.playing = motion, key
        self.token += 1
        self.next_frame()

    def frame(self, token: int) -> None:
        """The page's clock asks for the next frame: only of the motion it was given (any change since stopped it)."""
        if self.motion is not None and token == self.token:
            self.next_frame()

    def next_frame(self) -> None:
        key = self.playing
        if not self.bridge.motion_allowed:
            self.finish_step()
            if self.lab.advance(self.state, self.settings) is None:
                self.halt()
                self.refresh()
                self.say(key)
            return
        settings = self.lab.advance(self.state, self.settings)
        if settings is None:
            self.halt()
            self.refresh()
            self.say(key)
            return
        self.settings = settings
        ended = self.motion == "step" and self.lab.at_rest(settings)
        if ended:
            self.halt()
        self.refresh()
        if ended:
            self.say(key)

    def finish_step(self) -> None:
        for _frame in range(64):
            settings = self.lab.advance(self.state, self.settings)
            if settings is None:
                break
            self.settings = settings
            self.state = self.lab.state(settings)
            if self.lab.at_rest(settings):
                break
        self.refresh()

    def halt(self) -> None:
        if self.motion is not None:
            self.token += 1
        self.motion, self.playing = None, None

    def stop(self) -> None:
        """The frames that play stopped where they are (LabView.stop): the view leaves the screen, or its result is
        about to be handed. Nothing when no frame plays."""
        if self.motion is None:
            return
        self.halt()
        self.refresh()

    def leave(self) -> None:
        """Off screen (another step, the cover: LabView.hideEvent): its frames stop where they are, it says no cue until
        it is back, and the pointer is forgotten (the place under it is the screen's: back on screen the figure is drawn
        without it)."""
        self.away = True
        self.stop()
        if self.lab.pointer is not None:
            self.stale = True
        self.lab.forget()
        self.ranging = False
        self.pressed = False
        self.handle = None
        self.lab.dragging = False                               # a press cut short: the automatic slice moves again

    # ------------------------------------------------------------------ state
    def snapshot(self) -> dict:
        return {"settings": dict(self.settings), "handed": self.handed}

    def output(self):
        return None if self.state is None else self.lab.output(self.state)

    def unlocked(self, settings: dict) -> dict:
        """The settings with no value the lab keeps locked (LabView.unlocked)."""
        for control in self.lab.controls:
            value = settings.get(control.key)
            if not control.buttons or value not in control.values or not self.lab.locked(control.key, value, settings):
                continue
            held = (self.held or {}).get(control.key)
            kept = next((other for other in (held, control.values[control.initial], *control.values)
                         if other in control.values and not self.lab.locked(control.key, other, settings)), value)
            settings = settings | {control.key: kept}
        return settings

    def refresh(self) -> None:
        """A new state for the settings (LabView.refresh): what the column, the blocks and the figure show; "Show f"
        never shown where it is not offered (show_reveal)."""
        self.settings = self.unlocked(self.settings)
        self.held = dict(self.settings)
        if not self.reveal_offered() and self.lab.revealed:     # a student's lab never shows f before the bench is won
            self.lab.revealed = False
        try:
            self.state = self.lab.state(self.settings)
        except (ArithmeticError, ValueError) as error:
            self.state = None
            self.worth = ("", "plain")
            self.alert = (get_text("explorer.cannot", error=error), True)
            self.changed()
            return
        self.hovered = None
        for holder in self.holders.values():                    # what a block's mouse is over is said again at its move
            holder.hit = None
        alert = self.lab.alert(self.state)
        self.alert = (alert or self.lab.notice(self.state), bool(alert))
        self.worth = self.lab.summary(self.state)
        self.stale = True
        self.blocks_wanted = True
        self.changed()

    # ------------------------------------------------------------------ the arrangement (columned: the desktop's)
    def set_columned(self, columned: bool) -> None:
        """The arrangement the page shows the step in: columned (the desktop's workbench, the window's: the blocks in
        the column, the band over the figure, hero) or not (a phone's three panels). A change draws it again."""
        columned = bool(columned)
        if self.lab.columned == columned and self.lab.hero == columned:
            return
        self.lab.columned, self.lab.hero = columned, columned
        self.stale = True
        self.blocks_wanted = True

    # ------------------------------------------------------------------ "Show f" (the owner's 2B), a view
    def reveal_offered(self) -> bool:
        """Whether "Show f" is offered (LabView.reveal_offered): on a bench whose response is a simulation, to a teacher
        always, to a student once the bench is passed (Lab.won)."""
        lab = self.lab
        return lab.function in RESPONSES and not has_formula(lab.function) and (lab.mode == TEACHER or lab.won)

    def reveal_box(self) -> list | None:
        """The box the figure's plan keeps for the chip "Show f" (Plan.reveal), as [x, y from the top, width, height] in
        CSS pixels of the figure; None where the plan keeps none (a phone's plans never do) or nothing is drawn yet."""
        box = getattr(getattr(self.lab, "plan", None), "reveal", None)
        if box is None or self.drawn is None:
            return None
        left, bottom, wide, tall = box
        return [round(left, 1), round(self.drawn[1] - bottom - tall, 1), round(wide, 1), round(tall, 1)]

    def reveal(self, on: bool) -> None:
        """f shown or hidden (Lab.revealed), where "Show f" is offered: the step drawn again with it, never a change of the
        study (nothing said to the bench, no cue: LabView.reveal)."""
        on = bool(on) and self.reveal_offered()
        if on == self.lab.revealed:
            return
        self.lab.revealed = on
        told, self.on_change = self.on_change, None
        try:
            self.refresh()
        finally:
            self.on_change = told

    def reveal_clicked(self, on: bool) -> None:
        """The chip turned by the reader (LabView.reveal_clicked): shown here, then given to the bench."""
        self.reveal(on)
        if self.on_reveal is not None:
            self.on_reveal(self.lab.revealed)

    # ------------------------------------------------------------------ the view of a bench of more than two inputs
    def section(self) -> dict:
        """The view's truth (CARRIED: the pair, `held`) as the reader left them, carried as the angle (LabView.section)."""
        return {key: self.settings[key] for key in CARRIED if key in self.settings}

    def carried(self, settings: dict, view: dict | None) -> dict:
        """`settings` with the view's keys of `view` they hold, the lab told as of a change of HELD (LabView.carried)."""
        found = {key: view[key] for key in CARRIED if view and key in view and key in settings}
        if all(settings[key] == value for key, value in found.items()):
            return settings
        return self.lab.adjust(dict(settings) | found, HELD, settings.get(HELD))

    def carry(self, view: dict | None) -> None:
        """The view of the step left, taken and shown; never a change of the study: the bench is not told (nothing
        discarded, nothing judged) and no cue is asked (LabView.carry)."""
        settings = self.carried(self.settings, view)
        if settings == self.settings:
            return
        self.settings = settings
        told, self.on_change = self.on_change, None
        try:
            self.refresh()
        finally:
            self.on_change = told

    # ------------------------------------------------------------------ the 3D view's angle
    def axes_3d(self) -> list:
        return [ax for ax in self.figure.axes if ax.name == "3d"]

    def angle(self) -> tuple[float, float]:
        axes = self.axes_3d()
        return (float(axes[0].elev), float(axes[0].azim)) if axes else tuple(self.lab.view)

    def turn(self, angle) -> None:
        angle = tuple(float(a) for a in angle)
        if angle == self.angle():
            return
        self.lab.view = angle
        axes = self.axes_3d()
        for ax in axes:
            ax.view_init(*angle)
        if axes:
            self.canvas.wanted = True

    # ------------------------------------------------------------------ the pointer and the keys (LabView's)
    def event(self, name: str, x: float, y: float, button=None) -> MouseEvent:
        """A matplotlib mouse event at CSS pixels (x, y) from the figure's top left (mouse_event)."""
        return mouse_event(self.canvas, name, x, y, button)

    def set_hovered(self, hovered) -> None:
        if hovered != self.hovered:
            self.hovered = hovered
            self.stale = True
            self.blocks_wanted = True

    def pointer(self, kind: str, x: float, y: float, touch: bool) -> None:
        """A press, a move, a release or the pointer leaving the figure (LabView.on_press, on_move, on_release,
        on_leave), the 3D view turned by matplotlib itself. A touch has no hover; a pressed move that holds nothing (the
        3D view turning) looks for nothing under the pointer."""
        if self.drawn is None:
            return
        if kind == "leave":
            if not self.pressed:
                self.on_leave()
            return
        if kind == "down":
            event = self.event("button_press_event", x, y, MouseButton.LEFT)
            self.pressed = True
            if self.state is not None and touch:
                self.set_hovered(self.lab.hit(self.figure, self.state, event))
            self.canvas.callbacks.process(event.name, event)
            self.on_press(event)
        elif kind == "move":
            event = self.event("motion_notify_event", x, y, MouseButton.LEFT if self.pressed else None)
            self.canvas.callbacks.process(event.name, event)
            self.on_move(event, hover=not touch and not self.pressed)
        elif kind == "up":
            event = self.event("button_release_event", x, y, MouseButton.LEFT)
            self.canvas.callbacks.process(event.name, event)
            self.pressed = False
            self.on_release(event)

    def on_press(self, event) -> None:
        """A press on the figure (LabView.on_press): what the lab's grab takes, else, over a range of the beam's band,
        that range (a Drawn); the lab told a drag is under way (Lab.dragging) when what it took would recompute; the
        first move then follows at once."""
        if self.state is None or event.inaxes is None:
            return
        self.handle = self.lab.grab(self.figure, self.state, event)
        if self.handle is None:
            self.handle = self.drawn_handle(event)
        self.dragged = False
        drawn = isinstance(self.handle, Drawn)
        self.lab.dragging = self.handle is not None and (not drawn or self.handle.taken is not None)
        if self.handle is not None:
            self.on_move(event, hover=False)

    def on_move(self, event, hover: bool = True) -> None:
        """The pointer moved (LabView.on_move): what a press holds dragged (along a range of the band, drag_drawing);
        otherwise, `hover`, what is under the pointer (Lab.hit: drawn whole when it changes) and, on a bench drawn, the
        place under it (Lab.point), the live layer alone painted when only the place moved (trace); a place of the band
        that lands on a design (Lab.landed) is that design hovered."""
        if self.state is None:
            return
        lab, figure = self.lab, self.figure
        if self.handle is not None:
            if event.inaxes is None:
                return
            if isinstance(self.handle, Drawn):
                self.drag_drawing(event)
                return
            lab.pointer = lab.point(figure, self.state, event, self.handle, ranges=False)
            settings = lab.drag(figure, self.state, self.handle, event, dict(self.settings))
            if settings is not None:
                self.dragged = self.dragged or settings != self.settings
                self.halt()
                self.settings = settings
                self.refresh()
                self.hovered = self.handle
            else:
                self.trace()
            return
        if not hover:
            return
        hovered = lab.hit(figure, self.state, event)
        k = lab.ranged(figure, event)                           # the range of the band under the pointer, once
        beam = getattr(lab, "pointed_beam", None)               # the cross-beam under the pointer, before
        lit = getattr(lab, "lit_beam", None)                    # and the one the band lights, before
        pointer = lab.point(figure, self.state, event, hovered, k, ranges=False)
        landed = lab.landed(figure, self.state, pointer, k)
        if landed is not None:                                  # the band commands a design's place: that design
            hovered, pointer = landed, None
        moved = (pointer != lab.pointer or getattr(lab, "pointed_beam", None) != beam
                 or getattr(lab, "lit_beam", None) != lit)
        lab.pointer = pointer
        self.ranging = k is not None and (lab.holds(self.state, k) or lab.takes(self.state))
        if hovered != self.hovered:
            self.set_hovered(hovered)
            return
        if moved:
            self.trace()

    def on_leave(self) -> None:
        """The pointer left the figure (LabView.on_leave): nothing under it and no place."""
        lab = self.lab
        placed = lab.pointer is not None or getattr(lab, "pointed_beam", None) is not None or getattr(lab, "lit_beam", None) is not None
        lab.forget()
        self.ranging = False
        if self.hovered is not None:
            self.set_hovered(None)
            return
        if placed:
            self.trace()

    def trace(self) -> None:
        """What follows the pointer, painted without drawing the figure (LabView.trace): the live blocks asked again,
        and the live layer for the place under the pointer (Lab.follow, then Layer.update into Agg's buffer: a new
        picture for the page); a figure that waits for its draw takes the place with it, and a layer with no background
        at this size asks for the draw."""
        if self.state is None or self.stale:
            return
        self.live_wanted = True
        layer = self.lab.layer
        if layer is None:
            return
        self.lab.follow(self.figure, self.state, self.hovered)
        if layer.update():
            self.draws += 1
        else:
            self.stale = True

    def drawn_handle(self, event):
        """A press over a range of the beam's band (LabView.drawn_handle): a Drawn of its input, holding what the lab's
        grab takes at the place the press points at (Lab.aim), or, an input the view holds, nothing of the study; None
        off every range."""
        figure = self.figure
        k = self.lab.ranged(figure, event)
        if k is None:
            return None
        if self.lab.holds(self.state, k):
            return Drawn(k, True)
        place = self.lab.point(figure, self.state, event, None, k)
        spot = None if place is None else self.lab.aim(figure, self.state, place)
        return Drawn(k, False, None if spot is None else self.lab.grab(figure, self.state, spot))

    def drag_drawing(self, event) -> None:
        """The pointer along the range a press took (LabView.drag_drawing): an input the view holds, its slider there on
        the press (slide), the layer alone following the drag; otherwise what the press took dragged there as on the
        design space (Lab.drag at Lab.aim's event), the place alone followed where the step drags nothing."""
        handle, figure = self.handle, self.figure
        place = self.lab.point(figure, self.state, event, None, handle.k)
        if place is None:
            return
        self.lab.pointer = place
        if handle.held:
            if handle.slid:
                self.trace()
            else:
                handle.slid = True
                self.slide(handle.k, place)
            return
        spot = None if handle.taken is None else self.lab.aim(figure, self.state, place)
        settings = None if spot is None else self.lab.drag(figure, self.state, handle.taken, spot, dict(self.settings))
        if settings is None:
            self.trace()
            return
        self.dragged = self.dragged or settings != self.settings
        self.halt()
        self.settings = settings
        self.refresh()
        self.hovered = handle.taken
        if live.designed(handle.taken):                         # a point placed or moved: the design is in focus
            self.lab.pointer = None

    def slide(self, k: int, place) -> None:
        """The view's slider of the input k at the place's value (Lab.slid): the view only, when it is not there."""
        key, value = self.lab.slid(place, k)
        if self.settings.get(key) != value:
            self.choose(key, value)

    def on_release(self, _event=None) -> None:
        """The end of a press (LabView.on_release): a drag along the range of an input held ends with its slider there;
        the lab told the drag ended (Lab.dragging), and a bench of more than two inputs given its view's truth back (a
        change of HELD); a press or a drag that changed the settings asks once for its cue, "drag"."""
        handle = self.handle
        self.handle = None
        if isinstance(handle, Drawn) and handle.held and self.lab.pointer is not None:
            self.slide(handle.k, self.lab.pointer)
        if self.lab.dragging:
            self.lab.dragging = False
            if self.dragged and HELD in self.settings:
                self.settings = self.lab.adjust(dict(self.settings), HELD, self.settings[HELD])
                self.refresh()
        if self.dragged:
            self.dragged = False
            self.say("drag")

    def press(self, key: str) -> None:
        """An arrow key on the figure: the lab's (Lab.press), else the first slider."""
        settings = self.lab.press(key, self.state, dict(self.settings)) if self.state is not None else None
        if settings is not None:
            changed = settings != self.settings
            self.halt()
            self.settings = settings
            self.refresh()
            if changed:                                         # the key that did it names the cue (Lab.cue)
                self.say(key)
        elif key in ("left", "right"):
            self.step(1 if key == "right" else -1)

    def cursor(self) -> str:
        """The pointer's shape (LabView.show_cursor): the arrows across over a range of the band that commands, a hand
        for what can be dragged (closed while dragged), a pointing hand for what answers a click."""
        if self.ranging:
            return "ew-resize"
        if self.handle is not None and not isinstance(self.handle, Drawn) and self.lab.grabbable(self.hovered):
            return "grabbing"
        if self.lab.grabbable(self.hovered):
            return "grab"
        return "pointer" if self.lab.clickable(self.hovered) else ""

    # ------------------------------------------------------------------ the blocks (gui/blocks.BlockCard's mouse)
    def holder(self, key: str) -> Holder | None:
        holder = self.holders.get(key)
        return holder if holder is not None and holder.drawn is not None else None

    def block_pointer(self, key: str, kind: str, x: float, y: float) -> None:
        """The mouse over a block (BlockCard.on_move, on_leave): what the lab finds there (Lab.hit_block) is the view's
        design under the mouse (LabView.set_hovered), said when it changes."""
        holder = self.holder(key)
        if holder is None or self.state is None:
            return
        hit = None
        if kind != "leave":
            hit = self.lab.hit_block(key, holder.figure, self.state, holder.event("motion_notify_event", x, y))
        if hit != holder.hit:
            holder.hit = hit
            self.set_hovered(hit)

    def block_press(self, key: str, x: float, y: float) -> None:
        """A press on a block's figure (LabView.block_pressed): what the lab does with it (Lab.press_block: a click on
        the competition closes it), taken as any change of the settings."""
        holder = self.holder(key)
        if holder is None or self.state is None:
            return
        event = holder.event("button_press_event", x, y, MouseButton.LEFT)
        settings = self.lab.press_block(key, holder.figure, self.state, event, dict(self.settings))
        if settings is None or settings == self.settings:
            return
        self.halt()
        self.settings = settings
        self.refresh()

    def block_scroll(self, key: str, first: int) -> None:
        """The reader moved a block's scroll bar or turned the wheel over its table (BlockCard.scrolled): the lab's first
        row (Lab.scroll_to), the block drawn again from it."""
        holder = self.holders.get(key)
        if holder is None or not hasattr(self.lab, "scroll_to"):
            return
        self.lab.scroll_to(key, int(first))
        holder.wanted = True

    def shown_blocks(self) -> tuple:
        """The blocks of the state on screen (Lab.blocks), where the step is columned; () otherwise."""
        if not self.lab.columned or self.state is None:
            return ()
        return tuple(self.lab.blocks(self.state, BLOCK_WIDTH))

    def render_blocks(self, sizes: dict, ratio: float) -> dict:
        """Each block of the column drawn at the size the page gives it (CSS pixels, [width, height]; a block not given
        one: BLOCK_WIDTH wide, its most or its least high), by the lab (Lab.draw_block) and only when needed: a full draw's
        turn (a new state, the design under the mouse), the pointer moved for a live block, a scroll, a new size; the
        canvas drawn again only when the lab says something changed or the size did (BlockCard.draw). A block of the
        heading alone (most 0) has no figure. Returns {key: Holder} of the blocks with a figure."""
        found = {}
        ratio = density(ratio)
        for block in self.shown_blocks():
            if block.most == 0:
                continue
            given = sizes.get(block.key) if isinstance(sizes, dict) else None
            wide, tall = (given[0], given[1]) if given else (BLOCK_WIDTH, block.most if block.most else block.least)
            size = (max(int(round(wide)), 1), max(int(round(tall)), 1), ratio)
            holder = self.holders.get(block.key)
            if holder is None:
                holder = self.holders[block.key] = Holder()
            resized = size != holder.drawn
            if resized:
                set_size(holder.figure, size[0], size[1], ratio)
            if resized or holder.wanted or self.blocks_wanted or (block.live and self.live_wanted):
                changed = bool(self.lab.draw_block(block.key, holder.figure, self.state, self.hovered))
                if changed or resized:
                    holder.canvas.draw()
                    holder.draws += 1
            holder.drawn, holder.wanted = size, False
            found[block.key] = holder
        self.blocks_wanted = self.live_wanted = False
        return found

    def blocks_view(self) -> list:
        """The blocks as the column shows them (gui/blocks.BlockCard): heading, muted note, the heading's tip, the least
        and most height of the content (None: the column's room left; 0: the heading alone), whether it follows the
        pointer, and the scroll bar of a table longer than its block (Lab.scrolled, from its last draw)."""
        found = []
        scrolled = getattr(self.lab, "scrolled", None)
        for block in self.shown_blocks():
            said = scrolled(block.key) if scrolled is not None else None
            scroll = None if said is None else {"count": said.count, "rows": said.rows, "first": said.first,
                                                "top": round(float(said.top), 1), "height": round(float(said.height), 1)}
            found.append({"key": block.key, "title": block.title, "note": block.note, "tip": block.tip, "least": block.least,
                          "most": block.most, "live": block.live, "rows": block.rows, "scroll": scroll})
        return found

    # ------------------------------------------------------------------ the figure
    def render(self, width: float, height: float | None, ratio: float, panel: str | None) -> tuple:
        """The figure at `width` x `height` CSS pixels (None: as tall as the lab needs, a phone's stack), drawn by the
        lab when anything changed, at `ratio` device pixels per CSS pixel; the pixels of one panel when the figure is
        stacked (a phone) and a panel is asked for. (pixels, meta): pixels None while the state cannot be drawn."""
        wide = max(int(round(width)), LEAST_WIDTH)
        least = int(self.lab.height_for(wide))
        tall = least if height is None else max(int(round(height)), least)
        ratio = density(ratio)
        size = (wide, tall, ratio)
        if size != self.drawn:
            set_size(self.figure, wide, tall, ratio)
            self.stale = True
        if self.state is None:
            return None, {"width": wide, "height": tall}
        if self.stale or size != self.drawn:
            self.lab.draw(self.figure, self.state, self.hovered)
            self.canvas.draw()
            self.draws += 1
            self.blocks_wanted = True                           # drawn with the figure (LabView.redraw)
        elif self.canvas.wanted:
            self.canvas.draw()
            self.draws += 1
        self.stale, self.canvas.wanted, self.drawn = False, False, size
        pixels = np.asarray(self.canvas.buffer_rgba())
        cut = None if self.lab.columned else crops(wide, tall, self.lab.drawing)
        top, bottom = 0, tall
        if cut is not None and panel in cut:
            top, bottom = cut[panel]
            pixels = pixels[round(top * ratio):round(bottom * ratio)]
        meta = {"width": wide, "height": tall, "ratio": ratio, "top": top, "bottom": bottom, "pixel_width": int(pixels.shape[1]),
                "pixel_height": int(pixels.shape[0]), "panels": list(cut) if cut is not None else [], "draws": self.draws,
                "columned": bool(self.lab.columned)}
        return pixels, meta

    # ------------------------------------------------------------------ what the page shows
    def controls_view(self) -> list:
        """Each control as the column draws it (LabView.column_control, show_controls); a slider of a bench of more
        than two inputs read once released (tracking false), with the text of each of its values for the drag."""
        found = []
        released = sliders_on_release(self.lab)
        for control in self.lab.controls:
            value = self.settings.get(control.key, control.values[control.initial])
            item = {"key": control.key, "label": control.label, "tip": control.tip, "alone": control.alone,
                    "visible": bool(self.lab.shown(control, self.settings)), "band": control.key in VIEW_KEYS}
            if control.check:
                item |= {"kind": "check", "checked": bool(value)}
            elif control.buttons:
                item |= {"kind": "buttons", "names": list(control.names), "index": control.values.index(value),
                         "locked": [self.lab.locked(control.key, v, self.settings) for v in control.values],
                         "icons": [control.icon(v) for v in control.values]}           # Control.icons, by value
            elif control.typed:
                item |= {"kind": "typed", "symbol": control.symbol, "least": control.values[0], "most": control.values[-1],
                         "value": value, "empty": control.empty, "placeholder": get_text("lab.field_empty"),
                         "field_tip": get_text("lab.field_tip", least=control.values[0], most=control.values[-1])}
            else:
                top = self.slider_top(control)
                item |= {"kind": "slider", "index": min(position(control, value), max(top, 0)), "top": top,
                         "text": self.lab.showing(control.key, self.settings) or control.show(value), "fine_tip": get_text("lab.fine_tip"),
                         "tracking": not released}
                if released:                                    # the label follows the drag (LabView.follow)
                    item["texts"] = [control.show(v) for v in control.values]
            if control.shortcuts:
                item["shortcuts"] = [{"text": f"{v:g}", "checked": value is not None and f"{value:g}" == f"{v:g}"}
                                     for v in control.shortcuts]
            found.append(item)
        return found

    def placed(self, action: Action) -> str:
        """The key of the control whose label's line holds a command's slim copy now (LabView.placed): the last of its
        places (Action.beside, keys apart by spaces, a typed control's own row aside) shown; "" where none is."""
        keys = {control.key: control for control in self.lab.controls}
        places = [key for key in action.beside.split() if key in keys and not keys[key].typed]
        on = [key for key in places if self.lab.shown(keys[key], self.settings)]
        return on[-1] if on else ""

    def command(self, action: Action) -> dict:
        """A command as the column draws it, for the state on screen (LabView.show_commands)."""
        state = self.state
        playing = action.motion == "run" and self.motion == "run" and self.playing in (action.key, None)
        label = action.playing_label if playing and action.playing_label else action.label
        item = {"key": action.key, "visible": bool(self.lab.offered(action.key, self.settings)),
                "enabled": bool(state is not None and self.lab.enabled(action.key, state)) or playing,
                "tip": action.tip, "toggle": action.toggle, "checked": bool(action.toggle and self.settings.get(action.key)),
                "mark": action.mark,                                    # an icon before a chip's or a featured command's text
                "band": action.key == CHIP and any(control.key in VIEW_KEYS for control in self.lab.controls)}
        if action.featured and action is not self.filled:
            item |= {"label": label, "detail": minus(self.lab.naming(action.key, state)) if state is not None else ""}
        elif action.icon and action is not self.filled:
            item |= {"label": label, "icon": action.playing_icon if playing and action.playing_icon else action.icon}
        elif action.opens:
            item |= {"label": get_text("panel.view_code"), "tip": action.tip}
        else:
            named = self.lab.naming(action.key, state) if state is not None else ""
            item |= {"label": label if playing and action.playing_label else named or action.label,
                     "tip": (self.lab.tip_of(action.key, state) if state is not None else "") or action.tip}   # follows the name
        return item

    def card_view(self) -> dict:
        """The card of what the step works on (LabView.show_received): its heading and rows [label, value, kind, tip]
        (the kinds of explorers/doe: "goal", "bound", "aside" for the problem, a measure's kind otherwise; a row's tip
        its fourth, "" for none)."""
        heading, rows = self.lab.received(self.state) if self.state is not None else ("", ())
        return {"heading": heading, "rows": [[minus(row[0]), minus(row[1]), row[2] if len(row) > 2 else "plain",
                                              row[3] if len(row) > 3 else ""] for row in rows]}

    def view(self) -> dict:
        """The column, the strip or the blocks and the figure's words, as the workbench shows them (LabView)."""
        lab, state = self.lab, self.state
        featured, transport, chips, links = [], [], [], []
        controls = self.controls_view()
        fields = {item["key"]: item for item in controls if item["kind"] == "typed"}
        lines = {item["key"]: item for item in controls if item["kind"] != "typed"}
        for action in lab.actions:
            item = self.command(action)
            if action.beside in fields and action is not self.filled:   # in the row of its typed control (Action.beside)
                fields[action.beside].setdefault("beside", []).append(item)
            elif action.top:
                links.append(item)
            elif action is self.filled:
                continue
            elif action.featured:
                featured.append(item)
            elif action.icon:
                transport.append(item)
            else:
                place = self.placed(action) if action.beside else ""
                if place:                                               # a slim copy on that control's label line
                    item["placed"] = place
                    lines[place].setdefault("on_line", []).append(dict(item))
                chips.append(item)
        filled = None
        if self.filled is not None:
            filled = self.command(self.filled) | {"forward": self.filled.forward}
            ready = self.output() is not None if self.filled.forward else state is not None and lab.enabled(self.filled.key, state)
            why = "" if ready else lab.missing(state) if state is not None else get_text("lab.missing_state")
            own = lab.tip_of(self.filled.key, state) if state is not None else ""
            filled["enabled"] = bool(ready)
            filled["tip"] = minus((own or self.filled.tip) if ready or not why else why)   # the reason: its tooltip alone
            filled["demoted"] = bool(self.next[0])                      # outlined over the bench's command
        metrics = []
        if state is not None and not lab.columned and not lab.metrics_in_figure(state):
            for metric in lab.metrics(state):
                metrics.append({"title": minus(metric.title), "value": minus(metric.value), "kind": metric.kind, "tip": minus(metric.tip),
                                "color": metric.color, "detail": minus(metric.detail), "detail_kind": metric.detail_kind,
                                "strong": bool(metric.strong)})
        table = lab.table(state, self.hovered) if state is not None else None
        text, warning = self.alert
        offered = self.reveal_offered()
        return {"title": self.title, "purpose": self.purpose, "card": self.card_view(), "featured": featured, "controls": controls,
                "transport": transport, "stage": minus(lab.naming(TRANSPORT, state)) if transport and state is not None else "",
                "chips": chips, "links": links, "filled": filled, "status": self.status, "status_kind": self.status_kind,
                "status_tip": minus(lab.hint(state)) if state is not None else "",          # the verdict's reason (Lab.hint)
                "next": {"label": self.next[0], "tip": self.next[1]} if self.next[0] else None,
                "restore": {"shown": bool(lab.restore), "label": get_text("lab.reset"), "tip": get_text("lab.reset_tip")},
                "columned": bool(lab.columned), "blocks": self.blocks_view(),
                "reveal": {"offered": offered, "checked": bool(lab.revealed), "label": get_text("view.show_f"),
                           "tip": get_text("view.show_f_tip"), "mark": "eye", "box": self.reveal_box() if offered else None},
                "metrics": metrics, "alert": {"text": ("▲  " if warning else "") + minus(text), "warning": warning} if text else None,
                "lead": minus(lab.lead(state)) if state is not None else "",          # the figure's name; it has no tooltip
                "keys": minus(lab.keyboard(state)) if state is not None else "",      # its description: the keys on it
                "table": {"columns": list(table.columns), "rows": [list(r) for r in table.rows], "total": list(table.total),
                          "chosen": table.chosen} if table is not None else None,
                "playing": {"token": self.token, "ms": int(lab.frame_time(self.settings))} if self.motion is not None else None,
                "cursor": self.cursor(), "computed": state is not None}

# ------------------------------------------------------------------------------
# A bench: its three steps and its study (gui/bench_view.BenchView)
# ------------------------------------------------------------------------------
class Bench:
    def __init__(self, bridge: "Bridge", bench, snapshot: dict | None = None, mode: str = TEACHER, passed: bool = False):
        self.bridge = bridge
        self.bench = bench
        self.mode = mode
        self.passed = bool(passed)                               # the bench was passed: never undone
        self.verdict: bool | None = None                         # the last step's state on screen, judged (Lab.finished)
        self.won_now = False
        snapshot = snapshot or {}
        self.paid: dict = dict(snapshot.get("paid", {}))         # what the study paid for and no setting keeps (Lab.charged)
        self.best = snapshot.get("best")                         # the last step's worth when the bench was first passed
        self.study: Study = snapshot.get("study", Study())
        self.saved: dict = dict(snapshot.get("labs", {}))
        self.discarded: set[int] = set(snapshot.get("discarded", ()))
        self.revealed: bool = bool(snapshot.get("revealed", False))     # "Show f", a view carried as the angle
        self.saved_worth = worth(bench.key, snapshot, mode, self.passed)
        self.language = i18n.current_language()
        self.views: dict[int, Step] = {}
        self.on_screen: int | None = None
        self.enter(self.study.step, snapshot.get("view"), snapshot.get("section"))

    def current(self) -> Step:
        return self.views[self.study.step]

    def step_key(self) -> str:
        return STEPS[self.study.step]

    def states(self) -> tuple:
        return states(self.study)

    def view(self, step: int, handed=None, angle=None, section: dict | None = None) -> Step:
        if step not in self.views:
            key = STEPS[step]
            lab = lab_for(key, self.bench.key, self.mode)
            lab.columned = lab.hero = self.bridge.columned      # the page's arrangement (Step.set_columned follows it)
            lab.won = self.passed
            lab.paid = self.paid                                # before its first state: what was already paid for
            lab.revealed = self.revealed and (self.mode == TEACHER or self.passed)     # "Show f", where it is offered
            if angle is not None:
                lab.view = tuple(angle)
            view = Step(self.bridge, lab, self.saved.get(key), handed, get_text(f"step.{key}.title"), get_text(f"step.{key}.purpose"),
                        carried=section)
            view.on_change = lambda step=step: self.lab_changed(step)
            view.on_cue = lambda cue, step=step: self.lab_cue(cue, step)
            view.on_reveal = self.reveal
            self.say_status(step, view)
            self.views[step] = view
        return self.views[step]

    def status_text(self, step: int) -> str:
        """The status line (gui/bench_view.status_text): what was discarded; for the last step the verdict on screen, a
        validated result that does not complete the bench even on a bench passed before, else the bench passed (and,
        for a student, the bench it opened, unless the bench's command "Next bench" stands under the line)."""
        if step in self.discarded:
            return get_text(f"step.discarded.{STEPS[step]}")
        if step == LAST and self.verdict is False:
            return verdict_line(False)
        if step == LAST and self.passed:
            following = self.opened() if not self.onward_text(step)[0] else None
            return verdict_line(True, responses.title(following.key) if following is not None else "")
        return ""

    def say_status(self, step: int, view: Step | None = None) -> None:
        """A step's status line in its colour (gui/bench_view.status_kind) and, for the last step of a bench passed whose
        validated result on screen completes it, the foot's command on to the next bench (onward_text)."""
        view = view or self.views.get(step)
        if view is not None:
            ok = step == LAST and step not in self.discarded and self.passed and self.verdict is not False
            view.set_status(self.status_text(step), "ok" if ok else "warning")
            view.set_next(*self.onward_text(step))

    def following(self):
        """The bench after this one in benches.BENCHES (for a student the one its pass opens), or None for the last."""
        keys = list(BENCHES)
        place = keys.index(self.bench.key) if self.bench.key in keys else len(keys)
        return BENCHES[keys[place + 1]] if place + 1 < len(keys) else None

    def onward_text(self, step: int) -> tuple[str, str]:
        """The foot's command of a bench passed and its tooltip (gui/bench_view.onward_text): on the last step, while
        the bench is passed and the validated result on screen completes it, "Next bench →", or "Back to the cover" on
        the last bench; ("", "") otherwise."""
        if step != LAST or not self.passed or self.verdict is not True or step in self.discarded:
            return "", ""
        following = self.following()
        if following is None:
            return get_text("bench.home"), get_text("bench.home_tip")
        return get_text("bench.next"), get_text("bench.next_tip", bench=responses.title(following.key))

    def opened(self):
        """The bench a student's completion of this one opens (the next of benches.BENCHES), or None."""
        return self.following() if self.mode == STUDENT else None

    def show_step(self, step: int) -> None:
        if step == self.study.step or not enabled(self.study, step):
            return
        self.study = shown(self.study, step)
        self.enter(step)
        self.bridge.cues.append("navigate")

    def advance(self, step: int) -> None:
        view = self.views.get(step)
        if view is not None and step == self.study.step:
            view.stop()                                         # a competition that plays never crowns behind the reader
        output = view.output() if view is not None and step == self.study.step else None
        if output is None:
            return
        self.study = advanced(self.study, output)
        self.discarded.discard(step)
        view.set_status("")
        self.enter(self.study.step)
        if self.study.step != step:
            self.bridge.cues.append("advance")

    def enter(self, step: int, angle=None, section: dict | None = None) -> None:
        """The step on screen (BenchView.enter): built or given what was handed, at the angle and with the view of the
        step left (or the snapshot's), the view never a change of the study; the step left leaves the screen."""
        left = self.views.get(self.on_screen) if self.on_screen is not None else None
        if left is not None:
            angle = left.angle()
            section = left.section()
            if step != self.on_screen:
                left.leave()                                    # the step left plays nothing behind the reader
        handed = self.study.handed[step - 1] if step > 0 else None
        view = self.view(step, handed, angle, section)
        if handed is not None and view.handed != handed:
            view.receive(handed)
        view.carry(section)
        view.away = False
        self.on_screen = step
        if angle is not None:
            view.turn(angle)
        if step == LAST:
            self.judge()

    def lab_changed(self, step: int) -> None:
        if step != self.study.step:
            return
        self.won_now = False
        self.study, discarded = changed(self.study, self.views[step].output())
        if discarded:
            self.discarded.add(step)
            self.say_status(step)
            self.bridge.cues.append("discard")
        if step == LAST:
            self.judge()

    def lab_cue(self, cue: str, step: int | None = None) -> None:
        """A laboratory's cue: only the step on screen's; a validation's said as the verdict, none for the first pass
        (gui/bench_view.lab_cue)."""
        if step is not None and step != self.study.step:
            return
        if cue in VALIDATION:
            if self.won_now or self.verdict is None:
                return
            cue = "passed" if self.verdict else "missed"
        self.bridge.cues.append(cue)

    def reveal(self, on: bool) -> None:
        """"Show f" turned on or off in a step (gui/bench_view.reveal): kept (the snapshot) and given to the other steps,
        a view, never a change of the study; turned on, its cue "reveal"."""
        self.revealed = bool(on)
        for view in self.views.values():
            view.reveal(self.revealed)
        if self.revealed:
            self.bridge.cues.append("reveal")

    def stop(self) -> None:
        """The frames of every step stop where they are (the cover is shown), and none says a cue until shown again."""
        for view in self.views.values():
            view.leave()

    def charge(self, view: Step) -> None:
        """What the last step's state paid for that its settings will not keep (Lab.charges: a validation, by its
        experiment; several at once for a step that validates several designs), each kept in `paid` when it is not
        there yet and given to every laboratory (BenchView.charge)."""
        try:
            charges = view.lab.charges(view.state)
        except (ArithmeticError, ValueError):
            charges = ()
        paid = self.paid
        for key, item in charges:
            known = paid.get(key, ())
            if item not in known:
                paid = paid | {key: (*known, item)}              # a new dict: a lab's is never mutated
        if paid is self.paid:
            return
        self.paid = paid
        for each in self.views.values():
            each.lab.paid = self.paid

    def judge(self) -> None:
        """The last step's verdict (gui/bench_view.judge): the first True passes the bench, never undone."""
        view = self.views.get(LAST)
        if view is None:
            return
        found = None
        if view.state is not None:
            self.charge(view)
            try:
                found = view.lab.finished(view.state)
            except (ArithmeticError, ValueError):
                found = None
        self.verdict = None if found is None else bool(found)
        if not self.verdict or self.passed:
            self.say_status(LAST)
            return
        self.passed = True
        self.best = view.worth if view.worth[0] else self.best
        for each in self.views.values():
            each.lab.won = True
        self.say_status(LAST)
        for each in self.views.values():                        # what the labs kept until the bench was won opens
            each.refresh()
        self.won_now = True
        self.bridge.cues.append("achieved")
        self.bridge.bench_achieved(self.bench.key)

    def summaries(self) -> tuple:
        found = []
        for step in range(len(STEPS)):
            view = self.views.get(step)
            if not worth_said(self.study, step):
                found.append(None)
            elif step == LAST and self.best is not None:        # complete: what the completing study was worth
                found.append(self.best)
            elif view is None:
                found.append(self.saved_worth[step] if step < len(self.saved_worth) else None)
            else:
                found.append(view.worth if view.worth[0] else None)
        return tuple(found)

    def snapshot(self) -> dict:
        labs = dict(self.saved) | {STEPS[step]: view.snapshot() for step, view in self.views.items()}
        return {"study": self.study, "labs": labs, "view": self.current().angle(), "section": self.current().section(),
                "discarded": tuple(sorted(self.discarded)), "worth": (self.language, self.summaries()), "paid": self.paid,
                "best": self.best, "revealed": self.revealed}

# ------------------------------------------------------------------------------
# The application (gui/main_window.MainWindow, without the window)
# ------------------------------------------------------------------------------
class Bridge:
    """The cover and the benches, each mode's studies and benches passed, the language: what the page asks, answered."""

    def __init__(self):
        self.mode = FIRST_MODE
        self.bench = next(iter(BENCHES))
        self.studies: dict[str, dict[str, dict]] = {each: {} for each in MODES}
        self.passed: dict[str, set[str]] = {TEACHER: set(), STUDENT: set()}
        self.page: Bench | None = None
        self.page_key: str | None = None
        self.on_cover = True
        self.code_open = False
        self.motion_allowed = True
        self.unlocked = False                                    # a student's pass opened a bench the cover has not shown yet
        self.columned = True                                     # the page's arrangement: the desktop's until a size says
        self.cues: list[str] = []
        self.sent = None                                         # what the page shows of the figure: (step, draws, panel, ...)
        self.sent_blocks: dict[str, tuple] = {}                  # and of each block, by key
        self.fits: dict[tuple, tuple] = {}                       # a phone's fitting, by the lab's kind and the size asked
        self.slots: dict[tuple, dict] = {}                       # the card's slot of a bench, by bench and language

    @property
    def lab_states(self) -> dict:
        return self.studies[self.mode]

    # ------------------------------------------------------------------ the page's one call
    def handle(self, request: str):
        """Answer a request of the page (JSON text): (the view as JSON text, the figure's pixels or None, their meta as
        JSON text, the pixels of the blocks drawn anew as a list of (key, pixels)). An error that nothing handled goes
        back in the view, with its traceback, and the page goes on."""
        asked = json.loads(request)
        self.cues = []
        error = ""
        try:
            self.carry_out(asked)
        except Exception:                                       # the window's report_error: shown, and the page goes on
            error = traceback.format_exc()
        pixels, meta, blocks = None, {}, []
        try:
            pixels, meta, blocks = self.picture(asked.get("size"), bool(asked.get("force")))
        except Exception:
            error = error or traceback.format_exc()
        view = self.view()
        view["error"] = error
        return json.dumps(view, ensure_ascii=False), pixels, json.dumps(meta), blocks

    def carry_out(self, asked: dict) -> None:
        op = asked.get("op")
        size = asked.get("size")
        if isinstance(size, dict) and size:                     # the arrangement the page shows, before any step is built
            self.columned = columned_size(size)
        step = self.page.current() if self.page is not None and not self.on_cover else None
        if op == "boot":
            self.boot(asked.get("saved") or {}, asked.get("language"), asked.get("motion", True))
        elif op == "mode":
            self.choose_mode(asked["mode"])
        elif op == "language":
            self.set_language(asked["language"])
        elif op == "open":
            self.open_bench(asked["bench"])
        elif op == "home":
            self.go_home()
        elif op == "restart":
            self.restart_student()
        elif op == "code":
            self.code_open = bool(asked.get("open"))
        elif self.page is None or step is None:
            return
        elif op == "onward":
            self.go_on()
        elif op == "step":
            self.page.show_step(int(asked["index"]))
        elif op == "control":
            control = step.control(asked["key"])
            if control.check:
                step.choose(control.key, bool(asked["value"]))
            elif control.typed:
                number = asked.get("value")
                step.choose(control.key, None if number is None else step.nearest(control.key, float(number)))
            else:
                index = int(asked["value"])
                if 0 <= index < len(control.values):
                    step.choose(control.key, control.values[index])
        elif op == "pick":
            control = step.control(asked["key"])
            step.set_value(control.key, control.shortcuts[int(asked["index"])])
        elif op == "action":
            action = next((a for a in step.lab.actions if a.key == asked["key"]), None)
            if action is not None and action.forward:
                self.page.advance(self.page.study.step)
            elif action is not None:
                step.act(action.key)
        elif op == "restore":
            step.reset()
        elif op == "frame":
            step.frame(int(asked.get("token", -1)))
        elif op == "pointer":
            step.pointer(asked["kind"], float(asked.get("x", 0)), float(asked.get("y", 0)), bool(asked.get("touch")))
        elif op == "key":
            step.press(asked["key"])
        elif op == "reveal":
            step.reveal_clicked(bool(asked.get("on")))
        elif op == "block_pointer":
            step.block_pointer(asked["key"], asked.get("kind", "move"), float(asked.get("x", 0)), float(asked.get("y", 0)))
        elif op == "block_press":
            step.block_press(asked["key"], float(asked.get("x", 0)), float(asked.get("y", 0)))
        elif op == "block_scroll":
            step.block_scroll(asked["key"], int(asked.get("first", 0)))

    # ------------------------------------------------------------------ settings kept by the page
    def boot(self, saved: dict, language: str | None, motion: bool) -> None:
        """The first request: what the page kept (the mode, the language, the benches the student passed, or an older
        page's stars), or the first run's (the mode FIRST_MODE, the language the browser asked for)."""
        self.save_page_state()                                  # a page started again: no bench of before on screen
        self.drop_page()
        saved = saved if isinstance(saved, dict) else {}       # what a browser kept is read defensively: any other shape
        mode = saved.get("mode")                                # reads as nothing kept
        self.mode = mode if isinstance(mode, str) and mode in MODES else FIRST_MODE
        chosen = saved.get("language") or language
        i18n.set_language(chosen if isinstance(chosen, str) and chosen in LANGUAGES else i18n.DEFAULT_LANGUAGE)
        kept, older = saved.get("passed"), saved.get("stars")
        kept, older = (kept if isinstance(kept, dict) else {}), (older if isinstance(older, dict) else {})
        self.passed[STUDENT] = {key for key in BENCHES if stored_passed(kept.get(key)) or stored_passed(older.get(key))}
        self.motion_allowed = bool(motion)
        self.unlocked = False
        self.show_cover()

    def persist(self) -> dict:
        return {"mode": self.mode, "language": i18n.current_language(), "passed": dict.fromkeys(sorted(self.passed[STUDENT]), True)}

    # ------------------------------------------------------------------ the game
    def open_benches(self) -> dict:
        if self.mode != STUDENT:
            return {}
        keys, passed = list(BENCHES), self.passed[STUDENT]
        return {key: keys[place - 1] for place, key in enumerate(keys) if place and keys[place - 1] not in passed}

    def is_open(self, bench: str) -> bool:
        return bench not in self.open_benches()

    def choose_mode(self, mode: str) -> None:
        if mode not in MODES or mode == self.mode:
            return
        self.save_page_state()
        self.drop_page()
        self.mode = mode
        self.show_cover()

    def drop_page(self) -> None:
        self.page = None
        self.page_key = None

    def bench_achieved(self, bench: str) -> None:
        """A bench passed (gui/main_window.bench_achieved): kept; a bench it opens to a student is heard when the cover
        comes back (go_home: "unlock")."""
        if bench in self.passed[self.mode]:
            return
        closed = self.open_benches()
        self.passed[self.mode].add(bench)
        if self.mode == STUDENT:
            self.unlocked = self.unlocked or len(self.open_benches()) < len(closed)

    def restart_student(self) -> None:
        """The cover's quiet command, confirmed by the page: what the student passed and studied forgotten."""
        if self.mode == STUDENT:
            self.drop_page()
        self.passed[STUDENT] = set()
        self.studies[STUDENT] = {}
        self.unlocked = False
        self.bench = next(iter(BENCHES))
        self.show_cover()

    # ------------------------------------------------------------------ language and navigation
    def set_language(self, language: str) -> None:
        if language not in LANGUAGES or language == i18n.current_language():
            return
        i18n.set_language(language)
        if self.on_cover:
            return
        self.save_page_state()
        self.page = None
        self.select_bench(self.bench)

    def go_home(self) -> None:
        """Home (gui/main_window.go_home): the cover, a page turned; "unlock" in its place when a student's pass opened
        a bench since the cover was last shown."""
        if self.on_cover:
            return
        self.show_cover()
        self.cues.append("unlock" if self.unlocked else "navigate")
        self.unlocked = False

    def go_on(self) -> None:
        """The command of a bench passed (gui/main_window.go_on, onward): the following bench, a page turned (its opening
        heard as it is seen: no "unlock" later for it), or the cover after the last one (go_home)."""
        following = self.page.following() if self.page is not None else None
        if following is None:
            self.go_home()
        elif self.is_open(following.key):
            self.unlocked = False
            self.select_bench(following.key)
            self.cues.append("navigate")

    def open_bench(self, bench: str) -> None:
        if bench not in BENCHES or not self.is_open(bench):
            return
        self.select_bench(bench)
        self.cues.append("navigate")

    def show_cover(self) -> None:
        if self.page is not None:
            self.page.stop()                                     # nothing plays behind the cover (BenchView.stop)
        self.save_page_state()
        self.code_open = False
        self.on_cover = True
        for key in BENCHES:
            snapshot = self.lab_states.get(key)
            if snapshot:
                snapshot["worth"] = (i18n.current_language(), worth(key, snapshot, self.mode, key in self.passed[self.mode]))

    def select_bench(self, bench: str) -> None:
        self.save_page_state()
        self.on_cover = False
        if bench != self.page_key or self.page is None:
            self.bench = bench
            self.code_open = False
            self.page_key = bench
            self.page = Bench(self, BENCHES[bench], self.lab_states.get(bench), mode=self.mode, passed=bench in self.passed[self.mode])

    def save_page_state(self) -> None:
        if self.page is None or self.page_key is None:
            return
        self.lab_states[self.page_key] = self.page.snapshot()

    # ------------------------------------------------------------------ what the page shows
    def picture(self, size: dict | None, force: bool = False) -> tuple:
        """The figure of the step on screen at the page's size, or None when the page already shows it, and its blocks'
        pictures (the desktop's columned page). A size with `fit` and no height (a phone) is the room for the figure's
        box: the panel asked is drawn as wide as IT fits there (fitting), and the meta says the box, the width of each
        panel and where the measures go. (pixels, meta, [(key, pixels) of each block drawn anew])."""
        if self.on_cover or self.page is None or not size:
            self.sent = None
            self.sent_blocks = {}
            return None, {}, []
        step = self.page.current()
        step.set_columned(columned_size(size))
        panel = size.get("panel")
        width, height, fitted = size.get("width", 800), size.get("height"), None
        if height is None and size.get("fit"):
            fitted = self.fitting(step.lab, width, float(size["fit"]), size.get("aside"), size.get("below"))
            if fitted["whole"]:
                height, panel = fitted["box"][1], None
            else:
                panel = panel if panel in PANELS else PANELS[0]
                width = fitted["widths"][panel]
        pixels, meta = step.render(width, height, size.get("ratio", 1.0), panel)
        if fitted is not None:
            meta |= {"box": list(fitted["box"]), "widths": fitted["widths"], "beside": fitted["beside"], "scrolls": fitted["scrolls"]}
        sent = (id(step), meta.get("draws"), panel, meta.get("width"), meta.get("height"), meta.get("ratio"))
        same = pixels is not None and sent == self.sent and not force
        self.sent = sent if pixels is not None else None
        if same:
            pixels, meta = None, meta | {"same": True}
        elif pixels is not None:
            pixels = np.ascontiguousarray(pixels)
        blocks, told = [], {}
        if pixels is not None or same:                          # a state drawn: its blocks too
            for key, holder in step.render_blocks(size.get("blocks") or {}, size.get("ratio", 1.0)).items():
                wide, tall, ratio = holder.drawn
                shown = (id(step), holder.draws, wide, tall, ratio)
                alike = shown == self.sent_blocks.get(key) and not force
                told[key] = {"width": wide, "height": tall, "ratio": ratio, "pixel_width": int(holder.figure.bbox.width),
                             "pixel_height": int(holder.figure.bbox.height), "draws": holder.draws, "same": alike}
                if not alike:
                    blocks.append((key, np.ascontiguousarray(np.asarray(holder.canvas.buffer_rgba()))))
                    self.sent_blocks[key] = shown
        if step.lab.columned:
            meta["blocks"] = told
        return pixels, meta, blocks

    def fitting(self, lab: Lab, width: float, fit: float, aside=None, below=None) -> dict:
        """How a phone's figure fills the room it is given, `width` x `fit` CSS pixels: each panel of the stack as wide as
        it fits that height (fitted_widths) and the box that holds any of them (fitted_box), one panel shown at a time;
        the 3D view and the third panel, whose narrow layout is taller than the plane's (two title lines, the legend in
        rows, the third panel NARROW_THIRD more), are drawn as wide as the box instead and scroll in it when taller
        (SCROLLED, meta "scrolls"): their text keeps its size, where a fit to the height would scale it down by half;
        or, in a stage at least STACK_WIDTH wide, the labs' own arrangement of the three panels at once (WHOLE: the corner
        or the row; the pair leaves the third panel out) when its design space comes out at least as large, the measures
        then under it (`below` high). With `aside` (a phone in landscape), the measures stand in a column that wide at the
        figure's side, or in a line `below` high under it, whichever shows the panels wider in all (beside, on a tie).
        Kept by the lab's kind, its caption's block (Lab.drawing: the beam's drawing changes every height) and the size: a
        slider dragged asks for the same fitting at every move."""
        key = (type(lab).__name__, lab.drawing, round(width), round(fit), aside, below)
        if key in self.fits:
            return self.fits[key]
        under = fit - (below or 0)
        drawing = lab.drawing                                           # the lab's caption block (explorers/caption.py)

        def shown(widths: dict, room: float) -> float:                 # the plane's width on screen (too tall: scaled)
            return widths["plane"] * min(1.0, room / panel_heights(lab.height_for, widths["plane"], drawing)["plane"])

        def fitted(room: float, high: float) -> dict:                   # the plane fitted, the others as wide as the room
            widths = fitted_widths(lab.height_for, room, high, drawing)
            return widths | dict.fromkeys(SCROLLED, max(min(int(round(room)), STACK_WIDTH - 1), FIT_LEAST))
        if aside:
            beside = fitted(width - aside, fit)
            lower = fitted(width, under)
            side = shown(beside, fit) >= shown(lower, under)
            widths = beside if side else lower
        else:
            side, widths = False, fitted(width, fit)
        box = fitted_box(lab.height_for, widths, under if aside and not side else fit, drawing)
        scrolls = [name for name in SCROLLED if panel_heights(lab.height_for, widths[name], drawing)[name] > box[1]]
        found = {"widths": widths, "box": box, "beside": side, "whole": False, "scrolls": scrolls}
        if width >= STACK_WIDTH and under >= lab.height_for(round(width)):
            plan = arrangement(width, under, pair="space", fill=True, drawing=drawing, hero=False)
            if plan.kind in WHOLE and plan.side >= arrangement(widths["plane"], None, drawing=drawing).side:
                found = {"widths": {}, "box": (round(width), round(under)), "beside": False, "whole": True, "scrolls": []}
        self.fits[key] = found
        return found

    def png(self, width: float, height: float | None, ratio: float = 1.0, panel: str | None = None) -> bytes:
        """The figure of the step on screen as a PNG (b"" on the cover, or while it cannot be drawn): the pixels the
        page is sent, encoded (a height: the desktop's, columned; None: a phone's stack); for a check, a capture, or a
        page that would rather have an image file."""
        if self.on_cover or self.page is None:
            return b""
        step = self.page.current()
        step.set_columned(height is not None)                   # the desktop's columned, a phone's stack not
        pixels, _meta = step.render(width, height, ratio, panel)
        if pixels is None:
            return b""
        from matplotlib.image import imsave
        stream = io.BytesIO()
        imsave(stream, np.ascontiguousarray(pixels), format="png")
        return stream.getvalue()

    def cover_view(self) -> dict:
        locks = self.open_benches()
        cards = []
        passed = self.passed[self.mode]
        short = [get_text(f"step.{key}.short") for key in STEPS]
        for place, (key, bench) in enumerate(BENCHES.items(), start=1):
            snapshot = self.lab_states.get(key)
            said = worth(key, snapshot, self.mode, key in passed)
            study = snapshot["study"] if snapshot else Study()
            track = states(study)
            picture = cover.picture(key, designs=self.mode == TEACHER, truth=cover.shows_truth(key, key in passed))
            marks = [{"kind": mark.kind, "role": mark.role, "color": ROLE_COLORS[mark.role], "width": ROLE_WIDTHS[mark.role],
                      "dashed": mark.dashed, "hollow": mark.hollow, "small": mark.small,
                      "points": [[round(x, 4), round(y, 4)] for x, y in mark.points]}
                     for mark in picture.marks]
            cards.append({"key": key, "number": bench.label.zfill(2), "digit": str(place), "title": responses.title(key),
                          "challenge": get_text(f"bench.{key}.challenge"), "passed": key in passed,
                          "passed_text": get_text("bench.passed") if key in passed else "",
                          "locked": key in locks,
                          "lock_tip": get_text("cover.locked_tip", bench=responses.title(locks[key])) if key in locks else "",
                          "open_tip": get_text("cover.open_tip"),
                          "track": [{"state": state, "name": name, "worth": list(said[i]) if i < len(said) and said[i] else None,
                                     "tip": get_text(f"cover.track.{state}", name=name)}
                                    for i, (state, name) in enumerate(zip(track, short, strict=True))],
                          "picture": {"window": list(picture.window), "equal": picture.equal, "marks": marks}})
        return {"title": get_text("cover.title"), "edition": get_text("cover.edition"), "version": __version__,
                "lead": get_text("cover.lead"), "mode_label": get_text("mode.label"), "modes": [{"key": m, "name": get_text(f"mode.name.{m}")} for m in (STUDENT, TEACHER)],
                "mode_line": get_text(f"mode.line.{self.mode}"), "restart": self.mode == STUDENT and bool(passed),
                "restart_texts": {k: get_text(f"restart.{k}") for k in ("command", "tip", "title", "text", "confirm", "cancel")},
                "cards": cards, "last": self.bench}

    def slot(self, bench: str) -> dict:
        """The card's slot of a bench (gui/lab_views.CardSlot), the same in its three steps: the most rows of a received
        card of its later steps, and its problem's rows [word, value, kind] (the page measures the room of both)."""
        key = (bench, i18n.current_language())
        if key not in self.slots:
            self.slots[key] = {"rows": card_rows(bench),
                               "problem": [[minus(row[0]), minus(row[1]), row[2]] for row in problem_of(bench)]}
        return self.slots[key]

    def bench_view(self) -> dict:
        page = self.page
        found, said = page.states(), page.summaries()
        step = page.current()
        passed = self.bench in self.passed[self.mode]
        pills = [{"state": state, "name": get_text(f"step.{key}.title"), "short": get_text(f"step.{key}.short"),
                  "tip": step_tip(index, state, worth_of)}
                 for index, (key, state, worth_of) in enumerate(zip(STEPS, found, said, strict=True))]
        bench = BENCHES[self.bench]
        return {"key": self.bench, "name": f"{bench.label}  {responses.title(self.bench)}", "passed": passed,
                "passed_text": get_text("bench.passed") if passed else "", "pills": pills,
                "step": page.study.step, "step_key": page.step_key(), "lab": step.view(), "slot": self.slot(self.bench),
                "many": bool(many(self.bench)),             # several responses (bench 4): its 3D view is the objective space
                "code": {"open": self.code_open, "reading": reading_key(page.step_key(), step.state)}}

    def view(self) -> dict:
        view = {"version": __version__, "language": i18n.current_language(), "languages": [[k, v] for k, v in LANGUAGES.items()],
                "mode": self.mode, "screen": "cover" if self.on_cover or self.page is None else "bench", "cues": list(self.cues),
                "persist": self.persist(),
                "bar": {"home": get_text("cover.button"), "home_tip": get_text("cover.button_tip"), "steps": get_text("app.steps"),
                        "language": get_text("app.language"), "sound_on": get_text("app.sound_on"), "sound_off": get_text("app.sound_off"),
                        "app": get_text("cover.title")}}
        if view["screen"] == "cover":
            view["cover"] = self.cover_view()
        else:
            view["bench"] = self.bench_view()
        return view
