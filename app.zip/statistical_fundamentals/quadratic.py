# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: quadratic.py
# ==============================================================================
"""
The quadratic model of a response and its exact minimum in a box. Two methods of step 3 minimize one: NLPQL, at
each iteration, and the response surface method, on its fitted quadratic,

    q(d) = g^T d + (1/2) d^T H d,        low <= d <= high

g is the gradient and H the symmetric matrix of second derivatives (the Hessian, possibly not positive definite: a
response that curves down in some direction).

Where the minimum lies: at the minimum of q over the box, the coordinates that sit on a bound are fixed there and the
others are free, so the free ones are an unconstrained minimum of q with the fixed ones given. Every one of the 3^n ways
to choose them (each coordinate at its lower bound, free, or at its upper bound) is a face of the box, and is tried:

    H_FF d_F = -(g_F + H_FB d_B)            F the free coordinates, B the fixed ones, d_B their bounds

The reduced matrix H_FF is solved by Cholesky (linear.py), no inverse is formed. A face is skipped when Cholesky refuses
its H_FF (a pivot below linear.SINGULAR): a matrix that is not positive definite has no minimum of its own (the value is
lower or equal on a smaller face, which is tried too). The same refusal also skips a face whose H_FF is positive definite
but very ill-conditioned; that is harmless, since the step found elsewhere is still a descent step. A solution outside
the box is skipped too. Of the candidates that remain, the one with the lowest q is the global minimum, indefinite H
included, and it always exists: the vertices of the box have no free coordinate.

NLPQL (Schittkowski) solves this problem with QL, a dual method, which scales to many variables. For the few variables
of the laboratory the enumeration, 3^n faces (9 for two inputs, 81 for four), is exact and short enough to read, and
replaces it.

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
import itertools

from statistical_fundamentals.linear import cholesky, cholesky_solve, dot

def quadratic_value(g, H, d):
    """q(d) = g^T d + (1/2) d^T H d."""
    Hd = [dot(row, d) for row in H]
    return dot(g, d) + dot(d, Hd) / 2

def box_minimum(g, H, low, high):
    """The d that minimizes q over low <= d <= high: the best of the minima on the 3^n faces of the box."""
    n = len(g)
    best = None
    best_value = None
    for face in itertools.product((-1, 0, 1), repeat=n):
        free = [i for i in range(n) if face[i] == 0]
        d = [low[i] if face[i] < 0 else high[i] for i in range(n)]
        if free:
            rhs = [-g[i] - sum(H[i][j] * d[j] for j in range(n) if face[j] != 0)
                   for i in free]
            try:
                L = cholesky([[H[i][j] for j in free] for i in free])
            except ArithmeticError:
                continue
            solution = cholesky_solve(L, rhs)
            if any(not low[i] <= x <= high[i] for i, x in zip(free, solution)):
                continue
            for i, x in zip(free, solution):
                d[i] = x
        value = quadratic_value(g, H, d)
        if best is None or value < best_value:
            best = d
            best_value = value
    return best
