# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: i18n
# ==============================================================================
"""
The language of what the reader reads (the interface and the explanations), without Qt.
Everything else, the code, its names and its comments, stays in English.

A text is asked for by key: get_text("lab.reset"). The catalogs are JSON files,
locales/<language>/*.json, merged per language, with flat keys ("lab.reset"). Every
text lives in both languages (parity tested); an untranslated key shows its English text.

Order of lookup for a key: the language chosen, English, the default given, "[key]".
Parameters fill the {name} places of the text (str.format) and are optional.
"""
import json
import re
from functools import cache
from pathlib import Path

LOCALES_DIR = Path(__file__).resolve().parent / "locales"
DEFAULT_LANGUAGE = "en"
LANGUAGES = {"en": "English", "pt_BR": "Português (Brasil)"}      # each in its own language, never translated
PLACEHOLDER = re.compile(r"\{(\w*)\}")

_current = DEFAULT_LANGUAGE

@cache
def catalog(language: str) -> dict[str, str]:
    """Every text of a language: its JSON files merged (a key repeated in two files is a mistake, refused)."""
    texts: dict[str, str] = {}
    for path in sorted((LOCALES_DIR / language).glob("*.json")):
        with open(path, encoding="utf-8") as file:
            for key, text in json.load(file).items():
                if key in texts:
                    raise ValueError(f"{path}: the key {key!r} is already defined in another file of {language}")
                texts[key] = text
    return texts

def current_language() -> str:
    return _current

def set_language(language: str) -> None:
    global _current
    if language not in LANGUAGES:
        raise ValueError(f"unknown language {language!r} (allowed: {', '.join(LANGUAGES)})")
    _current = language

def has_text(key: str, language: str | None = None) -> bool:
    return key in catalog(language or _current)

def get_text(key: str, default: str | None = None, /, **parameters) -> str:
    """The text of a key in the current language (see the order of lookup above). The key and the default are given
    by position only, so that a text may have a place named {key} or {default}."""
    text = catalog(_current).get(key)
    if text is None:
        text = catalog(DEFAULT_LANGUAGE).get(key)
    if text is None:
        text = default if default is not None else f"[{key}]"
    return text.format(**parameters) if parameters else text

def placeholders(text: str) -> set[str]:
    return set(PLACEHOLDER.findall(text))
