# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: beam.py
# ==============================================================================
"""
The simulation of the beam: a main beam simply supported at its ends, x = 0 and x = L, resting on n cross-beams that
cross under it at x_1, ..., x_n, each an elastic support, a spring of stiffness k_i (k = RIGID for a support that does
not yield): one k for all of them, the beam's, or a stiffness per support given at each call. Its response is the
largest deflection of the main beam, max |w(x)| in mm; with two cross-beams it is the function y = f(x1, x2) a design
study explores, x1 and x2 the places of the cross-beams. The end supports hold the beam both ways, as a pin does: where
a design lifts an end (about a quarter of the bench's design space), its reaction is downward and holds it down.

The beam (Euler-Bernoulli): length LENGTH = 10 m, bending stiffness STIFFNESS = EI = 20 000 kN m^2, constant; the
springs SPRING = k = 10 000 kN/m. The load LOAD, downward, is given by pieces (start, end, coefficients of a polynomial
in x, ascending powers), summed where they overlap: q(x) = 8 + 1.6 x kN/m over the whole beam plus a patch of 30 kN/m
over 2.0 <= x <= 3.5 m, 205 kN in all. Units: kN and m throughout (EI in kN m^2, k and q in kN/m, a moment in kN m);
the method's own deflections (w0, G) are in m, and every deflection the module hands out is in mm (MM per m).

Signs: x from the left end A to the right end B; the load and the deflection w positive downward; a reaction positive
upward on the beam; the bending moment M positive when it sags; EI w'' = -M.

The force method, exact (closed forms, no quadrature, no elements):
1. The beam without the cross-beams (statically determinate) under the load. Each piece of the load is a polynomial
   switched on at its start and off at its end; written in powers of (x - a) at each switch a (Taylor's shift), its
   n-th integral from 0 is a sum of Macaulay brackets, <x - a> = max(x - a, 0):
       Q_n(x) = sum c_j j! / (j + n)! <x - a>^(j + n),
   so that the end reaction is R_A0 = Q_2(L) / L (moments about B), the moment M0(x) = R_A0 x - Q_2(x), and the
   deflection EI w0(x) = EI theta_A x - R_A0 x^3 / 6 + Q_4(x), the slope at A from w0(L) = 0:
   EI theta_A = R_A0 L^2 / 6 - Q_4(L) / L.
2. The influence functions of a unit downward load at a on the same beam, its deflection and its moment at x:
       G(x, a) = u (L - v) (2 L v - v^2 - u^2) / (6 L EI),   m(x, a) = u (L - v) / L,   u = min(x, a), v = max(x, a),
   symmetric in x and a (Maxwell's reciprocity).
3. The redundants, the forces R_i of the cross-beams. The deflection at support i is the free one less what all the
   R_j lift there, and it equals the spring's shortening R_i / k_i (compatibility):
       (F + diag(1 / k_i)) R = w0(x_s),   F_ij = G(x_i, x_j),
   with one k for all the supports diag(1 / k_i) = I / k, the beam's own path; a symmetric positive definite system,
   solved and never inverted: for two supports by the elimination written out, for n by Cholesky's factorization (as
   linear.py), on every design at once. Rigid supports (1 / k_i = 0) must stand apart and inside the beam, or the
   system is singular; springs keep it positive definite anywhere on the beam.
4. Superposition: w(x) = w0(x) - sum_j R_j G(x, x_j) and M(x) = M0(x) - sum_j R_j m(x, x_j); the end reactions
   R_A = R_A0 - sum_j R_j (L - x_j) / L and R_B = R_B0 - sum_j R_j x_j / L.

The response reads w at STATIONS = 401 equally spaced points of the beam and at the supports themselves, the nodes a
mesh would have there, and takes the largest |w| among them. Between two stations the exact maximum can be higher: on
the bench's design space by at most about 7e-4 mm, compared with the maximum found from the roots of the slope.

The second response, the RMS deflection, is the response of the beam on FOUR cross-beams (f4(x1, x2, x3, x4)): the
root mean square of w along the beam,

    w_rms = sqrt((1 / L) integral_0^L w(x)^2 dx),

in mm, the integral by Simpson's rule on the same stations (400 intervals of h = L / 400: weights h / 3 times 1, 4, 2,
4, ..., 2, 4, 1). w is a polynomial between two supports or ends of the patch, and its second derivative, -M / EI, is
continuous along the whole beam (a spring's force makes the shear jump and only kinks the moment), so the rule's error
is of order h^4 and varies smoothly with the design: a smooth response, with one global minimum on its design space,
where the largest deflection of two cross-beams has its minimum on a kink. It weighs the whole deflected line, not only
its peak.

The beam on two cross-beams SIZED: each cross-beam is itself a beam, of steel, simply supported on a span SPAN = 4 m and
loaded at its mid-span by the main beam, of SOLID SQUARE section a x a, MODULUS = E = 210 GPa = 2.1e8 kN/m^2, DENSITY
= rho = 7850 kg/m^3; its cross-sectional AREA A = a^2, in cm^2 (CM2 m^2 per cm^2), is a design input as its place is,
and its side a = sqrt(A) follows (side, in mm). Its own weight is a load neither on itself nor on the main beam. Three
formulas make it a spring under the main beam, a mass and a stress:
- its stiffness as a spring: a point load P at the mid-span of a simply supported span deflects it by P S^3 / (48 E I)
  there, so k = 48 E I / S^3, and with I = a^4 / 12 = A^2 / 12, k = 4 E A^2 / S^3 = 1.3125e7 A^2 kN/m (A in m^2):
  5 250 kN/m at A = 200 cm^2, a = 141 mm;
- its mass: its volume A S times the density, m = rho S A = 31 400 A kg (A in m^2), 628 kg at A = 200 cm^2;
- its bending stress: the force R it takes from the main beam splits R / 2 to each support, so the moment is largest
  at mid-span, M = (R / 2) (S / 2) = R S / 4, and with the section modulus W = I / (a / 2) = a^3 / 6 = A^(3/2) / 6
  the stress at its extreme fibres is sigma = M / W = 1.5 R S / A^(3/2), in MPa (MPA kN/m^2 per MPa), signed as R:
  positive when the main beam presses the cross-beam down, as it does all over the bench's design space;
  LIMIT_STRESS is the bench's limit (the range of A is the bench's bounds, functions.BEAM_PARETO).
So k grows as A^2 and m as A; sigma = 1.5 R S / A^(3/2) at a given force R, but R grows with A, since a stiffer spring
draws more of the load, so sigma falls more slowly than A^(-3/2) (about as A^(-1) over most of the range, A^(-0.4) at its
light end): the trade the bench is about.
The responses of one simulation of a design (x1, x2 in m, A1, A2 in cm^2), in this order: the MASS of the two cross-beams
(kg), the RMS DEFLECTION of the main beam on them (mm, the measure of f4), and the stresses sigma_1 and sigma_2 (MPa):
sized gives the four from one solve per design; mass_of, rms_of, stress_1 and stress_2 give one each (mass_of solves
nothing, the three others solve as sized does).

What does not depend on the supports (the load's terms, the free beam, the stations, w0 and Simpson's weights at them)
is computed once for a beam. The responses work on NumPy arrays of designs of any shape, a large grid in chunks of CHUNK
designs, so that no intermediate array of a 201 x 201 grid is held whole. BEAM is the bench's beam; f, f4, response,
rms, solve, load, sized, mass_of, rms_of, stress_1 and stress_2 are its calls.
"""
import math
from dataclasses import dataclass

import numpy as np

LENGTH = 10.0
STIFFNESS = 20000.0
SPRING = 10000.0
RIGID = math.inf
LOAD = ((0.0, 10.0, (8.0, 1.6)), (2.0, 3.5, (30.0,)))
STATIONS = 401
CHUNK = 128
MM = 1000.0
SPAN = 4.0
CM2 = 1e-4
MODULUS = 2.1e8
DENSITY = 7850.0
LIMIT_STRESS = 120.0
MPA = 1000.0

def switches(load):
    """The load as polynomials switched on at places a, q(x) = sum c_j <x - a>^j: each piece on at its start and off
    (negated) at its end, its coefficients shifted to powers of (x - a), c_j = sum_p c_p C(p, j) a^(p - j).
    Returns three arrays, one entry per term: the place a, the coefficient c_j and the power j."""
    places, coefficients, powers = [], [], []
    for start, end, polynomial in load:
        for a, sign in ((start, 1.0), (end, -1.0)):
            for j in range(len(polynomial)):
                shifted = sum(polynomial[p] * math.comb(p, j) * a ** (p - j) for p in range(j, len(polynomial)))
                places.append(a)
                coefficients.append(sign * shifted)
                powers.append(j)
    return np.array(places), np.array(coefficients), np.array(powers)

def solve_two(A, b):
    """x with A x = b for 2 x 2 systems A (..., 2, 2), b (..., 2), by elimination: the first row times a21 / a11 taken
    from the second leaves one equation in x2; x1 follows from the first row."""
    a11, a12, a21, a22 = A[..., 0, 0], A[..., 0, 1], A[..., 1, 0], A[..., 1, 1]
    x2 = (b[..., 1] - a21 / a11 * b[..., 0]) / (a22 - a21 / a11 * a12)
    x1 = (b[..., 0] - a12 * x2) / a11
    return np.stack([x1, x2], axis=-1)

def cholesky_solve(A, b):
    """x with A x = b for symmetric positive definite systems A (..., n, n), b (..., n), all at once: Cholesky's
    A = L L^T column by column, then L y = b from the first row down and L^T x = y from the last row up."""
    n = A.shape[-1]
    L = np.zeros_like(A)
    for j in range(n):
        L[..., j, j] = np.sqrt(A[..., j, j] - np.sum(L[..., j, :j] ** 2, axis=-1))
        for i in range(j + 1, n):
            L[..., i, j] = (A[..., i, j] - np.sum(L[..., i, :j] * L[..., j, :j], axis=-1)) / L[..., j, j]
    y = np.zeros_like(b)
    for i in range(n):
        y[..., i] = (b[..., i] - np.sum(L[..., i, :i] * y[..., :i], axis=-1)) / L[..., i, i]
    x = np.zeros_like(b)
    for i in range(n - 1, -1, -1):
        x[..., i] = (y[..., i] - np.sum(L[..., i + 1:, i] * x[..., i + 1:], axis=-1)) / L[..., i, i]
    return x

def simpson(stations):
    """The weights of Simpson's rule on equally spaced stations, an odd number of them: h / 3 times 1, 4, 2, 4, ..., 2,
    4, 1, so that the integral of g over the beam is the sum of the weights times g at the stations."""
    if len(stations) % 2 == 0:
        raise ValueError("Simpson's rule needs an odd number of stations")
    weights = np.ones(len(stations))
    weights[1:-1:2] = 4.0
    weights[2:-1:2] = 2.0
    return weights * (stations[1] - stations[0]) / 3.0

def side(area):
    """a, mm: the side of a cross-beam's solid square section of area `area` (cm^2), sqrt(A); numbers or arrays."""
    return np.sqrt(np.asarray(area, dtype=float) * CM2) * MM

def stiffness(area):
    """k, kN/m: the stiffness of a cross-beam of section area `area` (cm^2) as a spring under its mid-span,
    48 E I / S^3 with I = a^4 / 12 = A^2 / 12; numbers or arrays."""
    metres = np.asarray(area, dtype=float) * CM2
    inertia = metres ** 2 / 12
    return 48 * MODULUS * inertia / SPAN ** 3

def mass(area):
    """m, kg: the mass of one cross-beam of section area `area` (cm^2), rho S A; numbers or arrays."""
    return DENSITY * SPAN * np.asarray(area, dtype=float) * CM2

def stress(reaction, area):
    """sigma, MPa: the largest bending stress of a cross-beam of section area `area` (cm^2) that takes the force
    reaction (kN) at its mid-span, (R S / 4) / (a^3 / 6), a = sqrt(A), signed as the force; numbers or arrays."""
    metres = np.asarray(area, dtype=float) * CM2
    return np.asarray(reaction, dtype=float) * SPAN / 4 / (metres ** 1.5 / 6) / MPA

@dataclass(frozen=True)
class Solution:
    """One design solved, what a drawing of the beam needs. supports: the places x_i (m); reactions: the forces R_i of
    the cross-beams (kN, upward on the beam); ends: R_A and R_B (kN, upward); x: the stations and the supports, in
    order (m); w: the deflection there (mm, downward); moment: the bending moment there (kN m, sagging); largest: the
    largest |w| (mm), the response of two cross-beams; at: where it is (m); rms: the RMS deflection (mm), the response
    of four and the deflection of two sized."""
    supports: np.ndarray
    reactions: np.ndarray
    ends: tuple
    x: np.ndarray
    w: np.ndarray
    moment: np.ndarray
    largest: float
    at: float
    rms: float

class Beam:
    """The main beam on its cross-beams, for a load, a spring k (RIGID: supports that do not yield), a length, a
    stiffness EI and a number of stations; the supports' places are given at each call, an array (..., n) of designs
    of n supports each, and, where a call takes springs, a stiffness per support (kN/m) broadcast with them, None for
    the beam's k at every support."""

    def __init__(self, load=LOAD, k=SPRING, length=LENGTH, stiffness=STIFFNESS, stations=STATIONS):
        self.pieces = tuple(load)
        self.k = k
        self.length = length
        self.stiffness = stiffness
        self.places, self.coefficients, self.powers = switches(load)
        self.total = float(self.load_integral(length, 1))
        self.free_end_a = float(self.load_integral(length, 2)) / length
        self.free_end_b = self.total - self.free_end_a
        self.free_slope_a = (self.free_end_a * length ** 2 / 6 - float(self.load_integral(length, 4)) / length) / stiffness
        self.stations = np.linspace(0.0, length, stations)
        self.free_at_stations = self.free_deflection(self.stations)
        self.weights = simpson(self.stations)

    def load(self, x):
        """q(x), kN/m downward: the sum of the pieces that cover x (a piece covers its two ends)."""
        x = np.asarray(x, dtype=float)
        q = np.zeros_like(x)
        for start, end, polynomial in self.pieces:
            q = q + np.where((x >= start) & (x <= end), np.polynomial.polynomial.polyval(x, polynomial), 0.0)
        return q

    def load_integral(self, x, n):
        """Q_n(x), the n-th integral of q from 0 to x (n >= 1), kN m^(n - 1): sum c_j j! / (j + n)! <x - a>^(j + n)."""
        x = np.asarray(x, dtype=float)[..., None]
        weights = self.coefficients * np.array([math.factorial(j) / math.factorial(j + n) for j in self.powers])
        return np.sum(weights * np.maximum(x - self.places, 0.0) ** (self.powers + n), axis=-1)

    def free_moment(self, x):
        """M0(x), kN m: the moment of the beam without the cross-beams, R_A0 x - Q_2(x)."""
        return self.free_end_a * np.asarray(x, dtype=float) - self.load_integral(x, 2)

    def free_deflection(self, x):
        """w0(x), m: the deflection of the beam without the cross-beams, theta_A x - (R_A0 x^3 / 6 - Q_4(x)) / EI."""
        x = np.asarray(x, dtype=float)
        return self.free_slope_a * x - (self.free_end_a * x ** 3 / 6 - self.load_integral(x, 4)) / self.stiffness

    def influence(self, x, a):
        """G(x, a), m per kN: the deflection at x of a unit downward load at a, on the beam without the cross-beams."""
        u, v = np.minimum(x, a), np.maximum(x, a)
        return u * (self.length - v) * (2 * self.length * v - v * v - u * u) / (6 * self.length * self.stiffness)

    def influence_moment(self, x, a):
        """m(x, a), kN m per kN: the moment at x of a unit downward load at a, on the beam without the cross-beams."""
        u, v = np.minimum(x, a), np.maximum(x, a)
        return u * (self.length - v) / self.length

    def redundants(self, supports, springs=None):
        """R (..., n), kN: the forces of the cross-beams on the beam, from (F + diag(1 / k_i)) R = w0(x_s), for designs
        (..., n); springs None: k_i = k for all, (F + I / k) R = w0(x_s); else the stiffnesses k_i (..., n), kN/m."""
        supports = np.asarray(supports, dtype=float)
        if springs is None:
            flexibility = self.influence(supports[..., :, None], supports[..., None, :]) + np.eye(supports.shape[-1]) / self.k
        else:
            supports, springs = np.broadcast_arrays(supports, np.asarray(springs, dtype=float))
            compliances = (1.0 / springs)[..., :, None] * np.eye(supports.shape[-1])
            flexibility = self.influence(supports[..., :, None], supports[..., None, :]) + compliances
        solve = solve_two if supports.shape[-1] == 2 else cholesky_solve
        return solve(flexibility, self.free_deflection(supports))

    def lifted(self, supports, reactions, x):
        """sum_j R_j G(x, x_j), m: what the reactions (..., n) of designs (..., n) lift at points x (..., S). G is
        written here in brackets, a unit load at a being a load like the others (step 1 of the method):
            EI G(x, a) = theta(a) x - (L - a) x^3 / (6 L) + <x - a>^3 / 6,   theta(a) = (L - a) (L^2 - (L - a)^2) / (6 L),
        so that the sum over the supports gathers the terms in x and x^3, and only the brackets are left to add, point
        by point."""
        rest = self.length - supports
        slope = np.sum(reactions * rest * (self.length ** 2 - rest ** 2), axis=-1)[..., None] / (6 * self.length)
        share = np.sum(reactions * rest, axis=-1)[..., None] / (6 * self.length)
        beyond = np.maximum(x[..., :, None] - supports[..., None, :], 0.0)
        brackets = (beyond * beyond * beyond @ reactions[..., :, None])[..., 0] / 6
        return (slope * x - share * x ** 3 + brackets) / self.stiffness

    def largest_deflection(self, supports, springs=None):
        """max |w|, mm, over the stations and the supports, for a stack of designs (P, n) on springs (P, n) or None."""
        reactions = self.redundants(supports, springs)
        at_stations = self.free_at_stations - self.lifted(supports, reactions, self.stations)
        at_supports = self.free_deflection(supports) - self.lifted(supports, reactions, supports)
        return MM * np.maximum(np.abs(at_stations).max(axis=-1), np.abs(at_supports).max(axis=-1))

    def rms_deflection(self, supports, springs=None):
        """sqrt((1 / L) integral of w^2 dx), mm, by Simpson's rule on the stations, for a stack of designs (P, n) on
        springs (P, n) or None."""
        reactions = self.redundants(supports, springs)
        at_stations = self.free_at_stations - self.lifted(supports, reactions, self.stations)
        return MM * np.sqrt(np.sum(self.weights * at_stations ** 2, axis=-1) / self.length)

    def rms_and_reactions(self, supports, springs=None):
        """The RMS deflection (mm, as rms_deflection) and the forces R (kN) of a stack of designs (P, n) on springs
        (P, n) or None, from one solve: an array (P, 1 + n), the RMS deflection first."""
        reactions = self.redundants(supports, springs)
        at_stations = self.free_at_stations - self.lifted(supports, reactions, self.stations)
        rms = MM * np.sqrt(np.sum(self.weights * at_stations ** 2, axis=-1) / self.length)
        return np.column_stack([rms, reactions])

    def chunked(self, supports, measure, springs=None):
        """A measure of stacks of designs (P, n) on springs (P, n) or None -> (P) or (P, m), for designs of n supports
        (..., n) on springs broadcast with them or None: an array of shape (...) or (..., m), CHUNK designs at a time."""
        supports = np.asarray(supports, dtype=float)
        if springs is not None:
            supports, springs = np.broadcast_arrays(supports, np.asarray(springs, dtype=float))
            springs = springs.reshape(-1, supports.shape[-1])
        designs = supports.reshape(-1, supports.shape[-1])
        parts = []
        for start in range(0, len(designs), CHUNK):
            part = None if springs is None else springs[start:start + CHUNK]
            parts.append(measure(designs[start:start + CHUNK], part))
        values = np.concatenate(parts) if parts else measure(designs, springs)
        return values.reshape(supports.shape[:-1] + values.shape[1:])

    def response(self, supports, springs=None):
        """The response, max |w| in mm, for designs of n supports (..., n) on springs (..., n) or None: an array of
        shape (...), CHUNK designs at a time."""
        return self.chunked(supports, self.largest_deflection, springs)

    def rms(self, supports, springs=None):
        """The RMS deflection in mm for designs of n supports (..., n) on springs (..., n) or None: an array of shape
        (...), CHUNK designs at a time."""
        return self.chunked(supports, self.rms_deflection, springs)

    def deflection(self, supports, x, springs=None):
        """w(x), mm downward, at points x of any shape, for one design (supports: n places; springs: n or None)."""
        supports = np.asarray(supports, dtype=float)
        x = np.asarray(x, dtype=float)
        w = self.free_deflection(x.ravel()) - self.lifted(supports, self.redundants(supports, springs), x.ravel())
        return MM * w.reshape(x.shape)

    def moment(self, supports, x, springs=None):
        """M(x), kN m sagging, at points x of any shape, for one design (supports: n places; springs: n or None)."""
        supports = np.asarray(supports, dtype=float)
        x = np.asarray(x, dtype=float)
        points = x.ravel()
        lifted = self.influence_moment(points[:, None], supports[None, :]) @ self.redundants(supports, springs)
        return (self.free_moment(points) - lifted).reshape(x.shape)

    def ends(self, supports, reactions):
        """R_A and R_B, kN upward: the free beam's end reactions less the share of each R_j that its lever gives."""
        end_a = self.free_end_a - float(np.sum(reactions * (self.length - supports))) / self.length
        end_b = self.free_end_b - float(np.sum(reactions * supports)) / self.length
        return end_a, end_b

    def solve(self, supports, springs=None):
        """The Solution of one design (supports: n places; springs: n stiffnesses or None): reactions, deflection and
        moment at the stations and the supports, the largest deflection and its place, and the RMS deflection (rms, as
        f4 computes it)."""
        supports = np.asarray(supports, dtype=float)
        if springs is not None:
            springs = np.broadcast_to(np.asarray(springs, dtype=float), supports.shape)
        reactions = self.redundants(supports, springs)
        x = np.union1d(self.stations, supports)
        w = self.deflection(supports, x, springs)
        peak = int(np.argmax(np.abs(w)))
        stack = None if springs is None else springs[None, :]
        return Solution(supports, reactions, self.ends(supports, reactions), x, w, self.moment(supports, x, springs),
                        float(abs(w[peak])), float(x[peak]), float(self.rms_deflection(supports[None, :], stack)[0]))

BEAM = Beam()

def f(x1, x2):
    """The response of the bench, max |w| in mm, for cross-beams at x1 and x2 (m): numbers or arrays of a common shape."""
    x1, x2 = np.broadcast_arrays(np.asarray(x1, dtype=float), np.asarray(x2, dtype=float))
    y = BEAM.response(np.stack([x1, x2], axis=-1))
    return float(y) if y.ndim == 0 else y

def f4(x1, x2, x3, x4):
    """The response of the beam on four cross-beams, the RMS deflection in mm, for cross-beams at x1, x2, x3 and x4 (m):
    numbers or arrays of a common shape."""
    places = np.broadcast_arrays(*(np.asarray(x, dtype=float) for x in (x1, x2, x3, x4)))
    y = BEAM.rms(np.stack(places, axis=-1))
    return float(y) if y.ndim == 0 else y

def sized(x1, x2, A1, A2):
    """The four responses of the beam on two cross-beams sized, at x1 and x2 (m), of section areas A1 and A2 (cm^2), numbers
    or arrays of a common shape, from one solve per design, CHUNK designs at a time: (mass kg, RMS deflection mm,
    stress_1 MPa, stress_2 MPa)."""
    x1, x2, A1, A2 = np.broadcast_arrays(*(np.asarray(x, dtype=float) for x in (x1, x2, A1, A2)))
    springs = stiffness(np.stack([A1, A2], axis=-1))
    solved = BEAM.chunked(np.stack([x1, x2], axis=-1), BEAM.rms_and_reactions, springs)
    values = (mass(A1) + mass(A2), solved[..., 0], stress(solved[..., 1], A1), stress(solved[..., 2], A2))
    return tuple(float(y) if np.ndim(y) == 0 else y for y in values)

def mass_of(x1, x2, A1, A2):
    """The mass of the two cross-beams, kg, for designs as sized takes them: no solve (the places do not weigh)."""
    x1, x2, A1, A2 = np.broadcast_arrays(*(np.asarray(x, dtype=float) for x in (x1, x2, A1, A2)))
    y = mass(A1) + mass(A2)
    return float(y) if np.ndim(y) == 0 else y

def rms_of(x1, x2, A1, A2):
    """The RMS deflection of the main beam, mm, for designs as sized takes them: one solve per design (sized's)."""
    return sized(x1, x2, A1, A2)[1]

def stress_1(x1, x2, A1, A2):
    """The stress of the first cross-beam, MPa, for designs as sized takes them: one solve per design (sized's)."""
    return sized(x1, x2, A1, A2)[2]

def stress_2(x1, x2, A1, A2):
    """The stress of the second cross-beam, MPa, for designs as sized takes them: one solve per design (sized's)."""
    return sized(x1, x2, A1, A2)[3]

def response(supports, springs=None):
    """The response, max |w| in mm, for n cross-beams: supports (..., n), m, on springs (..., n), kN/m, or None; an
    array of shape (...)."""
    return BEAM.response(supports, springs)

def rms(supports, springs=None):
    """The RMS deflection in mm for n cross-beams: supports (..., n), m, on springs (..., n), kN/m, or None; an array
    of shape (...)."""
    return BEAM.rms(supports, springs)

def solve(supports, springs=None):
    """The Solution of one design of the bench's beam: supports, n places in m; springs, n stiffnesses in kN/m or None."""
    return BEAM.solve(supports, springs)

def load(x):
    """The bench's load q(x), kN/m downward, at points x (m)."""
    return BEAM.load(x)
