# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: prognosis.py
# ==============================================================================
"""
How good a metamodel is, in two numbers with the same form and different questions:

    CoD = 1 - SS_E / SS_T                  how well it reproduces the values it was fitted to
    CoP = 1 - SS_E^Prediction / SS_T       how well it predicts values it has not seen

SS_T = sum_i (y_i - mean)^2 is the variation of the simulated values; SS_E = sum_i (y_i - y^_i)^2 the squared errors
of the metamodel at the designs it was fitted to. SS_E^Prediction is the same sum with each y^_i predicted by a
metamodel that did not see the design i: the designs are dealt into k subsets, and each subset is predicted by a
metamodel fitted to the others (k-fold cross-validation). The CoD of an interpolating metamodel is 1 whatever it does
between the designs; the CoP has no such blind spot, and may even be negative (worse than predicting the mean).

- total_variation, squared_errors: SS_T and SS_E;
- coefficient_of_determination, coefficient_of_prognosis: the two numbers;
- folds: the designs dealt at random into k subsets of almost equal size (the sources leave open how the program
  deals them: at random here, from the seed of the caller);
- cross_validation: every value predicted by a metamodel that did not see it.

Reference: T. Most & J. Will, "Sensitivity analysis using the Metamodel of Optimal Prognosis", Weimar Optimization
and Stochastic Days 8.0, 2011 (the two coefficients as optiSLang states them; the subsets are "usually between 5 and
10": FOLDS = 5 here).

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
from statistical_fundamentals.sampling import permutation

FOLDS = 5

def total_variation(values):
    """SS_T: the squared differences of the values to their mean, summed."""
    mean = sum(values) / len(values)
    return sum((y - mean) ** 2 for y in values)

def squared_errors(values, estimates):
    """SS_E: the squared differences between the values and their estimates, summed."""
    return sum((y - estimate) ** 2 for y, estimate in zip(values, estimates))

def coefficient_of_determination(values, fitted):
    """CoD: the share of the variation of the values that the metamodel reproduces at its own designs."""
    return 1 - squared_errors(values, fitted) / total_variation(values)

def coefficient_of_prognosis(values, predictions):
    """CoP: the same share, with every value predicted by a metamodel that did not see it."""
    return 1 - squared_errors(values, predictions) / total_variation(values)

def folds(n, k, random):
    """The designs 0, ..., n - 1 dealt at random into k subsets of almost equal size."""
    order = permutation(n, random)
    return [order[j::k] for j in range(k)]

def cross_validation(points, values, subsets, metamodel):
    """Every value predicted without it: each subset by the metamodel fitted to the designs of the other subsets."""
    predictions = [0.0] * len(points)
    for subset in subsets:
        others = [i for i in range(len(points)) if i not in subset]
        model = metamodel([points[i] for i in others], [values[i] for i in others])
        for i in subset:
            predictions[i] = model(points[i])
    return predictions
