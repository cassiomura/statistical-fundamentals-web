# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: palette.py
# ==============================================================================
"""
The colours of the application, those of Numerical Fundamentals: a slate screen (the LAB's, the face of the whole
product: fundamentals_ui/theme.py), cyan as the main accent, and the hues of 3Blue1Brown's manim (BLUE_C, YELLOW_C,
TEAL_C, ...) as discreet extra colours. Each colour carries one meaning in a bench: blue (cyan) a design point or
the main object, yellow what is being computed now, teal what is right (an interval holding exactly one point), red
what is wrong (an empty interval: drawn hollow too, never told by colour alone), gold an excess (an interval holding
two points or more), slate a reference drawn light. Plain data, shared by the window (gui.style), the cover and the
laboratories.
"""
from fundamentals_ui import theme

BACKGROUND = theme.SURFACE # the page, and the figures drawn on it
WHITE = "#ECECEC"
GREY = "#8A939C"
DARK_GREY = "#434A51"
SLATE = "#C3CCD5"          # a reference curve (the original function, an exact solution): light, under the answer
BLUE = "#58C4DD"
YELLOW = "#FFFF00"
TEAL = "#5CD0B3"
RED = "#FC6255"
GOLD = "#F0AC5F"
PURPLE = "#9A72AC"

def tone(red: int, green: int, blue: int) -> str:
    """A material of the pages: BACKGROUND lifted by the same steps as before the LAB's colours, so that the surfaces
    keep telling themselves apart by tone (the steps were measured on the former background, #191C20)."""
    channels = (int(BACKGROUND[i:i + 2], 16) + step for i, step in zip((1, 3, 5), (red, green, blue), strict=True))
    return "#" + "".join(f"{min(max(channel, 0), 255):02X}" for channel in channels)

# Materials of the pages: surfaces told apart by tone, not by borders
CARD = tone(5, 6, 6)            # a raised card: the laboratories and their figures
TRACK = tone(13, 16, 17)        # the track of a segmented control, a quiet button
HOVER = tone(19, 23, 24)        # a control under the pointer
PRESSED = tone(27, 32, 35)      # a control while it is pressed: shown on the press, not on the release
PILL = tone(33, 39, 43)         # the chosen segment, a lighter material sliding on the track
LIFT = tone(10, 12, 16)         # a card under the pointer
ALERT_TINT = tone(33, 18, -9)   # the clipping alert over a plot

# The response surface y = f(x1, x2): a sequential ramp from the page's depth to the manim hues, low values dark
SURFACE_RAMP = ("#1B3442", "#24607A", "#3A93AE", "#58C4DD", "#9EDDC4", "#F4E58C")
