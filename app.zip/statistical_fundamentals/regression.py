# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: regression.py
# ==============================================================================
"""
Polynomial regression, the first metamodel: one polynomial for the whole design space, y^(u) = p(u)^T c, its
coefficients c those that minimize the sum of the squared differences to the N values already simulated (least
squares). The points are in the unit hypercube, as the sampling leaves them (sampling.py).

- basis: the terms p(u) of the polynomial, for the three orders of step 2: "linear" (1 and each coordinate),
  "pure_quadratic" (also each square) and "quadratic" (also each product of two coordinates, the mixed terms);
- least_squares: the coefficients, from the normal equations (B^T W B) c = B^T W y, solved by Cholesky (linear.py).
  B has one row p(u_i) per point; W is diagonal, one weight per point (all 1 here: the weights are what the moving
  least squares change, moving_least_squares.py);
- polynomial: the value of the fitted polynomial at a point; metamodel: the fitted polynomial as a function;
- influence: how much each simulated value counts in the prediction at a point. Every metamodel of step 2 is
  linear in the values, y^(u) = sum_i a_i(u) y_i: the a_i(u) are the weight of each design at the point u.

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
from statistical_fundamentals.linear import cholesky, cholesky_solve, dot

ORDERS = ("linear", "pure_quadratic", "quadratic")

def basis(u, order):
    """The terms of the polynomial at the point u, in the order of its coefficients."""
    terms = [1.0]
    for x in u:
        terms.append(x)
    if order in ("pure_quadratic", "quadratic"):
        for x in u:
            terms.append(x * x)
    if order == "quadratic":
        for j in range(len(u)):
            for k in range(j + 1, len(u)):
                terms.append(u[j] * u[k])
    return terms

def normal_matrix(rows, weights):
    """B^T W B: the matrix of the normal equations, from the rows p(u_i) of B and the weights of the points."""
    m = len(rows[0])
    A = [[0.0] * m for j in range(m)]
    for w, row in zip(weights, rows):
        for j in range(m):
            for k in range(m):
                A[j][k] = A[j][k] + w * row[j] * row[k]
    return A

def least_squares(points, values, order, weights=None):
    """The coefficients c that minimize sum_i w_i (y_i - p(u_i)^T c)^2."""
    if weights is None:
        weights = [1.0] * len(points)
    rows = [basis(u, order) for u in points]
    m = len(rows[0])
    b = [0.0] * m
    for w, row, y in zip(weights, rows, values):
        for j in range(m):
            b[j] = b[j] + w * row[j] * y
    L = cholesky(normal_matrix(rows, weights))
    return cholesky_solve(L, b)

def polynomial(c, u, order):
    """The value at u of the polynomial of coefficients c."""
    return dot(c, basis(u, order))

def metamodel(points, values, order):
    """The polynomial fitted to the values, as a function of the point."""
    c = least_squares(points, values, order)
    return lambda u: polynomial(c, u, order)

def influence(u, points, order, weights=None):
    """The a_i(u) of the prediction y^(u) = sum_i a_i(u) y_i: a_i = w_i p(u_i)^T z, with (B^T W B) z = p(u)."""
    if weights is None:
        weights = [1.0] * len(points)
    rows = [basis(point, order) for point in points]
    L = cholesky(normal_matrix(rows, weights))
    z = cholesky_solve(L, basis(u, order))
    return [w * dot(row, z) for w, row in zip(weights, rows)]
