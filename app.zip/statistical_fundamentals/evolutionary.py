# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                         Title: evolutionary.py
# ==============================================================================
"""
The evolutionary algorithm (EA), the best-known optimizer of the nature-inspired family: a population of designs
that, generation after generation, breeds new designs from its better members and keeps the best. It never uses a
gradient, only the value of each simulation, so it needs no smoothness, and it explores the whole design space at
once. The price is the number of simulations: every child is one run of the solver.

All designs live in the unit hypercube [0, 1]^d of the d parameters (the unit square for two; the lab maps them to the
bounds of the parameters); f(u) is one simulation and returns the value to minimize.

    start       mu designs, step 1's Latin hypercube in d dimensions; each one simulated
    generation  mu children, made in pairs:
                tournament   two designs drawn at random from the population (with replacement); the one with the
                             lower value is a parent. Done twice, it gives the two parents of a pair;
                sbx          with probability CROSSOVER the pair is crossed, coordinate by coordinate, by the simulated
                             binary crossover; otherwise the children are copies of their parents;
                mutation     every coordinate of every child moves by a Gaussian step of standard deviation sigma;
                each child is simulated
    survival    of the mu parents and the mu children together, the mu lowest values stay (the best design is
                never lost: the algorithm is elitist)
    sigma       the mutation step, going linearly from SIGMA_FIRST (the first generation) to SIGMA_LAST (the last):
                large steps to explore first, small ones to refine at the end

Simulated binary crossover (Deb & Agrawal 1995) imitates, on real numbers, the single-point crossover of binary
genetic algorithms: for the parents p and q and a random u in [0, 1), the spread factor is

    beta = (2 u)^(1 / (eta + 1))                    if u <= 1/2
    beta = (1 / (2 (1 - u)))^(1 / (eta + 1))        otherwise
    c1 = ((1 + beta) p + (1 - beta) q) / 2          c2 = ((1 - beta) p + (1 + beta) q) / 2

so c1 + c2 = p + q (the mean of the parents is kept) and |c1 - c2| = beta |p - q|. With beta near 1 the children
are near the parents; the larger eta, the closer to 1 the likely values of beta. Every coordinate draws its own u.

A binary tournament selects better designs without ranking the whole population: the best of mu members wins with
probability 1 - (1 - 1/mu)^2, the worst only with 1/mu^2 (Goldberg & Deb 1991).

The values eta = 10 (DISTRIBUTION), the crossover probability 0.9 (CROSSOVER), the schedule of sigma and the clipping
of a child that left the unit hypercube back onto its face are this app's choices: optiSLang documents no defaults
for them; mu and the number of generations are the same whatever d. The random numbers come from a random.Random given
by the caller (a seed makes a run reproducible): only the start population depends on d, so with two parameters a run
draws the same numbers, in the same order, as before d was an argument.
Readable cores: plain lists and loops, shown in the window as the method's code.

References:
J. H. Holland, Adaptation in Natural and Artificial Systems, University of Michigan Press, 1975.
D. E. Goldberg, Genetic Algorithms in Search, Optimization, and Machine Learning, Addison-Wesley, 1989.
D. E. Goldberg & K. Deb, "A comparative analysis of selection schemes used in genetic algorithms", in G. J. E.
Rawlins (ed.), Foundations of Genetic Algorithms, Morgan Kaufmann, 1991, 69-93.
K. Deb & R. B. Agrawal, "Simulated binary crossover for continuous search space", Complex Systems 9(2), 115-148, 1995.
"""
from statistical_fundamentals.sampling import latin_hypercube

CROSSOVER = 0.9
DISTRIBUTION = 10.0
SIGMA_FIRST = 0.10
SIGMA_LAST = 0.005
GENERATIONS = 30

def tournament(values, random):
    """The index of a parent: two members drawn at random, the lower value wins (a tie goes to the first drawn)."""
    a = random.randrange(len(values))
    b = random.randrange(len(values))
    if values[b] < values[a]:
        return b
    return a

def sbx(p, q, eta, random):
    """Two children of the parents p and q by the simulated binary crossover (Deb & Agrawal 1995), kept in [0, 1]."""
    first = []
    second = []
    for k in range(len(p)):
        a = p[k]
        b = q[k]
        u = random.random()
        if u <= 0.5:
            beta = (2 * u) ** (1 / (eta + 1))
        else:
            beta = (1 / (2 * (1 - u))) ** (1 / (eta + 1))
        c = ((1 + beta) * a + (1 - beta) * b) / 2
        d = ((1 - beta) * a + (1 + beta) * b) / 2
        first.append(min(1.0, max(0.0, c)))
        second.append(min(1.0, max(0.0, d)))
    return first, second

def mutation(child, sigma, random):
    """The child with every coordinate moved by a Gaussian step of standard deviation sigma, kept in [0, 1]."""
    moved = []
    for c in child:
        moved.append(min(1.0, max(0.0, c + random.gauss(0, sigma))))
    return moved

def sigma_of(k, generations):
    """The mutation step of generation k (0 is the first): linear from SIGMA_FIRST to SIGMA_LAST."""
    if generations < 2:
        return SIGMA_FIRST
    return SIGMA_FIRST + (SIGMA_LAST - SIGMA_FIRST) * k / (generations - 1)

def survivors(points, values, mu):
    """The indices of the mu lowest values, in the order of the list (a tie keeps the earlier design). Only the
    values decide who survives; the points are given with them, as in every other step, and not looked at."""
    ranked = sorted(range(len(values)), key=lambda i: (values[i], i))
    return sorted(ranked[:mu])

def generation(f, population, values, sigma, random):
    """One generation: mu children by tournament, SBX and mutation, simulated, and the mu survivors of the 2 mu."""
    mu = len(population)
    pairs = []
    crossed = []
    children = []
    while len(children) < mu:
        i = tournament(values, random)
        j = tournament(values, random)
        pairs.append((i, j))
        if random.random() < CROSSOVER:
            c1, c2 = sbx(population[i], population[j], DISTRIBUTION, random)
        else:
            c1, c2 = list(population[i]), list(population[j])
        crossed.append(c1)
        crossed.append(c2)
        children.append(mutation(c1, sigma, random))
        children.append(mutation(c2, sigma, random))
    crossed = crossed[:mu]
    children = children[:mu]
    children_values = [f(child) for child in children]
    kept = survivors(population + children, values + children_values, mu)
    return {"pairs": pairs, "crossed": crossed, "children": children,
            "children_values": children_values, "kept": kept, "sigma": sigma}

def evolutionary(f, mu, random, d=2):
    """The whole run in d parameters: the start population, then GENERATIONS generations, one record each
    (mu (1 + GENERATIONS) runs)."""
    population = latin_hypercube(mu, d, random)
    values = [f(point) for point in population]
    records = [{"population": population, "values": values}]
    for k in range(GENERATIONS):
        record = generation(f, population, values, sigma_of(k, GENERATIONS), random)
        record["population"] = population
        record["values"] = values
        records.append(record)
        pool = population + record["children"]
        pool_values = values + record["children_values"]
        population = [pool[i] for i in record["kept"]]
        values = [pool_values[i] for i in record["kept"]]
    return records
