# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                       Title: response_surface.py
# ==============================================================================
"""
The adaptive response surface method (ARSM), the optimizer of the response surface family: instead of asking the
simulation where the minimum is, fit a cheap polynomial to a few simulations and minimize the polynomial. Only near the
optimum is a quadratic a good picture of the response, so the polynomial is fitted in a small region, and the region
follows the optimum. One iteration:

    1. simulate m = designs_for(n) designs, a Latin hypercube (sampling.py) inside the region of interest;
    2. fit a quadratic polynomial to them by least squares (regression.py), in the coordinates t in [0, 1] of the
       region itself, t = (u - low) / width, well conditioned however small the region;
    3. minimize the polynomial over the region (quadratic.py: exact, even when it curves down somewhere) and simulate
       that optimum: the true response there is what the polynomial only predicted;
    4. move and resize the region (pan and zoom, below), centred on the optimum, and repeat.

Pan and zoom (Stander & Craig's simple domain reduction scheme): the move of the optimum from the point the region was
centred on (the previous optimum), in half-widths, d_i = 2 (x_i - anchor_i) / r_i, clamped to [-1, 1]. With d and the
previous move d', per coordinate i,

    c_i = d_i d'_i,  c^_i = sqrt(|c_i|) sign(c_i)           +1 same direction as before, -1 reversing it, 0 no move
    gamma_i = (gamma_pan (1 + c^_i) + gamma_osc (1 - c^_i)) / 2
    lambda_i = eta + |d_i| (gamma_i - eta),   r_i <- lambda_i r_i

In words: when the optimum hardly leaves the anchor (d = 0) the polynomial already points at it and the region shrinks to
eta = 60 %; a full move in the same direction as the last one (d = 1, c^ = 1) keeps the region its size, which pans
along to follow the optimum; a move that reverses the last one (an oscillation) shrinks it, to 60 %. Between these
the factor lambda grows with the move and with how consistent it is. The region stays inside the unit hypercube: where its
centre would put it across an edge it is shifted, not cut (subregion). The method stops when the largest width falls
below SMALLEST (converged) or after ITERATIONS iterations.

What is taken here, and what the sources say:
- optiSLang's ARSM fits a linear or quadratic polynomial on a D-optimal design with 50 % more designs than coefficients,
  and moves, shrinks or expands the region (Ansys, Methods for Parametric Design Optimization, 2026 R1; the manual gives
  no factors). Here the design is step 1's Latin hypercube with the same 50 % more (FACTOR = 1.5): a quadratic of n
  variables has (n + 1)(n + 2) / 2 coefficients, so m = ceil(1.5 (n + 1)(n + 2) / 2) designs (designs_for), 9 for the
  6 coefficients of two variables, 23 for the 15 of four; and the polynomial is step 2's quadratic;
- the pan and zoom, with gamma_pan = 1, gamma_osc = 0.6, eta = 0.6 (the values of Stander & Craig's tests), are theirs;
- two details are this app's: d is clamped to [-1, 1] (a region shifted at the box's edge is not centred on its anchor,
  so the move could pass 1 and the region would expand; the clamp keeps eta <= lambda <= 1), and c^ = 0 at the first
  iteration, where there is no previous move (the paper is silent). The first region is centred on the start design.
  An optimum that stays on the wall of the box is no move (d = 0), so a region pinned there still shrinks.

Each iteration is returned as a record, and the stages of it can be drawn from the record alone: "anchor" (the point
the region is centred on: the start, then each optimum), "low" and "width" (the region used), "designs" and "values",
"coefficients" (in the coordinates t), "optimum" and "optimum_value", "move" (d), "factors" (lambda), "next_width".
Each iteration costs m + 1 simulations, and the start one more: the start is a design of the study, simulated like
any other (it may be the best one found, and the laboratory counts it), though the method itself never uses its value.

Reference: N. Stander & K. J. Craig, "On the robustness of a simple domain reduction scheme for simulation-based
optimization", Engineering Computations 19(4), 431-450, 2002.

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
import math

from statistical_fundamentals import regression
from statistical_fundamentals.quadratic import box_minimum
from statistical_fundamentals.sampling import latin_hypercube

WIDTH = 0.5
FACTOR = 1.5
PAN = 1.0
OSCILLATION = 0.6
ZOOM = 0.6
SMALLEST = 1e-3
ITERATIONS = 30

def designs_for(n):
    """The designs of one iteration in n variables: FACTOR times the (n + 1)(n + 2) / 2 coefficients of the quadratic,
    rounded up (9 for two variables, 23 for four)."""
    coefficients = (n + 1) * (n + 2) // 2
    return math.ceil(FACTOR * coefficients)

def subregion(centre, width):
    """The lower corner of the region of the given width around the centre, shifted, not cut, to stay in [0, 1]."""
    low = []
    for x, r in zip(centre, width):
        low.append(min(max(x - r / 2, 0.0), 1.0 - r))
    return low

def local_quadratic(c):
    """The gradient g and the matrix H of the quadratic c0 + g^T t + (1/2) t^T H t, from the coefficients of the
    regression (the order 1, t_j, t_j^2, t_j t_k for j < k)."""
    n = 1
    while 1 + 2 * n + n * (n - 1) // 2 < len(c):
        n = n + 1
    g = [c[1 + j] for j in range(n)]
    H = [[0.0] * n for j in range(n)]
    for j in range(n):
        H[j][j] = 2 * c[1 + n + j]
    position = 1 + 2 * n
    for j in range(n):
        for k in range(j + 1, n):
            H[j][k] = c[position]
            H[k][j] = c[position]
            position = position + 1
    return g, H

def region_move(optimum, anchor, width):
    """d_i: the move of the optimum from the anchor of the region, in half-widths, clamped to [-1, 1]."""
    move = []
    for x, a, r in zip(optimum, anchor, width):
        move.append(min(max(2 * (x - a) / r, -1.0), 1.0))
    return move

def zoom_factors(move, previous):
    """lambda_i of the pan and zoom, per coordinate, from the move d and the previous move (None at the first iteration)."""
    factors = []
    for i in range(len(move)):
        c_hat = 0.0
        if previous is not None:
            c = move[i] * previous[i]
            c_hat = math.copysign(math.sqrt(abs(c)), c)
        gamma = (PAN * (1 + c_hat) + OSCILLATION * (1 - c_hat)) / 2
        factors.append(ZOOM + abs(move[i]) * (gamma - ZOOM))
    return factors

def pan_and_zoom(move, previous, width):
    """The widths of the next region: r_i times lambda_i."""
    factors = zoom_factors(move, previous)
    return [r * lam for r, lam in zip(width, factors)]

def arsm(f, start, random):
    """The run: the iterations (one record each) and why it stopped, "converged" or "iterations"."""
    n = len(start)
    m = designs_for(n)
    f(start)
    anchor = list(start)
    width = [WIDTH] * n
    previous = None
    iterations = []
    stop = "iterations"
    for k in range(ITERATIONS):
        low = subregion(anchor, width)
        t = latin_hypercube(m, n, random)
        designs = [[low[i] + width[i] * point[i] for i in range(n)] for point in t]
        values = [f(u) for u in designs]
        coefficients = regression.least_squares(t, values, "quadratic")
        g, H = local_quadratic(coefficients)
        t_best = box_minimum(g, H, [0.0] * n, [1.0] * n)
        optimum = [low[i] + width[i] * t_best[i] for i in range(n)]
        optimum_value = f(optimum)
        move = region_move(optimum, anchor, width)
        factors = zoom_factors(move, previous)
        next_width = pan_and_zoom(move, previous, width)
        iterations.append({"anchor": anchor, "low": low, "width": width,
                           "designs": designs, "values": values,
                           "coefficients": coefficients, "optimum": optimum,
                           "optimum_value": optimum_value, "move": move,
                           "factors": factors, "next_width": next_width})
        if max(next_width) < SMALLEST:
            stop = "converged"
            break
        anchor = optimum
        width = next_width
        previous = move
    return iterations, stop
