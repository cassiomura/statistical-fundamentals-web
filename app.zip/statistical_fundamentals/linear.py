# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: linear.py
# ==============================================================================
"""
The linear algebra the metamodels stand on: a symmetric positive definite system A x = b, solved by Cholesky's
factorization A = L L^T and two triangular systems. Both systems of step 2 have that form: the normal equations
of a least squares fit (regression.py, moving_least_squares.py) and the correlation matrix of Kriging (kriging.py).

Matrices are lists of rows, vectors are lists. No inverse is ever formed: a system is solved. A matrix that is not
positive definite (points that repeat, fewer points than coefficients, a weighting that leaves too few designs) is
refused with an ArithmeticError, which the laboratory says on its figure. In floating point the exact zero pivot of a
singular matrix comes out as a small number of either sign, so a pivot below SINGULAR times its diagonal entry is
refused too: past that the solution would be rounding noise, not the answer.

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
import math

SINGULAR = 1e-9

def cholesky(A):
    """The lower triangular L with A = L L^T, for A symmetric positive definite (only its lower half is read)."""
    n = len(A)
    L = [[0.0] * n for i in range(n)]
    for j in range(n):
        pivot = A[j][j] - sum(L[j][k] ** 2 for k in range(j))
        if pivot <= SINGULAR * A[j][j]:
            raise ArithmeticError("the matrix is not positive definite")
        L[j][j] = math.sqrt(pivot)
        for i in range(j + 1, n):
            L[i][j] = (A[i][j] - sum(L[i][k] * L[j][k] for k in range(j))) / L[j][j]
    return L

def forward_substitution(L, b):
    """The solution of L y = b, L lower triangular: from the first equation down."""
    n = len(b)
    y = [0.0] * n
    for i in range(n):
        y[i] = (b[i] - sum(L[i][j] * y[j] for j in range(i))) / L[i][i]
    return y

def back_substitution(L, y):
    """The solution of L^T x = y, L lower triangular: from the last equation up."""
    n = len(y)
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = (y[i] - sum(L[j][i] * x[j] for j in range(i + 1, n))) / L[i][i]
    return x

def cholesky_solve(L, b):
    """The solution of A x = b from the factor L of A = L L^T: L y = b, then L^T x = y."""
    return back_substitution(L, forward_substitution(L, b))

def dot(a, b):
    return sum(x * y for x, y in zip(a, b))
