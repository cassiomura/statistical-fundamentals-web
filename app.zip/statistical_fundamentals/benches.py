# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: benches.py
# ==============================================================================
"""
The benches and the steps of the study each one tells. A bench is one response y = f(x1, x2) of functions.RESPONSES
(the same keys, the same order); on it the reader goes through the three steps of an optimization study, the result of
a step being what the next one works on:

    doe             the design of experiments: N designs placed in the design space, then simulated
    metamodel       a cheap function fitted to those designs and their values, to stand in for the simulation
    optimization    the design of least response, sought on the metamodel and validated with one real simulation

A bench is known by its key in the code and in the keys of its texts ("bench.<key>.challenge"); the reader sees its label
and its title, the name of the response, which is a person's name and is never translated (TITLES). A step is known by
its key ("step.<key>.title"), which is also the key of its laboratory (explorers.LABS). The state of a bench's study is
explorers/study.py.
"""
from dataclasses import dataclass

from statistical_fundamentals.functions import RESPONSES

@dataclass(frozen=True)
class Bench:
    key: str                    # the key of its response (functions.RESPONSES) and of its texts
    title: str                  # the name of its response, the same in every language
    label: str                  # what the bar shows before the title

TITLES = {"branin": "Branin", "himmelblau": "Himmelblau", "rosenbrock": "Rosenbrock"}       # names of people: never translated

BENCHES = {key: Bench(key, TITLES[key], str(number)) for number, key in enumerate(RESPONSES, start=1)}

STEPS = ("doe", "metamodel", "optimization")
