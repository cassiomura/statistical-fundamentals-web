# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: benches.py
# ==============================================================================
"""
The benches and the steps of the study each one tells. A bench is a response of functions.RESPONSES (the same keys, the
same order): one response y = f(x1, ..., xd), or several of one simulation (functions.Response.outputs: two objectives
and constraints); on it the reader goes through the three steps of an optimization study, the result of a step being
what the next one works on:

    doe             the design of experiments: N designs placed in the design space, then simulated
    metamodel       a cheap function fitted to those designs and their values, to stand in for the simulation
    optimization    the design of least response (with two objectives, the front of their compromises), sought on the
                    metamodel and validated with real simulations (one x*; K designs of the front)

A bench is known by its key in the code and in the keys of its texts ("bench.<key>.challenge"); the reader sees its
label and its title. The title the reader sees is the concept the bench adds, in the catalogs ("bench.<key>.title":
"Test function", "Engineering case", "Multidimensional", "Multi-objective", and their Portuguese). This module holds no
text: TITLES, and Bench.title with it, keep the name of every bench's RESPONSE in English (Branin, Beam, Beam 4D, Beam
Pareto), the name the code and the documents know it by and a fallback no reader is shown; every reader asks
explorers/responses.title, the title in the language chosen. A step is known by its key
("step.<key>.title"), which is also the key of its laboratory (explorers.LABS). The state of a bench's study is
explorers/study.py. BENCHES is what the cover, the window, the bar and the page show, every response of
RESPONSES in its order, labelled from "1".
"""
from dataclasses import dataclass

from statistical_fundamentals.functions import RESPONSES

@dataclass(frozen=True)
class Bench:
    key: str                    # the key of its response (functions.RESPONSES) and of its texts
    title: str                  # the name of its response in English: never shown (the reader's is responses.title)
    label: str                  # what the bar shows before the title

TITLES = {"branin": "Branin", "beam": "Beam", "beam4": "Beam 4D",   # the responses' names, in English; the titles the
          "beam_pareto": "Beam Pareto"}                             # reader sees are the catalogs' (bench.<key>.title)

BENCHES = {key: Bench(key, TITLES[key], str(number)) for number, key in enumerate(RESPONSES, start=1)}

STEPS = ("doe", "metamodel", "optimization")
