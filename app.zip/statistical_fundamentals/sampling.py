# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: sampling.py
# ==============================================================================
"""
The design of experiments (DoE): where in the design space the N designs of a study are placed before any simulation
runs. Every sample lives in the unit hypercube [0, 1)^d, one coordinate per parameter, and is mapped to the bounds of
the parameters only at the end (scaled): the sampling never looks at the response.

- monte_carlo: plain random sampling, every coordinate of every point an independent U(0, 1);
- latin_hypercube: McKay, Beckman & Conover (1979). Each axis is divided into N intervals of equal probability; a
  random permutation of the intervals, one per axis, gives each point its interval on that axis, so that every
  interval of every axis holds exactly one point; inside its cell the point is placed at random;
- permutation: the Fisher-Yates shuffle, the random order of the intervals of one axis.

The random numbers come from a random.Random given by the caller (a seed makes a sample reproducible). Readable
cores: plain lists and loops, shown in the window as the method's code.

Reference: M. D. McKay, R. J. Beckman & W. J. Conover, "A comparison of three methods for selecting values of input
variables in the analysis of output from a computer code", Technometrics 21(2), 239-245, 1979.
"""

def permutation(n, random):
    """The numbers 0, 1, ..., n - 1 in a random order, every order equally likely (Fisher-Yates shuffle)."""
    order = list(range(n))
    for i in range(n - 1, 0, -1):
        j = random.randint(0, i)
        order[i], order[j] = order[j], order[i]
    return order

def latin_hypercube(n, d, random):
    """N points in [0, 1)^d, exactly one in each of the N intervals of every axis (McKay et al. 1979)."""
    intervals = [permutation(n, random) for j in range(d)]
    sample = []
    for i in range(n):
        point = []
        for j in range(d):
            k = intervals[j][i]
            point.append((k + random.random()) / n)
        sample.append(point)
    return sample

def monte_carlo(n, d, random):
    """N points in [0, 1)^d, every coordinate drawn independently of all the others."""
    sample = []
    for i in range(n):
        point = []
        for j in range(d):
            point.append(random.random())
        sample.append(point)
    return sample

def scaled(sample, bounds):
    """The sample mapped from the unit hypercube to the bounds of the parameters: x = a + (b - a) u."""
    designs = []
    for point in sample:
        design = []
        for u, (a, b) in zip(point, bounds):
            design.append(a + (b - a) * u)
        designs.append(design)
    return designs
