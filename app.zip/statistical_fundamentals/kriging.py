# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: kriging.py
# ==============================================================================
"""
Ordinary Kriging, the third metamodel: the response read as a constant mean plus a random field whose values at two
points are the more alike the closer the points are,

    R(u_i, u_j) = exp(-theta |u_i - u_j|^2)             the correlation (Gaussian, the same in every direction)
    mu = (1^T R^-1 y) / (1^T R^-1 1)                    the mean, by generalized least squares
    y^(u) = mu + r(u)^T R^-1 (y - mu 1)                 the prediction, r(u) the correlations of u with the designs

At a design r(u) is a column of R, so the prediction is the simulated value itself: Kriging interpolates (up to the
nugget, below). theta sets
how fast the correlation falls with the distance (at 1 / sqrt(theta) it is 1/e): it is chosen as the value that makes
the simulated values most likely (log_likelihood), not by the fit, which is always exact. Distances are measured in
the unit hypercube.

- correlation, correlation_matrix: R, with NUGGET added to its diagonal so that its factorization exists in floating
  point when designs are strongly correlated. The prediction at the design i is then y_i - NUGGET pull_i, not y_i:
  a miss of a part in 10^10 of the response's range or less while the designs are weakly correlated, which grows
  with the pull where R is nearly singular (at the least theta of the laboratory, with 20 designs, up to about half
  a percent of the range). Where R is singular to the working precision it is refused (linear.SINGULAR);
- kriging: the mean and the vector R^-1 (y - mu 1), all a prediction needs; kriging_prediction: the prediction;
  metamodel: the two together, as a function of the point;
- log_likelihood: the concentrated log-likelihood of theta, -(n/2) ln(sigma^2) - (1/2) ln|R|, with
  sigma^2 = (y - mu 1)^T R^-1 (y - mu 1) / n and ln|R| from the diagonal of the Cholesky factor;
- influence: how much each simulated value counts in a prediction, y^(u) = sum_i a_i(u) y_i.

R is symmetric positive definite: every system is solved by Cholesky (linear.py), no inverse is formed.

References: J. Sacks, W. J. Welch, T. J. Mitchell & H. P. Wynn, "Design and Analysis of Computer Experiments",
Statistical Science 4(4), 409-423, 1989. A. Forrester, A. Sobester & A. Keane, Engineering Design via Surrogate
Modelling, Wiley, 2008. The method is named after D. G. Krige, "A statistical approach to some basic mine valuation
problems on the Witwatersrand", Journal of the Chemical, Metallurgical and Mining Society of South Africa 52(6),
119-139, 1951.

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
import math

from statistical_fundamentals.linear import cholesky, cholesky_solve, dot

NUGGET = 1e-10

def correlation(h, theta):
    """The correlation of the response at two points a distance h apart."""
    return math.exp(-theta * h ** 2)

def correlation_matrix(points, theta):
    """R: the correlation of every pair of designs, with the nugget on its diagonal."""
    n = len(points)
    R = [[0.0] * n for i in range(n)]
    for i in range(n):
        for j in range(n):
            R[i][j] = correlation(math.dist(points[i], points[j]), theta)
        R[i][i] = R[i][i] + NUGGET
    return R

def kriging(points, values, theta):
    """The mean mu and the vector R^-1 (y - mu 1) of ordinary Kriging."""
    L = cholesky(correlation_matrix(points, theta))
    ones = [1.0] * len(points)
    R_y = cholesky_solve(L, values)
    R_1 = cholesky_solve(L, ones)
    mu = sum(R_y) / sum(R_1)
    pull = [a - mu * b for a, b in zip(R_y, R_1)]
    return mu, pull

def kriging_prediction(u, points, mu, pull, theta):
    """The prediction at u: the mean plus the pull of each design, by its correlation with u."""
    r = [correlation(math.dist(u, point), theta) for point in points]
    return mu + dot(r, pull)

def metamodel(points, values, theta):
    """Ordinary Kriging of the values, as a function of the point."""
    mu, pull = kriging(points, values, theta)
    return lambda u: kriging_prediction(u, points, mu, pull, theta)

def log_likelihood(points, values, theta):
    """The concentrated log-likelihood of theta: larger, the simulated values are more likely under that correlation."""
    n = len(points)
    L = cholesky(correlation_matrix(points, theta))
    R_y = cholesky_solve(L, values)
    R_1 = cholesky_solve(L, [1.0] * n)
    mu = sum(R_y) / sum(R_1)
    variance = sum((y - mu) * (a - mu * b) for y, a, b in zip(values, R_y, R_1)) / n
    log_determinant = 2 * sum(math.log(L[i][i]) for i in range(n))
    return -n / 2 * math.log(variance) - log_determinant / 2

def influence(u, points, theta):
    """The a_i(u) of the prediction y^(u) = sum_i a_i(u) y_i: R^-1 r(u), plus what the mean takes from every value."""
    L = cholesky(correlation_matrix(points, theta))
    r = [correlation(math.dist(u, point), theta) for point in points]
    R_r = cholesky_solve(L, r)
    R_1 = cholesky_solve(L, [1.0] * len(points))
    share = (1 - sum(R_r)) / sum(R_1)
    return [a + share * b for a, b in zip(R_r, R_1)]
