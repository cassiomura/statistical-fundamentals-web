# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: measures.py
# ==============================================================================
"""
What a sample of the unit hypercube is worth before any simulation runs, measured on the sample itself:

- interval_counts: how many points fall in each of the N equal intervals of one axis (the Latin property: one each);
- empty_intervals: how many intervals of one axis no point visits;
- correlation: Pearson's coefficient between two columns of the sample; the parameters are independent, so a sample
  that represents them well has a correlation near 0;
- smallest_distance: the least distance between two points (the maximin criterion: larger is better spread).

Readable cores, shown in the window as the measures' code.
"""
import math

def interval_counts(values, n):
    """How many of the values (in [0, 1)) fall in each of the n intervals [k/n, (k + 1)/n)."""
    counts = [0] * n
    for u in values:
        k = min(int(u * n), n - 1)
        counts[k] = counts[k] + 1
    return counts

def empty_intervals(values, n):
    """How many of the n intervals of [0, 1) hold none of the values."""
    return sum(1 for count in interval_counts(values, n) if count == 0)

def correlation(xs, ys):
    """Pearson's correlation coefficient: the covariance of x and y over the product of their standard deviations."""
    n = len(xs)
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    sxy = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    sxx = sum((x - mean_x) ** 2 for x in xs)
    syy = sum((y - mean_y) ** 2 for y in ys)
    return sxy / math.sqrt(sxx * syy)

def smallest_distance(sample):
    """The least Euclidean distance between two points of the sample."""
    smallest = math.inf
    for i in range(len(sample)):
        for j in range(i + 1, len(sample)):
            smallest = min(smallest, math.dist(sample[i], sample[j]))
    return smallest
