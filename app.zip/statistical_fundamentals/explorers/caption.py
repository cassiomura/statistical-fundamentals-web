# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: caption.py
# ==============================================================================
"""
The caption of the 3D view's card, the same in the three steps of a bench (explorers/panels.py: the block Plan.formula,
at the card's foot under its hairline, Plan.rule): the formula of the response as a paper sets it (panels.typeset), or,
for a response that is a simulation and has no formula (explorers/responses.has_formula: the beam, on two cross-beams
or more), the LIVING drawing of its problem (explorers/sketch.py) with one simulated design in focus. The three
laboratories make it through here and nowhere else, so that the caption is one thing drawn alike in the three steps; it
lives in a module of its own because it joins what the labs share and cannot import each other through: the plan's
block (panels), the formula (responses), the drawing (sketch, which imports panels) and the texts of the language
chosen (i18n; panels and sketch hold none).

`drawing(function)` is the height of the caption's block a bench asks the plan for (panels.arrangement's `drawing`):
sketch.HEIGHT for a bench drawn, never trimmed; None for a formula, whose block is panels' own (formula_room, trimmed
in a short corner). The three steps pass the same, so that they share one plan; the benches with a formula keep, to the
pixel, the boxes they had.

`Caption(figure, plan, heads, function, pair=None)`, made once per layout with the lab's axes: the formula's Text
(`written`, at panels.FORMULA_PX: the card's subtitle in the window's corner of one card) or
the drawing's axes (`ax`, one new axes on the block, kept apart from the lab's own axes so that clearing them for a
scene never clears it) with what never changes drawn on it (sketch.problem; its text column as
wide as the widest lines a design may show: `widest`). `show(focus, pair=None)`, at every draw, draws the design in
focus (a Focus, or None: the empty state) with its four lines (`lines`), for the pair of inputs on the figure's axes,
and only when the focus, its lines or the pair changed: the previous focus's artists are removed first, and a pointer
that moves without changing the design in focus costs nothing here. The pair (two indices of the inputs, the axes' own
order) matters only on a bench of more than two inputs, where the drawing tells the pair from the inputs held
(sketch.paint); on a bench of two it is ignored (both inputs are on the axes), so that bench 2 is drawn as it always
was. The column's width is measured on texts of the language chosen, so the labs hold the language in their layout's
key.

Under the beam's band (the plan's Plan.band: panels.banded, the hero arrangement) the drawing is the band's
(sketch.hero, over the whole card: Plan.formula is the card) and, by the owner's 1A of 2026-11-21 (benches 2, 3 and 4:
"closer to optiSLang", the readout beside the beam "polluted" it), it draws the GEOMETRY of the design in focus only:
its cross-beams at their places (solid for a simulated design, dashed for the place under the pointer), the rails, a
dimension line per input (labels: "x₁ = 3.68 m"), bench 4's square sections (named: "A₁ = 225 cm²"), and who is in
focus on the band's title's line (lab.caption.<key>.title), quiet: titled, "best design · design 20 of 50", "x*,
validated", "design 7 of 50", "under the pointer: not simulated" (widest_titles: their widest, for the layout; at the
band's right, or after the title with a "·" before it where the band is narrow: sketch.hero_focus). No deflected shape,
no dot, no cut, no readout (no y, no forces, no objectives, no check): the band never shows a number of a simulation,
and never solves a design; y lives in step 1's table and the scoreboard, bench 4's check in the column's card of the
cross-beams (explorers/crossbeams.py). The cross-beam the pointer is on in the band (Caption.lit, which live.Pointing
sets at every move: a view) is drawn in the accent, heavier (sketch.hero_focus's `lit`), and show draws again when it
changes. No caption stands under the 3D view then. Without the band, the COMPACT caption: on the web's figure (Lab.hero
False there; Caption's `geometric` False) as always, its shape, its dot and its four lines (lines); in the window
(`geometric`: Lab.columned, the step's block in the column, whose figure has no room for the band at the code panel's
side or a small size) by 1A too: the cross-beams of a simulated design at its places, SOLID on the straight beam
(sketch.pointed's `simulated`), who it is and its places (geometric_lines: no y, no forces, no objectives, no check, no
note on a shape none is drawn of), the place under the pointer dashed as always with "y: not simulated". Caption.drawn,
the focus's artists, is the layer a pointer moves (removed and made again at each change of the focus, apart from what
never changes).

What the compact caption shows of the response comes from the response itself, never from the bench's key (`measure`):
the response read at the middle of its design space is the beam's largest deflection there (sketch.LARGEST: a dot where
it is) or another measure of the whole deflected line (sketch.WHOLE: the RMS deflection of bench 3, the line filled to
its axis, no dot). The exaggeration of the deflected shapes is the bench's own, one for every design (factor: the
owner's 20 for bench 2, FACTORS; else sketch.exaggeration's rule, from the largest deflection of its design space: 50
for bench 3), and the note says it; a deeper shape is cut at the drawing's room, its dot hollow there.

The place under the pointer (Focus of the kind POINTER, `under`: Lab.pointer, which the window sets) is not simulated:
its cross-beams at that place, dashed, with their dimension lines in the band, no shape; in the compact caption "y: not
simulated" (lab.caption.unsimulated) and a note that says only what y reads, no scale of a shape none is drawn of
(lab.caption.<key>.read); a design under the pointer wins over it (pointed).

The design in focus is only ever a SIMULATED design, never a prediction (Focus; each lab says which, by `pointed` and
`best`): in steps 1 and 2 the design under the pointer, else the best design (the least simulated y, the first of
equals); none, no design at all (the empty state); in step 3 x* once validated (a validation is a simulation, its value
f(x*)), under Real Run the lowest point simulated by the run as far as it is on screen, else the best design of step 1.
A design is solved once (`solved`, cached, its arrays read-only) for its deflected shape; y is the lab's own
simulated value, written with the app's formatters (base.short, base.number) and the units of the response
(functions.Response.units: one per input, then y's, the last).

A bench of SEVERAL responses whose cross-beams are SIZED (bench 4, beam_pareto: functions.Response.places names the
inputs that are places, x₁ and x₂; the others, x₃ and x₄, are the AREAS A₁ and A₂ of the cross-beams' solid square
sections, Response.size naming them, section.physical; in the cross-beams' order: layout, sized) is drawn on the same
beam: its rails and dimension lines for the places only, each cross-beam's SQUARE section under its spring
(sketch.sections: to one scale, named "A₁ = 225 cm²", named), each spring the stiffness of its section (solution_of:
beam.solve on beam.stiffness of the areas, solved_sized), its factor 20 (FACTORS, with its reason), its response read
on the line the RMS deflection (measured, from its objectives). Its Focus carries the row of every output its
simulation gave (simulated: Focus.outputs, never a prediction) and a tag (TAGS: "non-dominated", "predicted
feasible"); a validated design is numbered among those validated ("validated 3 of 10"). The band says who it is and
its tag after the title ("· design 7 of 65 · non-dominated") and draws its places and sections, nothing else. Its
lines, the compact caption's (several, in the bench's catalog keys lab.caption.<key>.*): who; its places and areas by
their units, "x = (4.00, 6.02) m · A = (225, 260) cm²" (grouped); both objectives, "1413 kg · 4.36 mm" (objective_line,
with the objective space's decimals: explorers/objectives.written); the CHECK in words and numbers, "σ = 79 · 75 MPa ≤
120 · feasible", or naming the constraints past their limit and in the failed colour, "σ = 73 · 120.2 MPa · σ₂ > 120 ·
infeasible" (checked: a value near the limit takes the decimals that keep it on its side, against); the note (with the
factor). The compact caption shows the first four (compact: its fourth the check; no section: a block of 70 pixels has
no room for them). The place under the pointer: who, its places and areas, "m, δ: not simulated", what the objectives
are; with no design, the objectives, the constraints, the inputs and one simulation per design. What each section
gives (k, m, σ, the cross-beam in detail) is the column's card's (explorers/crossbeams.py), never the band's.

The four lines, in the language chosen (catalog texts "lab.caption.*"): who the design is ("design 17 of 50", "best
design", "x*, validated", "best of Real Run"), its places with their unit (two inputs: "x₁ = 3.50 m,  x₂ = 5.96 m";
more: "x = (3.03, 3.76, 5.68, 6.94) m"), y with its unit, the note (what y is and the scale of the shape); the empty
state's say what y is, in which unit, what the inputs are, and that a design is one simulation. A bench's own words are
keyed by the bench ("lab.caption.<key>.*": y, what, inputs, note, read), so that a bench without its texts never touches
another's.
"""
import math
from dataclasses import dataclass
from functools import lru_cache

from statistical_fundamentals import beam
from statistical_fundamentals.explorers import objectives, outputs, responses, section, sketch
from statistical_fundamentals.explorers.base import number, short
from statistical_fundamentals.explorers.panels import subscript, typeset
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.i18n import get_text

KINDS = ("design", "best", "validated", "run", "pointer")    # who is in focus: a design pointed at, the best one, x*
                                                  # validated, the lowest of a Real Run; the place under the pointer
POINTER = "pointer"                               # the kind of a place that is not simulated: no value, no shape
TAGS = ("nondominated", "feasible", "infeasible") # what a bench of several responses says after who a design is: no other
                                                  # design dominates it; a validated design predicted feasible, or not
FACTORS = {"beam": 20,                            # the owner's 4B (2026-11-20): bench 2's shapes 20 times the beam's scale,
                                                  # so that a good design's deflection reads (5 by the rule drew it a pixel
                                                  # deep); a deeper one is cut at the drawing's room and said so. Bench 3
                                                  # keeps the rule (sketch.exaggeration: its 50, never cut)
           "beam_pareto": 20}                     # bench 4 (the orchestrator's answer 5, 2026-11-20: bench 2's 4B again):
                                                  # the rule, on its largest deflection (36.8 mm, its lightest sections at
                                                  # bad places, beam.sized's springs), gives 10, which draws the front's
                                                  # stiff designs (2 to 8 mm RMS) a few pixels deep; at 20 the softest are
                                                  # cut and said so (sketch.exaggeration assumes one k for all the springs:
                                                  # it is never asked for a bench of sized cross-beams)
SIZE_DECIMALS = 0                                 # a size written in its unit (mm): to the millimetre
LIMIT_DECIMALS = 2                                # a constraint's value near its limit takes up to this many decimals
                                                  # (the room the band and the table keep): beyond it only a value within
MOST_DECIMALS = 6                                 # 0.005 of its limit, up to this many (against)
DECIMALS = 2                                      # a place written in its unit (m): to the centimetre
DIGITS = 4                                        # y, as the 3D view writes a simulated value (base.short)
MOST_DESIGNS = 100                                # the most designs an experiment has (doe.MOST): the widest "design i of N"
MOST_RUN = 8888                                   # the widest count of a Real Run of several responses (mu (1 + G) is at
                                                  # most 1240): "simulated i of n" measured with four eights
SAME = 1e-9                                       # relative: the response read equals the largest deflection (measure)

@dataclass(frozen=True)
class Focus:
    """Who the drawing shows: one simulated design (who it is, KINDS; its place, one coordinate per input, x1 to xd, in
    the bounds of the response; its simulated value y; for a design of the experiment pointed at, its number from 1
    among n), or the place under the pointer (POINTER: not simulated, its value None). On a bench of several responses
    (simulated): `outputs`, the row of every output its simulation gave (outputs.rows: never a prediction), its value
    the first output's, and `tag`, what the caption says after who it is (TAGS: "non-dominated", "predicted feasible").
    The best design of an experiment carries its number among them too (best), for the band's title."""
    kind: str
    point: tuple[float, ...]
    value: float | None = None
    index: int = 0
    n: int = 0
    outputs: tuple = ()
    tag: str = ""

def simulated(kind: str, point, row, index: int = 0, n: int = 0, tag: str = "") -> Focus:
    """The Focus of a simulated design of a bench of several responses: its place (the bounds), the row of its outputs
    (its value the first's), its number among n (the experiment's designs; the validated ones, kind "validated") and
    its tag (TAGS, or "")."""
    row = tuple(float(v) for v in row)
    return Focus(kind, tuple(float(c) for c in point), row[0], index, n, row, tag)

def drawing(function: str) -> float | None:
    """The height of the caption's block a bench asks the plan for, in layout pixels: sketch.HEIGHT for a response that
    is drawn (no formula), None for a formula (panels' own rule)."""
    return None if responses.has_formula(function) else sketch.HEIGHT

def best(points, values, kind: str = "best") -> Focus | None:
    """The design of least simulated y among `points` and `values` (the first of equals), or None without a design; the
    best design of an experiment (kind "best") with its number among them, which the band's title says ("best design ·
    design 20 of 50"); the lowest of a Real Run (kind "run") without (its who is "best of Real Run")."""
    if not len(values):
        return None
    k = min(range(len(values)), key=lambda i: values[i])
    number_, among = (k + 1, len(values)) if kind == "best" else (0, 0)
    return Focus(kind, tuple(float(c) for c in points[k]), float(values[k]), number_, among)

def pointed(points, values, hovered, pointer=None) -> Focus | None:
    """Steps 1 and 2: the design under the pointer (an index among the designs on screen), else the place under the
    pointer (`pointer`, Lab.pointer: not simulated), else the best design; None without a design nor a place. An index
    that is no longer a design (one removed, another experiment) is not one."""
    if isinstance(hovered, int) and not isinstance(hovered, bool) and 0 <= hovered < len(values):
        return Focus("design", tuple(float(c) for c in points[hovered]), float(values[hovered]), hovered + 1, len(values))
    if pointer is not None:
        return under(pointer)
    return best(points, values)

def under(pointer) -> Focus:
    """The place under the pointer as the drawing's focus: its places, no value (POINTER)."""
    return Focus(POINTER, tuple(float(c) for c in pointer))

@lru_cache(maxsize=512)
def solved(*places: float) -> beam.Solution:
    """The beam solved for one design, its cross-beams at `places` (m, one per input; cached: a design pointed at again
    is not solved again), its arrays read-only so that no caller can change what the cache hands the next."""
    solution = beam.solve(places)
    for array in (solution.supports, solution.reactions, solution.x, solution.w, solution.moment):
        array.flags.writeable = False
    return solution

@lru_cache(maxsize=1024)
def solved_sized(places: tuple[float, ...], areas: tuple[float, ...]) -> beam.Solution:
    """The beam solved for one design of cross-beams SIZED (bench 4): at `places` (m), each a spring of its section's
    stiffness (beam.stiffness of its area, cm²); cached and read-only as solved."""
    solution = beam.solve(places, beam.stiffness(areas))
    for array in (solution.supports, solution.reactions, solution.x, solution.w, solution.moment):
        array.flags.writeable = False
    return solution

def layout(function: str) -> tuple[tuple[int, ...], tuple[int, ...]]:
    """The inputs that are the cross-beams' places (functions.Response.places; None: every input) and those that are
    their sizes, the others, in their order (bench 4: x₁, x₂ the places, x₃, x₄ the areas of cross-beams 1 and 2)."""
    response = RESPONSES[function]
    places_ = tuple(range(response.d)) if response.places is None else tuple(response.places)
    return places_, tuple(k for k in range(response.d) if k not in places_)

def sized(function: str) -> bool:
    """Whether the bench's cross-beams have sizes of their own (inputs that are not places)."""
    return bool(layout(function)[1])

def solution_of(function: str, point) -> beam.Solution:
    """The beam solved for a design of the bench: at its places, on the bench's springs (solved), or, for cross-beams
    sized, on the stiffness of their sections (solved_sized)."""
    places_, sizes = layout(function)
    if not sizes:
        return solved(*point)
    return solved_sized(tuple(float(point[k]) for k in places_), tuple(float(point[k]) for k in sizes))

@lru_cache(maxsize=16)
def measured(response) -> str:
    """What the response is on the deflected line (a functions.Response, cached): sketch.LARGEST where its value at the
    middle of its design space is the beam's largest deflection there, else sketch.WHOLE (a measure of the whole line,
    the RMS deflection). A bench of cross-beams sized (Response.places: not every input a place) reads it on its
    objectives: LARGEST where one of them is the largest deflection at the middle, else WHOLE (bench 4's δ is the RMS)."""
    middle = tuple((low + up) / 2 for low, up in response.bounds)
    if response.places is None:
        return sketch.LARGEST if math.isclose(float(response.f(*middle)), beam.solve(middle).largest, rel_tol=SAME) else sketch.WHOLE
    places_ = tuple(middle[k] for k in response.places)
    areas = tuple(middle[k] for k in range(response.d) if k not in response.places)
    largest = beam.solve(places_, beam.stiffness(areas)).largest
    read = [float(output.f(*middle)) for output in response.outputs if output.role == "objective"]
    return sketch.LARGEST if any(math.isclose(value, largest, rel_tol=SAME) for value in read) else sketch.WHOLE

def measure(function: str) -> str:
    """What the drawing marks on a design's deflected line for the bench's response (measured): LARGEST or WHOLE."""
    return measured(RESPONSES[function])

def factor(function: str) -> int:
    """The bench's exaggeration of the deflected shapes, one for every design, in the band and in the compact caption
    alike: the owner's for bench 2 (FACTORS: 20) and bench 4's (20, FACTORS' reason), else the rule's
    (sketch.exaggeration on its design space: 50 on bench 3)."""
    return FACTORS.get(function) or sketch.exaggeration(RESPONSES[function].bounds)

def who(focus: Focus) -> str:
    """The first line: who the design in focus is ("design 17 of 50"; on a bench of several responses a validated
    design by its number too, "validated 3 of 10", and a design of a Real Run by its number among the simulations
    made so far, "simulated 412 of 1240"), and its tag after it where it has one ("· non-dominated")."""
    if focus.kind == "design":
        said = get_text("lab.caption.design", index=focus.index, n=focus.n)
    elif focus.kind == "validated" and focus.n:
        said = get_text("lab.caption.validated_of", index=focus.index, n=focus.n)
    elif focus.kind == "run" and focus.n:
        said = get_text("lab.caption.simulated_of", index=focus.index, n=focus.n)
    else:
        said = get_text(f"lab.caption.{focus.kind}")
    return f"{said} · {get_text(f'lab.caption.tag.{focus.tag}')}" if focus.tag else said

def lines(function: str, focus: Focus | None) -> tuple[str, str, str, str]:
    """The four lines of the text column in the language chosen: for a design in focus, who it is, its places and its
    simulated y (each with its unit) and the note; for the place under the pointer, the same but y, which nobody
    simulated ("y: not simulated"); with none, what y is, in which unit, what the inputs are, and that a design is one
    simulation. A bench of several responses: several (its own four lines)."""
    if outputs.many(function):
        return compact(several(function, focus))
    units = RESPONSES[function].units
    if focus is None:
        return (get_text(f"lab.caption.{function}.y"), get_text(f"lab.caption.{function}.what", unit=units[-1]),
                get_text(f"lab.caption.{function}.inputs", unit=units[0]), get_text("lab.caption.simulations"))
    written = places([number(x, DECIMALS) for x in focus.point], units)
    if focus.value is None:                                     # no shape drawn: the note says only what y reads
        return who(focus), written, get_text("lab.caption.unsimulated"), get_text(f"lab.caption.{function}.read")
    return who(focus), written, f"y = {with_unit(short(focus.value, DIGITS), units[-1])}", note(function)

def geometric_lines(function: str, focus: Focus | None) -> tuple[str, ...]:
    """The compact caption's lines by the owner's 1A (Caption's `geometric`): the empty state's four as always; for a
    simulated design who it is and its places alone (no y, no objectives, no check, no note on a shape: "" leaves a row
    empty); for the place under the pointer who, its places and that nobody simulated it."""
    said = lines(function, focus)
    if focus is None:
        return said
    return (said[0], said[1], said[2] if focus.value is None else "", "")

def titled(focus: Focus | None) -> str:
    """Who is in focus as the band's title says it after "The beam" (the owner's 1A: the band's one text of the focus):
    a design's who (who: "design 7 of 50", "x*, validated", "best of Real Run"; bench 4's with its number and tag), the
    best design with its number among the experiment's ("best design · design 20 of 50"), the place under the pointer
    "under the pointer: not simulated"; "" with no design (the title alone)."""
    if focus is None:
        return ""
    if focus.kind == POINTER:
        return get_text("lab.caption.unsimulated_place")
    if focus.kind == "best" and focus.n:
        said = f"{get_text('lab.caption.best')} · {get_text('lab.caption.design', index=focus.index, n=focus.n)}"
        return f"{said} · {get_text(f'lab.caption.tag.{focus.tag}')}" if focus.tag else said
    return who(focus)

def widest_titles(function: str) -> list[str]:
    """Every who the band's title may say for the bench at its widest (the most designs; on a bench of several
    responses the most validated and the most simulations of a Real Run, and every tag of a design or a validated one;
    its best design, which its labs never number, caption.simulated's, without its number),
    so that the load under the title keeps clear of each and the beam never moves from a focus to another."""
    point = tuple((low + up) / 2 for low, up in RESPONSES[function].bounds)
    many = outputs.many(function)
    focuses = [Focus(POINTER, point), Focus("run", point, 0.0, MOST_RUN if many else 0, MOST_RUN if many else 0)]
    for tag in ("", *TAGS) if many else ("",):
        focuses += [Focus("design", point, 0.0, MOST_DESIGNS, MOST_DESIGNS, tag=tag),
                    Focus("best", point, 0.0, 0 if many else MOST_DESIGNS, 0 if many else MOST_DESIGNS, tag=tag),
                    Focus("validated", point, 0.0, MOST_DESIGNS if many else 0, MOST_DESIGNS if many else 0, tag=tag)]
    return [titled(focus) for focus in focuses]

def several(function: str, focus: Focus | None) -> tuple[str, ...]:
    """The lines of a bench of several responses (bench 4), in the language chosen, from its catalog's
    lab.caption.<key>.*: with no design, what its objectives are, its constraints, its inputs and that a design is one
    simulation (four); a simulated design (Focus.outputs), who it is, its places and sizes ("x = (4.00, 6.02) m · (271,
    180) mm"), both objectives with their units ("1413 kg · 4.36 mm", objectives.written's decimals), its check
    (checked) and the note (five; the compact caption keeps the first four); the place under the pointer, who, its
    places and sizes, that nobody simulated them, no check (""), and what the objectives are (five)."""
    if focus is None:
        units = RESPONSES[function].units
        places_, sizes = layout(function)
        limit = outputs.limit(function, outputs.constraints(function)[0]) if outputs.constraints(function) else 0.0
        return (get_text(f"lab.caption.{function}.y"), get_text(f"lab.caption.{function}.what", limit=f"{limit:g}"),
                get_text(f"lab.caption.{function}.inputs", place=units[places_[0]], size=units[sizes[0]] if sizes else ""),
                get_text("lab.caption.simulations"))
    written = grouped(function, focus.point)
    if focus.value is None:
        return (who(focus), written, get_text(f"lab.caption.{function}.unsimulated"), "",
                get_text(f"lab.caption.{function}.read"))
    return who(focus), written, objective_line(function, focus.outputs), checked(function, focus.outputs), note(function)

def compact(said: tuple[str, ...]) -> tuple[str, ...]:
    """The compact caption's four lines of several's: the empty state's four; a simulated design's first four (who,
    its inputs, its objectives, its check); the place under the pointer's who, inputs, "not simulated" and what the
    objectives are (its check is empty: the note takes its row)."""
    if len(said) == 4:
        return said
    return said[:4] if said[3] else (*said[:3], said[4])

def grouped(function: str, point) -> str:
    """A design's inputs written by their units, each run of one unit in its own parentheses: the places to the
    centimetre, the sizes whole and named by what they are (Response.size): "x = (4.00, 6.02) m · A = (225, 260) cm²"."""
    response = RESPONSES[function]
    units = response.units
    _, sizes = layout(function)
    runs: list[tuple[str, bool, list[str]]] = []
    for k, x in enumerate(point):
        text = number(float(x), SIZE_DECIMALS if k in sizes else DECIMALS)
        if runs and runs[-1][0] == units[k] and runs[-1][1] == (k in sizes):
            runs[-1][2].append(text)
        else:
            runs.append((units[k], k in sizes, [text]))
    written = [with_unit(f"({', '.join(values)})", unit) for unit, _, values in runs]
    named_ = [f"{response.size} = {text}" if size and response.size else text for (_, size, _), text in zip(runs, written)]
    return "x = " + " · ".join(named_)

def objective_line(function: str, row) -> str:
    """Both objectives of a simulated design with their units, as the objective space writes them: "1413 kg · 4.36 mm"."""
    found = outputs.objectives(function)
    decimals = objectives.window(function).decimals
    return " · ".join(with_unit(number(row[k], places_), outputs.unit(function, k)) for k, places_ in zip(found, decimals))

def against(value: float, limit: float) -> str:
    """A constraint's value written to the unit, or with the fewest decimals that keep it, as written, on its side of
    the limit: 120.2 is never written 120, which would read as within it, and 120.003 is "120.003", never "120.00" (up to
    MOST_DECIMALS; a value nearer the limit than that is written past it with them all). A value within it may read as
    the limit itself ("120" for 119.997): a tie is within."""
    for decimals in range(MOST_DECIMALS + 1):
        written = number(value, decimals)
        if (float(written.replace("−", "-")) > limit) == (value > limit):
            return written
    return number(value, MOST_DECIMALS)

def failing(function: str, row) -> tuple[int, ...]:
    """The constraints of a simulated design past their limits (exactly: outputs.feasible's rule)."""
    return tuple(k for k in outputs.constraints(function) if row[k] > outputs.limit(function, k))

def checked(function: str, row) -> str:
    """A simulated design's check in words and numbers: its constraints' values and the limit, feasible ("σ = 79 · 75
    MPa ≤ 120 · feasible") or, naming the constraints past it, infeasible ("σ = 73 · 120.2 MPa · σ₂ > 120 · infeasible");
    "" for a bench with no constraint."""
    found = outputs.constraints(function)
    if not found:
        return ""
    limit = outputs.shared_limit(function)                         # written once: one limit for all
    values = " · ".join(against(row[k], outputs.limit(function, k)) for k in found)
    failed = failing(function, row)
    if not failed:
        return get_text(f"lab.caption.{function}.feasible", stresses=values, limit=f"{limit:g}")
    return get_text(f"lab.caption.{function}.infeasible", stresses=values, limit=f"{limit:g}",
                    failed=", ".join(outputs.symbol(function, k) for k in failed))

def labels(function: str, focus: Focus | None) -> tuple[str, ...]:
    """The band's dimension lines, one per input: "x₁ = 3.68 m" for a design or the place under the pointer; with none,
    () (the drawing names them by their symbols alone)."""
    if focus is None:
        return ()
    units = RESPONSES[function].units
    places_, _ = layout(function)
    return tuple(f"x{subscript(k + 1)} = {with_unit(number(focus.point[k], DECIMALS), units[k])}" for k in places_)

def named(function: str, focus: Focus | None) -> tuple[str, ...]:
    """The band's names of the cross-beams' square sections, one per size, by what they are (section.physical): "A₁ =
    225 cm²"; with none, the names alone, "A₁"; () on a bench whose cross-beams have no size."""
    units = RESPONSES[function].units
    _, sizes = layout(function)
    if focus is None:
        return tuple(section.physical(function, k) or section.symbol(k) for k in sizes)
    return tuple(f"{section.physical(function, k) or section.symbol(k)} = {with_unit(number(focus.point[k], SIZE_DECIMALS), units[k])}"
                 for k in sizes)

def places(written: list[str], units) -> str:
    """The places of a design, each written: two inputs, "x₁ = 3.50 m,  x₂ = 5.96 m"; more, one vector,
    "x = (3.03, 3.76, 5.68, 6.94) m" (each with its own unit inside where the inputs' units differ)."""
    if len(written) == 2:
        return f"x₁ = {with_unit(written[0], units[0])},  x₂ = {with_unit(written[1], units[1])}"
    inputs = units[:len(written)]
    if len(set(inputs)) == 1:
        return with_unit(f"x = ({', '.join(written)})", inputs[0])
    return f"x = ({', '.join(with_unit(value, unit) for value, unit in zip(written, inputs))})"

def note(function: str) -> str:
    """The fourth line: what y is and the bench's exaggeration of the shape."""
    return get_text(f"lab.caption.{function}.note", factor=factor(function))

def with_unit(value: str, unit: str) -> str:
    """A value written with its unit after a space, or alone where the response has none."""
    return f"{value} {unit}" if unit else value

def widest(function: str) -> list[tuple[str, str, str, str]]:
    """The lines a design in focus may show at their widest, for each who: the most designs, and places and values of
    the most digits the bounds and the drawing hold, every digit an 8 (the widest the faces draw), so that the text
    column never moves from a design to another."""
    if outputs.many(function):
        return [compact(lines_) for lines_ in widest_several(function)]
    response = RESPONSES[function]
    eights = str.maketrans("0123456789", "8888888888")
    written = [max((number(v, DECIMALS) for v in ends), key=len).translate(eights) for ends in response.bounds]
    middle = places(written, response.units)
    third = f"y = {with_unit(short(88.88, DIGITS), response.units[-1])}"
    firsts = [get_text("lab.caption.design", index=MOST_DESIGNS, n=MOST_DESIGNS),
              *(get_text(f"lab.caption.{kind}") for kind in KINDS[1:])]
    simulated = [(first, middle, third, note(function)) for first in firsts]
    return [*simulated, (simulated[-1][0], middle, get_text("lab.caption.unsimulated"), get_text(f"lab.caption.{function}.read"))]

def widest_several(function: str) -> list[tuple[str, ...]]:
    """A bench of several responses' five lines at their widest (every who with every tag, the inputs, the objectives
    and the constraints of the most digits their ranges and the drawing hold, every digit an 8, the check failed by
    every constraint at once), the place under the pointer's last."""
    response = RESPONSES[function]
    eights = str.maketrans("0123456789", "8888888888")
    _, sizes = layout(function)
    point = [max((number(v, SIZE_DECIMALS if k in sizes else DECIMALS) for v in ends), key=len).translate(eights)
             for k, ends in enumerate(response.bounds)]
    middle = grouped(function, [float(text) for text in point])
    shown = objectives.window(function)
    found = outputs.objectives(function)
    reach = [max(abs(v) for v in span) for span in (shown.across, shown.up)]
    most = " · ".join(with_unit(number(value, places_).translate(eights), outputs.unit(function, k))
                      for k, value, places_ in zip(found, reach, shown.decimals))
    failed, held = [0.0] * len(outputs.of(function)), [0.0] * len(outputs.of(function))
    for k in outputs.constraints(function):                           # just past the limit (its decimals all written),
        failed[k] = outputs.limit(function, k) + 4 * 10.0 ** -LIMIT_DECIMALS     # and at it, every digit an 8
        held[k] = outputs.limit(function, k)
    checks = [checked(function, failed).translate(eights), checked(function, held).translate(eights)]
    firsts = [get_text("lab.caption.design", index=MOST_DESIGNS, n=MOST_DESIGNS),
              get_text("lab.caption.validated_of", index=MOST_DESIGNS, n=MOST_DESIGNS),
              get_text("lab.caption.simulated_of", index=MOST_RUN, n=MOST_RUN),
              *(get_text(f"lab.caption.{kind}") for kind in KINDS[1:])]
    tagged = [first if not tag else f"{first} · {get_text(f'lab.caption.tag.{tag}')}" for first in firsts for tag in ("", *TAGS)]
    simulated_ = [(first, middle, most, check, note(function)) for first in tagged for check in checks]
    pointer = (get_text(f"lab.caption.{POINTER}"), middle, get_text(f"lab.caption.{function}.unsimulated"), "",
               get_text(f"lab.caption.{function}.read"))
    return [*simulated_, pointer]

class Caption:
    """The caption of one lab's 3D view's card for one layout: the formula (written, a Text) or the drawing (ax, its
    axes on the block; sketch, what sketch.problem drew, or under the band, sketch.hero: the beam as the hero) with the
    design in focus shown last (show). `geometric`: the compact caption by 1A, the design's geometry only (the window's,
    Lab.columned); False, the compact caption as the web's figure has it."""

    def __init__(self, figure, plan, heads: dict, function: str, pair=None, geometric: bool = False):
        self.function = function
        self.written = None                    # the formula's Text (a bench with a formula)
        self.ax = None                         # the drawing's axes (a bench drawn)
        self.sketch = None
        self.hero = getattr(plan, "band", None) is not None    # the band's drawing over the figure, not the compact caption
        self.geometric = geometric and not self.hero           # the compact caption by 1A: no shape, no readout
        self.drawn: list = []                  # the artists of the design in focus, removed before the next one: the LIVE
                                               # layer a pointer moves (what never changes is the problem's, kept)
        self.shown = None                      # what they show: (focus, lines, pair, lit)
        self.lit = None                        # the band's cross-beam under the pointer (its index; a view: live.Pointing sets
                                               # it), drawn in the accent by show; None, none
        if responses.has_formula(function):
            self.written = typeset(figure, heads, responses.terms(function))
            return
        x0, y0, x1, y1 = heads["formula"]
        self.ax = figure.add_axes((x0, y0, x1 - x0, y1 - y0))
        _, _, wide, high = plan.formula
        bounds = RESPONSES[function].bounds
        places_, sizes = layout(function)
        shape = {} if not sizes else {"inputs": places_, "sizes": tuple(bounds[k] for k in sizes), "sized": sizes}
        bounds = bounds if not sizes else tuple(bounds[k] for k in places_)      # the rails: the places' ranges alone
        if self.hero:
            self.sketch = sketch.hero(self.ax, wide, high, bounds, get_text(f"lab.caption.{function}.title"),
                                      widest_titles(function), self.held(pair), **shape)
            return
        self.sketch = sketch.problem(self.ax, wide, high, bounds, lines(function, None), widest(function),
                                     factor(function), measure(function), self.held(pair), **shape)

    def held(self, pair):
        """The pair as the drawing takes it: None on a bench of two inputs (both on the axes), else its two indices."""
        return None if pair is None or RESPONSES[self.function].d <= 2 else tuple(int(k) for k in pair)

    def show(self, focus: Focus | None, pair=None) -> None:
        """The design in focus (None: the empty state) and its lines, for the pair of inputs on the figure's axes (None,
        or ignored, on a bench of two inputs), drawn when they changed since the last show; under the band, the
        cross-beam the pointer is on (`lit`, set by live.Pointing) in the accent; a formula has nothing to show."""
        if self.sketch is None:
            return
        said = (titled(focus),) if self.hero else geometric_lines(self.function, focus) if self.geometric else lines(self.function, focus)
        pair = self.held(pair)
        lit = self.lit if self.hero else None
        if (focus, said, pair, lit) == self.shown:
            return
        for artist in self.drawn:
            artist.remove()
        pointer = focus is not None and focus.value is None
        places_, sizes = layout(self.function)
        areas = () if focus is None or not sizes else tuple(focus.point[k] for k in sizes)
        if self.hero:                                                 # the band: the geometry alone, never solved
            where = None if focus is None else tuple(focus.point[k] for k in places_)
            self.drawn = sketch.hero_focus(self.sketch, where, said[0], pair, not pointer, labels(self.function, focus), areas,
                                           named(self.function, focus) if sizes else (), lit)
        elif self.geometric and focus is not None:                    # 1A in the compact caption: the places alone
            self.drawn = sketch.pointed(self.sketch, tuple(focus.point[k] for k in places_), said, pair, not pointer)
        elif not sizes:
            solution = None if focus is None or pointer else solved(*focus.point)
            self.drawn = sketch.focus(self.sketch, solution, said, pair, focus.point if pointer else None)
        else:                                                         # cross-beams sized: their places, their check
            solution = None if focus is None or pointer else solution_of(self.function, focus.point)
            failed = focus is not None and not pointer and bool(failing(self.function, focus.outputs))
            self.drawn = sketch.focus(self.sketch, solution, said, pair, tuple(focus.point[k] for k in places_) if pointer else None,
                                      labels(self.function, focus), areas, named(self.function, focus), failed)
        self.shown = (focus, said, pair, lit)
