# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: live.py
# ==============================================================================
"""
What follows the pointer on a bench drawn (explorers/caption.drawing is not None: the beam on two cross-beams or four),
without Qt: the PLACE under the pointer (Lab.pointer, a point of the design space nobody simulated) and the LIVE LAYER
that shows it, so that a move of the pointer never draws the whole figure again (the owner's 2A and 3B, 2026-11-20).

The place under the pointer (Pointing.point), one point of d coordinates in the response's bounds:
- over the design space, away from a design: the pair on the axes under the pointer, the inputs held at the values of
  the slice on screen (Section.lift: two inputs, the point itself); over a design, none (in steps 1 and 2 the design is
  in focus, as it always was, and the drawing shows it whole; step 3 keeps its own focus: the best design, x*, the run);
- over the beam's band (the hero's drawing, Caption.hero: panels.banded), over a cross-beam's RANGE (Sketch.ranged: the
  ranges are disjoint along the beam, so the place along it names the input; where two ranges share an end, the first,
  the lower input, keeps it): that input at the place along the beam, kept in its range; the other input of the pair on
  the axes where the pointer last left it (Pointing.last), else at the drawing's focus (the design shown, or the middle
  of the ranges); the inputs the slice holds at the slice's values (sliced), so that what the drawing shows is what a
  press there gives. A HELD input follows the pointer only while the pointer is on its own range (a preview of its
  slider: its value never passes into a later place). A drag that began on a range keeps its input (`grabbed`) wherever
  the pointer goes. The compact caption (the figure without the band) shows the place but never commands it: its ranges
  are bars of a few pixels;
- anywhere else, none: the drawing's focus is the step's own again (caption.pointed, optimization.focus).
A place the band commands over a range of an input on the axes that lands on a design (landed: the lab's own hit at that
place of the design space, aim) is that DESIGN, not a place: the window hovers it, drawn whole with its y, exactly as
from the plane (a design just placed from the band is shown simulated while the pointer stays on it).

The live layer is the drawing's focus (Caption.drawn: the place's dashed cross-beams and dimension lines, or the design
in focus) and, while there is a place, a CROSSHAIR on the design space (crosshair: two hairlines through the place's
pair, in the light ink and dashed, and its two values written INSIDE the frame, on a tag of the card's tone at its foot
and at its left edge, where neither a tick label nor the axis' name can be met, in the digits of the drawing's dimension
lines and of the view's band: two decimals of a place in m, an area in cm² whole (section.decimals of each input's
range), in the axes' unit, which their names say; tagged keeps both inside near a corner). Each lab's draw
ends with Pointing.live, which shows them for the state on screen; a full draw therefore always holds them. The window
(gui/lab_views.LabView) gives a lab drawn a Layer of its canvas (Lab.layer): then the layer's artists are ANIMATED,
left out of matplotlib's draw on screen, and the Layer, at the end of every draw on screen (matplotlib's draw_event),
copies the figure's pixels as the BACKGROUND and paints its artists over them; a move of the pointer (Pointing.follow,
then Layer.update) makes the artists of the new place, puts the background back, paints them and blits the regions of
the axes they stand on and of those they stood on at the last paint (an artist that left, the crosshair taken away, is
erased on screen too): nothing else of the figure is drawn. A move while a draw is pending is safe: the blit's repaint
runs the canvas's paintEvent, which first does matplotlib's pending draw. A picture saved (savefig: matplotlib draws
animated artists while it saves, sorted by their zorder as any other), a test's draw and the web's bridge (no Layer: the
artists are plain) are whole with no help. On screen the layer is painted over the figure it was copied from (by zorder among its
own artists): a deflected shape crosses the end supports' apex over them, not under. A background copied at another size
or density (a saved picture, a resized canvas) is refused (update answers False) and the window draws the figure whole.

A bench whose cross-beams are SIZED (bench 4: x₁ and x₂ their places, x₃ and x₄ their areas; functions.Response.places)
has a rail only for each PLACE (Sketch.ranged names the input of the place, Sketch.inputs): a size is never commanded
along the beam. The place under the pointer carries every input, its sizes too (from the plane where the pair holds
them, else the slice's values), so that the drawing's sections follow the pointer as its cross-beams do. With the pair
(x₃, x₄) on the axes both places are held: the band then commands nothing of the study, and a rail under the pointer
previews and moves its place's slider only (holds, slid), as a held input's rail does on bench 3. The cross-beam under
the pointer in the band's strip of the cross-beams (its spring and its section: Pointing.pointed_beam, beam_under, set
at every move) is named for the column's card of the cross-beams, which shows it in detail. The cross-beam the pointer is
on in the band (Pointing.lit_beam: that one, else the cross-beam whose rail is under the pointer, or whose rail a drag
took; benches 2 to 4) is drawn there in the accent, heavier, its section too (Caption.lit, sketch.hero_focus's `lit`), on
the live layer with the rest of the focus: the band answers the pointer. It is the view's too.

Branin, and every bench whose response has a formula, has none of this: no place, no crosshair, no layer, nothing
added to its figure, its moves what they were. The place and the layer are the view's, as the 3D angle: never a
setting, never in a snapshot, never a cue, never a change of the study; the window forgets them when the pointer leaves
the figure or the view leaves the screen (Pointing.forget).

A press over a range of the band's drawing is a press at the place in the design space (aim: a Spot, the event a press
there would be, given to the lab's own grab and drag): the free sampling places its point (or takes the design there),
step 2 moves its query point, step 3 its start (its pair only: the start keeps its own coordinates on the inputs held,
as a press on the plane always did, so on bench 3 they may differ from the slice's the drawing showed); what the step
refuses on its plane it refuses here (an algorithm's sample, the EA, a free sample full: takes, which also gives the
range its cursor). On a bench of more than two inputs a range of an input HELD (holds: off the axes) moves the view's
slider of that input instead (slid: the window does it on the press and at the end of a drag, never at every move: a
slice costs seconds), the view only, never the study.
"""
from dataclasses import dataclass

from matplotlib.transforms import Bbox, offset_copy

from statistical_fundamentals import beam
from statistical_fundamentals.explorers import panels, section, sketch
from statistical_fundamentals.explorers.base import number
from statistical_fundamentals.explorers.lab import LAYOUT_DPI, size
from statistical_fundamentals.functions import RESPONSES

CROSS_INK = panels.LEGEND_INK             # the crosshair: the light ink of the place under the pointer (sketch's LIGHT)
CROSS_ALPHA = 0.7                         # its hairlines, a step under the ink: the designs they cross still read
CROSS_WIDTH = 0.8                         # points
CROSS_DASH = (0, (3.0, 2.5))              # dashed: a place nobody simulated, as its cross-beams in the drawing
CROSS_ZORDER = 8                          # over the plane's designs and level lines (the layer is painted last anyway)
DECIMALS = 2                              # the place's values at the axes: the dimension lines' (caption.DECIMALS), or
                                          # the band's for each input of the pair (section.decimals: bench 4's cm² whole)
TAG_PAD = 0.25                            # a tag's box around its digits, in font sizes
TAG_BOX = {"boxstyle": f"round,pad={TAG_PAD},rounding_size=0.3", "facecolor": panels.CARD_TONE, "edgecolor": "none",
           "alpha": 1.0}                  # the card's tone at full opacity: what it stands on never shows through
INSIDE = 3.0                              # layout pixels: a tag's box from the frame's edge (and from its hairline, beside it)
TAG_TALL = 1.3                            # a tag's digits' height, in font sizes (the box adds its pad)
TAG_SLACK = 2.0                           # layout pixels a tag's digits may take beyond their width measured (rounding)
MARGIN = 8.0                              # layout pixels a region blitted takes around its axes: a stroke's overhang
BEAM_OVER = 12.0                          # layout pixels over the beam where the strip of the cross-beams starts (pointed_beam)
BEAM_REACH = 6.0                          # how far beyond the half of the largest section a cross-beam answers the pointer

def crosshair(ax, x: float, y: float, decimals: tuple[int, int] = (DECIMALS, DECIMALS)) -> list:
    """The crosshair of the place under the pointer on the design space `ax` (its data coordinates, the pair's values
    x across and y up): two dashed hairlines through it and each value written inside the frame, on a tag of the
    card's tone (the x value at the frame's foot, the y value at its left edge: tagged), with `decimals` each. Returns
    the artists added."""
    line = {"color": CROSS_INK, "alpha": CROSS_ALPHA, "linewidth": CROSS_WIDTH, "linestyle": CROSS_DASH, "zorder": CROSS_ZORDER}
    drawn = [ax.axvline(x, **line), ax.axhline(y, **line)]
    tag = panels.TAG | {"color": CROSS_INK, "bbox": TAG_BOX, "zorder": CROSS_ZORDER + 1, "clip_on": False}
    drawn.append(ax.text(x, 0.0, "", **tag))
    drawn.append(ax.text(0.0, y, "", **tag))
    tagged(ax, drawn[2], drawn[3], x, y, decimals)
    return drawn

def tagged(ax, under, left, x: float, y: float, decimals: tuple[int, int] = (DECIMALS, DECIMALS)) -> None:
    """The crosshair's two tags for the place (x, y) of `ax`, INSIDE its frame, where they can meet neither a tick
    label nor an axis' name: x's at the frame's foot, centred on its hairline, and y's at the frame's left edge, centred
    on its own; a tag that would pass the frame near a corner stands beside its hairline instead, on the side away from
    that corner; where the two tags would meet (the pointer near the lower left corner), y's goes to the frame's right
    edge. In layout pixels measured in the face drawn, so the same at any screen density."""
    under.set_text(number(x, decimals[0]))
    left.set_text(number(y, decimals[1]))
    width, height = size(ax.figure)
    box = ax.get_position()
    wide, tall = box.width * width, box.height * height                 # the frame
    (x0, x1), (y0, y1) = ax.get_xlim(), ax.get_ylim()
    across, up = (x - x0) / (x1 - x0) * wide, (y - y0) / (y1 - y0) * tall
    points = panels.TAG["fontsize"]
    pad = TAG_PAD * points * LAYOUT_DPI / 72
    high = TAG_TALL * points * LAYOUT_DPI / 72 + 2 * pad
    long_x = panels.text_width(under.get_text(), points) + 2 * pad + TAG_SLACK
    long_y = panels.text_width(left.get_text(), points) + 2 * pad + TAG_SLACK
    beside = INSIDE + pad                                               # from the hairline or the edge to the digits
    if across - long_x / 2 < INSIDE:                                    # x's: beside its hairline near a side
        ha, dx, a = "left", beside, across + INSIDE
    elif across + long_x / 2 > wide - INSIDE:
        ha, dx, a = "right", -beside, across - INSIDE - long_x
    else:
        ha, dx, a = "center", 0.0, across - long_x / 2
    if up - high / 2 < INSIDE:                                          # y's: beside its hairline near the foot or the top
        va, dy, c = "bottom", beside, up + INSIDE
    elif up + high / 2 > tall - INSIDE:
        va, dy, c = "top", -beside, up - INSIDE - high
    else:
        va, dy, c = "center", 0.0, up - high / 2
    meet = a < INSIDE + long_y and c < INSIDE + high                    # the two would meet at the lower left corner
    pt = 72 / LAYOUT_DPI                                                # layout pixels to points
    under.set_position((x, 0.0))
    under.set_transform(offset_copy(ax.get_xaxis_transform(), ax.figure, x=dx * pt, y=beside * pt, units="points"))
    under.set_horizontalalignment(ha)
    under.set_verticalalignment("bottom")
    left.set_position((1.0 if meet else 0.0, y))
    left.set_transform(offset_copy(ax.get_yaxis_transform(), ax.figure, x=(-beside if meet else beside) * pt, y=dy * pt,
                                   units="points"))
    left.set_horizontalalignment("right" if meet else "left")
    left.set_verticalalignment(va)

@dataclass(frozen=True)
class Spot:
    """A mouse event at a place of the design space, made for the lab's own grab and drag (a press over a range of the
    band's drawing is a press there): device pixels from the canvas's lower left (x, y), the plane's axes, and the
    place's pair in its data coordinates."""
    x: float
    y: float
    inaxes: object
    xdata: float
    ydata: float
    button: int = 1

class Layer:
    """The live layer of one canvas (the window's: one canvas per lab, for the lab's life): its artists (hold), the
    background copied at the end of every draw on screen (drawn, matplotlib's draw_event), and the update that paints
    them over it and blits (update). `draws` counts the draws on screen it saw, `updates` the moves it painted (the
    tests read them)."""

    def __init__(self, canvas):
        self.canvas = canvas
        self.artists: list = []
        self.background = None                # the figure's pixels without the layer, from the last draw on screen
        self.renderer = None                  # the renderer they were copied from (another one: refused)
        self.painted: list = []               # the regions the layer stood on at its last paint (update blits them too)
        self.draws = 0
        self.updates = 0
        canvas.mpl_connect("draw_event", self.drawn)

    def hold(self, artists) -> None:
        """The layer's artists from now on, animated: matplotlib's draw on screen leaves them to the layer."""
        self.artists = list(artists)
        for artist in self.artists:
            artist.set_animated(True)

    def alive(self) -> list:
        """The artists still on the figure (an axes cleared or a figure laid out again took the others), by zorder."""
        return sorted((artist for artist in self.artists if artist.figure is not None), key=lambda artist: artist.get_zorder())

    def drawn(self, event) -> None:
        """At the end of a draw on screen: the background copied, then the layer painted over it. A picture being saved
        draws the animated artists itself, so it is left alone (and nothing of it is copied)."""
        canvas = self.canvas
        if event.canvas is not canvas or canvas.is_saving() or not hasattr(canvas, "copy_from_bbox"):
            return
        self.draws += 1
        self.background = canvas.copy_from_bbox(canvas.figure.bbox)
        self.renderer = event.renderer
        self.painted = self.paint(event.renderer)

    def paint(self, renderer) -> list:
        """The layer's artists drawn with `renderer`; the regions they stand on (their axes, with MARGIN around), as
        (x0, y0, x1, y1) in device pixels."""
        regions = {}
        for artist in self.alive():
            artist.draw(renderer)
            ax = artist.axes
            if ax is not None and id(ax) not in regions:
                margin = MARGIN * ax.figure.dpi / LAYOUT_DPI
                regions[id(ax)] = tuple(ax.bbox.expanded(1.0, 1.0).padded(margin).extents)
        return list(regions.values())

    def update(self) -> bool:
        """The layer as its artists now are, over the background of the last draw on screen, and blitted: the regions
        they stand on now and those they stood on at the last paint (an artist that left, the crosshair taken away, is
        erased on screen too). False when there is no background to paint it on (no draw on screen yet, or a renderer
        of another size or density since: the caller draws the figure whole)."""
        canvas = self.canvas
        renderer = getattr(canvas, "renderer", None)
        if self.background is None or renderer is None or renderer is not self.renderer:
            return False
        canvas.restore_region(self.background)
        figure = canvas.figure.bbox
        regions = self.paint(renderer)
        for region in dict.fromkeys([*self.painted, *regions]):
            canvas.blit(Bbox.intersection(Bbox.from_extents(*region), figure) or figure)
        self.painted = regions
        self.updates += 1
        return True

class Pointing:
    """What a laboratory of a bench drawn does with the pointer, the same in the three steps: mixed in before
    section.Viewing (class SamplingLab(live.Pointing, section.Viewing, Lab)) by a lab that has `function`, `d`, `axes`
    (its "plane"), `caption` (explorers/caption.Caption, once per layout), `drawing` (caption.drawing: None for a
    formula, and then nothing here does anything), and `focused(state, hovered)`, the Focus its drawing shows."""
    last: tuple | None = None             # the place the pointer last left (a view): the others of a range pointed at
    crossed: tuple = ()                   # the crosshair's artists on the plane
    pointed_beam: int | None = None       # the sized cross-beam under the pointer in the band (its index; a view): the
                                          # column's card of the cross-beams shows it in detail (explorers/crossbeams.py)
    lit_beam: int | None = None           # the cross-beam the pointer is on in the band (its index; a view): pointed_beam,
                                          # else the one of the rail under the pointer or taken by a drag; the band lights it

    def focused(self, state, hovered):
        """The drawing's focus for the state on screen and what is under the pointer (the lab's own rule)."""
        raise NotImplementedError

    def live(self, state, hovered) -> None:
        """The live layer for the state on screen: the drawing's focus (Caption.show: made again only when it changed)
        and the crosshair of the place under the pointer, handed to the Layer when the window gave one. Each lab's draw
        ends with it, and a move of the pointer calls it (follow)."""
        if self.caption is not None:
            self.caption.lit = self.lit_beam                          # a caption made again for a new layout learns it too
            self.caption.show(self.focused(state, hovered), state.section.pair)
        crossed = self.crossing(state)
        if self.layer is not None:
            self.layer.hold([*(self.caption.drawn if self.caption is not None else ()), *crossed])

    def follow(self, figure, state, hovered) -> None:
        """A move of the pointer: the live layer for the place now under it (the window then calls Layer.update)."""
        if state is not None:
            self.live(state, hovered)

    def crossing(self, state) -> list:
        """The crosshair on the design space through the place's pair while there is a place: the one on the plane
        moved there (its hairlines and its tags: a move makes nothing new), or a new one; none, taken away, without a
        place, on a bench with a formula, or where the plane is not shown."""
        plane = self.axes.get("plane")
        if self.drawing is None or self.pointer is None or plane is None or not plane.get_visible():
            for artist in self.crossed:
                if artist.figure is not None:
                    artist.remove()
            self.crossed = ()
            return []
        x, y = (float(v) for v in state.section.project(self.pointer))
        bounds = RESPONSES[self.function].bounds
        decimals = tuple(section.decimals(bounds[k]) for k in state.section.pair)       # the band's: an area in cm² whole
        if len(self.crossed) == 4 and all(artist.axes is plane for artist in self.crossed):
            across, up, under, left = self.crossed
            across.set_xdata([x, x])
            up.set_ydata([y, y])
            tagged(plane, under, left, x, y, decimals)
            return list(self.crossed)
        for artist in self.crossed:
            if artist.figure is not None:
                artist.remove()
        self.crossed = tuple(crosshair(plane, x, y, decimals))
        return list(self.crossed)

    def point(self, figure, state, event, hovered=None, grabbed=None, ranges=True) -> tuple | None:
        """The place under the pointer for `event` (module docstring): over the plane away from a design, over a range
        of the band's drawing (or, `grabbed`, along the range a drag took, or the range found already under the event:
        the window asks ranged once per move; `ranges` False: no range looked for), else None; remembered as `last`.
        None on a bench with a formula, without a state, and over a design (`hovered` an index). On a bench sized it
        also names the cross-beam under the pointer in the band (pointed_beam, beam_under); on every bench drawn, the
        cross-beam the band lights (lit_beam, beam_lit: the drawing's Caption.lit)."""
        self.pointed_beam = self.beam_under(event)
        self.lit_beam = self.beam_lit(figure, event, grabbed, ranges)
        if self.caption is not None:
            self.caption.lit = self.lit_beam
        if self.drawing is None or self.caption is None or state is None or event is None or designed(hovered):
            return None
        bounds = RESPONSES[self.function].bounds
        plane = self.axes.get("plane")
        if grabbed is None and plane is not None and event.inaxes is plane and plane.get_visible():
            x, y = plane.transData.inverted().transform((event.x, event.y))
            (a1, b1), (a2, b2) = section.pair_bounds(bounds, state.section)
            p, q = kept((float(x) - a1) / (b1 - a1)), kept((float(y) - a2) / (b2 - a2))
            place = section.mapped(bounds, state.section.lift(p, q))
        else:
            k = (self.ranged(figure, event) if ranges else None) if grabbed is None else grabbed
            if k is None:
                return None
            low, up = bounds[k]
            base = self.last if self.last is not None and len(self.last) == self.d else self.standing()
            place = list(sliced(bounds, state.section, base))        # the inputs held at the slice's values
            place[k] = min(max(self.along(event), low), up)
            place = tuple(place)
        self.last = tuple(float(v) for v in place)
        return self.last

    def beam_under(self, event) -> int | None:
        """The sized cross-beam under the event in the band (bench 4): in the strip of the cross-beams, from BEAM_OVER
        over the beam to the rails' ticks, the one whose spring and section stand nearest the pointer across, within
        BEAM_REACH of it (as the band drew them last: the focus's places, side by side where they touch); None
        elsewhere, on a bench whose cross-beams have no size, and without the band."""
        caption_ = self.caption
        if self.drawing is None or caption_ is None or not caption_.hero or caption_.sketch is None or event is None:
            return None
        drawn = caption_.sketch
        if not drawn.sizes or event.inaxes is not caption_.ax:
            return None
        across, down = (float(v) for v in caption_.ax.transData.inverted().transform((event.x, event.y)))
        if not drawn.beam - BEAM_OVER <= down <= drawn.rail - sketch.RAIL_TICK:
            return None
        shown = caption_.shown[0] if caption_.shown is not None else None
        places = list(drawn.places) if shown is None else [float(shown.point[k]) for k in drawn.inputs]
        at = sketch.spread([float(drawn.at(place)) for place in places], sketch.HERO_SPRING[0])
        reach = float(beam.side(max(up for _, up in drawn.sizes))) * sketch.SECTION_SCALE / 2 + BEAM_REACH
        found = min(range(len(at)), key=lambda j: abs(across - at[j]))
        return found if abs(across - at[found]) <= reach else None

    def beam_lit(self, figure, event, grabbed=None, ranges=True) -> int | None:
        """The cross-beam the band lights for `event`: the one under the pointer in the strip of the cross-beams
        (pointed_beam, bench 4), else the one whose rail holds the place under the pointer (ranged; `grabbed`, the input
        a drag took or the range the window found already) as its index among the cross-beams (Sketch.inputs: on bench
        4 a rail is a place's); None off the band, on the compact caption and on a bench with a formula."""
        if self.pointed_beam is not None:
            return self.pointed_beam
        caption_ = self.caption
        if self.drawing is None or caption_ is None or not caption_.hero or caption_.sketch is None or event is None:
            return None
        k = grabbed if grabbed is not None else self.ranged(figure, event) if ranges else None
        if k is None:
            return None
        inputs = caption_.sketch.inputs
        return inputs.index(k) if inputs else k

    def landed(self, figure, state, place, k) -> int | None:
        """The design a place the band's drawing commands lands on (`place`, over the range of input `k` on the axes):
        the lab's own hit at that place of the design space (aim), as a pointer there would find it; None off a design,
        for anything else hit finds there (the query point, the start), and over a held input's range (a preview of the
        view, never a design)."""
        if place is None or k is None or self.holds(state, k):
            return None
        spot = self.aim(figure, state, place)
        found = None if spot is None else self.hit(figure, state, spot)
        return found if designed(found) else None

    def standing(self) -> tuple:
        """Where the drawing's cross-beams stand now: the focus's place, or the middle of their ranges."""
        shown = self.caption.shown if self.caption is not None else None
        if shown is not None and shown[0] is not None:
            return tuple(shown[0].point)
        return tuple((low + up) / 2 for low, up in RESPONSES[self.function].bounds)

    def along(self, event) -> float:
        """The place along the beam (m) under the event, on the band's drawing (Sketch.place)."""
        across, _ = self.caption.ax.transData.inverted().transform((event.x, event.y))
        return float(self.caption.sketch.place(float(across)))

    def ranged(self, figure, event) -> int | None:
        """The input whose range of the band's drawing is under the event (Sketch.ranged), or None: off the band, off
        every range, or the compact caption (which never commands)."""
        caption_ = self.caption
        if self.drawing is None or caption_ is None or not caption_.hero or caption_.sketch is None or event is None:
            return None
        if event.inaxes is not caption_.ax:
            return None
        return caption_.sketch.ranged(self.along(event))

    def aim(self, figure, state, place) -> Spot | None:
        """The press a press at `place` (d coordinates, the bounds) of the design space would be: a Spot over the
        plane at the place's pair, for the lab's own grab and drag; None where the plane is not shown."""
        plane = self.axes.get("plane")
        if plane is None or not plane.get_visible() or state is None:
            return None
        p, q = state.section.project(place)
        x, y = plane.transData.transform((float(p), float(q)))
        return Spot(float(x), float(y), plane, float(p), float(q))

    def holds(self, state, k: int) -> bool:
        """Whether input k is held by the slice on screen (a bench of more than two inputs, k off the axes): its range
        in the drawing moves the view's slider, not the study."""
        return state is not None and self.d > 2 and k in state.section.others

    def slid(self, place, k: int) -> tuple[str, float]:
        """The view's slider of input k and the value of it nearest to the place's k-th coordinate."""
        low, up = RESPONSES[self.function].bounds[k]
        u = (float(place[k]) - low) / (up - low)
        return section.slider_key(k), min(section.SLIDER, key=lambda value: abs(value - u))

    def forget(self) -> None:
        """The pointer away (off the figure, the view off the screen): no place, nothing remembered."""
        self.pointer = None
        self.last = None
        self.pointed_beam = None
        self.lit_beam = None
        if self.caption is not None:
            self.caption.lit = None

def designed(hovered) -> bool:
    """Whether what is under the pointer is a design (an index among those on screen)."""
    return isinstance(hovered, int) and not isinstance(hovered, bool)

def kept(u: float) -> float:
    """A coordinate of the unit square kept inside it."""
    return min(max(float(u), 0.0), 1.0)

def sliced(bounds, cut, place) -> tuple:
    """A place (d coordinates in `bounds`) with the inputs the slice `cut` holds at its held values, the pair's as they
    are (Section.lift of the pair's): the place itself on a bench of two inputs."""
    if cut.plain:
        return tuple(place)
    p, q = cut.project(section.unit(bounds, place))
    return section.mapped(bounds, cut.lift(p, q))
