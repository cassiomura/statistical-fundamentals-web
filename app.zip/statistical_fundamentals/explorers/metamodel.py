# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: metamodel.py
# ==============================================================================
"""
Step 2 of a bench's study, the metamodel: a cheap function y^ fitted to the N designs that step 1 simulated, to stand
in for the simulation in step 3: a polynomial (regression.py), moving least squares (moving_least_squares.py) or
Kriging (kriging.py), judged by how it reproduces the values it saw (CoD) and how it predicts the ones it did not (CoP,
by cross-validation: prognosis.py), on the bench's response y = f(x1, ..., xd) (functions.RESPONSES; two inputs for
benches 1 and 2, four for bench 3: see the end of this docstring).

What the step receives (receive, received): step 1's doe.Experiment (the response, the sampling, N, the seed) and with
it the N designs and their simulated values (doe.simulated): of f the metamodel knows nothing else. The column says
what came in, in the order every received card of steps 2 and 3 keeps (sampled: the sampling, then N), and the
correlation of the designs measured by measures.py (the owner's 2026-11-21: the empty intervals and the smallest
distance are step 1's, left to it). Any experiment is fitted, a Monte Carlo one too, and N
from 5 on: with few designs some metamodels cannot be computed (a quadratic basis has 6 coefficients; a subset of the
cross-validation leaves 4 designs when N = 5), and two random designs very close make Kriging's matrix singular. What
cannot be computed is kept as None (a Fit, a Validation, a candidate's CoP, the influences), never raised: the state,
the commands and the drawing say it, on the figure and in the strip.

What the step hands (output, missing): the Surrogate (experiment, candidate) of the metamodel on screen, from which
step 3 computes y^ again (fit(candidate, experiment).model, cached); None while that metamodel cannot be computed, and
missing says why in one sentence. The forward command "Go to the optimization" is answered by the window.

    [ Optimal prognosis                  ]  the featured command, and under it the winner and its CoP
    Model (Polynomial | MLS | Kriging)   Basis (Linear | Pure quadratic | Quadratic)   Radius D -o-  (or Correlation theta)
    the weight of each design in y^ at  | the metamodel as a surface, the true    | the coefficient of prognosis: the CoP
    the query point: the designs, each  | response as a wire over it, the designs | large on its gauge, its definition,
    with a disc of area |a_i(u)|, over  | at their simulated values, the query    | the CoD (and against f) beside it; each
    y^'s faint level lines, and the     | point's prediction and true value       | design predicted without it; or the
    query point (dragged, clicked, the arrow keys)                                 | competition: the seven candidates' CoP
    strip: CoP (strong) | CoD | against the true response (a student's: once the bench is complete)   [Best D]   [Go to the ...]

The diagram is the figure as the web draws it (columned False). In the window (columned) the coefficient of prognosis
and its check (or the competition) are the column's block, the 3D view takes the right column alone, and there is no
strip; on a simulation the true response is drawn only once revealed (Lab.truth_shown).

The controls and the commands stand in the window's column at the left of the figure, under what was received; the
measures in the strip under the figure, each with a tip of one sentence that defines it; the 3D view's card has the
caption every step draws (explorers/caption.py, made once per layout): the formula of the bench's response, typeset,
or, for the beam, which has none, the drawing of its problem with the design in focus, the design under the pointer
(in the design space or in the check), else the best design, never the query point (a prediction, not a simulation).
The axes of the plane and of the 3D view carry the response's units where it has them (panels.name_plane, style_space).

What the step opens on depends on how the application is used (explorers/game.py, Lab.mode). The TEACHER's lab opens
on the optimal prognosis: its first settings, Restore and an experiment received that is not the one on screen put the
winner of the competition (champion: the candidate of largest CoP, computed once per experiment and kept) on screen,
its model, basis, D or theta, with the competition closed (the check of the winner in the third panel: no frame plays
on entering; the competition costs about a second at N = 60 and two to four at N = 100, most of it the search of the
moving least squares' D). When no candidate can be computed the settings stay as they were; a choice of the reader is kept while
the experiment stays the same. "Optimal prognosis" is the featured command, drawn over the controls: pressed, it plays
the competition again, one candidate per frame, and ends on the winner; its second line (naming) names the winner and
its CoP, with a check mark when the model on screen is the winner and the word "winner" when the reader chose another.
The Best command (tune: Best basis, Best D, Best theta, by the model on screen) names the basis, D and theta as its
places (Action.beside): the window's column sets it on the line of the last of them shown, at the right of its name.
The STUDENT's lab calibrates by hand, reading the CoP: neither the optimal prognosis nor the Best command is offered
(offered; settings that ask for the competition show none, and its frames never start), and it opens on the simplest
metamodel, the linear polynomial, keeping the reader's choice when another experiment comes; the strip does not show
him the coefficient against the true response (the answer a study never has) until the bench is complete (Lab.won).
The true response of a SIMULATION (the beams': the owner's 2B) is drawn only where the reader asked to see it
(Lab.truth_shown: a test function's always, a simulation's once Lab.revealed): f's wire in the 3D view, the query
point's true value (its ring and "f = ..."), the legend's entry (the 3D view's title then "Metamodel ŷ"); the
coefficient against it needs that and the student's rule both (against_shown).
A competition is run only where its winner will be shown: a lab given an experiment as it opens (opening) crowns that
one, never the bench's first experiment as well. A competition played to its end asks for the sound "complete", a Best
command for "apply" (cue).

The three panels answer three questions. The left one, where a prediction comes from: every metamodel of this step is
linear in the simulated values, y^(u) = sum_i a_i(u) y_i, and the a_i(u) (the cores' `influence`) are drawn on the
designs, blue and filled where positive, purple and hollow where negative, over the faint level lines of y^ (from its
surface on the grid, with the levels and the look of step 3's plane, panels.level_values and LINES: the same lines the
optimization then searches on). The middle one, what the metamodel is: its surface on a GRID x GRID grid, beside the
true response, which a study never has. The right one, what it is worth: its card is the coefficient of prognosis. The
CoP is its hero (draw_hero): the number large (panels.HERO, the strip's very text: cop_written), its definition typeset
small as prognosis.coefficient_of_prognosis computes it (DEFINED), and a gauge from 0 to 1 filled to it (panels.gauge:
clamped, so a CoP below 0 leaves it empty and its number says how far); under it, smaller and muted, the CoD at the
designs (which flatters: Kriging's is 1) and, where the strip shows it, the coefficient against the true response, on
gauges of the same scale. Beside the hero, or under it where that leaves the larger square (composed: the corner and
the stack side by side, a row usually over; the hero and the check's legend on the row under the card's title), the
check: every design predicted by a metamodel fitted without it, against its simulated value. The pair has no third card,
so no hero: the strip says the CoP. A card whose check would be smaller than CHECK_LEAST (a phone's) shows the hero
alone, and the 3D view's clause then says why a metamodel cannot be computed; there the competition's names leave out
their D or theta, then step down to RANKING_LEAST, before they would meet their CoP.

A CoP at or below 0 (poor) has an exact meaning, CoP = 1 - SS_E/SS_T: the metamodel predicts the designs it did not see
no better than their mean. Then the strip's CoP and the hero take the warning's colour and its mark (MARK), and the
step's summary (the cover's track, the pill's tooltip) is a warning; no other threshold is drawn. The rows of what the
step received are plain.

The figure is laid out by panels.arrangement(width, height, pair="space", drawing=...), the plan the three steps share
(drawing: the beam's caption block, Lab.drawing): for the same figure size the design space and the 3D view have the
same boxes in every step, the design space the same axes and the
designs of step 1 at the same places, and the 3D view the same vertical window (truth) and the same angle (Lab.view,
which the window carries between the steps: read at every draw, updated when the reader turns the view). The third
panel is this step's. In a figure with room, the corner (the design space large at the left; at its right the 3D view
over the check, a square); otherwise the three panels in a row; the design space and the 3D view side by side, the
check left out, when there is no room for three (the code panel open beside the lab); and the three stacked in a narrow
figure. The competition takes the place of the check (in the corner, its whole rectangle), and where there is no check
that of the design space, until a control changes or a click closes it. The 3D view and the check (or the competition
in its place) stand on the cards of the right column (panels.draw_cards, once per layout; the check on the card's
tone), and f is the wire every step draws over a metamodel (panels.true_wire, its legend's handle wire_handle).

Where the window sets Lab.columned, the third panel leaves the figure for the window's column (panels.arrangement's
third=False through arranged: the design space and the 3D view alone; the competition never takes the design space's
place) and is the step's one BLOCK there, "Coefficient of prognosis (CoP)" (blocks, PROGNOSIS): on a figure of its own
(panels.block_plan, painted in BLOCK_TONE), as the owner chose on 2026-11-21 (the canvas "premium", 1C): the CoP's
number large at the block's left edge under its title (at or below 0 in the warning's colour, with the warning's
triangle at the figures' height beside it, never colour alone: warning), under it a slim scale from 0 to 1 filled to
the CoP in the accent, with no threshold (scale: empty at or below 0, a small arrow at its 0 pointing left), and under
both the check: a square of equal scales in a well one tone under the card (welled, WELL), the line 1:1 and the designs
clipped to the well, a prediction beyond the window a small arrow on the edge it passes, pointing out (draw_welled),
centred under them as large as the block's width or height leaves it (block_composition, block_composed: up to about
180 layout pixels a side in the column's 248, at least BLOCK_CHECK, 106), named by its axes ("predicted without it",
every bench) and with no legend; or the competition while it is shown, as many candidates as hold, the largest CoP
first. The block takes the column's room left up to its natural height (Block.most: the check as large as the width
holds it), so that the card ends where its content ends and the room to spare stays the column's, at least
block_height (the number's and the scale's lines, STACK_GAP and a check of BLOCK_CHECK with its tick labels and names),
the same for the competition; no gauge of the CoD, no definition there (the CoP's definition is its tooltip's; the CoD
and the coefficient against f the strip's, the web's figure). Its axes in block_axes, its layout and what it shows in
block_made, drawn again only when the metamodel, the experiment, the competition or the language change (draw_block: a
drag of the query point draws nothing there); a design in its check is found (hit_block) and ringed, a click while the
competition is shown closes it (press_block). Columned, the 3D view's card is the owner's 2A and 3A of 2026-11-21
(panels.alone_card): its legend on one row with the query point named ("query x"), the formula under it, the 3D box
filling the card at the plan's aspect (Plan.aspect), y^'s facets lit (panels.lit_facets) under f's fine wire, and the
values read in the view moved off its surface to the readout at its foot (readings: x, y^ and, where f is shown, f at
the query point; the design under the mouse, x_i and y_i). Not columned (the web's page), the figure is what it always
was. Every plan of the lab, height_for's too, comes from arranged.

Everything shown is computed by the cores through their public functions; NumPy only holds the grids of the drawing
and evaluates the test function. What is expensive is cached by the experiment and the candidate (sample, fit,
validation, the best values). Dragging the query point changes only the influences and the two values at that point:
the figure keeps the artists of everything else (scene: the hero and its gauges among them), and draws again what moves.

The sampling never looks at f: the designs are step 1's, placed before any simulation, mapped to the bounds of the
response and then simulated.

What is computed, and where. fit(candidate, experiment) keeps the metamodel (the cores', a function of a unit point of
d coordinates), its values at the designs, its CoD and its values on the check grid (checked_grid); the surface drawn
is not in it but in caches of its own: predicted(candidate, experiment, cut), y^ on the GRID x GRID grid of a slice,
and truth(function, cut), f there; true_cod(candidate, experiment), the coefficient against the true response
(Fit.surface reads the first for a bench of two inputs, and is None for more; Fit.against reads the second). The caches
of a slice are keyed by its key (sliced, Section.key), so that two Sections that differ only in the pair's coordinates
of `held` share one entry. For two inputs every one of them is what this step always computed, the same numbers in the
same order: the check grid IS the grid of the surfaces, so a candidate can be computed where its 31 x 31 surface can,
and its CoD against f is measured on that grid with the check.

A bench of more than two inputs (d of them: the beam on four cross-beams) is read through the same figure, by one rule
(explorers/section.py): a mark is a projection, a surface is a slice. Every coordinate of the figure goes through the
slice on screen, MetamodelState.section (section.of from the settings; for two inputs the whole design space, and every
step below the identity, so that benches 1 and 2 draw what they always drew).
- Whether a candidate can be computed: its cross-validation, its fit at the designs and its values on the 3^d grid of
  the unit hypercube (CORNERS 0, 1/2 and 1 on every input: in four inputs its 16 vertices, 32 midpoints of edges, 24
  centres of faces, 8 centres of facets and its centre, 81 points) finite and not refused (a slice cannot be checked in
  advance: one the reader asks for whose y^ is refused somewhere has no surface drawn, and the 3D view says that y^
  cannot be computed on this slice, lab.mm.space.slice, not that the metamodel cannot be computed). The
  competition, best_radius, best_theta, entry and champion follow it. The CoD against f is measured on TESTED points of
  a Latin hypercube of the design space (seed TESTED_SEED: tested), only for the metamodel on screen (true_cod, cached),
  never for every candidate of the competition; its texts say what it is measured on.
- The view's controls: first among the lab's controls (section.controls: the two axes and a slider per input held),
  then the metamodel's; the window draws them, with the chip of the slice (section.chip("best"), offered while a slider
  pinned it), in the band over the figure (gui/lab_views.ViewBand), never in the column. While nothing is pinned
  the slice passes through the best design of the experiment received (automatic: doe.through), which then lies on the
  surfaces drawn, and the sliders stand there (viewed). adjust sends a key of the view to section.after and nothing of
  the study follows: the competition stays open or closed as it was, the Surrogate, the CoP and the CoD do not change.
  slice_of, viewed, showing and adjust_view are section.Viewing's, the same in the three steps; automatic is the lab's.
- The query point is a unit point of d coordinates kept in the settings (probe); its two coordinates of the pair are
  the reader's (dragged, clicked, the arrow keys), its others are always the slice's held values when it is used
  (state.probe = lift(project(probe))), so that the surfaces drawn pass through it. The weights a_i(u) are those at
  that point of d inputs, each drawn at its design's projection; the dashed circle stays exact (the ball of radius D,
  or 1/sqrt(theta), around a point of the slice meets the slice in that circle).
- The figure: the plane's axes are the pair's, y^'s level lines its slice, the designs at their projections, fainter
  the farther they are from the slice and larger near it (doe.Marks, section's fade: never colour alone); the 3D view
  draws y^'s slice cut at the bench's window (doe.window), f's slice as the wire, coloured on the bench's range
  (doe.extent), the designs at their projections and their own y, faded and smaller off the slice; the heads write the
  slice's note (section.note). The third panel and the
  strip do not depend on the view (but the coefficient against f, measured on the whole design space). The received
  card writes the correlation as step 1's strip said it (its words: the largest correlation with its pair).
- The cost (pure-Python cores, no threads: the window shows a wait cursor): the competition on the first entry, the
  slice of a new pair or held value (GRID x GRID predictions; at N = 85 about 2 s for the quadratic MLS, a third of a
  second for the linear one, tens of milliseconds for Kriging and a polynomial), computed only when drawn and kept
  (predicted, bounded); so the window computes a slice once a held slider is released, not at every step it is dragged
  through (gui/lab_views: tracking off in more than two inputs; the keyboard's steps still compute each value).

The pointer on a bench drawn (explorers/live.py, live.Pointing mixed in, the same in the three steps): away from a
design the place under it (Lab.pointer) is the drawing's focus, its cross-beams dashed and no y, never the query point
(a prediction), and a crosshair through it on the plane; they are the live layer, the last of every draw (live, with
focused: caption.pointed), which a move of the pointer paints alone. A press over a range of the band's drawing is a
press at that place of the plane (live.Pointing.aim): the query point goes there (grab and drag, as on the plane).

A bench of several responses has a laboratory of its own that is this one per response (explorers/pareto_metamodel.py,
one metamodel per response, its competitions run together by explorers/prognoses.py). The lab reaches what that one
replaces through a few methods, each here this module's own function, so that a bench of one response is what it always
was: fitted_to (the experiment fitted: the one received), validation_of, entry_of, champion_of, best_radius_of (the
cross-validation, the competition, its winner, Best D), crown (the winner on screen: crowned), composition (the third
card: composed), plane_mesh (the grid of y^'s level lines on the plane: the true response's, truth) and plane_designs
(the designs on the plane: blue dots under the weights; by their kind, feasible or not, on a bench of several
responses).
"""
import math
from dataclasses import dataclass, field
from functools import cache, lru_cache
from itertools import product
from random import Random
from textwrap import fill
from typing import Callable

import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patheffects import withStroke
from matplotlib.patches import Ellipse, FancyBboxPatch, Patch, Polygon, Rectangle
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from statistical_fundamentals import kriging, moving_least_squares, palette, regression
from statistical_fundamentals.explorers.base import Control, nearest, short, style_axes
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.doe import (FIRST_SEED, HEIGHT, RAMP, SPACE_ZOOM, VIEW, Experiment, Marks, extent,
                                                    first_experiment, largest_correlation, marker_size, simulated,
                                                    style_space, through, window)
from statistical_fundamentals.explorers.lab import BENCH, LAYOUT_DPI, LINK, Action, Block, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.panels import (BELOW, CARD_FOOT, CARD_TONE, CHECK_LEFT, DEFINITION, HEAD, HEAD_GAP, HERO,
                                                       HERO_LEAST, LEGEND_DROP, LEGEND_PITCH, LEGEND_ROW, LEGEND_SIZE, LINES,
                                                       MUTED_INK, NOTE, RANK_INSET, READING, SMALL, STACK_WIDTH, TAG, TITLE_DROP,
                                                       TITLE_LINE, arrangement, cut_note, dot, draw_cards, facets, gauge, head,
                                                       legend_at, legend_rows, legend_width, level_values, mathtext_width, number_width,
                                                       name_plane, places, plane_ticks, space_ticks, subscript, text_width, ticks,
                                                       tint, titled, true_wire, wire_handle, LABEL, LABELS_APART, screen_gap,
                                                       lit_facets, read_point, read_value, readout)
from statistical_fundamentals.explorers import caption, live, outputs, panels, section
from statistical_fundamentals.explorers.responses import formula
from statistical_fundamentals.explorers.section import Section
from statistical_fundamentals.functions import RESPONSES, Response, many, response_of
from statistical_fundamentals.i18n import current_language, get_text
from statistical_fundamentals.measures import correlation
from statistical_fundamentals.prognosis import (FOLDS, coefficient_of_determination, coefficient_of_prognosis, cross_validation,
                                                 folds)
from statistical_fundamentals.sampling import latin_hypercube, scaled

MODELS = ("polynomial", "mls", "kriging")
ORDERS = regression.ORDERS
RADII = tuple(round(0.05 * 50 ** (k / 23), 2) for k in range(24))             # D: 0.05 to 2.5 in geometric steps
THETAS = tuple(float(f"{0.25 * 1600 ** (k / 24):.2g}") for k in range(25))    # theta: 0.25 to 400 in geometric steps
FIRST_MODEL, FIRST_ORDER = "polynomial", "linear"     # the simplest metamodel: the controls' first values, the student's
                                                      # metamodel, the teacher's when no candidate can be computed
COACHED = ("tune", "contest")         # the commands that calibrate for the reader: not offered to a student
FIRST_RADIUS = min(RADII, key=lambda D: abs(D - 0.3))
FIRST_THETA = min(THETAS, key=lambda theta: abs(theta - 7.4))
FIRST_FUNCTION = next(iter(RESPONSES))    # the bench of a lab made without one: the first response
FIRST_PROBE = (0.62, 0.42)            # the query point, in the unit square (more inputs: in the pair's, the others held)
STEP = 0.02                           # an arrow key moves the query point this far in the unit square
GRID = 31                             # samples per axis of the surfaces: the metamodel's and the true response's
AXIS = tuple(k / (GRID - 1) for k in range(GRID))     # the grid of one axis of the surfaces, in the unit square
CORNERS = (0.0, 0.5, 1.0)             # more than two inputs: a candidate is checked on the 3^d grid of these values per input
                                      # (vertices, midpoints of edges, centres of faces and facets, the centre; the
                                      # sweep's 6^d grid never changed a winner)
TESTED = 400                          # more than two inputs: the CoD against f on a Latin hypercube of this many points
TESTED_SEED = FIRST_SEED              # of this seed (27)
MARGIN = 0.15                         # the vertical window: the range of the true response and this share of it on each side
CANDIDATES = 7                        # of the competition: three polynomials, three moving least squares, one Kriging
AREA = 620.0                          # points squared: the disc of a design whose weight a_i is 1
PROBE_RADIUS = 14                     # pixels: how close the mouse must come to the query point to take hold of it
QUERY = palette.YELLOW                # the query point, its prediction, the circle of its radius
POINT = palette.BLUE                  # a design, and its weight where positive
NEGATIVE = palette.PURPLE             # a negative weight (hollow, too)
TRUE = palette.SLATE                  # the true response: a reference
WINNER = palette.TEAL                 # the largest CoP of the competition
WARNING = palette.GOLD
MARK = "▲"                            # beside the warning's colour (never colour alone): a CoP at or below 0, a cut surface
DASH = "—"                            # a value that cannot be computed
SUPERSCRIPTS = {"-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹"}
BOXED = {"boxstyle": "round,pad=0.25", "facecolor": palette.CARD, "edgecolor": "none", "alpha": 0.8}
HALO = [withStroke(linewidth=2.6, foreground=palette.CARD)]      # a text over the surface: read on any of its colours
TAG_BOX = {"boxstyle": "round,pad=0.2", "facecolor": CARD_TONE, "edgecolor": "none", "alpha": 0.85}     # under the query point's
                                                                  # values in the 3D view: read over f's light wire too
REFUSED = (ArithmeticError, ValueError)   # how the cores refuse: a matrix not positive definite, a logarithm of nothing
# The third card: the CoP as its hero, the check beside it or under it (composed), in layout pixels
DEFINED = r"$\mathrm{CoP} = 1 - SS_E^{\,\mathrm{pred}}\,/\,SS_T$"     # prognosis.coefficient_of_prognosis, as it computes it
COP_INK = POINT                       # the CoP's gauge: the colour of a CoP's bar in the competition
REFERENCE_INK = MUTED_INK             # the gauges of the references beside it (the CoD at the designs, against f): one ink,
                                      # muted
WIDEST = "−0.000"                     # the widest number a row of the hero keeps room for (quality near 1 and below 0)
HERO_GAP = 16.0                       # from the hero to the check's tick labels (beside) or its axes (over)
HERO_MOST = 260.0                     # the hero is never wider
HERO_FEWEST = 140.0                   # nor narrower
ROW_GAP = 10.0                        # in a row of the hero, between its name and its number
GAUGE_HIGH, ROW_HIGH = 8.0, 6.0       # the CoP's gauge, a reference's gauge (a gauge, not a rule)
DROPS = {"formula": 26.0, "gauge": 9.0, "row": 17.0, "under": 5.0, "scale": 13.0}    # from a line of the hero to the next
SCALE_FOOT = 4.0                      # under the scale's baseline: the last thing the hero draws
CHECK_FEW = 160.0                     # a check smaller than this has at most three intervals on each axis (two under half)
RANKING_LEAST = 8.0                   # points: a candidate's name too wide for a phone's card steps down to this, never below
CHECK_LEAST = 90.0                   # a check smaller than this is left out: the hero alone in its card (composed)
CHECK_GAP = 8.0                       # from the check's legend down to its axes (its top tick label rises half its height)
CHECK_TIGHT, BELOW_TIGHT = 44.0, 26.0     # a check too small to name its axes: its tick labels' gutter and foot alone
# The block of the step in the window's column (Lab.columned), the owner's word of 2026-11-21 ("the most important is
# the value of the CoP and the plot", then his mock: the number large at the top right, the check under it across the
# block's width; then "it leaves more room for the figure": always so): the CoP over the check (block_composed); in
# layout pixels
PROGNOSIS = "prognosis"               # the block's key (Lab.blocks)
STACK_GAP = 10.0                      # from the CoP's line down to the check's top spine (its top tick label's half rises
                                      # into it, in the gutter at the left; the number's descent box stands over it)
BLOCK_CHECK = 106.0                   # the check's least side in the block (block_height): a check one still reads (116 before
                                      # the scale of 1C took its line: the column of bench 2's teacher still holds at 1536 x 864)
ROWS_CHECK = 80.0                     # its least in the rows over the figure of a narrow lab (the code panel open: Block.rows)
BLOCK_WIDTH = 248.0                   # the column's block, its figure's width (gui/blocks.CONTENT_WIDTH): the height is
                                      # measured for it (block_height)
BLOCK_EDGE = 10.0                     # the check's right spine from the block's right (half its last tick label's room)
BLOCK_ABOVE = 5.0                     # its top under the block's top
BLOCK_BELOW = 37.0                    # under it: its tick labels and the name of its axis (BLOCK_PAD over it)
BLOCK_FOOT = 2.0                      # then the block's foot
BLOCK_TICK = "−888"                   # the widest tick label its gutter keeps room for (then its turned name)
BLOCK_PAD = 1.0                       # points: from the check's tick labels to the name of its axis under them
RANK_SIDE = 8.0                       # the competition from the block's sides: the scale's end labels inside it
RANK_ROW = 24.0                       # the competition in the block: the least height of a candidate's row
RANK_BELOW = 22.0                     # its scale's tick labels under its rows
# The owner's 1C of 2026-11-21 (the canvas "premium"): the number, a slim scale from 0 to 1 under it, then the check
SCALE_DROP = 11.0                     # from the number's baseline down to the scale's track
SCALE_HIGH = 6.0                      # the track's thickness (rounded ends)
SCALE_END = 16.0                      # the track's ends from the block's sides: its "0" and "1" outside them
SCALE_ALONE = 14.0                    # the scale's line alone (bench 4: under its line of the four CoPs, no number)
WARN_SHARE, WARN_GAP = 0.62, 8.0      # the warning's triangle beside a CoP at or below 0: its height in the figures' (cap)
                                      # height, its base on their baseline; from it to the number
WELL = palette.theme.BLOCK            # the check's well in the block: one tone under the card (BLOCK_TONE), its corners
WELL_RADIUS = 8.0                     # rounded this much (layout pixels)
EDGE_ARROW = 26.0                     # points squared: a prediction beyond the check's window, a small arrow on its edge

# ------------------------------------------------------------------------------
# What is computed, by the cores, and kept by the experiment and the candidate
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Candidate:
    """A metamodel to fit: its type, its basis (None for Kriging) and its parameter (D of the moving least squares,
    theta of Kriging; None for a polynomial, and for a candidate none of whose values can be computed)."""
    model: str
    order: str | None
    value: float | None

@dataclass(frozen=True)
class Surrogate:
    """Step 2's result, handed to the optimization: the metamodel `candidate` fitted to the designs of `experiment`.
    Everything else is computed from it (fit(candidate, experiment)), so two surrogates are the same when equal."""
    experiment: Experiment
    candidate: Candidate

@dataclass(frozen=True)
class Sample:
    unit: tuple[tuple[float, ...], ...]         # the designs in the unit hypercube (d coordinates): step 1's experiment
    points: tuple[tuple[float, ...], ...]       # the same, mapped to the bounds of the response
    values: tuple[float, ...]                   # y = f at every design: the simulations
    subsets: tuple[tuple[int, ...], ...]        # the designs dealt into the subsets of the cross-validation

@dataclass(frozen=True)
class Truth:
    """The true response on the grid of the surfaces: what a metamodel is drawn beside (and, for two inputs, measured
    against). For more inputs, its slice: the grid of the pair, the inputs held at the slice's values."""
    axis: tuple[float, ...]                     # the grid of one axis, in the unit square
    x1: np.ndarray                              # the coordinates of the pair's first input (across), in its bounds
    x2: np.ndarray                              # and of its second (up)
    y: np.ndarray
    flat: tuple[float, ...]                     # y row by row, as the cores take it
    low: float                                  # the vertical window of the 3D view (the bench's: doe.window)
    high: float

@dataclass(frozen=True)
class Fit:
    """A candidate fitted to the designs of an experiment: the metamodel (from the cores), its values at the designs,
    its CoD, and its values on the check grid (checked_grid) that said it can be computed. What it is drawn and measured
    with is computed from the candidate and the experiment it keeps, by caches of their own: its surface on a slice
    (predicted) and its CoD against the true response (true_cod). `surface` reads the first for the whole design space
    of two inputs (None for more: a slice is the view's, asked with predicted); `against` reads the second, on the grid
    of the surfaces for two inputs and on the TESTED points of a Latin hypercube for more."""
    model: Callable                             # the metamodel, a function of a point of the unit hypercube (d coordinates)
    fitted: tuple[float, ...]                   # its values at the designs
    cod: float
    candidate: Candidate | None = None          # what it was fitted as, and to what: the keys of its surface and its CoD
    experiment: Experiment | None = None        # against f
    checked: tuple[float, ...] = field(default=(), repr=False)     # its values on the check grid, in its order
    whole: float | None = None                  # two inputs: the CoD against f on the grid of the surfaces (the check's)

    @property
    def surface(self) -> np.ndarray | None:
        """Its values on the grid of the surfaces, row by row: the surface drawn of a bench of two inputs (predicted);
        None for more inputs (the surface drawn is the slice on screen's, predicted with that slice: never a slice
        through the middle computed for nothing) and for a Fit made without its candidate."""
        if self.candidate is None or RESPONSES[self.experiment.function].d > 2:
            return None
        return predicted(self.candidate, self.experiment)

    @property
    def against(self) -> float | None:
        """The coefficient of determination of the true response (true_cod): on the grid of the surfaces for two inputs,
        on TESTED points of a Latin hypercube for more; None where it cannot be computed."""
        return None if self.candidate is None else true_cod(self.candidate, self.experiment)

@dataclass(frozen=True)
class Validation:
    predictions: tuple[float, ...]              # every design predicted by a metamodel fitted without it
    cop: float

@dataclass(frozen=True)
class Entry:
    """A candidate of the competition with its CoP (None: it cannot be computed)."""
    candidate: Candidate
    cop: float | None

@cache
def sample(experiment: Experiment) -> Sample:
    """The designs of step 1 and their simulations (doe.simulated), and the subsets of the cross-validation, dealt from
    the experiment's seed."""
    simulations = simulated(experiment)
    subsets = tuple(tuple(subset) for subset in folds(experiment.n, FOLDS, Random(experiment.seed)))
    return Sample(simulations.unit, simulations.points, simulations.values, subsets)

def sliced(cut: Section | None) -> tuple | None:
    """The key a cache of a slice takes: None for the whole design space of two inputs (one entry, as before the view
    existed), the Section's key otherwise (Section.key: d, the pair and the values held, so that two Sections that
    differ only in the pair's coordinates of `held` share one entry)."""
    return None if cut is None or cut.plain else cut.key

def truth(function: str, cut: Section | None = None, output: int = 0) -> Truth:
    """f on the GRID x GRID grid of the surfaces: for two inputs the whole design space, with the vertical window of
    the 3D view the range of f there and MARGIN of it on each side; for more, its slice `cut` (None: through the middle
    of the ranges), the pair's grid with the inputs held at the slice's values, and the bench's window (doe.window, the
    same for every slice). f is the response of `output` (functions.response_of: the bench's own for a bench of one
    response, output 0). Cached by the slice's key and the output (sliced: the whole design space of two inputs one
    entry however it is asked): never mutate what it returns."""
    return true_slice(function, sliced(cut), output)

@lru_cache(maxsize=64)
def true_slice(function: str, cut: tuple | None, output: int = 0) -> Truth:
    """truth, cached by the key of its slice (sliced; None: the whole design space, or the middle for more inputs) and
    the output read."""
    response = response_of(function, output)
    if response.d == 2:
        (a1, b1), (a2, b2) = response.bounds
        axis = AXIS
        u1, u2 = np.meshgrid(np.array(axis), np.array(axis))
        x1, x2 = a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2
        y = np.asarray(response.f(x1, x2), dtype=float)
        low, high = float(y.min()), float(y.max())
        margin = MARGIN * (high - low)
        return Truth(axis, x1, x2, y, tuple(float(v) for v in y.ravel()), low - margin, high + margin)
    cut = Section(response.d) if cut is None else Section.from_key(cut)
    across, up = cut.pair
    (a1, b1), (a2, b2) = response.bounds[across], response.bounds[up]
    axis = np.array(AXIS)
    arrays = cut.mesh(a1 + (b1 - a1) * axis, a2 + (b2 - a2) * axis, section.mapped(response.bounds, cut.held))
    y = np.asarray(response.f(*arrays), dtype=float)
    low, high, _ = window(function)
    return Truth(AXIS, arrays[across], arrays[up], y, tuple(float(v) for v in y.ravel()), low, high)

def maker(candidate: Candidate) -> Callable:
    """The candidate as the cross-validation asks for it: from points and values, a function of the point."""
    if candidate.model == "polynomial":
        return lambda points, values: regression.metamodel(points, values, candidate.order)
    if candidate.model == "mls":
        return lambda points, values: moving_least_squares.metamodel(points, values, candidate.order, candidate.value)
    return lambda points, values: kriging.metamodel(points, values, candidate.value)

def influence_of(candidate: Candidate, u, points) -> list[float]:
    """The a_i(u) of the candidate: how much each simulated value counts in its prediction at u."""
    if candidate.model == "polynomial":
        return regression.influence(u, points, candidate.order)
    if candidate.model == "mls":
        return moving_least_squares.influence(u, points, candidate.order, candidate.value)
    return kriging.influence(u, points, candidate.value)

@cache
def checked_grid(d: int) -> tuple[tuple[float, ...], ...]:
    """The unit points a candidate must be computed at, besides the designs, to be one that can be computed: for two
    inputs the grid of the surfaces, row by row (GRID x GRID: the surface drawn, the points metamodel.fit always took,
    Section(2).grid), so that what is checked is what is drawn; for more, the 3^d grid of CORNERS (0, 1/2 and 1 on every
    input: in four inputs the 16 vertices of the unit hypercube, the 32 midpoints of its edges, the 24 centres of its
    faces, the 8 centres of its facets and its centre, 81 points; its vertices and edges are where a design is
    farthest, where a local fit is the first to lack designs carrying weight), since every slice cannot be checked in
    advance."""
    if d == 2:
        return tuple(point for row in Section(2).grid(AXIS) for point in row)
    return tuple(product(CORNERS, repeat=d))

@lru_cache(maxsize=256)
def fit(candidate: Candidate, experiment: Experiment) -> Fit | None:
    """The candidate fitted to the designs of the experiment, at the designs and on the check grid (checked_grid: for
    two inputs the whole grid of the surfaces, with the CoD against f on it; for more, the 3^d grid of the unit
    hypercube); None when it cannot be computed there (a matrix that is not positive definite: too few designs for its
    terms, too few carrying weight there, or two designs too close) or gives a value that is not finite."""
    if candidate.model != "polynomial" and candidate.value is None:
        return None
    data, d = sample(experiment), RESPONSES[experiment.function].d
    try:
        model = maker(candidate)(data.unit, data.values)
        fitted = tuple(model(u) for u in data.unit)
        checked = tuple(model(u) for u in checked_grid(d))
        cod = coefficient_of_determination(data.values, fitted)
        whole = coefficient_of_determination(truth(experiment.function, None, experiment.output).flat, checked) if d == 2 else None
    except REFUSED:
        return None
    if not (all(math.isfinite(v) for v in checked) and all(math.isfinite(v) for v in fitted) and math.isfinite(cod)
            and (whole is None or math.isfinite(whole))):
        return None
    return Fit(model, fitted, cod, candidate, experiment, checked, whole)

def predicted(candidate: Candidate, experiment: Experiment, cut: Section | None = None) -> np.ndarray | None:
    """y^ of the candidate fitted to the experiment on the GRID x GRID grid of a slice, row by row (the rows by the
    input up), the surface drawn and its level lines: for two inputs the whole design space (the values fit checked,
    the same numbers in the same order); for more, the slice `cut` (None: through the middle), its points lifted
    (Section.grid), each a prediction of the cores. None where the candidate cannot be computed, or on this slice (a
    point refused or not finite). Cached by the slice (the whole design space of two inputs one entry however it is
    asked), computed only when asked (a slice drawn): never mutate what it returns."""
    return predicted_slice(candidate, experiment, sliced(cut))

@lru_cache(maxsize=256)
def predicted_slice(candidate: Candidate, experiment: Experiment, cut: tuple | None) -> np.ndarray | None:
    """predicted, cached by the key of its slice (sliced): a bounded cache, a slice of the quadratic MLS costing about
    two seconds at N = 85."""
    fitted = fit(candidate, experiment)
    if fitted is None:
        return None
    d = RESPONSES[experiment.function].d
    if d == 2:
        return np.array(fitted.checked).reshape(GRID, GRID)
    cut = Section(d) if cut is None else Section.from_key(cut)
    try:
        surface = np.array([[fitted.model(u) for u in row] for row in cut.grid(AXIS)], dtype=float)
    except REFUSED:
        return None
    return surface if np.isfinite(surface).all() else None

@lru_cache(maxsize=8)
def tested(function: str, output: int = 0) -> tuple[tuple[tuple[float, ...], ...], tuple[float, ...]]:
    """A bench of more than two inputs: the TESTED unit points of the Latin hypercube of TESTED_SEED in its design space
    and f at each one (a call of the response of `output` per point, as a simulation: functions.response_of), where a
    metamodel is measured against the true response. A bench of several responses reads the column of `output` of ONE
    simulation of the points (outputs.simulate: every output of a design from one solve, the same values) rather than
    a solve per point and per output."""
    response = response_of(function, output)
    unit = tuple(tuple(float(v) for v in u) for u in latin_hypercube(TESTED, response.d, Random(TESTED_SEED)))
    points = scaled([list(u) for u in unit], list(response.bounds))
    if many(function):
        return unit, tuple(float(row[output]) for row in outputs.simulate(function, [tuple(x) for x in points]))
    return unit, tuple(float(response.f(*x)) for x in points)

@lru_cache(maxsize=256)
def true_cod(candidate: Candidate, experiment: Experiment) -> float | None:
    """The coefficient of determination of the true response by the candidate fitted to the experiment, what the CoP
    estimates and a study never has: for two inputs on the grid of the surfaces (computed with the check: fit); for
    more, on the TESTED points of the Latin hypercube (tested), computed only when asked (the metamodel on screen,
    never every candidate of the competition) and kept. None where it cannot be computed."""
    fitted = fit(candidate, experiment)
    if fitted is None:
        return None
    if RESPONSES[experiment.function].d == 2:
        return fitted.whole
    unit, values = tested(experiment.function, experiment.output)
    try:
        predictions = [fitted.model(u) for u in unit]
        cod = coefficient_of_determination(values, predictions)
    except REFUSED:
        return None
    return cod if math.isfinite(cod) and all(math.isfinite(p) for p in predictions) else None

@lru_cache(maxsize=2048)
def validation(candidate: Candidate, experiment: Experiment) -> Validation | None:
    """The cross-validation of the candidate and its CoP; None when one of its fits cannot be computed."""
    if candidate.model != "polynomial" and candidate.value is None:
        return None
    data = sample(experiment)
    try:
        predictions = cross_validation(data.unit, data.values, data.subsets, maker(candidate))
        cop = coefficient_of_prognosis(data.values, predictions)
    except REFUSED:
        return None
    if not (math.isfinite(cop) and all(math.isfinite(p) for p in predictions)):
        return None
    return Validation(tuple(predictions), cop)

@cache
def best_order(experiment: Experiment) -> str | None:
    """The basis of the polynomial with the largest CoP (None: no basis can be computed)."""
    scores = [(checked.cop, order) for order in ORDERS
              if (checked := validation(Candidate("polynomial", order, None), experiment)) is not None
              and fit(Candidate("polynomial", order, None), experiment) is not None]
    return max(scores, key=lambda score: score[0])[1] if scores else None

@cache
def best_radius(order: str, experiment: Experiment) -> float | None:
    """The D with the largest CoP among the slider's values, for a basis: the values in the order of their CoP, the
    first whose metamodel can also be computed on the check grid (fit; None: none can)."""
    scores = [(checked.cop, D) for D in RADII if (checked := validation(Candidate("mls", order, D), experiment)) is not None]
    for _cop, D in sorted(scores, key=lambda score: -score[0]):
        if fit(Candidate("mls", order, D), experiment) is not None:
            return D
    return None

@cache
def best_theta(experiment: Experiment) -> float | None:
    """The theta with the largest concentrated log-likelihood among the slider's values (None: none can be computed)."""
    data = sample(experiment)
    scores = []
    for theta in THETAS:
        try:
            likelihood = kriging.log_likelihood(data.unit, data.values, theta)
        except REFUSED:
            continue
        if math.isfinite(likelihood):
            scores.append((likelihood, theta))
    for _likelihood, theta in sorted(scores, reverse=True):             # the likeliest whose surface can be computed:
        if fit(Candidate("kriging", None, theta), experiment) is not None:     # usually the first, one fit
            return theta
    return None

@cache
def entry(k: int, experiment: Experiment) -> Entry:
    """Candidate k of the competition: the three polynomials, the three moving least squares, each at its best D, and
    Kriging at its theta of largest likelihood."""
    if k < len(ORDERS):
        candidate = Candidate("polynomial", ORDERS[k], None)
    elif k < 2 * len(ORDERS):
        order = ORDERS[k - len(ORDERS)]
        candidate = Candidate("mls", order, best_radius(order, experiment))
    else:
        candidate = Candidate("kriging", None, best_theta(experiment))
    if candidate.model != "polynomial" and candidate.value is None:
        return Entry(candidate, None)
    checked = validation(candidate, experiment)
    computed = checked is not None and fit(candidate, experiment) is not None
    return Entry(candidate, checked.cop if computed else None)

def winner(entries) -> int | None:
    """The index of the entry with the largest CoP (the first of them), or None when none was computed."""
    scored = [k for k, item in enumerate(entries) if item.cop is not None]
    return max(scored, key=lambda k: entries[k].cop) if scored else None

@cache
def champion(experiment: Experiment) -> Entry | None:
    """The winner of the competition on the designs of the experiment, the entry of largest CoP; None when no candidate
    can be computed. Computed once per experiment (about a second at N = 60): the first settings, the experiments
    received and the featured command's line ask for it often."""
    entries = [entry(k, experiment) for k in range(CANDIDATES)]
    first = winner(entries)
    return None if first is None else entries[first]

def candidate_of(settings: dict) -> Candidate:
    """The metamodel the controls choose."""
    model = settings["model"]
    if model == "polynomial":
        return Candidate(model, settings["order"], None)
    if model == "mls":
        return Candidate(model, settings["order"], settings["radius"])
    return Candidate(model, None, settings["theta"])

def chosen(candidate: Candidate) -> dict:
    """The settings of the controls that choose a candidate."""
    if candidate.model == "polynomial":
        return {"model": candidate.model, "order": candidate.order}
    if candidate.model == "mls":
        return {"model": candidate.model, "order": candidate.order, "radius": candidate.value}
    return {"model": candidate.model, "theta": candidate.value}

def first_surrogate(function: str, mode: str = TEACHER) -> Surrogate:
    """The surrogate a stand-alone optimization lab opens on: the first experiment of the bench, with the metamodel the
    step 2 of the mode opens on: the teacher's, the winner of its competition (the simplest one, should no candidate be
    computed); the student's, the simplest one (no competition is run)."""
    experiment = first_experiment(function)
    best = champion(experiment) if mode != STUDENT else None
    return Surrogate(experiment, Candidate(FIRST_MODEL, FIRST_ORDER, None) if best is None else best.candidate)

# ------------------------------------------------------------------------------
# The state
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class MetamodelState:
    model: str
    experiment: Experiment
    response: Response
    candidate: Candidate
    data: Sample
    fit: Fit | None                             # None: the metamodel cannot be computed with these designs
    check: Validation | None                    # None: the cross-validation cannot be computed (nor without a fit)
    probe: tuple[float, ...]                    # the query point, in the unit hypercube (on the slice: the held values its own)
    point: tuple[float, ...]                    # the same, in the bounds of the response
    influence: tuple[float, ...] | None         # a_i(u): how much each simulated value counts in the prediction there
    prediction: float | None                    # the metamodel at the query point (None with the influences)
    truth: float                                # the true response there
    ranking: tuple[Entry, ...]                  # the candidates of the competition shown so far
    language: str
    refused: str = ""                           # why the metamodel (or its value at the query point) cannot be computed
    section: Section = Section(2)               # the slice the figure shows (explorers/section.py): the whole design space
                                                # for two inputs; a view, never a part of the study

    @property
    def n(self) -> int:
        return self.experiment.n

    @property
    def scene(self) -> tuple:
        """Everything the figure shows that does not depend on the query point (the slice among it, by its key,
        Section.key: the same always for two inputs)."""
        return (self.candidate, self.experiment, len(self.ranking), self.language, self.section.key)

    @property
    def complete(self) -> bool:
        """Every candidate of the competition is shown."""
        return len(self.ranking) == CANDIDATES

class MetamodelLab(live.Pointing, section.Viewing, Lab):
    """Three metamodels of the designs of step 1: the weight of each design at a point, the surface beside the true response, and
    what the prediction is worth where nothing was simulated; the one on screen is handed to the optimization."""
    keys_text = "lab.mm.keys"                                   # what press does, for assistive technology (Lab.keyboard)
    winner_text = "lab.mm.contest.winner"                       # the featured command's second line, another model on
                                                                # screen ("winner: CoP 0.992 · Kriging ...": the CoP first,
                                                                # never cut; a lab may say it its own way)

    def __init__(self, function: str = FIRST_FUNCTION, mode: str = TEACHER):
        self.function = function
        self.mode = mode
        self.d = RESPONSES[function].d                        # the inputs: more than two, the figure shows a slice
        many = self.d > 2                                     # the tips that name the unit square or (u1, u2) say it in d
        self.controls = section.controls(function) + (        # the view's first (none for two inputs), then the metamodel's
            Control("model", get_text("lab.mm.model"), MODELS, MODELS.index(FIRST_MODEL),
                    names=tuple(get_text(f"lab.mm.model.{m}") for m in MODELS), tip=get_text("lab.mm.model_tip"), alone=True,
                    icons={"polynomial": "polynomial", "mls": "mls", "kriging": "kriging"}),
            Control("order", get_text("lab.mm.order"), ORDERS, ORDERS.index(FIRST_ORDER),
                    names=tuple(get_text(f"lab.mm.order.{o}") for o in ORDERS),
                    tip=get_text("lab.mm.order_many_tip" if many else "lab.mm.order_tip"),
                    visible=lambda settings: settings["model"] in ("polynomial", "mls"),
                    icons={"linear": "linear", "pure_quadratic": "pure_quadratic", "quadratic": "quadratic"}),
            Control("radius", get_text("lab.mm.radius"), RADII, RADII.index(FIRST_RADIUS), show=lambda D: f"D = {D:.2f}",
                    tip=get_text("lab.mm.radius_many_tip" if many else "lab.mm.radius_tip"),
                    visible=lambda settings: settings["model"] == "mls"),
            Control("theta", get_text("lab.mm.theta"), THETAS, THETAS.index(FIRST_THETA), show=lambda theta: f"θ = {theta:g}",
                    tip=get_text("lab.mm.theta_many_tip" if many else "lab.mm.theta_tip"),
                    visible=lambda settings: settings["model"] == "kriging"),
        )
        self.actions = (
            page_link(),
            Action("tune", get_text("lab.mm.tune.polynomial"), get_text("lab.mm.tune_tip"), mark="best",
                   beside="order radius theta"),             # on the line of the basis, D or theta, the last shown
            *((section.chip("best"),) if many else ()),      # back to the automatic slice, through the best design
            Action("contest", get_text("lab.mm.contest"), get_text("lab.mm.contest_tip"), motion="run",
                   playing_label=get_text("lab.mm.pause"), featured=True, mark="ranking"),
            Action("advance", get_text("lab.mm.advance"), get_text("lab.mm.advance_tip"), forward=True),
        )
        self.data = {"probe": first_probe(self.d), "contest": 0}
        self.restore = True
        self.height = HEIGHT                   # the least height of the three steps (doe.HEIGHT)
        self.frame_ms = 700                    # a candidate of the competition is read before the next one
        self.view = VIEW                       # the 3D view as the reader left it (a view, not a setting; the window carries it)
        self.turned = None                     # the angle the 3D view had when this lab last drew it: another one, the mouse turned it
        self.layout_key = None                 # the axes on the figure are reused while their layout holds
        self.cards = {}                        # the cards of the right column (panels.draw_cards), drawn once per layout
        self.scene = None                      # what the axes hold, but the query point: drawn again only when it changes
        self.plan = None
        self.axes: dict = {}
        self.moving: list = []                 # the artists that follow the query point and the mouse
        self.drawing = caption.drawing(function)     # the caption's block: a drawing's height, or None (the formula's)
        self.caption = None                    # the caption of the 3D view's card (explorers/caption.py), once per layout
        self.written = None                    # the formula of the response, typeset once per layout (None: drawn)
        self.block_made = {}                   # by the block's key: its layout, its composition, what it shows (draw_block)

    def settings(self) -> dict:
        """The experiment first (the bench's first one, so the lab works alone), then the controls and the data: the
        teacher's on the winner of the competition, the student's on the simplest metamodel."""
        settings = {"experiment": first_experiment(self.function)} | super().settings() | section.first(self.function)
        return self.viewed(self.crown(settings) if self.mode != STUDENT else settings)

    def opening(self, handed: Experiment | None = None) -> dict:
        """The first settings given an experiment: the controls and the data on it, the teacher's on the winner of ITS
        competition only (the first experiment's is never run for nothing), the student's on the simplest metamodel."""
        if handed is None:
            return self.settings()
        settings = {"experiment": handed} | Lab.settings(self) | section.first(self.function)
        return self.viewed(self.crown(settings) if self.mode != STUDENT else settings)

    def arranged(self, width: float, height: float | None):
        """The shared plan of a figure `width` x `height` layout pixels (height None: as tall as it needs), the one the
        three steps of the bench lay out with (panels.arrangement): without the third panel where the step's own stands
        in the column (Lab.columned: third=False; the readout's room at the 3D card's foot on a bench of one response)."""
        return arrangement(width, height, pair="space", drawing=self.drawing, notes=section.heading(self.function),
                           hero=self.hero, third=not self.columned, readout=not many(self.function))

    def height_for(self, width: int) -> int:
        """In a row or side by side, the lab's own height; stacked, the three blocks one under the other."""
        if width >= STACK_WIDTH:
            return self.height
        return round(self.arranged(width, None).room)

    def indicators(self, width: float, height: float) -> tuple | None:
        """The block of the step's measures beside the 3D view, under the beam's band (the plan's, Lab.indicators)."""
        return self.arranged(width, height).indicators

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """For the key BENCH, the formula of the bench's response (one line of mathtext; the figure typesets it); nothing
        for a control."""
        return formula(self.function) if key == BENCH else ((), "")

    # ------------------------------------------------------------------ what a lab of several responses replaces
    # (explorers/pareto_metamodel.py: one metamodel per response, the competitions shared, explorers/prognoses.py);
    # here each is this module's own function, the step of a bench of one response as it always was
    def fitted_to(self, settings: dict) -> Experiment:
        """The experiment the metamodel on screen is fitted to: the one received."""
        return settings["experiment"]

    def validation_of(self, candidate: Candidate, experiment: Experiment) -> Validation | None:
        """The cross-validation of a candidate and its CoP (validation)."""
        return validation(candidate, experiment)

    def entry_of(self, k: int, experiment: Experiment) -> Entry:
        """Candidate k of the competition (entry)."""
        return entry(k, experiment)

    def champion_of(self, experiment: Experiment) -> Entry | None:
        """The winner of the competition (champion)."""
        return champion(experiment)

    def best_radius_of(self, order: str, experiment: Experiment) -> float | None:
        """The D of largest CoP of a basis (best_radius): the Best D command's."""
        return best_radius(order, experiment)

    def crown(self, settings: dict) -> dict:
        """The settings with the winner of the competition on screen (crowned)."""
        return crowned(settings)

    def composition(self, plan) -> "Composition | None":
        """The third card's hero and check (composed)."""
        return composed(plan)

    def block_composition(self, plan) -> "Composition | None":
        """The block's CoP and check on a block's plan (panels.block_plan): block_composed."""
        _, _, wide, tall = plan.cards["check"]
        return block_composed(wide, tall)

    def plane_mesh(self, state: MetamodelState) -> tuple[np.ndarray, np.ndarray]:
        """The grid of the slice shown in the bounds of the pair, across and up, on which y^'s level lines are drawn on
        the plane (the true response's grid: truth)."""
        true = truth(state.response.key, state.section)
        return true.x1, true.x2

    # ------------------------------------------------------------------ a step of the study
    def output(self, state: MetamodelState) -> Surrogate | None:
        """The metamodel on screen, for the optimization; None while it cannot be computed with these designs."""
        return None if state.fit is None else Surrogate(state.experiment, state.candidate)

    def missing(self, state: MetamodelState) -> str:
        return "" if state.fit is not None else get_text("lab.mm.missing")

    def receive(self, settings: dict, handed: Experiment) -> dict:
        """The experiment on screen again: nothing changes (the reader's choice is kept). Another experiment from step 1:
        the competition closes and the query point stays; the teacher's lab puts the winner of the new competition on
        screen (the settings as they were when none can be computed), the student's keeps the model, the basis, D and
        theta the reader chose (the state says when they cannot be computed with the new designs)."""
        if handed == settings.get("experiment"):
            return settings
        received = settings | {"experiment": handed, "contest": 0}
        return self.viewed(self.crown(received) if self.mode != STUDENT else received)

    def received(self, state: MetamodelState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """What came from step 1 (the owner's 2026-11-21: no empty intervals, no smallest distance), in the order every
        received card of steps 2 and 3 keeps: the sampling and N (sampled), then Pearson's correlation of the designs in
        the unit square (from N = 3), all plain. A bench of more than two inputs writes the correlation as step 1's
        strip said it, in its words: the largest |ρ| among the pairs of inputs with its pair ("ρ(x₁, x₃) = +0.087")."""
        n, unit = state.n, state.data.unit
        if self.d > 2:
            columns = [[u[k] for u in unit] for k in range(self.d)]
            found = largest_correlation(columns) if n >= 3 else None
            rho = DASH if found is None else f"ρ({section.symbol(found[1][0])}, {section.symbol(found[1][1])}) = {found[0]:+.3f}"
            return get_text("lab.mm.received"), sampled(state.experiment) + ((get_text("lab.lhs.m.correlation_most"),
                                                                             rho.replace("-", "−"), "plain"),)
        xs, ys = [u[0] for u in unit], [u[1] for u in unit]
        try:
            rho = f"{correlation(xs, ys):+.3f}".replace("-", "−") if n >= 3 else DASH
        except ZeroDivisionError:
            rho = DASH
        return get_text("lab.mm.received"), sampled(state.experiment) + ((get_text("lab.mm.received.correlation"), rho, "plain"),)

    def summary(self, state: MetamodelState) -> tuple[str, str]:
        """What the step is worth, for the cover's track and the pill's tooltip: the CoP of the metamodel on screen, a
        warning at or below 0 (no better than the mean of the simulated values) and when it cannot be computed (a
        dash)."""
        if state.check is None:
            return get_text("lab.mm.summary", cop=DASH), "warning"
        return get_text("lab.mm.summary", cop=quality(state.check.cop)), "warning" if poor(state.check.cop) else "plain"

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> MetamodelState:
        """The state of the settings; never raises: what cannot be computed is None, and `refused` says why."""
        experiment = self.fitted_to(settings)
        candidate = candidate_of(settings)
        response = response_of(experiment.function, experiment.output)     # the response read: the bench's, for one
        data = sample(experiment)
        fitted = fit(candidate, experiment)
        cut = self.slice_of(settings)
        if cut.plain:
            probe = (float(settings["probe"][0]), float(settings["probe"][1]))
        else:                                                         # on the slice: the pair's two are the reader's
            probe = tuple(float(v) for v in cut.lift(*cut.project(probe_of(settings, self.d))))
        point = tuple(scaled([list(probe)], list(response.bounds))[0])
        influence = prediction = None
        refused = ""
        if fitted is None:
            refused = cannot(candidate, "fit", experiment.n, self.d)
        else:
            try:
                influence = tuple(influence_of(candidate, probe, data.unit))
                prediction = fitted.model(probe)
            except REFUSED:
                influence = prediction = None
            if influence is not None and not (math.isfinite(prediction) and all(math.isfinite(a) for a in influence)):
                influence = prediction = None
            if influence is None:
                refused = cannot(candidate, "probe", experiment.n, self.d)
        check = self.validation_of(candidate, experiment) if fitted is not None else None
        shown = 0 if self.mode == STUDENT else min(settings["contest"], CANDIDATES)     # a student never sees the competition
        ranking = tuple(self.entry_of(k, experiment) for k in range(shown))
        return MetamodelState(settings["model"], experiment, response, candidate, data, fitted, check, probe, point, influence,
                              prediction, float(response.f(*point)), ranking, current_language(), refused, cut)

    def automatic(self, settings: dict) -> tuple[float, ...] | None:
        """Where the slice of a bench of more than two inputs stands while no slider pinned it (section.of's `auto`):
        through the best design of the experiment received (the least simulated y, the first of equals: doe.through),
        which then lies on the surfaces drawn; None for two inputs (the slice is the whole design space)."""
        if self.d == 2 or settings.get("experiment") is None:
            return None
        return through(simulated(settings["experiment"]))

    def adjust(self, settings: dict, key: str, old) -> dict:
        """A control of the view (a bench of more than two inputs: an axis, a slider, the slice held the window carries)
        follows section.after (an axis given the input the other shows swaps the two, a slider pins the slice there),
        and nothing of the study changes: the competition stays as it is, the metamodel too. Another control changed:
        the competition closes; and the moving least squares come on screen with a radius that can be computed for
        these designs (its slider was not on show while another model was chosen). Then the sliders stand at the slice
        on screen (viewed)."""
        viewed = self.adjust_view(settings, key, old)                  # a key of the view (section.Viewing)
        if viewed is not None:
            return viewed
        settings = settings | {"contest": 0}
        if key == "model" and settings["model"] == "mls":
            within = next((D for D in RADII[RADII.index(settings["radius"]):]
                           if fit(Candidate("mls", settings["order"], D), self.fitted_to(settings)) is not None), None)
            if within is not None:
                settings = settings | {"radius": within}
        return self.viewed(settings)

    def act(self, key: str, state: MetamodelState, settings: dict) -> dict:
        experiment = self.fitted_to(settings)
        if key == section.CHIP:                                       # the view: back to the automatic slice
            return self.viewed(section.released(settings))
        if key in COACHED and not self.offered(key, settings):          # a student's lab: nothing chosen for the reader
            return settings
        if key == "tune":
            if settings["model"] == "polynomial":                     # only the search of the model on screen
                name, best = "order", best_order(experiment)
            elif settings["model"] == "mls":
                name, best = "radius", self.best_radius_of(settings["order"], experiment)
            else:
                name, best = "theta", best_theta(experiment)
            return settings | {"contest": 0} | ({} if best is None else {name: best})
        return super().act(key, state, settings)

    def enabled(self, key: str, state: MetamodelState) -> bool:
        """The optimization can be reached only with a metamodel that can be computed."""
        return state.fit is not None if key == "advance" else True

    def offered(self, key: str, settings: dict) -> bool:
        """A student calibrates by hand, reading the CoP: neither the optimal prognosis nor the Best command. The chip of
        the slice (a bench of more than two inputs), while a slider pinned it."""
        if key == section.CHIP:
            return section.pinned(settings)
        return self.mode != STUDENT or key not in COACHED

    def rewind(self, key: str, state: MetamodelState, settings: dict) -> dict:
        """The competition already at its end begins again, from no candidate."""
        if key == "contest" and settings["contest"] >= CANDIDATES:
            return settings | {"contest": 0}
        return settings

    def advance(self, state: MetamodelState, settings: dict) -> dict | None:
        """One more candidate; with the last one, the candidate of largest CoP becomes the model on screen (none for a
        student, who has no competition)."""
        shown = settings["contest"]
        if shown >= CANDIDATES or self.mode == STUDENT:
            return None
        following = settings | {"contest": shown + 1}
        return self.crown(following) if shown + 1 == CANDIDATES else following

    def cue(self, key: str, state: MetamodelState) -> str:
        """The competition played to its end: "complete"; a Best command: "apply"; nothing else sounds."""
        if key == "contest" and state.complete:
            return "complete"
        return "apply" if key == "tune" and self.mode != STUDENT else ""

    def link(self, key: str, state: MetamodelState) -> str:
        """"View code" asks the window for the reading of the model on screen (gui/lab_code.py)."""
        return state.model if key == LINK else ""

    def naming(self, key: str, state: MetamodelState) -> str:
        """The command Best says what it looks for: the basis, D or theta. The featured command's second line: while its
        frames play, the candidate shown; otherwise the winner and its CoP, a check mark before it when it is the model
        on screen, the word "winner" when the reader chose another (and what a competition that judges none says)."""
        if key == "tune":
            return get_text(f"lab.mm.tune.{state.model}")
        if key != "contest" or self.mode == STUDENT:
            return ""
        if 0 < len(state.ranking) < CANDIDATES:
            return get_text("lab.mm.contest.playing", shown=len(state.ranking), total=CANDIDATES)
        best = self.champion_of(state.experiment)
        if best is None:
            return get_text("lab.mm.contest.none")
        cop = f"{MARK} {quality(best.cop)}" if poor(best.cop) else quality(best.cop)
        said = "lab.mm.contest.on_screen" if best.candidate == state.candidate else self.winner_text
        return get_text(said, name=named(best.candidate), cop=cop)

    # ------------------------------------------------------------------ what to read
    def lead(self, state: MetamodelState) -> str:
        """One short sentence, the figure's accessible description: the model on screen, or the competition."""
        if state.complete and (first := winner(state.ranking)) is not None:
            item = state.ranking[first]
            return get_text("lab.mm.lead.winner", total=CANDIDATES, name=named(item.candidate), cop=quality(item.cop))
        if state.complete:
            return get_text("lab.mm.lead.none", total=CANDIDATES)
        if state.ranking:
            item = state.ranking[-1]
            return get_text("lab.mm.lead.contest", shown=len(state.ranking), total=CANDIDATES, name=named(item.candidate),
                            cop=DASH if item.cop is None else quality(item.cop))
        if state.fit is None:                                         # why: on the figure, in the 3D view's place
            return get_text("lab.mm.lead.cannot")
        if self.d > 2 and state.model == "kriging":                   # a slice passes through the designs on it only
            return get_text("lab.mm.lead.kriging_many")
        return get_text(f"lab.mm.lead.{state.model}")

    def metrics(self, state: MetamodelState) -> list[Metric]:
        """The CoP first and emphasised (strong: the one the step is judged by), then the CoD and the coefficient
        against the true response, each with a tip of one sentence that defines it (why a value cannot be computed is
        said on the figure). A student calibrates by the CoP, never by the answer: the coefficient against the true
        response, which a study never has, is not shown to him until the bench is complete (won). For two inputs that
        coefficient is measured on the GRID x GRID grid; for more, on the TESTED points of a Latin hypercube, and its
        texts say so."""
        fitted = state.fit is not None
        measures = [Metric(get_text("lab.mm.m.cop"), cop_written(state), kind="warning" if cop_warned(state) else "plain",
                           detail=get_text("lab.mm.m.cop_detail", folds=FOLDS), tip=get_text("lab.mm.m.cop_tip"),
                           strong=True),
                    Metric(get_text("lab.mm.m.cod"), quality(state.fit.cod) if fitted else DASH, kind="plain" if fitted else "warning",
                           detail=get_text("lab.mm.m.cod_detail"), tip=get_text("lab.mm.m.cod_tip"))]
        if not self.against_shown():
            return measures
        against = state.fit.against if fitted else None
        if self.d > 2:
            detail, tip = get_text("lab.mm.m.true_detail_many", points=TESTED), get_text("lab.mm.m.true_many_tip", points=TESTED)
        else:
            detail, tip = get_text("lab.mm.m.true_detail", grid=GRID), get_text("lab.mm.m.true_tip", grid=GRID)
        return measures + [Metric(get_text("lab.mm.m.true"), DASH if against is None else quality(against),
                                  kind="plain" if against is not None else "warning", detail=detail, tip=tip)]

    def against_shown(self) -> bool:
        """Whether the coefficient against the true response is shown (the strip, the hero): where the true response
        is shown at all (Lab.truth_shown: a test function's, a simulation's once revealed), to a teacher, and to a
        student once the bench is complete."""
        return self.truth_shown() and (self.mode != STUDENT or self.won)

    def references(self, state: MetamodelState) -> list[tuple[str, float | None, str]]:
        """What the hero sets beside the CoP, smaller and muted, each with its name, its value (None: not computed) and
        the ink of its gauge: the CoD at the designs, and the coefficient against the true response where it is shown."""
        fitted = state.fit is not None
        rows = [(get_text("lab.mm.hero.cod"), state.fit.cod if fitted else None, REFERENCE_INK)]
        if self.against_shown():
            rows.append((get_text("lab.mm.hero.true"), state.fit.against if fitted else None, REFERENCE_INK))
        return rows

    # ------------------------------------------------------------------ the mouse and the keys
    def hit(self, figure, state: MetamodelState, event):
        """The query point ("probe") or the design (its index) under the mouse, in the design space or in the check."""
        if event is None:
            return None
        plane, check = self.axes.get("plane"), self.axes.get("check")
        if plane is not None and event.inaxes is plane:
            cut = state.section
            if nearest(plane, [state.point if cut.plain else cut.project(state.point)], event, radius=PROBE_RADIUS) is not None:
                return "probe"
            return nearest(plane, section.projected(state.section, state.data.points), event)
        if check is not None and event.inaxes is check and state.check is not None:
            return nearest(check, checked_points(state), event)
        return None

    def grabbable(self, hovered) -> bool:
        return hovered == "probe"

    def grab(self, figure, state: MetamodelState, event):
        """A press anywhere in the design space takes the query point there; one on the competition closes it."""
        if event is None or event.inaxes is None:
            return None
        if event.inaxes is self.axes.get("plane"):
            return "probe"
        if event.inaxes is self.axes.get("ranking") and state.ranking:
            return "ranking"
        return None

    def takes(self, state: MetamodelState) -> bool:
        """A press on the design space takes the query point there, always."""
        return True

    def drag(self, figure, state: MetamodelState, handle, event, settings: dict) -> dict | None:
        if handle == "ranking":
            return settings | {"contest": 0} if settings["contest"] else None
        plane = self.axes.get("plane")
        if handle != "probe" or plane is None or not plane.get_visible():
            return None
        x1, x2 = plane.transData.inverted().transform((event.x, event.y))      # also from over another panel: kept on the border
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        return moved(settings, (x1 - a1) / (b1 - a1), (x2 - a2) / (b2 - a2), state.section)

    def press(self, key: str, state: MetamodelState, settings: dict) -> dict | None:
        """The arrow keys move the query point (on a bench of more than two inputs, in the pair's unit square, the
        inputs held at the slice's values)."""
        du1, du2 = {"left": (-STEP, 0.0), "right": (STEP, 0.0), "up": (0.0, STEP), "down": (0.0, -STEP)}.get(key, (0.0, 0.0))
        if self.d == 2:
            return moved(settings, settings["probe"][0] + du1, settings["probe"][1] + du2)
        cut = self.slice_of(settings)
        p, q = cut.project(probe_of(settings, self.d))
        return moved(settings, p + du1, q + du2, cut)

    # ------------------------------------------------------------------ the figure
    def boxes(self, figure) -> dict:
        """The panels' boxes and the places of their titles, in figure fractions, from the plan the three steps share
        (panels.arrangement with pair="space"), in layout pixels; on the third card, the hero and the check where
        composed puts them. Where the step's own panel stands in the column (Lab.columned), the design space and the 3D
        view alone: no check, no hero, no competition in the figure (they are the block's, draw_block)."""
        width, height = size(figure)
        plan = self.arranged(width, height)

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)     # a box is never empty
        if self.columned:
            return {"plane": frac(*plan.plane), "space": frac(*plan.space), "heads": places(plan, width, height)}
        boxes = {"plane": frac(*plan.plane), "space": frac(*plan.space), "ranking": frac(*plan.ranking)}
        third = self.composition(plan)
        if third is not None:
            boxes["check"], boxes["hero"] = frac(*third.check), frac(*third.hero)
        boxes["heads"] = places(plan, width, height)
        return boxes

    def prepare(self, figure, state: MetamodelState) -> dict:
        """The axes of the figure: made again when the layout changes, reused otherwise (the panels keep what they
        hold). The 3D view turned with the mouse since this lab drew it gives its angle to `view`."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height), state.language,      # the hero's width is measured in its language
               self.columned)
        space = self.axes.get("space")
        if space is not None and space.figure is figure and self.turned is not None and (space.elev, space.azim) != self.turned:
            self.view = (space.elev, space.azim)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = self.arranged(width, height)
            self.cards = draw_cards(figure, self.plan)                   # the 3D view's and the third panel's, once per layout
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "check", "hero", "ranking") if name in boxes}
            self.ranking_box = boxes.get("ranking")                   # the competition's box, before it rises (draw_ranking)
            self.axes["space"] = figure.add_axes(boxes["space"], projection="3d")
            self.axes["plane"].set_zorder(1)                          # its last x1 tick label overhangs the 3D box, which
                                                                      # begins 2 px later: drawn above it, the label is whole
            self.heads = boxes["heads"]
            self.caption = caption.Caption(figure, self.plan, self.heads, self.function,     # once per layout: its axes
                                           state.section.pair, self.columned)     # 1A where columned
            self.written = self.caption.written                       # are the caption's own, never the lab's to clear
            self.layout_key = key
            self.scene = None
            self.moving = []
        return self.axes

    def draw(self, figure, state: MetamodelState, hovered) -> None:
        axes = self.prepare(figure, state)
        scene = (state.scene, self.against_shown(), self.truth_shown())     # a bench completed shows the student the
        if self.scene != scene:                                       # truth; anything but the query point: the whole figure
            self.draw_scene(figure, axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        if axes["plane"].get_visible():
            self.draw_voices(axes["plane"], state, hovered)
        self.draw_query(axes["space"], state, hovered)
        if "check" in axes and axes["check"].get_visible():
            self.draw_found(axes["check"], state, hovered)
        self.live(state, hovered)                                     # the drawing's focus and the crosshair, last
        space = axes["space"]
        if (space.elev, space.azim) != tuple(self.view):              # the angle the window carried from another step
            space.view_init(*self.view)
        self.turned = (space.elev, space.azim)

    def focused(self, state: MetamodelState, hovered):
        """The drawing's focus: the design pointed at, the place under the pointer, or the best design; never the
        query point (a prediction)."""
        return caption.pointed(state.data.points, state.data.values, hovered, self.pointer)

    def draw_scene(self, figure, axes: dict, state: MetamodelState) -> None:
        """Everything that stays while the query point moves: the designs, the surfaces, the check or the competition,
        the titles and the legends."""
        for ax in axes.values():
            ax.clear()
        for text in list(figure.texts):
            if text is not self.written:                              # the formula stays: drawn once per layout
                text.remove()
        for legend in list(figure.legends):
            legend.remove()
        self.moving = []
        contest = bool(state.ranking) and not self.columned           # in the column, the competition is the block's
        alone = (third := self.composition(self.plan)) is not None and third.alone     # a phone's narrow card: the hero alone
        shown = {"plane": not (contest and "check" not in axes), "space": True, "check": not contest and not alone,
                 "hero": not contest, "ranking": contest}
        for name, ax in axes.items():
            ax.set_visible(shown[name])
        note = section.note(self.function, state.section)            # the slice shown: "" for two inputs
        surface = surface_of(state)
        if shown["plane"]:
            self.draw_plane(axes["plane"], state, surface)
            handles = [dot(POINT, get_text("lab.mm.legend.positive"), soft=True),
                       dot(NEGATIVE, get_text("lab.mm.legend.negative"), hollow=True),
                       dot(QUERY, get_text("lab.mm.legend.probe"), marker="D", size=6.5)]
            if surface is not None:
                handles.append(Line2D([], [], color=LINES["colors"], linewidth=1.0, alpha=0.8, label=get_text("lab.mm.legend.levels")))
            head(figure, self.heads, self.axes, "plane", get_text("lab.mm.plane_title"), handles, note,
                 "plane" in self.plan.noted, panels.legend_most(self.plan, "plane"))
        self.draw_space(axes["space"], state, surface)
        true = self.truth_shown()                                     # f, where it is shown (a simulation's: revealed)
        title = get_text(("lab.mm.space_title_many" if self.d > 2 else "lab.mm.space_title") if true      # shorter beside
                         else "lab.mm.space_title_alone")                                                # the note
        alone, read = self.plan.alone, self.plan.readout is not None    # the card alone (2A): one row, the query point
        head(figure, self.heads, self.axes, "space", title, [
            Patch(facecolor=palette.SURFACE_RAMP[3], label=get_text("lab.mm.legend.surface")),
            *((wire_handle(get_text("lab.mm.legend.truth"), alone),) if true else ()),
            dot(POINT, get_text("lab.mm.legend.designs")),
            *((dot(QUERY, get_text("lab.mm.legend.query")),) if read else ())], note, "space" in self.plan.noted,
            panels.legend_most(self.plan, "space"))
        if contest:
            rows = head(figure, self.heads, self.axes, "ranking", get_text("lab.mm.ranking_title"), [
                Patch(facecolor=POINT, label=get_text("lab.mm.legend.cop")),
                Patch(facecolor=WINNER, label=get_text("lab.mm.legend.largest"))])
            self.draw_ranking(axes["ranking"], state, rows)
        elif "check" in axes:
            if not alone:
                self.draw_check(axes["check"], state)
            self.draw_hero(axes["hero"], state)
            head(figure, self.heads, self.axes, "check", get_text("lab.mm.check_title"), [])      # its title alone: the
            third = self.composition(self.plan)                                                  # check's legend over it
            if third is not None and third.legend is not None and state.check is not None and not alone:
                x, top, room = third.legend
                width, height = size(figure)
                legend_at(figure, x / width, top / height, room, check_handles(), 4 if self.plan.head > HEAD else 2)

    def draw_plane(self, ax, state: MetamodelState, surface: np.ndarray | None) -> None:
        """The design space with every design where step 1 placed it and simulated it, over the faint level lines of
        the metamodel y^ (`surface`, its values on the grid of the surfaces: surface_of; the levels and the look step 3
        draws them with, where it searches on them); none when the metamodel cannot be computed. They belong to the
        scene: the query point moving leaves them. On a bench of more than two inputs, the pair's axes, y^'s slice, and
        each design at its projection, fainter the farther it is from the slice and larger near it (doe.Marks)."""
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        cut = state.section
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        plane_ticks(ax, self.plan is not None and self.plan.band is not None)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        self.plane_designs(ax, state, min(marker_size(state.n), 16.0))
        if surface is not None and (levels := level_values(surface)):       # under everything (zorder), drawn after the
            x1, x2 = self.plane_mesh(state)                           # designs: the first collection stays theirs
            ax.contour(x1, x2, surface, levels=levels, **LINES)
        name_plane(ax, state.response.units, cut.pair, many(self.function))     # x1, x2 and their units, as in the other steps

    def plane_designs(self, ax, state: MetamodelState, area: float) -> None:
        """Every design on the plane, a blue dot of `area` (a bench of more than two inputs: at its projection, larger
        near the slice and fainter off it, doe.Marks), under the weights' discs."""
        cut = state.section
        if cut.plain:
            xs, ys = zip(*state.data.points)
            ax.scatter(xs, ys, s=area, c=POINT, edgecolors=palette.CARD, linewidths=0.7, zorder=6)
        else:                                                         # projections, larger near the slice, fainter off it
            marks = Marks.of(cut, state.data.points, state.data.unit)
            ax.scatter(marks.xs, marks.ys, s=marks.areas(area), color=marks.inks(POINT), edgecolors=marks.inks(palette.CARD),
                       linewidths=Marks.EDGE, zorder=6)

    def draw_voices(self, ax, state: MetamodelState, hovered) -> None:
        """The weight of each design in y^ at the query point: on each design a disc of area |a_i(u)|, filled where a_i is positive, hollow
        where it is negative; the query point and, around it, the distance where a weight or a correlation is 1/e. When
        the metamodel cannot be computed there, the query point alone (and, the metamodel computed, why: on the panel).
        On a bench of more than two inputs the weights are those at the query point of d inputs (on the slice), each
        disc at its design's projection; the circle is exact there: the ball of that radius around a point of the
        slice meets the slice in it."""
        cut = state.section
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        x, y = state.point if cut.plain else cut.project(state.point)
        if state.influence is not None:
            placed = sorted(zip(state.influence, section.projected(cut, state.data.points)),
                            key=lambda pair: -abs(pair[0]))                       # the small ones on top
            for sign, face, edge, width in ((1, tint(POINT, 0.42), POINT, 0.9), (-1, "none", NEGATIVE, 1.5)):
                voices = [(abs(a), point) for a, point in placed if a * sign > 0]
                if voices:
                    areas, points = zip(*voices)
                    xs, ys = zip(*points)
                    self.moving.append(ax.scatter(xs, ys, s=[AREA * area for area in areas], facecolors=face, edgecolors=edge,
                                                  linewidths=width, zorder=4 if sign > 0 else 5))
            reach = reach_of(state.candidate)
            if reach is not None:
                radius, name = reach
                circle = Ellipse((x, y), 2 * radius * (b1 - a1), 2 * radius * (b2 - a2), fill=False, edgecolor=QUERY, linewidth=1.1,
                                 linestyle=(0, (4, 3)), alpha=0.9, zorder=7)
                self.moving.append(ax.add_patch(circle))
                p, q = cut.project(state.probe)
                for angle in (45, 135, 315, 225):                     # its name, on the first place of its rim inside the panel
                    u1 = p + radius * math.cos(math.radians(angle))
                    u2 = q + radius * math.sin(math.radians(angle))
                    if 0.06 < u1 < 0.94 and 0.06 < u2 < 0.94:
                        right, above = math.cos(math.radians(angle)) > 0, math.sin(math.radians(angle)) > 0
                        place = (a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2)
                        self.moving.append(ax.annotate(name, place, xytext=(4 if right else -4, 3 if above else -3),
                                                       textcoords="offset points", ha="left" if right else "right",
                                                       va="bottom" if above else "top", color=QUERY, **TAG, zorder=9))
                        break
        elif state.fit is not None:                                   # the metamodel exists, not at this point
            columns = max(int(ax.get_position().width * size(ax.figure)[0] / 6.6), 12)
            self.moving.append(ax.text(0.5, 0.04, fill(state.refused, columns), transform=ax.transAxes, ha="center", va="bottom",
                                       color=WARNING, **TAG, zorder=10, bbox=BOXED))
        if isinstance(hovered, int) and hovered < state.n:
            hx, hy = cut.project(state.data.points[hovered])
            ring = 150 if cut.plain else section.shrunk(150, cut.closeness(state.data.unit[hovered]))     # smaller off the slice
            self.moving.append(ax.scatter([hx], [hy], s=ring, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4, zorder=8))
            if state.influence is not None:
                p, q = cut.project(state.data.unit[hovered])
                right, above = p < 0.62, q < 0.86
                label = f"a{subscript(hovered + 1)} = {state.influence[hovered]:+.3f}".replace("-", "−")
                self.moving.append(ax.annotate(label, (hx, hy), xytext=(9 if right else -9, 8 if above else -8),
                                               textcoords="offset points", ha="left" if right else "right",
                                               va="bottom" if above else "top", color=palette.WHITE, **TAG, zorder=10,
                                               bbox=BOXED))
        self.moving.append(ax.scatter([x], [y], s=95 if hovered == "probe" else 70, marker="D", c=QUERY, edgecolors=palette.CARD,
                                      linewidths=1.0, zorder=9))

    def draw_space(self, ax, state: MetamodelState, surface: np.ndarray | None) -> None:
        """The metamodel as a surface (`surface`: surface_of), cut at the vertical window (said at the top of the card,
        under its legend: panels.cut_note), the true response as a wire over it, and the designs at their simulated
        values; without a metamodel, the wire, the designs and one clause on the card's tone saying there is no surface
        (why: the CoP's card), centred on the card, or under the band on the 3D box (its card's side holds the head and
        the measures). On a bench of more than two inputs, y^'s slice and f's slice on the pair (the inputs held
        at the values the heads write), coloured on the bench's range (doe.extent) in the bench's window, and the
        designs at their projections and their own y, fainter and smaller off the slice: only a design on the slice
        lies on the surfaces drawn."""
        ax.set_facecolor("none")                                       # its card shows
        ax.computed_zorder = False                                    # the wire and the designs stay in front of the surface
        section_ = state.section
        true = truth(state.response.key, section_)
        low, high = true.low, true.high
        if surface is not None:
            polygons, heights, cut = facets(true.x1, true.x2, surface, low, high)
            if polygons:
                if section_.plain:
                    shares = (np.array(heights) - float(true.y.min())) / float(true.y.max() - true.y.min())
                else:                                                 # every slice in the bench's colours
                    lowest, highest = extent(state.response.key)
                    shares = (np.array(heights) - lowest) / (highest - lowest)
                colors = RAMP(np.clip(shares, 0.0, 1.0))
                if self.plan.alone:                                   # the window's figure: a light on y^'s facets (3A)
                    colors = lit_facets(polygons, colors, spans(state, low, high, self.plan.aspect))
                ax.add_collection3d(Poly3DCollection(polygons, facecolors=colors, edgecolors="none", linewidths=0, antialiaseds=False,
                                                     alpha=0.9, zorder=1))
            if cut:
                cut_note(ax, self.heads, "space", f"{MARK} " + get_text("lab.mm.cut", low=short(float(surface.min()), 4),
                                                                         high=short(float(surface.max()), 4)),
                         WARNING, panels.dropped(self.plan, "space"))
        else:                                                         # one clause, on the card's tone: why is the CoP card's
            width = size(ax.figure)[0]                                # in the room of its card, centred on it; under the
            left, _, wide, _ = self.plan.space if self.plan.indicators is not None else self.plan.cards["space"]   # band,
                                                                      # of the 3D box (the card's side holds the head and
                                                                      # the measures)
            room = min(wide - 2 * RANK_INSET, 0.8 * ax.get_position().width * width) - 12.0
            clause = "lab.mm.space.slice" if state.fit is not None else "lab.mm.space.cannot"     # computed, not on this slice
            said = f"{MARK}  " + wrapped(get_text(clause), NOTE["fontsize"], room - 20.0)       # (no CoP card, the pair,
            if state.refused and not self.columned and ("check" not in self.axes          # a phone's card: why under it;
                                                        or self.composition(self.plan).alone):     # the column's block
                                                                      # says it in its check's place)
                said += "\n" + wrapped(state.refused[:1].upper() + state.refused[1:] + ".", NOTE["fontsize"], room)
            box = ax.get_position()
            ax.text2D(((left + wide / 2) / width - box.x0) / box.width, 0.62, said, transform=ax.transAxes, ha="center", va="center",
                      color=WARNING, **NOTE, zorder=10, bbox=BOXED | {"facecolor": CARD_TONE, "alpha": 1.0, "boxstyle": "round,pad=0.5"})
        if self.truth_shown():                                        # f, a simulation's only once revealed: a fine wire
            true_wire(ax, true.x1, true.x2, true.y, fine=self.plan.alone)     # over a lit surface (3A)
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        ax.plot([a1, b1, b1, a1, a1], [a2, a2, b2, b2, a2], [low] * 5, color=palette.DARK_GREY, linewidth=0.8, zorder=1)
        area = marker_size(state.n) * 0.7
        if section_.plain:
            xs, ys = zip(*state.data.points)
            ax.scatter(xs, ys, state.data.values, s=area, c=POINT, edgecolors=palette.CARD, linewidths=0.7, depthshade=False, zorder=4)
        else:
            marks = Marks.of(section_, state.data.points, state.data.unit, state.data.values)
            ax.scatter(marks.xs, marks.ys, marks.values, s=marks.areas(area, grow=False), color=marks.inks(POINT),
                       edgecolors=marks.inks(palette.CARD), linewidths=Marks.EDGE, depthshade=False, zorder=4)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        ax.set_zlim(low, high)
        ax.set_box_aspect((1.0, 1.0, self.plan.aspect), zoom=SPACE_ZOOM)     # the plan's: filling its card, alone
        style_space(ax, state.response.units, section_.pair)
        space_ticks(ax, not section_.plain)
        ax.view_init(*self.view)

    def draw_query(self, ax, state: MetamodelState, hovered) -> None:
        """At the query point: a vertical line, the prediction on it (a triangle on the edge of the window when it is
        beyond) and the true value (a ring and "f = ...", only where f is shown: Lab.truth_shown); and the design under
        the mouse. On a bench of more than two inputs, at the query point's projection (it lies on the slice: its
        prediction on y^'s surface, its true value on f's wire), and the design at its own projection and y; its two
        values, less than a line apart on screen (panels.screen_gap, LABELS_APART), written on one line at the higher,
        "ŷ = 3.386 · f = 3.387", instead of one over the other."""
        cut_ = state.section
        true = truth(state.response.key, cut_)
        low, high = true.low, true.high
        x, y = state.point if cut_.plain else cut_.project(state.point)
        self.moving += ax.plot([x, x], [y, y], [low, high], color=QUERY, linewidth=0.9, linestyle=(0, (3, 2)), alpha=0.8, zorder=5)
        known, merged = self.truth_shown(), False                     # f's value there, where f is shown (Lab.truth_shown)
        if known:
            self.moving.append(ax.scatter([x], [y], [state.truth], s=74, facecolors="none", edgecolors=TRUE, linewidths=1.6,
                                          depthshade=False, zorder=6))
        if state.prediction is None:
            values = ((state.truth, "f", TRUE, True),) if known else ()
        else:
            inside = low <= state.prediction <= high
            marker = "o" if inside else ("^" if state.prediction > high else "v")
            self.moving.append(ax.scatter([x], [y], [min(max(state.prediction, low), high)], s=46, marker=marker, c=QUERY,
                                          edgecolors=palette.CARD, linewidths=0.8, depthshade=False, zorder=7))
            above = state.prediction >= state.truth or not known      # the two values, each on its side of the other
            values = ((state.prediction, "ŷ", QUERY, above),) + (((state.truth, "f", TRUE, not above),) if known else ())
            ends = [min(max(value, low), high) for value in (state.prediction, state.truth)]
            if known and not cut_.plain and screen_gap(ax, x, y, *ends) < LABELS_APART:     # less than a line apart: one
                # line, at the higher (a bench of more than two inputs; those of two keep their labels as they were drawn)
                said = f"ŷ = {short(state.prediction, 4)} · f = {short(state.truth, 4)}"
                values, merged = ((max(state.prediction, state.truth), said, palette.WHITE, True),), True
        if self.plan.readout is not None:                             # the card alone (2A): the values read at its foot,
            values = ()                                               # never over the surface (readout)
            self.moving += readout(ax.figure, self.plan, self.readings(state, hovered))
        for value, name, color, over in values:
            said = name if merged else f"{name} = {short(value, 4)}"
            self.moving.append(ax.text(x, y, min(max(value, low), high), f"  {said}", color=color, **TAG,
                                       ha="left", va="bottom" if over else "top", zorder=5.8, bbox=TAG_BOX))     # under the
                                                                                # marks (6, 7), over the wire and the line
        if isinstance(hovered, int) and hovered < state.n:
            (hx, hy), value = cut_.project(state.data.points[hovered]), state.data.values[hovered]
            ring = marker_size(state.n) * 2.4 * (1.0 if cut_.plain else section.shrunk(1.0, cut_.closeness(state.data.unit[hovered])))
            self.moving.append(ax.scatter([hx], [hy], [value], s=ring, facecolors="none", edgecolors=palette.WHITE,
                                          linewidths=1.4, depthshade=False, zorder=7))
            if self.plan.readout is None:                             # else the readout's
                self.moving.append(ax.text(hx, hy, value, f"   y{subscript(hovered + 1)} = {short(value, 4)}", color=palette.WHITE,
                                           **TAG, ha="left", va="bottom", zorder=8, path_effects=HALO))

    def readings(self, state: MetamodelState, hovered) -> list:
        """The readout of the 3D view's card alone (panels.readout, the owner's 2A): on its first row the query point x,
        y^ there and, where f is shown (Lab.truth_shown), f there; on its second the design under the mouse, x_i and its
        simulated y_i; each name in its mark's ink, the units of the response after the numbers."""
        units = state.response.units
        first = [("x", MUTED_INK, read_point(state.point, units[0]))]
        if state.prediction is not None:
            first.append(("ŷ", QUERY, read_value(short(state.prediction, 4), units[-1])))
        if self.truth_shown():
            first.append(("f", TRUE, read_value(short(state.truth, 4), units[-1])))
        rows = [first]
        if isinstance(hovered, int) and hovered < state.n:
            index = subscript(hovered + 1)
            rows.append([(f"x{index}", MUTED_INK, read_point(state.data.points[hovered], units[0])),
                         (f"y{index}", palette.WHITE, read_value(short(state.data.values[hovered], 4), units[-1]))])
        return rows

    def draw_check(self, ax, state: MetamodelState) -> None:
        """Every design predicted by a metamodel fitted without it, against its simulated value: on the diagonal the two
        agree. A prediction beyond the window is a triangle on its edge. The CoP it gives is the hero's, beside it. What
        cannot be computed is said on the panel, across the square and its tick labels' room, with nothing to plot."""
        style_axes(ax)
        ax.set_facecolor(panels.BLOCK_TONE if self.in_block(ax) else CARD_TONE)     # on its card, or on the block
        low, high = spread(state.data.values)
        ax.set_xlim(low, high)
        ax.set_ylim(low, high)
        side = ax.get_position().width * size(ax.figure)[0]
        third = self.composed_for(ax)
        named = third is None or third.names                          # a square too small for its names: its tick labels
        gutter, under = (CHECK_LEFT, BELOW) if named else (CHECK_TIGHT, BELOW_TIGHT)     # alone, a tighter gutter
        well = self.in_block(ax) and self.columned                    # the block's check (1C): a square in a well
        if state.check is None:
            if state.fit is None:                                     # why, once: the 3D view says only that there is no
                why = state.refused[:1].upper() + state.refused[1:] + "."     # surface, the foot that it cannot hand
            else:
                why = get_text("lab.mm.check.cannot." + ("mls" if state.model == "mls" else "fit"))
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            room = side + gutter - 12.0                              # the square and the room of its tick labels and names
            ax.text(0.5 - gutter / 2 / side, 0.5 - (under - 6.0) / 2 / side, wrapped(why, NOTE["fontsize"], room),
                    transform=ax.transAxes, ha="center", va="center", color=WARNING, **NOTE, zorder=5, linespacing=1.15)
            return
        bins = 5 if side >= CHECK_FEW else 3 if side >= CHECK_FEW / 2 else 2
        ax.xaxis.set_major_locator(MaxNLocator(bins))
        ax.yaxis.set_major_locator(MaxNLocator(bins))
        if named:                                                     # its full names, or its short ones (composed)
            x_name, y_name = check_names("full" if third is None else third.names)
            ax.set_xlabel(x_name, **LABEL, labelpad=3)
            ax.set_ylabel(y_name, **LABEL, labelpad=4)
        if well:
            welled(ax, side)
            self.draw_welled(ax, state, low, high)
            return
        ax.plot([low, high], [low, high], color=TRUE, linewidth=1.1, alpha=0.8, zorder=2)
        area = marker_size(state.n) * 0.8
        for marker, keep in (("o", lambda p: low <= p <= high), ("^", lambda p: p > high), ("v", lambda p: p < low)):
            points = [(value, min(max(p, low), high)) for value, p in zip(state.data.values, state.check.predictions) if keep(p)]
            if points:
                xs, ys = zip(*points)
                ax.scatter(xs, ys, s=area, marker=marker, c=POINT, edgecolors=palette.CARD, linewidths=0.7, zorder=4, clip_on=marker == "o")

    def draw_welled(self, ax, state: MetamodelState, low: float, high: float) -> None:
        """The check of the block (the owner's 1C), in its well (welled): the line 1:1 and the designs predicted within
        the window clipped to the well's corners; a prediction beyond the window a small arrow on the edge it passes,
        pointing out (EDGE_ARROW), at its simulated value."""
        well = ax.patches[0]
        inset = 0.03 * (high - low)                                   # the line stops short of the well's rounded corners
        line, = ax.plot([low + inset, high - inset], [low + inset, high - inset], color=TRUE, linewidth=1.1, alpha=0.75, zorder=2,
                        solid_capstyle="butt")
        line.set_clip_path(well)
        area = marker_size(state.n) * 0.8
        inside = [(value, p) for value, p in zip(state.data.values, state.check.predictions) if low <= p <= high]
        if inside:
            xs, ys = zip(*inside)
            ax.scatter(xs, ys, s=area, c=POINT, edgecolors=panels.BLOCK_TONE, linewidths=0.8, zorder=4).set_clip_path(well)
        for marker, beyond, edge in (("^", lambda p: p > high, high - 0.025 * (high - low)),
                                     ("v", lambda p: p < low, low + 0.025 * (high - low))):
            xs = [value for value, p in zip(state.data.values, state.check.predictions) if beyond(p)]
            if xs:
                ax.scatter(xs, [edge] * len(xs), s=EDGE_ARROW, marker=marker, c=POINT, edgecolors="none", zorder=5, clip_on=False)

    def draw_hero(self, ax, state: MetamodelState) -> None:
        """The CoP, the hero of the third card: its number large (the warning's colour and mark at or below 0, poor; a
        dash while it cannot be computed), its definition typeset small as prognosis.py computes it, and a gauge from 0
        to 1 filled to it (empty below 0: the number says how far); under it, smaller and muted, the CoD at the designs
        and, where it is shown, the coefficient against the true response, each on a gauge of the same scale (one ink,
        REFERENCE_INK), every gauge with a tick at 0 and at 1, and the scale's ends written. In layout pixels from the
        hero's lower left corner (hero_lines), the lines hung from the top of its box (the row a legend starts on, under
        the card's title: composed); drawn once per scene."""
        wide, tall = pixel_axes(ax)                                   # no tick labels left in matplotlib's own face
        rows = self.references(state)
        lines = hero_lines(HERO["fontsize"], len(rows))
        top = tall                                                    # hung from the top (one reference row, or two)
        written = cop_written(state)
        points = HERO["fontsize"]
        while points > HERO_LEAST and text_width(written, points, HERO["fontweight"]) > wide:
            points -= 1
        ink = WARNING if state.check is None or cop_warned(state) else palette.WHITE
        ax.text(0.0, top - lines["number"], written, ha="left", va="baseline", color=ink, **(HERO | {"fontsize": points}))
        ax.text(0.0, top - lines["formula"], DEFINED, ha="left", va="baseline", color=palette.PROSE, **DEFINITION)
        cop = None if state.check is None else state.check.cop
        gauge(ax, 0.0, top - lines["gauge"] - GAUGE_HIGH, wide, GAUGE_HIGH, cop, COP_INK, ends=True)
        for (name, value, color), (base, under) in zip(rows, lines["rows"]):
            number = DASH if value is None else quality(value)
            room = wide - number_width(number, READING["fontsize"]) - ROW_GAP     # a number far below 0 is wider than WIDEST
            ax.text(0.0, top - base, clipped(name, LABEL["fontsize"], room), ha="left", va="baseline", **LABEL)
            ax.text(wide, top - base, number, ha="right", va="baseline", color=WARNING if value is None else palette.PROSE, **READING)
            gauge(ax, 0.0, top - under - ROW_HIGH, wide, ROW_HIGH, value, color, ends=True)
        ax.text(0.0, top - lines["scale"], "0", ha="left", va="baseline", **LABEL)
        ax.text(wide, top - lines["scale"], "1", ha="right", va="baseline", **LABEL)

    def draw_found(self, ax, state: MetamodelState, hovered) -> None:
        """The design under the mouse, in the check."""
        if state.check is None or not isinstance(hovered, int) or hovered >= state.n:
            return
        x, y = checked_points(state)[hovered]
        self.moving.append(ax.scatter([x], [y], s=marker_size(state.n) * 2.6, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4,
                                      zorder=6, clip_on=False))

    def draw_ranking(self, ax, state: MetamodelState, rows: int = 2) -> None:
        """The competition: a row per candidate, its name and, once shown, a bar as long as its CoP between 0 and 1 (a
        negative CoP has no bar: its number is written). Every candidate shown, the largest CoP is marked. Its legend on
        one row (`rows`, head's), the competition rises into the room of the second: air between a bar and the next name
        in the small window."""
        left, bottom, wide, tall = self.ranking_box
        rise = LEGEND_ROW / 2 / size(ax.figure)[1] if rows <= 1 else 0.0
        ax.set_position((left, bottom, wide, tall + rise))
        ax.set_facecolor(CARD_TONE if "check" in self.axes else palette.CARD)     # on the card, or on the page at the plane's place
        for side in ("left", "top", "right"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color(palette.DARK_GREY)
        ax.set_yticks([])
        ax.set_xticks([0.0, 0.25, 0.5, 0.75, 1.0], ["0", "", "0.5", "", "1"])
        ticks(ax)
        ax.tick_params(length=3)
        ax.set_xlabel(get_text("lab.mm.m.cop"), **LABEL, labelpad=3)
        box = ax.get_position()
        height = box.height * size(ax.figure)[1]
        hint = "check" not in self.axes                               # the competition stands where the design space was
        written, small, foot = get_text("lab.mm.ranking.back"), 8.5, 18.0 if hint else 0.0
        if hint:                                                      # in the room the panel has: smaller, then on two lines
            room = 0.976 * box.width * size(ax.figure)[0]
            while small > 7.5 and text_width(written, small) > room:
                small -= 0.5
            if text_width(written, small) > room:
                written, foot = fill(written, max(int(len(written) * room / text_width(written, small)), 12)), 30.0
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, height)
        row = (height - foot) / CANDIDATES
        thick = min(10.0, 0.2 * row)
        first = winner(state.ranking) if state.complete else None
        for k in range(CANDIDATES):
            top = height - k * row
            item = state.ranking[k] if k < len(state.ranking) else None
            if item is None:                                          # still to come: its name, without the value it will take
                ax.text(0.012, top - 0.28 * row, named(entry_to_come(k)), ha="left", va="center", **TAG, color=palette.DARK_GREY)
                continue
            small = self.rank_row(ax, item, top, row, thick, k == first)
        if hint:
            ax.text(0.988, foot / 2, written, ha="right", va="center", color=MUTED_INK, zorder=3, linespacing=1.1,
                    **(SMALL | {"fontsize": small}))

    def rank_row(self, ax, item: Entry, top: float, row: float, thick: float, leading: bool) -> float:
        """A candidate's row of the competition, `row` high under `top` (in its axes' pixels up, 0 to 1 across): its name
        (without its D or theta, then a step smaller, where it would meet its CoP), its bar on the hero's scale and its
        CoP (or that it cannot be computed); the winner on a lit band, in white. Returns the size its name took."""
        box = ax.get_position()
        bar = top - 0.70 * row - thick / 2
        if leading:
            ax.add_patch(Rectangle((0.0, top - row + 1.0), 1.0, row - 2.0, facecolor=palette.PILL, edgecolor="none", zorder=1))
        ink, weight = (palette.WHITE, "semibold") if leading else (palette.SLATE, "normal")
        said = named(item.candidate)                                  # a narrow card: the name without its D or theta
        beside = 0.976 * box.width * size(ax.figure)[0] - number_width(WIDEST, READING["fontsize"]) - 8.0     # where it would
        if text_width(said, TAG["fontsize"], weight) > beside and " · " in said and item.candidate.value is not None:  # meet
            said = said.rsplit(" · ", 1)[0]                                                                     # its CoP
        small = TAG["fontsize"]                                       # then a step smaller (no parameter to leave out)
        while small > RANKING_LEAST and text_width(said, small, weight) > beside:
            small -= 0.5
        ax.text(0.012, top - 0.28 * row, said, ha="left", va="center", **(TAG | {"fontsize": small}), color=ink, fontweight=weight,
                zorder=3)
        gauge(ax, 0.0, bar, 1.0, thick, item.cop, WINNER if leading else POINT, zorder=2)     # the hero's scale and track
        if item.cop is None:
            ax.text(0.988, top - 0.28 * row, get_text("lab.mm.ranking.cannot"), ha="right", va="center", **TAG,
                    color=MUTED_INK, zorder=3)
        else:
            ax.text(0.988, top - 0.28 * row, quality(item.cop), ha="right", va="center", **READING, color=ink, fontweight=weight,
                    zorder=3)
        return small

    # ------------------------------------------------------------------ the step's block in the column (Lab.columned)
    def blocks(self, state: MetamodelState, width: float) -> tuple[Block, ...]:
        """Where the window sets columned, the step's own panel as one block of the column, "Coefficient of prognosis
        (CoP)": the CoP and its scale over the check, or the competition while it is shown, at least block_height (for
        the column's `width`: the number's lines over a check of BLOCK_CHECK; ROWS_CHECK in the rows of a narrow lab,
        Block.rows) and taking the column's room left up to its natural height (most: the check as large as the width
        holds it; the owner's 1C, "the card ends where its content ends", the room to spare stays the column's), the
        same for both, so that the column never moves when the competition opens or closes; its heading's tooltip the
        CoP's definition (what "predicted without it" means); () otherwise."""
        if not self.columned:
            return ()
        return (Block(PROGNOSIS, get_text("lab.mm.check_title"), least=block_height(width), most=block_height(width, width),
                      tip=get_text("lab.mm.m.cop_tip"), rows=block_height(width, ROWS_CHECK)),)

    def in_block(self, ax) -> bool:
        """Whether `ax` is one of the blocks' axes (block_axes), not the figure's: a block keeps a dict of axes, or one
        axes alone (another block of the step, bench 4's cross-beams)."""
        return any(ax is found for axes in self.block_axes.values() for found in block_members(axes))

    def composed_for(self, ax) -> "Composition | None":
        """The composition the check `ax` stands in: its block's (block_composition), or the figure's third card's."""
        for key, axes in self.block_axes.items():
            if any(ax is found for found in block_members(axes)) and key in self.block_made:
                return self.block_made[key]["third"]
        return self.composition(self.plan)

    def draw_block(self, key: str, figure, state: MetamodelState, hovered) -> bool:
        """The block "prognosis" on its own figure (panels.block_plan, painted in BLOCK_TONE), the owner's word and mock
        of 2026-11-21 and his 1C: the CoP's number large at the block's left under its title, its slim scale under it
        (draw_block_hero), and the check under both, a square centred as large as the block leaves it (block_composed),
        named by its axes (no legend); or the competition while it is shown, as many candidates as the block holds, the
        largest CoP first; the design under the mouse ringed in the check. How the CoP is computed is its tooltip's
        (lab.mm.m.cop_tip), the CoD the strip's (the web's figure).
        Its axes are made once per layout (block_axes, never the figure's), its content drawn again only when the
        metamodel, the experiment, the competition or the language change, its ring only when the design under the
        mouse does: a drag of the query point draws nothing here (False: nothing changed)."""
        if key != PROGNOSIS or not self.columned:
            return False
        width, height = size(figure)
        layout = (id(figure), round(width), round(height), figure.dpi, state.language)
        made = self.block_made.get(key)
        axes = self.block_axes.get(key, {})
        if made is None or made["layout"] != layout or any(ax.figure is not figure for ax in axes.values()):
            figure.clear()
            figure.set_facecolor(panels.BLOCK_TONE)
            third = self.block_composition(panels.block_plan(width, height))

            def frac(x, y, w, h):
                return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)
            ranking = (RANK_SIDE, RANK_BELOW, width - 2 * RANK_SIDE, height - RANK_BELOW - BLOCK_FOOT)
            axes = {"check": figure.add_axes(frac(*third.check)), "hero": figure.add_axes(frac(*third.hero)),
                    "ranking": figure.add_axes(frac(*ranking))}
            self.block_axes[key] = axes
            made = {"layout": layout, "third": third, "scene": None, "ring": None, "moving": []}
            self.block_made[key] = made
        scene = (state.candidate, state.experiment, len(state.ranking), state.language)
        pointed = isinstance(hovered, int) and 0 <= hovered < state.n and state.check is not None and not state.ranking
        ring = hovered if pointed else None
        changed = made["scene"] != scene
        if changed:
            self.draw_block_scene(figure, axes, made, state)
            made["scene"], made["ring"] = scene, None
        if changed or made["ring"] != ring:
            for artist in made["moving"]:
                artist.remove()
            made["moving"] = []
            if ring is not None:
                x, y = checked_points(state)[ring]
                made["moving"].append(axes["check"].scatter([x], [y], s=marker_size(state.n) * 2.6, facecolors="none",
                                                            edgecolors=palette.WHITE, linewidths=1.4, zorder=6, clip_on=False))
            made["ring"] = ring
            changed = True
        return changed

    def draw_block_scene(self, figure, axes: dict, made: dict, state: MetamodelState) -> None:
        """The block's content: the CoP and the check, or the competition."""
        for ax in axes.values():
            ax.clear()
        for text in list(figure.texts):
            text.remove()
        made["moving"] = []
        contest = bool(state.ranking)
        for name, ax in axes.items():
            ax.set_visible(contest == (name == "ranking"))
        if contest:
            self.draw_block_ranking(axes["ranking"], state)
            return
        self.draw_block_hero(axes["hero"], state, made["third"])
        if state.check is None:
            self.draw_block_cannot(axes["check"], state)
            return
        self.draw_check(axes["check"], state)
        side = made["third"].check[2]                                 # x's full name where it holds along its side; y's
        (x_full, y_full), (x_short, _) = check_names("full"), check_names("short")     # always ("predicted without it",
        axes["check"].set_xlabel(x_full if text_width(x_full, LABEL["fontsize"]) <= side + 2 * BLOCK_EDGE else x_short,
                                 **LABEL, labelpad=BLOCK_PAD)         # every bench), its top on the spine's where it is
        axes["check"].set_ylabel(y_full, **LABEL, labelpad=4)         # longer than the side: it hangs into the empty corner
        long = text_width(y_full, LABEL["fontsize"])                  # under the gutter, never over the block's top
        if long > side:
            axes["check"].yaxis.label.set_y(1.0 - long / 2 / side)

    def draw_block_hero(self, ax, state: MetamodelState, third: "Composition") -> None:
        """The CoP's number, large (the strip's value; at or below 0, poor, the warning's colour and, never colour alone,
        the warning's triangle beside it at the figures' height, warning; a dash while it cannot be computed; a step
        smaller where it is wider than its room), on the hero's axes `ax` of the block's composition `third`
        (block_composed): at the block's left edge under its title, its figures' tops BLOCK_ABOVE under the block's
        top; and under it the slim scale from 0 to 1 filled to it (scale: no threshold; below 0 empty, an arrow at its
        0 pointing left), the owner's 1C. The check stands under both."""
        wide, tall = pixel_axes(ax)
        warned = state.check is not None and poor(state.check.cop)
        written = DASH if state.check is None else quality(state.check.cop)
        digits = 0.72 * HERO["fontsize"] * LAYOUT_DPI / 72            # the figures' height over the baseline
        mark = 2 * 0.58 * WARN_SHARE * digits + WARN_GAP if warned else 0.0     # the triangle and its gap
        points = HERO["fontsize"]
        while points > HERO_LEAST and mark + text_width(written, points, HERO["fontweight"]) > wide:
            points -= 1
        baseline = tall - BLOCK_ABOVE - digits
        ink = WARNING if state.check is None or warned else palette.WHITE
        if warned:                                                    # never colour alone: the triangle, at cap height
            warning(ax, 0.0, baseline, WARN_SHARE * 0.72 * points * LAYOUT_DPI / 72)
        ax.text(mark, baseline, written, ha="left", va="baseline", color=ink, **(HERO | {"fontsize": points}))
        scale(ax, wide, baseline - SCALE_DROP - SCALE_HIGH, None if state.check is None else state.check.cop)

    def draw_block_cannot(self, ax, state: MetamodelState) -> None:
        """Where the check cannot be computed, why, in its place (as draw_check says it in the figure's card): from
        the check's gutter to the block's right edge, on the check's height."""
        ax.set_axis_off()
        if state.fit is None:
            why = state.refused[:1].upper() + state.refused[1:] + "."
        else:
            why = get_text("lab.mm.check.cannot." + ("mls" if state.model == "mls" else "fit"))
        width = size(ax.figure)[0]
        room = width - BLOCK_EDGE - block_gutter()
        ax.text(1.0, 0.5, wrapped(why, SMALL["fontsize"], room), transform=ax.transAxes, ha="right", va="center", color=WARNING,
                **SMALL, linespacing=1.15)

    def draw_block_ranking(self, ax, state: MetamodelState) -> None:
        """The competition in the block, at its one height: as many candidates as hold RANK_ROW each, the largest CoP
        first (ranked; the winner on its lit band once every candidate is shown), each with its bar and its CoP on the
        hero's scale, whose ends are written under them (the block's title names the CoP)."""
        ax.set_facecolor(panels.BLOCK_TONE)
        for side in ("left", "top", "right"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color(palette.DARK_GREY)
        ax.set_yticks([])
        ax.set_xticks([0.0, 0.25, 0.5, 0.75, 1.0], ["0", "", "0.5", "", "1"])
        ticks(ax)
        ax.tick_params(length=3)
        height = ax.get_position().height * size(ax.figure)[1]
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, height)
        fits = max(int(height // RANK_ROW), 1)
        row = height / fits
        thick = min(10.0, 0.2 * row)
        first = winner(state.ranking) if state.complete else None
        for slot, k in enumerate(ranked(state.ranking)[:fits]):
            self.rank_row(ax, state.ranking[k], height - slot * row, row, thick, k == first)

    def hit_block(self, key: str, figure, state: MetamodelState, event):
        """A design in the block's check (its index), as hit finds one in the figure's check; None elsewhere, and while
        the competition is shown."""
        if key != PROGNOSIS or event is None or state.check is None or state.ranking:
            return None
        check = self.block_axes.get(key, {}).get("check")
        if check is None or event.inaxes is not check or not check.get_visible():
            return None
        return nearest(check, checked_points(state), event)

    def press_block(self, key: str, figure, state: MetamodelState, event, settings: dict) -> dict | None:
        """A click on the block while the competition is shown closes it (the CoP and the check come back), as a click
        on the figure's competition does; None otherwise."""
        if key == PROGNOSIS and state.ranking and settings.get("contest"):
            return settings | {"contest": 0}
        return None

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def crowned(settings: dict) -> dict:
    """The settings with the winner of the competition on their experiment chosen (its model, basis, D or theta); as
    they were when no candidate can be computed."""
    best = champion(settings["experiment"])
    return settings if best is None else settings | chosen(best.candidate)

def sampled(experiment: Experiment) -> tuple[tuple[str, str, str], ...]:
    """The first two rows of every received card of steps 2 and 3, on every bench, in one wording: the sampling of
    step 1 ("Latin hypercube") and its simulations ("N = 60")."""
    return ((get_text("lab.mm.received.sampling"), get_text(f"lab.mm.received.{experiment.method}"), "plain"),
            (get_text("lab.mm.received.designs"), get_text("lab.mm.received.designs_value", n=experiment.n), "plain"))

@dataclass(frozen=True)
class Composition:
    """The third card of the step, in layout pixels (left, bottom, width, height): the hero's column and the check's
    square (its axes; its tick labels in its gutter at its left and under it, with the names of its axes as long as its
    side holds: `names`, "full", "short" or None), side by side or the hero over the check; the check's legend over the
    check (`legend`: its left, on the check's left spine, its top, and its room, in layout pixels; None with no check);
    `alone`, the hero by itself, where the check would be smaller than CHECK_LEAST (a phone's narrow card: the strip and
    the hero say the CoP, a check that small says nothing)."""
    hero: tuple[float, float, float, float]
    check: tuple[float, float, float, float]
    beside: bool
    alone: bool = False
    legend: tuple[float, float, float] | None = None
    names: str | None = "full"

def check_handles() -> list:
    """The check's legend: a design predicted without it, and the diagonal of a perfect prediction."""
    return [dot(POINT, get_text("lab.mm.legend.design"), short=get_text("lab.mm.legend.design_short")),
            Line2D([], [], color=TRUE, linewidth=1.1, label=get_text("lab.mm.legend.diagonal"))]

def block_composed(width: float, height: float, top: float = 0.0, row: float | None = None) -> Composition:
    """The block's CoP and check (the owner's word of 2026-11-21: the CoP and the plot alone, larger; then his mock: the
    number at the top right, the check under it; then always so, "it leaves more room for the figure"), in layout pixels
    of a block's figure `width` x `height`, under `top` kept at its top for another line (bench 4's four CoPs): the
    CoP's line (`row`, hero_row by default; 0 where the line at the top stands for it) over a square STACK_GAP under
    that line, as large as the width leaves it after its gutter and BLOCK_EDGE or the height after its tick labels and
    names under it (stacked_side), centred in the width its gutter leaves; the hero's axes that line, as wide as the block (the number
    at its left, draw_block_hero)."""
    row = hero_row() if row is None else row
    upper = height - top                                              # the block's top, under the line kept there
    side = max(stacked_side(width, height, top, row), 1.0)
    hung = upper - row - STACK_GAP                                    # the check's top spine
    room = width - BLOCK_EDGE - block_gutter()                        # the square centred in the width its gutter leaves
    left = block_gutter() + (room - side) / 2
    return Composition((0.0, upper - row, width, max(row, 1.0)), (left, hung - side, side, side), False, names="full")

def hero_row() -> float:
    """The CoP's lines over the check (the owner's 1C): BLOCK_ABOVE, the figures of a number at HERO's size, then
    SCALE_DROP down to its scale and the scale's track."""
    return BLOCK_ABOVE + 0.72 * HERO["fontsize"] * LAYOUT_DPI / 72 + SCALE_DROP + SCALE_HIGH

def warning(ax, x: float, baseline: float, height: float) -> None:
    """The warning's triangle (never colour alone: a CoP at or below 0), its base on the number's baseline at `x`, as
    tall as `height` (WARN_SHARE of the figures'), in the axes' layout pixels (the block's hero axes)."""
    half = 0.58 * height
    ax.add_patch(Polygon([(x, baseline), (x + 2 * half, baseline), (x + half, baseline + height)], closed=True,
                         facecolor=WARNING, edgecolor="none", zorder=3))

def scale(ax, wide: float, bottom: float, cop: float | None) -> None:
    """The slim scale from 0 to 1 under the CoP (the owner's 1C), in the axes' layout pixels, its track `wide` less
    SCALE_END at each side, SCALE_HIGH thick from `bottom`, its ends written "0" and "1" outside it (the tick labels'
    role): filled to the CoP in the accent (COP_INK), clamped at 1; at or below 0 empty, and a small arrow in the
    warning's colour at its 0, pointing left, says the CoP lies beyond it; no threshold (the owner has none: 7B); a CoP
    that cannot be computed, the track alone."""
    track = wide - 2 * SCALE_END
    middle = bottom + SCALE_HIGH / 2
    style = f"round,pad=0,rounding_size={SCALE_HIGH / 2}"
    ax.add_patch(FancyBboxPatch((SCALE_END, bottom), track, SCALE_HIGH, boxstyle=style, facecolor=panels.GAUGE_TRACK,
                                edgecolor="none", zorder=1))
    if cop is not None and cop > 0:
        ax.add_patch(FancyBboxPatch((SCALE_END, bottom), max(track * min(cop, 1.0), SCALE_HIGH), SCALE_HIGH, boxstyle=style,
                                    facecolor=COP_INK, edgecolor="none", zorder=2))
    elif cop is not None:
        ax.add_patch(Polygon([(SCALE_END + 1.0, middle), (SCALE_END + 8.0, middle + 4.0), (SCALE_END + 8.0, middle - 4.0)],
                             closed=True, facecolor=WARNING, edgecolor="none", zorder=2))
    for x, said, align in ((0.0, "0", "left"), (wide, "1", "right")):
        ax.text(x, middle, said, ha=align, va="center", color=panels.TICK_INK, **panels.SCALE_END_ROLE)

def welled(ax, side: float) -> None:
    """The block's check set in its well (the owner's 1C): a square of WELL, its corners rounded WELL_RADIUS, one tone
    under the block's card, the axes' own face and spines away, a faint grid, its tick labels without ticks; the
    well is the axes' first patch (draw_welled clips the line and the designs to it)."""
    ax.set_facecolor("none")
    for spine in ax.spines.values():
        spine.set_visible(False)
    rounding = WELL_RADIUS / max(side, 1.0)
    ax.add_patch(FancyBboxPatch((0.0, 0.0), 1.0, 1.0, boxstyle=f"round,pad=0,rounding_size={rounding}", transform=ax.transAxes,
                                facecolor=WELL, edgecolor="none", zorder=0, clip_on=False))
    ax.grid(True, color=palette.DARK_GREY, linewidth=0.6, alpha=0.55)
    ax.set_axisbelow(True)
    ax.tick_params(length=0, pad=4)

def stacked_side(width: float, height: float, top: float = 0.0, row: float | None = None) -> float:
    """The check's side under the CoP's line (`row`, under `top`): the width after its gutter and BLOCK_EDGE, the
    height after that line, STACK_GAP, its tick labels and names under it and the foot, the lesser."""
    row = hero_row() if row is None else row
    return min(width - BLOCK_EDGE - block_gutter(), height - top - row - STACK_GAP - BLOCK_BELOW - BLOCK_FOOT)

def pixel_axes(ax) -> tuple[float, float]:
    """An axes made a sheet in layout pixels from its lower left corner (no frame, no ticks): its width and height."""
    ax.set_axis_off()
    ax.set_xticks([])
    ax.set_yticks([])
    wide, tall = ax.get_position().width * size(ax.figure)[0], ax.get_position().height * size(ax.figure)[1]
    ax.set_xlim(0.0, wide)
    ax.set_ylim(0.0, tall)
    return wide, tall

def block_gutter() -> float:
    """The check's gutter at its left in the block: its ticks, its tick labels (BLOCK_TICK) and its turned name."""
    return panels.OBJECTIVE_TICKS + text_width(BLOCK_TICK, panels.TICK) + (4.0 + panels.LINE_HEIGHT * LABEL["fontsize"]) * LAYOUT_DPI / 72

def block_members(axes) -> tuple:
    """The axes a block keeps in Lab.block_axes: its dict's values (this step's "prognosis"), or the one axes another
    block keeps alone (bench 4's "beams")."""
    return tuple(axes.values()) if isinstance(axes, dict) else (axes,)

def block_height(width: float = BLOCK_WIDTH, check: float = BLOCK_CHECK, top: float = 0.0, row: float | None = None) -> int:
    """The block's least height for a column `width` layout pixels wide (201 at 248): `top` (another line kept at its
    top: bench 4's four CoPs), the CoP's line (`row`, hero_row by default), STACK_GAP, a check of side `check` (or as
    wide as the width holds), its tick labels and names under it, and the foot: block_composed's inverse."""
    row = hero_row() if row is None else row
    side = min(check, width - BLOCK_EDGE - block_gutter())
    return math.ceil(top + row + STACK_GAP + max(side, 1.0) + BLOCK_BELOW + BLOCK_FOOT)

def ranked(entries) -> list[int]:
    """The candidates shown, in the block's order: by their CoP, the largest (the winner) first, those that cannot be
    computed last, ties in the competition's order."""
    return sorted(range(len(entries)), key=lambda k: (entries[k].cop is None, -(entries[k].cop or 0.0), k))

def composed(plan, handles: Callable[[], list] | None = None, most: int | None = None) -> Composition | None:
    """The third card under its title shared by the hero and the check, on lines they share: the hero hung from the
    row where a legend starts under the card's title (the number's capitals on it), left-aligned with the title; the
    check's legend on the same row, its left on the check's left spine; the check a square hung CHECK_GAP under its
    legend, as large as the room under it allows (its foot at the card's foot where the height binds), beside the hero
    (the corner and the stack) or under it (a row), whichever leaves the larger square. Its gutter and its foot keep the
    room of its axis names where it is large enough for them, their full names or their short ones (CHECK_LEFT and
    BELOW; CHECK_TIGHT and BELOW_TIGHT for its tick labels alone, where even the short ones do not fit along its side).
    The hero block stays whole at the top. None where the plan has no third card (the pair). `handles`: what makes the
    entries of the check's legend the square is measured with, anew at each measure (a legend may shorten their
    labels; check_handles: a design predicted without it, the diagonal), in at most `most` rows (two; four on a
    phone's narrow card)."""
    if plan.check is None or "check" not in plan.cards:
        return None
    card, foot, wide, tall = plan.cards["check"]
    left, right = card + RANK_INSET, card + wide - RANK_INSET
    narrow = plan.head > HEAD                                         # a phone's head: two lines of title, four rows of legend
    most = (4 if narrow else 2) if most is None else most
    row = foot + tall - TITLE_DROP - LEGEND_DROP                      # the legend's row under a title on one line
    if narrow:                                                        # (on two where it breaks)
        said, _ = titled(get_text("lab.mm.check_title"), wide - RANK_INSET - HEAD_GAP, 2)
        row -= (len(said) - 1) * TITLE_LINE
    need, high = hero_wide(), hero_lines(HERO["fontsize"])["tall"]
    pitch = LEGEND_PITCH * LEGEND_SIZE / 72 * LAYOUT_DPI
    edge = card + wide - HEAD_GAP                                     # a legend ends HEAD_GAP before the card's edge

    def legend(spine: float, gutter: float) -> tuple[float, float, int]:
        """The check's legend: its left on the check's spine, where its rows hold in the room to the card's edge; else
        moved left over the check's gutter, just as far as its widest row needs. Its left, its room, its rows."""
        for left_, flush in ((spine, False), (spine - gutter, True)):
            rows, small = legend_rows((check_handles if handles is None else handles)(), edge - left_, most)
            rows = [one for one in rows if one]
            widest = max(legend_width([handle.get_label() for handle in one], small) for one in rows)
            if widest <= edge - left_ or flush:
                x = max(min(spine, edge - widest), spine - gutter)
                return x, edge - x, len(rows)
        return spine, edge - spine, most

    def square(hang_from: float, across: float, beside: bool) -> tuple[float, str | None, int]:
        """The side of the check under its legend hung from `hang_from`, `across` layout pixels wide with its gutter
        (its spine at the card's right beside the hero, centred under it), the names of its axes ("full", "short" or
        None), its legend's rows: the rows reserved are never fewer than those the legend draws (a square made larger by
        a smaller reservation moves the spine and the legend's room; where that room brings back a row, the previous,
        larger reservation is kept)."""
        rows, previous = most, None
        for _ in range(3):
            top = hang_from - rows * pitch - CHECK_GAP
            full, tight = (max(min(top - foot - CARD_FOOT - under, across - gutter), 1.0)
                           for gutter, under in ((CHECK_LEFT, BELOW), (CHECK_TIGHT, BELOW_TIGHT)))
            names = next((kind for kind in ("full", "short") if full >= names_least(kind)), None)
            side, gutter = (full, CHECK_LEFT) if names else (tight, CHECK_TIGHT)
            spine = right - side if beside else left + (right - left - gutter - side) / 2 + gutter
            drawn = legend(spine, gutter)[2]
            if drawn == rows:
                break
            if drawn > rows:                                          # more rows than reserved: the larger reservation
                side, names, rows = previous
                break
            previous = (side, names, rows)
            rows = max(drawn, 1)
        return side, names, rows
    by, by_names, by_rows = square(row, right - left - need - HERO_GAP, True)
    under, under_names, under_rows = square(row - high - HERO_GAP, right - left, False)
    if by >= under:
        side, names, rows = by, by_names, by_rows
        spine = right - side
        top = row - rows * pitch - CHECK_GAP
        hero = min(spine - (CHECK_LEFT if names else CHECK_TIGHT) - HERO_GAP - left, HERO_MOST)
        x, room, _ = legend(spine, CHECK_LEFT if names else CHECK_TIGHT)
        return Composition((left, row - high, hero, high), (spine, top - side, side, side), True, legend=(x, row, room),
                           names=names)
    side, names, rows = under, under_names, under_rows
    hero = min(right - left, HERO_MOST)
    hero_box = (left, row - high, hero, high)
    if side < CHECK_LEAST and plan.head > HEAD:                       # a phone's card with no room for a check that reads:
        return Composition(hero_box, (left, foot, 1.0, 1.0), False, True)     # the hero alone
    gutter = CHECK_LEFT if names else CHECK_TIGHT
    spine = left + (right - left - gutter - side) / 2 + gutter        # the check centred in the card under the hero
    top = row - high - HERO_GAP - rows * pitch - CHECK_GAP
    x, room, _ = legend(spine, gutter)
    return Composition(hero_box, (spine, top - side, side, side), False, legend=(x, row - high - HERO_GAP, room), names=names)

def check_names(kind: str) -> tuple[str, str]:
    """The names of the check's axes, x then y: their full names ("full") or their short ones ("short")."""
    if kind == "full":
        return get_text("lab.mm.check.x"), get_text("lab.mm.check.y")
    return get_text("lab.mm.check.x_short"), get_text("lab.mm.check.y_short")

def names_least(kind: str = "full") -> float:
    """The least side of a check that names its axes with these names (in the language on screen): the longer, along
    its side, with room to spare."""
    return max(text_width(name, LABEL["fontsize"]) for name in check_names(kind)) + 8.0

def hero_lines(points: float, rows: int = 2) -> dict:
    """Where the lines of the hero stand, in layout pixels down from its top, for a number of `points`: the number's
    baseline, the formula's, the top of the CoP's gauge, each reference row's baseline and the top of its gauge, the
    scale's baseline under the last gauge, and the height the whole takes (tall)."""
    number = 0.76 * points * LAYOUT_DPI / 72
    formula = number + DROPS["formula"]
    gauge_top = formula + DROPS["gauge"]
    below = gauge_top + GAUGE_HIGH
    lines = []
    for _ in range(rows):
        base = below + DROPS["row"]
        lines.append((base, base + DROPS["under"]))
        below = base + DROPS["under"] + ROW_HIGH
    scale = below + DROPS["scale"]
    return {"number": number, "formula": formula, "gauge": gauge_top, "rows": tuple(lines), "scale": scale, "tall": scale + SCALE_FOOT}

def hero_wide() -> float:
    """The width the hero needs, in layout pixels, in the language on screen: its formula, and a reference row's name,
    its gap and the widest number it keeps room for (WIDEST); between HERO_FEWEST and HERO_MOST."""
    names = (get_text("lab.mm.hero.cod"), get_text("lab.mm.hero.true"))
    rows = max(text_width(name, LABEL["fontsize"]) for name in names) + ROW_GAP + number_width(WIDEST, READING["fontsize"])
    formula = mathtext_width(DEFINED, DEFINITION["fontsize"] * LAYOUT_DPI / 72)
    return min(max(formula + 2.0, rows, HERO_FEWEST), HERO_MOST)

def cop_written(state: MetamodelState) -> str:
    """The CoP as the strip and the hero write it: its value (quality), with the warning's mark at or below 0 (poor),
    a dash while it cannot be computed."""
    if state.check is None:
        return DASH
    return f"{MARK} {quality(state.check.cop)}" if poor(state.check.cop) else quality(state.check.cop)

def cop_warned(state: MetamodelState) -> bool:
    """The CoP warns: it cannot be computed, or it is at or below 0."""
    return state.check is None or poor(state.check.cop)

def clipped(text: str, points: float, room: float) -> str:
    """A name as wide as `room` layout pixels at most in the figure's face at `points`: whole, or cut with an ellipsis
    (beside a number far below 0, wider than the room the hero keeps; the strip names it whole)."""
    if text_width(text, points) <= room:
        return text
    while len(text) > 1 and text_width(text.rstrip() + "…", points) > room:
        text = text[:-1]
    return text.rstrip() + "…"

def wrapped(text: str, points: float, room: float) -> str:
    """A sentence broken into lines no wider than `room` layout pixels in the figure's face at `points` (a word longer
    than the room stands alone on its line)."""
    lines: list[str] = []
    for word in text.split():
        if lines and text_width(f"{lines[-1]} {word}", points) <= room:
            lines[-1] = f"{lines[-1]} {word}"
        else:
            lines.append(word)
    return "\n".join(lines)

def first_probe(d: int) -> tuple[float, ...]:
    """The first query point: FIRST_PROBE, and for more than two inputs the middle of the others (used only once the
    pair shows them: elsewhere a query point's inputs held are the slice's)."""
    return FIRST_PROBE + (section.MIDDLE,) * (d - 2)

def probe_of(settings: dict, d: int) -> tuple[float, ...]:
    """The query point the settings keep, d unit coordinates (one of another length, from an older snapshot: the
    first)."""
    probe = tuple(float(v) for v in settings.get("probe") or ())
    return probe if len(probe) == d else first_probe(d)

def moved(settings: dict, u1: float, u2: float, cut: Section | None = None) -> dict | None:
    """The settings with the query point at (u1, u2) of the pair's unit square, kept inside it (for more than two
    inputs, lifted onto the slice `cut`: the inputs held at its values); None when it does not move."""
    p, q = round(min(max(float(u1), 0.0), 1.0), 3), round(min(max(float(u2), 0.0), 1.0), 3)
    probe = (p, q) if cut is None or cut.plain else tuple(round(float(v), 3) for v in cut.lift(p, q))
    return None if probe == tuple(settings["probe"]) else settings | {"probe": probe}

def spans(state, low: float, high: float, aspect: float) -> tuple[float, float, float]:
    """The extents of the pair's two inputs and of y that the 3D box draws as its sides (its vertical one divided by its
    aspect, Plan.aspect), for the light on a surface's facets (panels.lit_facets): the box's drawn proportions."""
    (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
    return b1 - a1, b2 - a2, (high - low) / aspect

def surface_of(state: MetamodelState) -> np.ndarray | None:
    """y^ of the metamodel on screen on the grid of the slice shown (predicted), or None where it cannot be computed:
    the surface of the 3D view and the level lines of the plane."""
    return None if state.fit is None else predicted(state.candidate, state.experiment, state.section)

def terms(order: str, d: int = 2) -> int:
    """The number of terms of a polynomial basis in d inputs (1, d, d squares, d(d - 1)/2 products: 3, 5, 6 for two;
    5, 9, 15 for four): the least number of designs a fit of that basis needs."""
    return len(regression.basis((0.5,) * d, order))

def cannot(candidate: Candidate, where: str, n: int, d: int = 2) -> str:
    """Why a choice cannot be computed with n designs of d inputs, as a sentence for the figure and the lead (where:
    "fit", somewhere on the grid; "probe", at the query point). A basis with more terms than designs; the moving least
    squares with a radius that leaves some point with too few designs carrying weight; Kriging's R singular to the
    working precision (theta so small, or two designs so close, that two rows of R are nearly the same); a polynomial
    whose designs do not determine its coefficients."""
    if candidate.order is not None and n < terms(candidate.order, d):
        return get_text("lab.mm.cannot.terms", basis=get_text(f"lab.mm.order.{candidate.order}").lower(),
                        terms=terms(candidate.order, d), n=n)
    if candidate.model == "mls" and candidate.value is not None:
        return get_text(f"lab.mm.cannot.{'probe' if where == 'probe' else 'mls'}", radius=f"{candidate.value:.2f}")
    if candidate.model == "kriging" and candidate.value is not None:
        return get_text("lab.mm.cannot.kriging", theta=f"{candidate.value:g}")
    return get_text("lab.mm.cannot.fit", model=get_text(f"lab.mm.model.{candidate.model}"))

def named(candidate: Candidate) -> str:
    """A candidate in words: its model, its basis and its parameter (once known)."""
    parts = [get_text(f"lab.mm.model.{candidate.model}")]
    if candidate.order is not None:
        parts.append(get_text(f"lab.mm.order.{candidate.order}").lower())
    if candidate.value is not None:
        parts.append(f"D = {candidate.value:.2f}" if candidate.model == "mls" else f"θ = {candidate.value:g}")
    return " · ".join(parts)

def entry_to_come(k: int) -> Candidate:
    """Candidate k of the competition before it is computed: its model and its basis, not yet its parameter."""
    if k < len(ORDERS):
        return Candidate("polynomial", ORDERS[k], None)
    if k < 2 * len(ORDERS):
        return Candidate("mls", ORDERS[k - len(ORDERS)], None)
    return Candidate("kriging", None, None)

def reach_of(candidate: Candidate) -> tuple[float, str] | None:
    """The distance, in the unit square, at which a design's weight (moving least squares) or its correlation with the
    point (Kriging) is 1/e, and its name; None for a polynomial, which has no such distance."""
    if candidate.model == "mls":
        return candidate.value, "D"
    if candidate.model == "kriging":
        return 1 / math.sqrt(candidate.value), "1/√θ"
    return None

def checked_points(state: MetamodelState) -> list[tuple[float, float]]:
    """The points of the check as they are drawn: (simulated, predicted without it), a prediction beyond the window on
    its edge."""
    low, high = spread(state.data.values)
    return [(value, min(max(prediction, low), high)) for value, prediction in zip(state.data.values, state.check.predictions)]

def spread(values, share: float = 0.12) -> tuple[float, float]:
    """A window that holds the values, with a margin."""
    low, high = min(values), max(values)
    margin = share * ((high - low) or abs(high) or 1.0)
    return low - margin, high + margin

def poor(cop: float) -> bool:
    """A CoP at or below 0: CoP = 1 - SS_E/SS_T, so the metamodel predicts the designs it did not see no better than
    their mean. An exact meaning, not a threshold: the strip, the check and the summary warn of it."""
    return cop <= 0.0

def quality(value: float) -> str:
    """A coefficient (CoD, CoP) as the lab writes it: three decimals near 1, fewer far below 0, a power of ten beyond."""
    if abs(value) < 10:
        text = f"{value:.3f}"
    elif abs(value) < 1000:
        text = f"{value:.1f}"
    else:
        mantissa, exponent = f"{value:.1e}".split("e")
        text = f"{mantissa} × 10{''.join(SUPERSCRIPTS[c] for c in str(int(exponent)))}"
    return "0.000" if text == "-0.000" else text.replace("-", "−")
