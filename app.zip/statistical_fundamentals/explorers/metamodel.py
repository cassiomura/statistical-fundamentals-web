# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: metamodel.py
# ==============================================================================
"""
Step 2 of a bench's study, the metamodel: a cheap function y^ fitted to the N designs that step 1 simulated, to stand
in for the simulation in step 3: a polynomial (regression.py), moving least squares (moving_least_squares.py) or
Kriging (kriging.py), judged by how it reproduces the values it saw (CoD) and how it predicts the ones it did not (CoP,
by cross-validation: prognosis.py), on the bench's response y = f(x1, x2) (functions.RESPONSES).

What the step receives (receive, received): step 1's doe.Experiment (the response, the sampling, N, the seed) and with
it the N designs and their simulated values (doe.simulated): of f the metamodel knows nothing else. The column says
what came in, measured on the designs by measures.py (the sampling, N, the empty intervals, the correlation, the
smallest distance): the quality of step 1 carried into step 2. Any experiment is fitted, a Monte Carlo one too, and N
from 5 on: with few designs some metamodels cannot be computed (a quadratic basis has 6 coefficients; a subset of the
cross-validation leaves 4 designs when N = 5), and two random designs very close make Kriging's matrix singular. What
cannot be computed is kept as None (a Fit, a Validation, a candidate's CoP, the influences), never raised: the state,
the commands and the drawing say it, on the figure and in the strip.

What the step hands (output, missing): the Surrogate (experiment, candidate) of the metamodel on screen, from which
step 3 computes y^ again (fit(candidate, experiment).model, cached); None while that metamodel cannot be computed, and
missing says why in one sentence. The forward command "Go to the optimization" is answered by the window.

    [ Optimal prognosis                  ]  the featured command, and under it the winner and its CoP
    Model (Polynomial | MLS | Kriging)   Basis (Linear | Pure quadratic | Quadratic)   Radius D -o-  (or Correlation theta)
    the weight of each design in y^ at  | the metamodel as a surface, the true    | each design predicted without it
    the query point: the designs, each  | response as a wire over it, the designs | (the cross-validation) against its
    with a disc of area |a_i(u)|, over  | at their simulated values, the query    | simulated value; or the competition:
    y^'s faint level lines, and the     | point's prediction and true value       | the CoP of the seven candidates
    query point (dragged, clicked, the arrow keys)
    strip: CoD | CoP | against the true response (a student's: once the bench is complete)   [Best D]   [Go to the ...]

The controls and the commands stand in the window's column at the left of the figure, under what was received; the
measures in the strip under the figure, each with a tip of one sentence that defines it; the formula of the bench's
response is typeset in the figure over the 3D view (panels.typeset, once per layout), as in the other steps.

What the step opens on depends on how the application is used (explorers/game.py, Lab.mode). The TEACHER's lab opens
on the optimal prognosis: its first settings, Restore and an experiment received that is not the one on screen put the
winner of the competition (champion: the candidate of largest CoP, computed once per experiment and kept) on screen,
its model, basis, D or theta, with the competition closed (the check of the winner in the third panel: no frame plays
on entering; the competition costs about a second at N = 60 and two to four at N = 100, most of it the search of the
moving least squares' D). When no candidate can be computed the settings stay as they were; a choice of the reader is kept while
the experiment stays the same. "Optimal prognosis" is the featured command, drawn over the controls: pressed, it plays
the competition again, one candidate per frame, and ends on the winner; its second line (naming) names the winner and
its CoP, with a check mark when the model on screen is the winner and the word "winner" when the reader chose another.
The STUDENT's lab calibrates by hand, reading the CoP: neither the optimal prognosis nor the Best command is offered
(offered; settings that ask for the competition show none, and its frames never start), and it opens on the simplest
metamodel, the linear polynomial, keeping the reader's choice when another experiment comes; the strip does not show
him the coefficient against the true response (the answer a study never has) until the bench is complete (Lab.won).
A competition is run only where its winner will be shown: a lab given an experiment as it opens (opening) crowns that
one, never the bench's first experiment as well. A competition played to its end asks for the sound "complete", a Best
command for "apply" (cue).

The three panels answer three questions. The left one, where a prediction comes from: every metamodel of this step is
linear in the simulated values, y^(u) = sum_i a_i(u) y_i, and the a_i(u) (the cores' `influence`) are drawn on the
designs, blue and filled where positive, purple and hollow where negative, over the faint level lines of y^ (from its
surface on the grid, with the levels and the look of step 3's plane, panels.level_values and LINES: the same lines the
optimization then searches on). The middle one, what the metamodel is: its surface on a GRID x GRID grid, beside the
true response, which a study never has. The right one, what it is worth: every design predicted by a metamodel fitted
without it.

A CoP at or below 0 (poor) has an exact meaning, CoP = 1 - SS_E/SS_T: the metamodel predicts the designs it did not see
no better than their mean. Then the strip's CoP and the CoP written in the check take the warning's colour and its mark
(MARK), and the step's summary (the cover's track, the pill's tooltip) is a warning; no other threshold is drawn. What
the step received carries its kind too: the empty intervals of step 1 as its strip paints them.

The figure is laid out by panels.arrangement(width, height, pair="space"), the plan the three steps share: for the same
figure size the design space and the 3D view have the same boxes in every step, the design space the same axes and the
designs of step 1 at the same places, and the 3D view the same vertical window (truth) and the same angle (Lab.view,
which the window carries between the steps: read at every draw, updated when the reader turns the view). The third
panel is this step's. In a figure with room, the corner (the design space large at the left; at its right the 3D view
over the check, a square); otherwise the three panels in a row; the design space and the 3D view side by side, the
check left out, when there is no room for three (the code panel open beside the lab); and the three stacked in a narrow
figure. The competition takes the place of the check (in the corner, its whole rectangle), and where there is no check
that of the design space, until a control changes or a click closes it.

Everything shown is computed by the cores through their public functions; NumPy only holds the grids of the drawing
and evaluates the test function. What is expensive is cached by the experiment and the candidate (sample, fit,
validation, the best values). Dragging the query point changes only the influences and the two values at that point:
the figure keeps the artists of everything else (scene), and draws again what moves.

The sampling never looks at f: the designs are step 1's, placed before any simulation, mapped to the bounds of the
response and then simulated.
"""
import math
from dataclasses import dataclass
from functools import cache, lru_cache
from random import Random
from textwrap import fill
from typing import Callable

import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patheffects import withStroke
from matplotlib.patches import Ellipse, Patch, Rectangle
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from statistical_fundamentals import kriging, moving_least_squares, palette, regression
from statistical_fundamentals.explorers.base import Control, nearest, short, style_axes
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.doe import (HEIGHT, LABEL, RAMP, SPACE_ZOOM, VIEW, Experiment, first_experiment,
                                                    marker_size, simulated, style_space)
from statistical_fundamentals.explorers.lab import BENCH, LINK, Action, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.panels import (LINES, STACK_WIDTH, arrangement, dot, facets, head, level_values, places,
                                                       space_ticks, subscript, tint, typeset)
from statistical_fundamentals.explorers.panels import (HEAD, HEAD_GAP, LEGEND_LEAST, LEGEND_SIZE, LEVELS, ROW_LEAST,  # noqa: F401
                                                       TITLE, TITLE_DROP, TITLE_LEAST, Plan, cut_at, legend_width,   # kept
                                                       text_width)                                                   # importable here
from statistical_fundamentals.explorers.responses import FORMULAS, formula
from statistical_fundamentals.functions import RESPONSES, Response
from statistical_fundamentals.i18n import current_language, get_text
from statistical_fundamentals.measures import correlation, empty_intervals, smallest_distance
from statistical_fundamentals.prognosis import (FOLDS, coefficient_of_determination, coefficient_of_prognosis, cross_validation,
                                                 folds)
from statistical_fundamentals.sampling import scaled

MODELS = ("polynomial", "mls", "kriging")
ORDERS = regression.ORDERS
RADII = tuple(round(0.05 * 50 ** (k / 23), 2) for k in range(24))             # D: 0.05 to 2.5 in geometric steps
THETAS = tuple(float(f"{0.25 * 1600 ** (k / 24):.2g}") for k in range(25))    # theta: 0.25 to 400 in geometric steps
FIRST_MODEL, FIRST_ORDER = "polynomial", "linear"     # the simplest metamodel: the controls' first values, the student's
                                                      # metamodel, the teacher's when no candidate can be computed
COACHED = ("tune", "contest")         # the commands that calibrate for the reader: not offered to a student
FIRST_RADIUS = min(RADII, key=lambda D: abs(D - 0.3))
FIRST_THETA = min(THETAS, key=lambda theta: abs(theta - 7.4))
FIRST_FUNCTION = next(iter(RESPONSES))    # the bench of a lab made without one: the first response
FIRST_PROBE = (0.62, 0.42)            # the query point, in the unit square
STEP = 0.02                           # an arrow key moves the query point this far in the unit square
GRID = 31                             # samples per axis of the surfaces: the metamodel's and the true response's
MARGIN = 0.15                         # the vertical window: the range of the true response and this share of it on each side
CANDIDATES = 7                        # of the competition: three polynomials, three moving least squares, one Kriging
AREA = 620.0                          # points squared: the disc of a design whose weight a_i is 1
PROBE_RADIUS = 14                     # pixels: how close the mouse must come to the query point to take hold of it
QUERY = palette.YELLOW                # the query point, its prediction, the circle of its radius
POINT = palette.BLUE                  # a design, and its weight where positive
NEGATIVE = palette.PURPLE             # a negative weight (hollow, too)
TRUE = palette.SLATE                  # the true response: a reference
WINNER = palette.TEAL                 # the largest CoP of the competition
WARNING = palette.GOLD
MARK = "▲"                            # beside the warning's colour (never colour alone): a CoP at or below 0, a cut surface
DASH = "—"                            # a value that cannot be computed
SUPERSCRIPTS = {"-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹"}
BOXED = {"boxstyle": "round,pad=0.25", "facecolor": palette.CARD, "edgecolor": "none", "alpha": 0.8}
HALO = [withStroke(linewidth=2.6, foreground=palette.CARD)]      # a text over the surface: read on any of its colours
REFUSED = (ArithmeticError, ValueError)   # how the cores refuse: a matrix not positive definite, a logarithm of nothing

# ------------------------------------------------------------------------------
# What is computed, by the cores, and kept by the experiment and the candidate
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Candidate:
    """A metamodel to fit: its type, its basis (None for Kriging) and its parameter (D of the moving least squares,
    theta of Kriging; None for a polynomial, and for a candidate none of whose values can be computed)."""
    model: str
    order: str | None
    value: float | None

@dataclass(frozen=True)
class Surrogate:
    """Step 2's result, handed to the optimization: the metamodel `candidate` fitted to the designs of `experiment`.
    Everything else is computed from it (fit(candidate, experiment)), so two surrogates are the same when equal."""
    experiment: Experiment
    candidate: Candidate

@dataclass(frozen=True)
class Sample:
    unit: tuple[tuple[float, float], ...]       # the designs in the unit square: step 1's experiment
    points: tuple[tuple[float, float], ...]     # the same, mapped to the bounds of the response
    values: tuple[float, ...]                   # y = f at every design: the simulations
    subsets: tuple[tuple[int, ...], ...]        # the designs dealt into the subsets of the cross-validation

@dataclass(frozen=True)
class Truth:
    """The true response on the grid of the surfaces: what a metamodel is drawn beside, and measured against."""
    axis: tuple[float, ...]                     # the grid of one axis, in the unit square
    x1: np.ndarray
    x2: np.ndarray
    y: np.ndarray
    flat: tuple[float, ...]                     # y row by row, as the cores take it
    low: float                                  # the vertical window of the 3D view
    high: float

@dataclass(frozen=True)
class Fit:
    model: Callable                             # the metamodel, a function of the point of the unit square (from the cores)
    fitted: tuple[float, ...]                   # its values at the designs
    cod: float
    surface: np.ndarray                         # its values on the grid: the surface drawn
    against: float                              # the coefficient of determination of the true response on the grid

@dataclass(frozen=True)
class Validation:
    predictions: tuple[float, ...]              # every design predicted by a metamodel fitted without it
    cop: float

@dataclass(frozen=True)
class Entry:
    """A candidate of the competition with its CoP (None: it cannot be computed)."""
    candidate: Candidate
    cop: float | None

@cache
def sample(experiment: Experiment) -> Sample:
    """The designs of step 1 and their simulations (doe.simulated), and the subsets of the cross-validation, dealt from
    the experiment's seed."""
    simulations = simulated(experiment)
    subsets = tuple(tuple(subset) for subset in folds(experiment.n, FOLDS, Random(experiment.seed)))
    return Sample(simulations.unit, simulations.points, simulations.values, subsets)

@cache
def truth(function: str) -> Truth:
    response = RESPONSES[function]
    (a1, b1), (a2, b2) = response.bounds
    axis = tuple(k / (GRID - 1) for k in range(GRID))
    u1, u2 = np.meshgrid(np.array(axis), np.array(axis))
    x1, x2 = a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2
    y = np.asarray(response.f(x1, x2), dtype=float)
    low, high = float(y.min()), float(y.max())
    margin = MARGIN * (high - low)
    return Truth(axis, x1, x2, y, tuple(float(v) for v in y.ravel()), low - margin, high + margin)

def maker(candidate: Candidate) -> Callable:
    """The candidate as the cross-validation asks for it: from points and values, a function of the point."""
    if candidate.model == "polynomial":
        return lambda points, values: regression.metamodel(points, values, candidate.order)
    if candidate.model == "mls":
        return lambda points, values: moving_least_squares.metamodel(points, values, candidate.order, candidate.value)
    return lambda points, values: kriging.metamodel(points, values, candidate.value)

def influence_of(candidate: Candidate, u, points) -> list[float]:
    """The a_i(u) of the candidate: how much each simulated value counts in its prediction at u."""
    if candidate.model == "polynomial":
        return regression.influence(u, points, candidate.order)
    if candidate.model == "mls":
        return moving_least_squares.influence(u, points, candidate.order, candidate.value)
    return kriging.influence(u, points, candidate.value)

@lru_cache(maxsize=256)
def fit(candidate: Candidate, experiment: Experiment) -> Fit | None:
    """The candidate fitted to the designs of the experiment, at the designs and on the whole grid; None when it cannot
    be computed somewhere (a matrix that is not positive definite: too few designs for its terms, too few carrying
    weight there, or two designs too close)."""
    if candidate.model != "polynomial" and candidate.value is None:
        return None
    data, true = sample(experiment), truth(experiment.function)
    try:
        model = maker(candidate)(data.unit, data.values)
        fitted = tuple(model(u) for u in data.unit)
        rows = [[model((u1, u2)) for u1 in true.axis] for u2 in true.axis]
        cod = coefficient_of_determination(data.values, fitted)
        against = coefficient_of_determination(true.flat, [value for row in rows for value in row])
    except REFUSED:
        return None
    surface = np.array(rows)
    if not (np.isfinite(surface).all() and all(math.isfinite(v) for v in fitted) and math.isfinite(cod) and math.isfinite(against)):
        return None
    return Fit(model, fitted, cod, surface, against)

@lru_cache(maxsize=2048)
def validation(candidate: Candidate, experiment: Experiment) -> Validation | None:
    """The cross-validation of the candidate and its CoP; None when one of its fits cannot be computed."""
    if candidate.model != "polynomial" and candidate.value is None:
        return None
    data = sample(experiment)
    try:
        predictions = cross_validation(data.unit, data.values, data.subsets, maker(candidate))
        cop = coefficient_of_prognosis(data.values, predictions)
    except REFUSED:
        return None
    if not (math.isfinite(cop) and all(math.isfinite(p) for p in predictions)):
        return None
    return Validation(tuple(predictions), cop)

@cache
def best_order(experiment: Experiment) -> str | None:
    """The basis of the polynomial with the largest CoP (None: no basis can be computed)."""
    scores = [(checked.cop, order) for order in ORDERS
              if (checked := validation(Candidate("polynomial", order, None), experiment)) is not None
              and fit(Candidate("polynomial", order, None), experiment) is not None]
    return max(scores, key=lambda score: score[0])[1] if scores else None

@cache
def best_radius(order: str, experiment: Experiment) -> float | None:
    """The D with the largest CoP among the slider's values, for a basis: the values in the order of their CoP, the
    first whose metamodel can also be computed on the whole grid (None: none can)."""
    scores = [(checked.cop, D) for D in RADII if (checked := validation(Candidate("mls", order, D), experiment)) is not None]
    for _cop, D in sorted(scores, key=lambda score: -score[0]):
        if fit(Candidate("mls", order, D), experiment) is not None:
            return D
    return None

@cache
def best_theta(experiment: Experiment) -> float | None:
    """The theta with the largest concentrated log-likelihood among the slider's values (None: none can be computed)."""
    data = sample(experiment)
    scores = []
    for theta in THETAS:
        try:
            likelihood = kriging.log_likelihood(data.unit, data.values, theta)
        except REFUSED:
            continue
        if math.isfinite(likelihood):
            scores.append((likelihood, theta))
    for _likelihood, theta in sorted(scores, reverse=True):             # the likeliest whose surface can be computed:
        if fit(Candidate("kriging", None, theta), experiment) is not None:     # usually the first, one fit
            return theta
    return None

@cache
def entry(k: int, experiment: Experiment) -> Entry:
    """Candidate k of the competition: the three polynomials, the three moving least squares, each at its best D, and
    Kriging at its theta of largest likelihood."""
    if k < len(ORDERS):
        candidate = Candidate("polynomial", ORDERS[k], None)
    elif k < 2 * len(ORDERS):
        order = ORDERS[k - len(ORDERS)]
        candidate = Candidate("mls", order, best_radius(order, experiment))
    else:
        candidate = Candidate("kriging", None, best_theta(experiment))
    if candidate.model != "polynomial" and candidate.value is None:
        return Entry(candidate, None)
    checked = validation(candidate, experiment)
    computed = checked is not None and fit(candidate, experiment) is not None
    return Entry(candidate, checked.cop if computed else None)

def winner(entries) -> int | None:
    """The index of the entry with the largest CoP (the first of them), or None when none was computed."""
    scored = [k for k, item in enumerate(entries) if item.cop is not None]
    return max(scored, key=lambda k: entries[k].cop) if scored else None

@cache
def champion(experiment: Experiment) -> Entry | None:
    """The winner of the competition on the designs of the experiment, the entry of largest CoP; None when no candidate
    can be computed. Computed once per experiment (about a second at N = 60): the first settings, the experiments
    received and the featured command's line ask for it often."""
    entries = [entry(k, experiment) for k in range(CANDIDATES)]
    first = winner(entries)
    return None if first is None else entries[first]

def candidate_of(settings: dict) -> Candidate:
    """The metamodel the controls choose."""
    model = settings["model"]
    if model == "polynomial":
        return Candidate(model, settings["order"], None)
    if model == "mls":
        return Candidate(model, settings["order"], settings["radius"])
    return Candidate(model, None, settings["theta"])

def chosen(candidate: Candidate) -> dict:
    """The settings of the controls that choose a candidate."""
    if candidate.model == "polynomial":
        return {"model": candidate.model, "order": candidate.order}
    if candidate.model == "mls":
        return {"model": candidate.model, "order": candidate.order, "radius": candidate.value}
    return {"model": candidate.model, "theta": candidate.value}

def first_surrogate(function: str, mode: str = TEACHER) -> Surrogate:
    """The surrogate a stand-alone optimization lab opens on: the first experiment of the bench, with the metamodel the
    step 2 of the mode opens on: the teacher's, the winner of its competition (the simplest one, should no candidate be
    computed); the student's, the simplest one (no competition is run)."""
    experiment = first_experiment(function)
    best = champion(experiment) if mode != STUDENT else None
    return Surrogate(experiment, Candidate(FIRST_MODEL, FIRST_ORDER, None) if best is None else best.candidate)

# ------------------------------------------------------------------------------
# The state
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class MetamodelState:
    model: str
    experiment: Experiment
    response: Response
    candidate: Candidate
    data: Sample
    fit: Fit | None                             # None: the metamodel cannot be computed with these designs
    check: Validation | None                    # None: the cross-validation cannot be computed (nor without a fit)
    probe: tuple[float, float]                  # the query point, in the unit square
    point: tuple[float, float]                  # the same, in the bounds of the response
    influence: tuple[float, ...] | None         # a_i(u): how much each simulated value counts in the prediction there
    prediction: float | None                    # the metamodel at the query point (None with the influences)
    truth: float                                # the true response there
    ranking: tuple[Entry, ...]                  # the candidates of the competition shown so far
    language: str
    refused: str = ""                           # why the metamodel (or its value at the query point) cannot be computed

    @property
    def n(self) -> int:
        return self.experiment.n

    @property
    def scene(self) -> tuple:
        """Everything the figure shows that does not depend on the query point."""
        return (self.candidate, self.experiment, len(self.ranking), self.language)

    @property
    def complete(self) -> bool:
        """Every candidate of the competition is shown."""
        return len(self.ranking) == CANDIDATES

class MetamodelLab(Lab):
    """Three metamodels of the designs of step 1: the weight of each design at a point, the surface beside the true response, and
    what the prediction is worth where nothing was simulated; the one on screen is handed to the optimization."""

    def __init__(self, function: str = FIRST_FUNCTION, mode: str = TEACHER):
        self.function = function
        self.mode = mode
        self.controls = (
            Control("model", get_text("lab.mm.model"), MODELS, MODELS.index(FIRST_MODEL),
                    names=tuple(get_text(f"lab.mm.model.{m}") for m in MODELS), tip=get_text("lab.mm.model_tip"), alone=True),
            Control("order", get_text("lab.mm.order"), ORDERS, ORDERS.index(FIRST_ORDER),
                    names=tuple(get_text(f"lab.mm.order.{o}") for o in ORDERS), tip=get_text("lab.mm.order_tip"),
                    visible=lambda settings: settings["model"] in ("polynomial", "mls")),
            Control("radius", get_text("lab.mm.radius"), RADII, RADII.index(FIRST_RADIUS), show=lambda D: f"D = {D:.2f}",
                    tip=get_text("lab.mm.radius_tip"), visible=lambda settings: settings["model"] == "mls"),
            Control("theta", get_text("lab.mm.theta"), THETAS, THETAS.index(FIRST_THETA), show=lambda theta: f"θ = {theta:g}",
                    tip=get_text("lab.mm.theta_tip"), visible=lambda settings: settings["model"] == "kriging"),
        )
        self.actions = (
            page_link(),
            Action("tune", get_text("lab.mm.tune.polynomial"), get_text("lab.mm.tune_tip")),
            Action("contest", get_text("lab.mm.contest"), get_text("lab.mm.contest_tip"), motion="run",
                   playing_label=get_text("lab.mm.pause"), featured=True),
            Action("advance", get_text("lab.mm.advance"), get_text("lab.mm.advance_tip"), forward=True),
        )
        self.data = {"probe": FIRST_PROBE, "contest": 0}
        self.restore = True
        self.height = HEIGHT                   # the least height of the three steps (doe.HEIGHT)
        self.frame_ms = 700                    # a candidate of the competition is read before the next one
        self.tip = get_text("lab.mm.figure_tip")
        self.view = VIEW                       # the 3D view as the reader left it (a view, not a setting; the window carries it)
        self.turned = None                     # the angle the 3D view had when this lab last drew it: another one, the mouse turned it
        self.layout_key = None                 # the axes on the figure are reused while their layout holds
        self.scene = None                      # what the axes hold, but the query point: drawn again only when it changes
        self.plan = None
        self.axes: dict = {}
        self.moving: list = []                 # the artists that follow the query point and the mouse
        self.written = None                    # the formula of the response, typeset once per layout

    def settings(self) -> dict:
        """The experiment first (the bench's first one, so the lab works alone), then the controls and the data: the
        teacher's on the winner of the competition, the student's on the simplest metamodel."""
        settings = {"experiment": first_experiment(self.function)} | super().settings()
        return crowned(settings) if self.mode != STUDENT else settings

    def opening(self, handed: Experiment | None = None) -> dict:
        """The first settings given an experiment: the controls and the data on it, the teacher's on the winner of ITS
        competition only (the first experiment's is never run for nothing), the student's on the simplest metamodel."""
        if handed is None:
            return self.settings()
        settings = {"experiment": handed} | Lab.settings(self)
        return crowned(settings) if self.mode != STUDENT else settings

    def height_for(self, width: int) -> int:
        """In a row or side by side, the lab's own height; stacked, the three blocks one under the other."""
        if width >= STACK_WIDTH:
            return self.height
        return round(arrangement(width, None, pair="space").room)

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """For the key BENCH, the formula of the bench's response (one line of mathtext; the figure typesets it); nothing
        for a control."""
        return formula(self.function) if key == BENCH else ((), "")

    # ------------------------------------------------------------------ a step of the study
    def output(self, state: MetamodelState) -> Surrogate | None:
        """The metamodel on screen, for the optimization; None while it cannot be computed with these designs."""
        return None if state.fit is None else Surrogate(state.experiment, state.candidate)

    def missing(self, state: MetamodelState) -> str:
        return "" if state.fit is not None else get_text("lab.mm.missing")

    def receive(self, settings: dict, handed: Experiment) -> dict:
        """The experiment on screen again: nothing changes (the reader's choice is kept). Another experiment from step 1:
        the competition closes and the query point stays; the teacher's lab puts the winner of the new competition on
        screen (the settings as they were when none can be computed), the student's keeps the model, the basis, D and
        theta the reader chose (the state says when they cannot be computed with the new designs)."""
        if handed == settings.get("experiment"):
            return settings
        received = settings | {"experiment": handed, "contest": 0}
        return crowned(received) if self.mode != STUDENT else received

    def received(self, state: MetamodelState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """What came from step 1, measured on its designs by measures.py: the sampling, N, the empty intervals of each
        axis, Pearson's correlation (from N = 3) and the smallest distance, in the unit square. The empty intervals carry
        the kind step 1's strip paints them with ("error" when an interval is empty, "ok" when none is); the other rows
        are plain."""
        n, unit = state.n, state.data.unit
        xs, ys = [u[0] for u in unit], [u[1] for u in unit]
        try:
            rho = f"{correlation(xs, ys):+.3f}".replace("-", "−") if n >= 3 else DASH
        except ZeroDivisionError:
            rho = DASH
        spread_ = f"{smallest_distance([list(u) for u in unit]):.3f}" if n >= 2 else DASH
        empty = (empty_intervals(xs, n), empty_intervals(ys, n))
        rows = ((get_text("lab.mm.received.sampling"), get_text(f"lab.mm.received.{state.experiment.method}"), "plain"),
                (get_text("lab.mm.received.designs"), get_text("lab.mm.received.designs_value", n=n), "plain"),
                (get_text("lab.mm.received.empty"), f"{empty[0]}  ·  {empty[1]}", "error" if sum(empty) else "ok"),
                (get_text("lab.mm.received.correlation"), rho, "plain"),
                (get_text("lab.mm.received.distance"), spread_, "plain"))
        return get_text("lab.mm.received"), rows

    def summary(self, state: MetamodelState) -> tuple[str, str]:
        """What the step is worth, for the cover's track and the pill's tooltip: the CoP of the metamodel on screen, a
        warning at or below 0 (no better than the mean of the simulated values) and when it cannot be computed (a
        dash)."""
        if state.check is None:
            return get_text("lab.mm.summary", cop=DASH), "warning"
        return get_text("lab.mm.summary", cop=quality(state.check.cop)), "warning" if poor(state.check.cop) else "plain"

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> MetamodelState:
        """The state of the settings; never raises: what cannot be computed is None, and `refused` says why."""
        experiment = settings["experiment"]
        candidate = candidate_of(settings)
        response = RESPONSES[experiment.function]
        data = sample(experiment)
        fitted = fit(candidate, experiment)
        probe = (float(settings["probe"][0]), float(settings["probe"][1]))
        point = tuple(scaled([list(probe)], list(response.bounds))[0])
        influence = prediction = None
        refused = ""
        if fitted is None:
            refused = cannot(candidate, "fit", experiment.n)
        else:
            try:
                influence = tuple(influence_of(candidate, probe, data.unit))
                prediction = fitted.model(probe)
            except REFUSED:
                influence = prediction = None
            if influence is not None and not (math.isfinite(prediction) and all(math.isfinite(a) for a in influence)):
                influence = prediction = None
            if influence is None:
                refused = cannot(candidate, "probe", experiment.n)
        check = validation(candidate, experiment) if fitted is not None else None
        shown = 0 if self.mode == STUDENT else min(settings["contest"], CANDIDATES)     # a student never sees the competition
        ranking = tuple(entry(k, experiment) for k in range(shown))
        return MetamodelState(settings["model"], experiment, response, candidate, data, fitted, check, probe, point, influence,
                              prediction, float(response.f(*point)), ranking, current_language(), refused)

    def adjust(self, settings: dict, key: str, old) -> dict:
        """A control changed: the competition closes. And the moving least squares come on screen with a radius that
        can be computed for these designs (its slider was not on show while another model was chosen)."""
        settings = settings | {"contest": 0}
        if key == "model" and settings["model"] == "mls":
            within = next((D for D in RADII[RADII.index(settings["radius"]):]
                           if fit(Candidate("mls", settings["order"], D), settings["experiment"]) is not None), None)
            if within is not None:
                settings = settings | {"radius": within}
        return settings

    def act(self, key: str, state: MetamodelState, settings: dict) -> dict:
        experiment = settings["experiment"]
        if key in COACHED and not self.offered(key, settings):          # a student's lab: nothing chosen for the reader
            return settings
        if key == "tune":
            if settings["model"] == "polynomial":                     # only the search of the model on screen
                name, best = "order", best_order(experiment)
            elif settings["model"] == "mls":
                name, best = "radius", best_radius(settings["order"], experiment)
            else:
                name, best = "theta", best_theta(experiment)
            return settings | {"contest": 0} | ({} if best is None else {name: best})
        return super().act(key, state, settings)

    def enabled(self, key: str, state: MetamodelState) -> bool:
        """The optimization can be reached only with a metamodel that can be computed."""
        return state.fit is not None if key == "advance" else True

    def offered(self, key: str, settings: dict) -> bool:
        """A student calibrates by hand, reading the CoP: neither the optimal prognosis nor the Best command."""
        return self.mode != STUDENT or key not in COACHED

    def rewind(self, key: str, state: MetamodelState, settings: dict) -> dict:
        """The competition already at its end begins again, from no candidate."""
        if key == "contest" and settings["contest"] >= CANDIDATES:
            return settings | {"contest": 0}
        return settings

    def advance(self, state: MetamodelState, settings: dict) -> dict | None:
        """One more candidate; with the last one, the candidate of largest CoP becomes the model on screen (none for a
        student, who has no competition)."""
        shown = settings["contest"]
        if shown >= CANDIDATES or self.mode == STUDENT:
            return None
        following = settings | {"contest": shown + 1}
        return crowned(following) if shown + 1 == CANDIDATES else following

    def cue(self, key: str, state: MetamodelState) -> str:
        """The competition played to its end: "complete"; a Best command: "apply"; nothing else sounds."""
        if key == "contest" and state.complete:
            return "complete"
        return "apply" if key == "tune" and self.mode != STUDENT else ""

    def link(self, key: str, state: MetamodelState) -> str:
        """"View code" asks the window for the reading of the model on screen (gui/lab_code.py)."""
        return state.model if key == LINK else ""

    def naming(self, key: str, state: MetamodelState) -> str:
        """The command Best says what it looks for: the basis, D or theta. The featured command's second line: while its
        frames play, the candidate shown; otherwise the winner and its CoP, a check mark before it when it is the model
        on screen, the word "winner" when the reader chose another (and what a competition that judges none says)."""
        if key == "tune":
            return get_text(f"lab.mm.tune.{state.model}")
        if key != "contest" or self.mode == STUDENT:
            return ""
        if 0 < len(state.ranking) < CANDIDATES:
            return get_text("lab.mm.contest.playing", shown=len(state.ranking), total=CANDIDATES)
        best = champion(state.experiment)
        if best is None:
            return get_text("lab.mm.contest.none")
        cop = f"{MARK} {quality(best.cop)}" if poor(best.cop) else quality(best.cop)
        place = "on_screen" if best.candidate == state.candidate else "winner"
        return get_text(f"lab.mm.contest.{place}", name=named(best.candidate), cop=cop)

    # ------------------------------------------------------------------ what to read
    def lead(self, state: MetamodelState) -> str:
        """One short sentence, the figure's accessible description: the model on screen, or the competition."""
        if state.complete and (first := winner(state.ranking)) is not None:
            item = state.ranking[first]
            return get_text("lab.mm.lead.winner", total=CANDIDATES, name=named(item.candidate), cop=quality(item.cop))
        if state.complete:
            return get_text("lab.mm.lead.none", total=CANDIDATES)
        if state.ranking:
            item = state.ranking[-1]
            return get_text("lab.mm.lead.contest", shown=len(state.ranking), total=CANDIDATES, name=named(item.candidate),
                            cop=DASH if item.cop is None else quality(item.cop))
        if state.fit is None:                                         # why: on the figure, in the 3D view's place
            return get_text("lab.mm.lead.cannot")
        return get_text(f"lab.mm.lead.{state.model}")

    def metrics(self, state: MetamodelState) -> list[Metric]:
        """CoD, CoP and the coefficient against the true response, each with a tip of one sentence that defines it (why
        a value cannot be computed is said on the figure). A student calibrates by the CoP, never by the answer: the
        coefficient against the true response, which a study never has, is not shown to him until the bench is
        complete (won)."""
        fitted = state.fit is not None
        warned = state.check is not None and poor(state.check.cop)
        cop = DASH if state.check is None else f"{MARK} {quality(state.check.cop)}" if warned else quality(state.check.cop)
        measures = [Metric(get_text("lab.mm.m.cod"), quality(state.fit.cod) if fitted else DASH, kind="plain" if fitted else "warning",
                           detail=get_text("lab.mm.m.cod_detail"), tip=get_text("lab.mm.m.cod_tip")),
                    Metric(get_text("lab.mm.m.cop"), cop, kind="plain" if state.check is not None and not warned else "warning",
                           detail=get_text("lab.mm.m.cop_detail", folds=FOLDS), tip=get_text("lab.mm.m.cop_tip", folds=FOLDS))]
        if self.mode == STUDENT and not self.won:
            return measures
        return measures + [Metric(get_text("lab.mm.m.true"), quality(state.fit.against) if fitted else DASH,
                                  kind="plain" if fitted else "warning", detail=get_text("lab.mm.m.true_detail", grid=GRID),
                                  tip=get_text("lab.mm.m.true_tip", grid=GRID))]

    # ------------------------------------------------------------------ the mouse and the keys
    def hit(self, figure, state: MetamodelState, event):
        """The query point ("probe") or the design (its index) under the mouse, in the design space or in the check."""
        if event is None:
            return None
        plane, check = self.axes.get("plane"), self.axes.get("check")
        if plane is not None and event.inaxes is plane:
            if nearest(plane, [state.point], event, radius=PROBE_RADIUS) is not None:
                return "probe"
            return nearest(plane, state.data.points, event)
        if check is not None and event.inaxes is check and state.check is not None:
            return nearest(check, checked_points(state), event)
        return None

    def grabbable(self, hovered) -> bool:
        return hovered == "probe"

    def grab(self, figure, state: MetamodelState, event):
        """A press anywhere in the design space takes the query point there; one on the competition closes it."""
        if event is None or event.inaxes is None:
            return None
        if event.inaxes is self.axes.get("plane"):
            return "probe"
        if event.inaxes is self.axes.get("ranking") and state.ranking:
            return "ranking"
        return None

    def drag(self, figure, state: MetamodelState, handle, event, settings: dict) -> dict | None:
        if handle == "ranking":
            return settings | {"contest": 0} if settings["contest"] else None
        plane = self.axes.get("plane")
        if handle != "probe" or plane is None or not plane.get_visible():
            return None
        x1, x2 = plane.transData.inverted().transform((event.x, event.y))      # also from over another panel: kept on the border
        (a1, b1), (a2, b2) = state.response.bounds
        return moved(settings, (x1 - a1) / (b1 - a1), (x2 - a2) / (b2 - a2))

    def press(self, key: str, state: MetamodelState, settings: dict) -> dict | None:
        """The arrow keys move the query point."""
        du1, du2 = {"left": (-STEP, 0.0), "right": (STEP, 0.0), "up": (0.0, STEP), "down": (0.0, -STEP)}.get(key, (0.0, 0.0))
        return moved(settings, settings["probe"][0] + du1, settings["probe"][1] + du2)

    # ------------------------------------------------------------------ the figure
    def boxes(self, figure) -> dict:
        """The panels' boxes and the places of their titles, in figure fractions, from the plan the three steps share
        (panels.arrangement with pair="space"), in layout pixels."""
        width, height = size(figure)
        plan = arrangement(width, height, pair="space")

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)     # a box is never empty
        boxes = {"plane": frac(*plan.plane), "space": frac(*plan.space), "ranking": frac(*plan.ranking)}
        if plan.check is not None:
            boxes["check"] = frac(*plan.check)
        boxes["heads"] = places(plan, width, height)
        return boxes

    def prepare(self, figure, state: MetamodelState) -> dict:
        """The axes of the figure: made again when the layout changes, reused otherwise (the panels keep what they
        hold). The 3D view turned with the mouse since this lab drew it gives its angle to `view`."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height))
        space = self.axes.get("space")
        if space is not None and space.figure is figure and self.turned is not None and (space.elev, space.azim) != self.turned:
            self.view = (space.elev, space.azim)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = arrangement(width, height, pair="space")
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "check", "ranking") if name in boxes}
            self.axes["space"] = figure.add_axes(boxes["space"], projection="3d")
            self.axes["plane"].set_zorder(1)                          # its last x1 tick label overhangs the 3D box, which
                                                                      # begins 2 px later: drawn above it, the label is whole
            self.heads = boxes["heads"]
            self.written = typeset(figure, self.heads, FORMULAS[self.function])      # once per layout: it never changes here
            self.layout_key = key
            self.scene = None
            self.moving = []
        return self.axes

    def draw(self, figure, state: MetamodelState, hovered) -> None:
        axes = self.prepare(figure, state)
        if self.scene != state.scene:                                 # anything but the query point: the whole figure
            self.draw_scene(figure, axes, state)
            self.scene = state.scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        if axes["plane"].get_visible():
            self.draw_voices(axes["plane"], state, hovered)
        self.draw_query(axes["space"], state, hovered)
        if "check" in axes and axes["check"].get_visible():
            self.draw_found(axes["check"], state, hovered)
        space = axes["space"]
        if (space.elev, space.azim) != tuple(self.view):              # the angle the window carried from another step
            space.view_init(*self.view)
        self.turned = (space.elev, space.azim)

    def draw_scene(self, figure, axes: dict, state: MetamodelState) -> None:
        """Everything that stays while the query point moves: the designs, the surfaces, the check or the competition,
        the titles and the legends."""
        for ax in axes.values():
            ax.clear()
        for text in list(figure.texts):
            if text is not self.written:                              # the formula stays: drawn once per layout
                text.remove()
        for legend in list(figure.legends):
            legend.remove()
        self.moving = []
        contest = bool(state.ranking)
        shown = {"plane": not (contest and "check" not in axes), "space": True, "check": not contest, "ranking": contest}
        for name, ax in axes.items():
            ax.set_visible(shown[name])
        if shown["plane"]:
            self.draw_plane(axes["plane"], state)
            handles = [dot(POINT, get_text("lab.mm.legend.positive"), soft=True),
                       dot(NEGATIVE, get_text("lab.mm.legend.negative"), hollow=True),
                       dot(QUERY, get_text("lab.mm.legend.probe"), marker="D", size=6.5)]
            if state.fit is not None:
                handles.append(Line2D([], [], color=LINES["colors"], linewidth=1.0, alpha=0.8, label=get_text("lab.mm.legend.levels")))
            head(figure, self.heads, self.axes, "plane", get_text("lab.mm.plane_title"), handles)
        self.draw_space(axes["space"], state)
        head(figure, self.heads, self.axes, "space", get_text("lab.mm.space_title"), [
            Patch(facecolor=palette.SURFACE_RAMP[3], label=get_text("lab.mm.legend.surface")),
            Line2D([], [], color=TRUE, linewidth=1.2, label=get_text("lab.mm.legend.truth")),
            dot(POINT, get_text("lab.mm.legend.designs"))])
        if contest:
            self.draw_ranking(axes["ranking"], state)
            head(figure, self.heads, self.axes, "ranking", get_text("lab.mm.ranking_title"), [
                Patch(facecolor=POINT, label=get_text("lab.mm.legend.cop")),
                Patch(facecolor=WINNER, label=get_text("lab.mm.legend.largest"))])
        elif "check" in axes:
            self.draw_check(axes["check"], state)
            head(figure, self.heads, self.axes, "check", get_text("lab.mm.check_title"), [
                dot(POINT, get_text("lab.mm.legend.design")),
                Line2D([], [], color=TRUE, linewidth=1.1, label=get_text("lab.mm.legend.diagonal"))])

    def draw_plane(self, ax, state: MetamodelState) -> None:
        """The design space with every design where step 1 placed it and simulated it, over the faint level lines of
        the metamodel y^ (its values on the grid of the surfaces, the levels and the look step 3 draws them with, where
        it searches on them); none when the metamodel cannot be computed. They belong to the scene: the query point
        moving leaves them."""
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        (a1, b1), (a2, b2) = state.response.bounds
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        xs, ys = zip(*state.data.points)
        ax.scatter(xs, ys, s=min(marker_size(state.n), 16.0), c=POINT, edgecolors=palette.CARD, linewidths=0.7, zorder=6)
        if state.fit is not None and (levels := level_values(state.fit.surface)):     # under everything (zorder), drawn
            true = truth(state.response.key)                                         # after the designs: the first
            ax.contour(true.x1, true.x2, state.fit.surface, levels=levels, **LINES)    # collection stays theirs
        ax.set_xlabel("x₁", **LABEL, labelpad=2)
        ax.set_ylabel("x₂", **LABEL, labelpad=9, rotation=0, va="center")

    def draw_voices(self, ax, state: MetamodelState, hovered) -> None:
        """The weight of each design in y^ at the query point: on each design a disc of area |a_i(u)|, filled where a_i is positive, hollow
        where it is negative; the query point and, around it, the distance where a weight or a correlation is 1/e. When
        the metamodel cannot be computed there, the query point alone (and, the metamodel computed, why: on the panel)."""
        (a1, b1), (a2, b2) = state.response.bounds
        x, y = state.point
        if state.influence is not None:
            placed = sorted(zip(state.influence, state.data.points), key=lambda pair: -abs(pair[0]))     # the small ones on top
            for sign, face, edge, width in ((1, tint(POINT, 0.42), POINT, 0.9), (-1, "none", NEGATIVE, 1.5)):
                voices = [(abs(a), point) for a, point in placed if a * sign > 0]
                if voices:
                    areas, points = zip(*voices)
                    xs, ys = zip(*points)
                    self.moving.append(ax.scatter(xs, ys, s=[AREA * area for area in areas], facecolors=face, edgecolors=edge,
                                                  linewidths=width, zorder=4 if sign > 0 else 5))
            reach = reach_of(state.candidate)
            if reach is not None:
                radius, name = reach
                circle = Ellipse((x, y), 2 * radius * (b1 - a1), 2 * radius * (b2 - a2), fill=False, edgecolor=QUERY, linewidth=1.1,
                                 linestyle=(0, (4, 3)), alpha=0.9, zorder=7)
                self.moving.append(ax.add_patch(circle))
                for angle in (45, 135, 315, 225):                     # its name, on the first place of its rim inside the panel
                    u1 = state.probe[0] + radius * math.cos(math.radians(angle))
                    u2 = state.probe[1] + radius * math.sin(math.radians(angle))
                    if 0.06 < u1 < 0.94 and 0.06 < u2 < 0.94:
                        right, above = math.cos(math.radians(angle)) > 0, math.sin(math.radians(angle)) > 0
                        place = (a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2)
                        self.moving.append(ax.annotate(name, place, xytext=(4 if right else -4, 3 if above else -3),
                                                       textcoords="offset points", ha="left" if right else "right",
                                                       va="bottom" if above else "top", color=QUERY, fontsize=9, zorder=9))
                        break
        elif state.fit is not None:                                   # the metamodel exists, not at this point
            columns = max(int(ax.get_position().width * size(ax.figure)[0] / 6.6), 12)
            self.moving.append(ax.text(0.5, 0.04, fill(state.refused, columns), transform=ax.transAxes, ha="center", va="bottom",
                                       color=WARNING, fontsize=9, zorder=10, bbox=BOXED))
        if isinstance(hovered, int) and hovered < state.n:
            hx, hy = state.data.points[hovered]
            self.moving.append(ax.scatter([hx], [hy], s=150, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4, zorder=8))
            if state.influence is not None:
                right, above = state.data.unit[hovered][0] < 0.62, state.data.unit[hovered][1] < 0.86
                label = f"a{subscript(hovered + 1)} = {state.influence[hovered]:+.3f}".replace("-", "−")
                self.moving.append(ax.annotate(label, (hx, hy), xytext=(9 if right else -9, 8 if above else -8),
                                               textcoords="offset points", ha="left" if right else "right",
                                               va="bottom" if above else "top", color=palette.WHITE, fontsize=9, zorder=10,
                                               bbox=BOXED))
        self.moving.append(ax.scatter([x], [y], s=95 if hovered == "probe" else 70, marker="D", c=QUERY, edgecolors=palette.CARD,
                                      linewidths=1.0, zorder=9))

    def draw_space(self, ax, state: MetamodelState) -> None:
        """The metamodel as a surface, cut at the vertical window, the true response as a wire over it, and the designs
        at their simulated values; without a metamodel, the wire, the designs and why there is no surface."""
        ax.set_facecolor(palette.CARD)
        ax.computed_zorder = False                                    # the wire and the designs stay in front of the surface
        true = truth(state.response.key)
        low, high = true.low, true.high
        if state.fit is not None:
            polygons, heights, cut = facets(true.x1, true.x2, state.fit.surface, low, high)
            if polygons:
                colors = RAMP(np.clip((np.array(heights) - float(true.y.min())) / float(true.y.max() - true.y.min()), 0.0, 1.0))
                ax.add_collection3d(Poly3DCollection(polygons, facecolors=colors, edgecolors="none", linewidths=0, antialiaseds=False,
                                                     alpha=0.9, zorder=1))
            if cut:                                                   # in the room of the 3D box: on two lines when narrow
                columns = max(int(0.94 * ax.get_position().width * size(ax.figure)[0] / 6.2), 24)
                said = fill(get_text("lab.mm.cut", low=short(float(state.fit.surface.min()), 4),
                                     high=short(float(state.fit.surface.max()), 4)), columns, initial_indent=f"{MARK}  ")
                ax.text2D(0.03, 0.03, said, transform=ax.transAxes, ha="left", va="bottom", color=WARNING, fontsize=9, zorder=10)
        else:
            columns = max(int(0.8 * ax.get_position().width * size(ax.figure)[0] / 6.6), 16)
            ax.text2D(0.5, 0.62, fill(get_text("lab.mm.space.cannot", why=state.refused), columns), transform=ax.transAxes,
                      ha="center", va="center", color=WARNING, fontsize=9.5, zorder=10, bbox=BOXED)
        ax.plot_wireframe(true.x1, true.x2, true.y, rstride=3, cstride=3, color=TRUE, linewidth=0.6, alpha=0.55, zorder=2)
        (a1, b1), (a2, b2) = state.response.bounds
        ax.plot([a1, b1, b1, a1, a1], [a2, a2, b2, b2, a2], [low] * 5, color=palette.DARK_GREY, linewidth=0.8, zorder=1)
        xs, ys = zip(*state.data.points)
        ax.scatter(xs, ys, state.data.values, s=marker_size(state.n) * 0.7, c=POINT, edgecolors=palette.CARD, linewidths=0.7,
                   depthshade=False, zorder=4)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        ax.set_zlim(low, high)
        style_space(ax)
        space_ticks(ax)
        ax.set_box_aspect((1.0, 1.0, 0.72), zoom=SPACE_ZOOM)
        ax.view_init(*self.view)

    def draw_query(self, ax, state: MetamodelState, hovered) -> None:
        """At the query point: a vertical line, the prediction on it (a triangle on the edge of the window when it is
        beyond) and the true value (a ring); and the design under the mouse."""
        true = truth(state.response.key)
        low, high = true.low, true.high
        x, y = state.point
        self.moving += ax.plot([x, x], [y, y], [low, high], color=QUERY, linewidth=0.9, linestyle=(0, (3, 2)), alpha=0.8, zorder=5)
        self.moving.append(ax.scatter([x], [y], [state.truth], s=74, facecolors="none", edgecolors=TRUE, linewidths=1.6,
                                      depthshade=False, zorder=6))
        if state.prediction is None:
            values = ((state.truth, "f", TRUE, True),)
        else:
            inside = low <= state.prediction <= high
            marker = "o" if inside else ("^" if state.prediction > high else "v")
            self.moving.append(ax.scatter([x], [y], [min(max(state.prediction, low), high)], s=46, marker=marker, c=QUERY,
                                          edgecolors=palette.CARD, linewidths=0.8, depthshade=False, zorder=7))
            above = state.prediction >= state.truth                   # the two values, each on its side of the other
            values = ((state.prediction, "ŷ", QUERY, above), (state.truth, "f", TRUE, not above))
        for value, name, color, over in values:
            self.moving.append(ax.text(x, y, min(max(value, low), high), f"   {name} = {short(value, 4)}", color=color, fontsize=9,
                                       ha="left", va="bottom" if over else "top", zorder=8, path_effects=HALO))
        if isinstance(hovered, int) and hovered < state.n:
            (hx, hy), value = state.data.points[hovered], state.data.values[hovered]
            self.moving.append(ax.scatter([hx], [hy], [value], s=marker_size(state.n) * 2.4, facecolors="none", edgecolors=palette.WHITE,
                                          linewidths=1.4, depthshade=False, zorder=7))
            self.moving.append(ax.text(hx, hy, value, f"   y{subscript(hovered + 1)} = {short(value, 4)}", color=palette.WHITE,
                                       fontsize=9, ha="left", va="bottom", zorder=8, path_effects=HALO))

    def draw_check(self, ax, state: MetamodelState) -> None:
        """Every design predicted by a metamodel fitted without it, against its simulated value: on the diagonal the two
        agree. A prediction beyond the window is a triangle on its edge. What cannot be computed is said on the panel."""
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        low, high = spread(state.data.values)
        ax.set_xlim(low, high)
        ax.set_ylim(low, high)
        ax.xaxis.set_major_locator(MaxNLocator(5))
        ax.yaxis.set_major_locator(MaxNLocator(5))
        ax.set_xlabel(get_text("lab.mm.check.x"), **LABEL, labelpad=3)
        ax.set_ylabel(get_text("lab.mm.check.y"), **LABEL, labelpad=4)
        ax.plot([low, high], [low, high], color=TRUE, linewidth=1.1, alpha=0.8, zorder=2)
        if state.check is None:
            if state.fit is None:
                why = get_text("lab.mm.check.unfitted")
            else:
                why = get_text("lab.mm.check.cannot." + ("mls" if state.model == "mls" else "fit"))
            box = ax.get_position()
            columns = max(int(box.width * size(ax.figure)[0] / 6.6), 12)
            ax.text(0.5, 0.5, fill(why, columns), transform=ax.transAxes, ha="center", va="center", color=WARNING, fontsize=9.5,
                    zorder=5, bbox=BOXED)
            return
        area = marker_size(state.n) * 0.8
        for marker, keep in (("o", lambda p: low <= p <= high), ("^", lambda p: p > high), ("v", lambda p: p < low)):
            points = [(value, min(max(p, low), high)) for value, p in zip(state.data.values, state.check.predictions) if keep(p)]
            if points:
                xs, ys = zip(*points)
                ax.scatter(xs, ys, s=area, marker=marker, c=POINT, edgecolors=palette.CARD, linewidths=0.7, zorder=4, clip_on=marker == "o")
        warned = poor(state.check.cop)                               # no better than the mean: the warning's colour and mark
        said = f"{get_text('lab.mm.m.cop')} = {quality(state.check.cop)}"
        ax.text(0.04, 0.95, f"{MARK} {said}" if warned else said, transform=ax.transAxes, ha="left", va="top",
                color=WARNING if warned else palette.WHITE, fontsize=11, fontweight="semibold", zorder=5)

    def draw_found(self, ax, state: MetamodelState, hovered) -> None:
        """The design under the mouse, in the check."""
        if state.check is None or not isinstance(hovered, int) or hovered >= state.n:
            return
        x, y = checked_points(state)[hovered]
        self.moving.append(ax.scatter([x], [y], s=marker_size(state.n) * 2.6, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4,
                                      zorder=6, clip_on=False))

    def draw_ranking(self, ax, state: MetamodelState) -> None:
        """The competition: a row per candidate, its name and, once shown, a bar as long as its CoP between 0 and 1 (a
        negative CoP has no bar: its number is written). Every candidate shown, the largest CoP is marked."""
        ax.set_facecolor(palette.CARD)
        for side in ("left", "top", "right"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color(palette.DARK_GREY)
        ax.set_yticks([])
        ax.set_xticks([0.0, 0.25, 0.5, 0.75, 1.0], ["0", "", "0.5", "", "1"])
        ax.tick_params(colors=palette.GREY, labelsize=9, length=3)
        ax.set_xlabel(get_text("lab.mm.m.cop"), **LABEL, labelpad=3)
        box = ax.get_position()
        height = box.height * size(ax.figure)[1]
        hint = "check" not in self.axes                               # the competition stands where the design space was
        written, small, foot = get_text("lab.mm.ranking.back"), 8.5, 18.0 if hint else 0.0
        if hint:                                                      # in the room the panel has: smaller, then on two lines
            room = 0.976 * box.width * size(ax.figure)[0]
            while small > 7.5 and text_width(written, small) > room:
                small -= 0.5
            if text_width(written, small) > room:
                written, foot = fill(written, max(int(len(written) * room / text_width(written, small)), 12)), 30.0
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, height)
        row = (height - foot) / CANDIDATES
        thick = min(10.0, 0.26 * row)
        first = winner(state.ranking) if state.complete else None
        for k in range(CANDIDATES):
            top = height - k * row
            item = state.ranking[k] if k < len(state.ranking) else None
            bar = top - 0.70 * row - thick / 2
            if item is None:                                          # still to come: its name, without the value it will take
                ax.text(0.012, top - 0.30 * row, named(entry_to_come(k)), ha="left", va="center", fontsize=9, color=palette.DARK_GREY)
                continue
            leading = k == first
            if leading:
                ax.add_patch(Rectangle((0.0, top - row + 1.0), 1.0, row - 2.0, facecolor=palette.PILL, edgecolor="none", zorder=1))
            ink, weight = (palette.WHITE, "semibold") if leading else (palette.SLATE, "normal")
            ax.text(0.012, top - 0.30 * row, named(item.candidate), ha="left", va="center", fontsize=9, color=ink, fontweight=weight,
                    zorder=3)
            ax.add_patch(Rectangle((0.0, bar), 1.0, thick, facecolor=palette.TRACK, edgecolor="none", zorder=2))
            if item.cop is None:
                ax.text(0.988, top - 0.30 * row, get_text("lab.mm.ranking.cannot"), ha="right", va="center", fontsize=9,
                        color=palette.GREY, zorder=3)
                continue
            if item.cop > 0:
                ax.add_patch(Rectangle((0.0, bar), min(item.cop, 1.0), thick, facecolor=WINNER if leading else POINT, edgecolor="none",
                                       zorder=3))
            ax.text(0.988, top - 0.30 * row, quality(item.cop), ha="right", va="center", fontsize=9.5, color=ink, fontweight=weight,
                    zorder=3)
        if hint:
            ax.text(0.988, foot / 2, written, ha="right", va="center", fontsize=small, color=palette.GREY, zorder=3, linespacing=1.1)

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def crowned(settings: dict) -> dict:
    """The settings with the winner of the competition on their experiment chosen (its model, basis, D or theta); as
    they were when no candidate can be computed."""
    best = champion(settings["experiment"])
    return settings if best is None else settings | chosen(best.candidate)

def moved(settings: dict, u1: float, u2: float) -> dict | None:
    """The settings with the query point at (u1, u2), kept inside the unit square; None when it does not move."""
    probe = (round(min(max(float(u1), 0.0), 1.0), 3), round(min(max(float(u2), 0.0), 1.0), 3))
    return None if probe == tuple(settings["probe"]) else settings | {"probe": probe}

def terms(order: str) -> int:
    """The number of terms of a polynomial basis: the least number of designs a fit of that basis needs."""
    return len(regression.basis((0.5, 0.5), order))

def cannot(candidate: Candidate, where: str, n: int) -> str:
    """Why a choice cannot be computed with n designs, as a sentence for the figure and the lead (where: "fit",
    somewhere on the grid; "probe", at the query point). A basis with more terms than designs; the moving least squares
    with a radius that leaves some point with too few designs carrying weight; Kriging's R singular to the working
    precision (theta so small, or two designs so close, that two rows of R are nearly the same); a polynomial whose
    designs do not determine its coefficients."""
    if candidate.order is not None and n < terms(candidate.order):
        return get_text("lab.mm.cannot.terms", basis=get_text(f"lab.mm.order.{candidate.order}").lower(), terms=terms(candidate.order),
                        n=n)
    if candidate.model == "mls" and candidate.value is not None:
        return get_text(f"lab.mm.cannot.{'probe' if where == 'probe' else 'mls'}", radius=f"{candidate.value:.2f}")
    if candidate.model == "kriging" and candidate.value is not None:
        return get_text("lab.mm.cannot.kriging", theta=f"{candidate.value:g}")
    return get_text("lab.mm.cannot.fit", model=get_text(f"lab.mm.model.{candidate.model}"))

def named(candidate: Candidate) -> str:
    """A candidate in words: its model, its basis and its parameter (once known)."""
    parts = [get_text(f"lab.mm.model.{candidate.model}")]
    if candidate.order is not None:
        parts.append(get_text(f"lab.mm.order.{candidate.order}").lower())
    if candidate.value is not None:
        parts.append(f"D = {candidate.value:.2f}" if candidate.model == "mls" else f"θ = {candidate.value:g}")
    return " · ".join(parts)

def entry_to_come(k: int) -> Candidate:
    """Candidate k of the competition before it is computed: its model and its basis, not yet its parameter."""
    if k < len(ORDERS):
        return Candidate("polynomial", ORDERS[k], None)
    if k < 2 * len(ORDERS):
        return Candidate("mls", ORDERS[k - len(ORDERS)], None)
    return Candidate("kriging", None, None)

def reach_of(candidate: Candidate) -> tuple[float, str] | None:
    """The distance, in the unit square, at which a design's weight (moving least squares) or its correlation with the
    point (Kriging) is 1/e, and its name; None for a polynomial, which has no such distance."""
    if candidate.model == "mls":
        return candidate.value, "D"
    if candidate.model == "kriging":
        return 1 / math.sqrt(candidate.value), "1/√θ"
    return None

def checked_points(state: MetamodelState) -> list[tuple[float, float]]:
    """The points of the check as they are drawn: (simulated, predicted without it), a prediction beyond the window on
    its edge."""
    low, high = spread(state.data.values)
    return [(value, min(max(prediction, low), high)) for value, prediction in zip(state.data.values, state.check.predictions)]

def spread(values, share: float = 0.12) -> tuple[float, float]:
    """A window that holds the values, with a margin."""
    low, high = min(values), max(values)
    margin = share * ((high - low) or abs(high) or 1.0)
    return low - margin, high + margin

def poor(cop: float) -> bool:
    """A CoP at or below 0: CoP = 1 - SS_E/SS_T, so the metamodel predicts the designs it did not see no better than
    their mean. An exact meaning, not a threshold: the strip, the check and the summary warn of it."""
    return cop <= 0.0

def quality(value: float) -> str:
    """A coefficient (CoD, CoP) as the lab writes it: three decimals near 1, fewer far below 0, a power of ten beyond."""
    if abs(value) < 10:
        text = f"{value:.3f}"
    elif abs(value) < 1000:
        text = f"{value:.1f}"
    else:
        mantissa, exponent = f"{value:.1e}".split("e")
        text = f"{mantissa} × 10{''.join(SUPERSCRIPTS[c] for c in str(int(exponent)))}"
    return "0.000" if text == "-0.000" else text.replace("-", "−")
