# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: metamodel.py
# ==============================================================================
"""
Step 2 of a bench's study, the metamodel: a cheap function y^ fitted to the N designs that step 1 simulated, to stand
in for the simulation in step 3: a polynomial (regression.py), moving least squares (moving_least_squares.py) or
Kriging (kriging.py), judged by how it reproduces the values it saw (CoD) and how it predicts the ones it did not (CoP,
by cross-validation: prognosis.py), on the bench's response y = f(x1, x2) (functions.RESPONSES).

What the step receives (receive, received): step 1's doe.Experiment (the response, the sampling, N, the seed) and with
it the N designs and their simulated values (doe.simulated): of f the metamodel knows nothing else. The column says
what came in, measured on the designs by measures.py (the sampling, N, the empty intervals, the correlation, the
smallest distance): the quality of step 1 carried into step 2. Any experiment is fitted, a Monte Carlo one too, and N
from 5 on: with few designs some metamodels cannot be computed (a quadratic basis has 6 coefficients; a subset of the
cross-validation leaves 4 designs when N = 5), and two random designs very close make Kriging's matrix singular. What
cannot be computed is kept as None (a Fit, a Validation, a candidate's CoP, the influences), never raised: the state,
the commands and the drawing say it, on the figure and in the strip.

What the step hands (output, missing): the Surrogate (experiment, candidate) of the metamodel on screen, from which
step 3 computes y^ again (fit(candidate, experiment).model, cached); None while that metamodel cannot be computed, and
missing says why in one sentence. The forward command "Go to the optimization" is answered by the window.

    [ Optimal prognosis                  ]  the featured command, and under it the winner and its CoP
    Model (Polynomial | MLS | Kriging)   Basis (Linear | Pure quadratic | Quadratic)   Radius D -o-  (or Correlation theta)
    the weight of each design in y^ at  | the metamodel as a surface, the true    | the coefficient of prognosis: the CoP
    the query point: the designs, each  | response as a wire over it, the designs | large on its gauge, its definition,
    with a disc of area |a_i(u)|, over  | at their simulated values, the query    | the CoD (and against f) beside it; each
    y^'s faint level lines, and the     | point's prediction and true value       | design predicted without it; or the
    query point (dragged, clicked, the arrow keys)                                 | competition: the seven candidates' CoP
    strip: CoP (strong) | CoD | against the true response (a student's: once the bench is complete)   [Best D]   [Go to the ...]

The controls and the commands stand in the window's column at the left of the figure, under what was received; the
measures in the strip under the figure, each with a tip of one sentence that defines it; the formula of the bench's
response is typeset in the figure as the 3D view's caption (panels.typeset, once per layout), as in the other steps.

What the step opens on depends on how the application is used (explorers/game.py, Lab.mode). The TEACHER's lab opens
on the optimal prognosis: its first settings, Restore and an experiment received that is not the one on screen put the
winner of the competition (champion: the candidate of largest CoP, computed once per experiment and kept) on screen,
its model, basis, D or theta, with the competition closed (the check of the winner in the third panel: no frame plays
on entering; the competition costs about a second at N = 60 and two to four at N = 100, most of it the search of the
moving least squares' D). When no candidate can be computed the settings stay as they were; a choice of the reader is kept while
the experiment stays the same. "Optimal prognosis" is the featured command, drawn over the controls: pressed, it plays
the competition again, one candidate per frame, and ends on the winner; its second line (naming) names the winner and
its CoP, with a check mark when the model on screen is the winner and the word "winner" when the reader chose another.
The STUDENT's lab calibrates by hand, reading the CoP: neither the optimal prognosis nor the Best command is offered
(offered; settings that ask for the competition show none, and its frames never start), and it opens on the simplest
metamodel, the linear polynomial, keeping the reader's choice when another experiment comes; the strip does not show
him the coefficient against the true response (the answer a study never has) until the bench is complete (Lab.won).
A competition is run only where its winner will be shown: a lab given an experiment as it opens (opening) crowns that
one, never the bench's first experiment as well. A competition played to its end asks for the sound "complete", a Best
command for "apply" (cue).

The three panels answer three questions. The left one, where a prediction comes from: every metamodel of this step is
linear in the simulated values, y^(u) = sum_i a_i(u) y_i, and the a_i(u) (the cores' `influence`) are drawn on the
designs, blue and filled where positive, purple and hollow where negative, over the faint level lines of y^ (from its
surface on the grid, with the levels and the look of step 3's plane, panels.level_values and LINES: the same lines the
optimization then searches on). The middle one, what the metamodel is: its surface on a GRID x GRID grid, beside the
true response, which a study never has. The right one, what it is worth: its card is the coefficient of prognosis. The
CoP is its hero (draw_hero): the number large (panels.HERO, the strip's very text: cop_written), its definition typeset
small as prognosis.coefficient_of_prognosis computes it (DEFINED), and a gauge from 0 to 1 filled to it (panels.gauge:
clamped, so a CoP below 0 leaves it empty and its number says how far); under it, smaller and muted, the CoD at the
designs (which flatters: Kriging's is 1) and, where the strip shows it, the coefficient against the true response, on
gauges of the same scale. Beside the hero, or under it where that leaves the larger square (composed: the corner and
the stack side by side, a row usually over; the hero and the check's legend on the row under the card's title), the
check: every design predicted by a metamodel fitted without it, against its simulated value. The pair has no third card,
so no hero: the strip says the CoP. A card whose check would be smaller than CHECK_LEAST (a phone's) shows the hero
alone, and the 3D view's clause then says why a metamodel cannot be computed; there the competition's names leave out
their D or theta, then step down to RANKING_LEAST, before they would meet their CoP.

A CoP at or below 0 (poor) has an exact meaning, CoP = 1 - SS_E/SS_T: the metamodel predicts the designs it did not see
no better than their mean. Then the strip's CoP and the hero take the warning's colour and its mark (MARK), and the
step's summary (the cover's track, the pill's tooltip) is a warning; no other threshold is drawn. What the step
received carries its kind too: the empty intervals of step 1 as its strip paints them.

The figure is laid out by panels.arrangement(width, height, pair="space"), the plan the three steps share: for the same
figure size the design space and the 3D view have the same boxes in every step, the design space the same axes and the
designs of step 1 at the same places, and the 3D view the same vertical window (truth) and the same angle (Lab.view,
which the window carries between the steps: read at every draw, updated when the reader turns the view). The third
panel is this step's. In a figure with room, the corner (the design space large at the left; at its right the 3D view
over the check, a square); otherwise the three panels in a row; the design space and the 3D view side by side, the
check left out, when there is no room for three (the code panel open beside the lab); and the three stacked in a narrow
figure. The competition takes the place of the check (in the corner, its whole rectangle), and where there is no check
that of the design space, until a control changes or a click closes it. The 3D view and the check (or the competition
in its place) stand on the cards of the right column (panels.draw_cards, once per layout; the check on the card's
tone), and f is the wire every step draws over a metamodel (panels.true_wire, its legend's handle wire_handle).

Everything shown is computed by the cores through their public functions; NumPy only holds the grids of the drawing
and evaluates the test function. What is expensive is cached by the experiment and the candidate (sample, fit,
validation, the best values). Dragging the query point changes only the influences and the two values at that point:
the figure keeps the artists of everything else (scene: the hero and its gauges among them), and draws again what moves.

The sampling never looks at f: the designs are step 1's, placed before any simulation, mapped to the bounds of the
response and then simulated.
"""
import math
from dataclasses import dataclass
from functools import cache, lru_cache
from random import Random
from textwrap import fill
from typing import Callable

import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patheffects import withStroke
from matplotlib.patches import Ellipse, Patch, Rectangle
from matplotlib.ticker import MaxNLocator
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from statistical_fundamentals import kriging, moving_least_squares, palette, regression
from statistical_fundamentals.explorers.base import Control, nearest, short, style_axes
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.doe import (HEIGHT, RAMP, SPACE_ZOOM, VIEW, Experiment, first_experiment,
                                                    marker_size, simulated, style_space)
from statistical_fundamentals.explorers.lab import BENCH, LAYOUT_DPI, LINK, Action, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.panels import (BELOW, CARD_FOOT, CARD_TONE, CHECK_LEFT, DEFINITION, HEAD, HEAD_GAP, HERO,
                                                       HERO_LEAST, LEGEND_DROP, LEGEND_PITCH, LEGEND_ROW, LEGEND_SIZE, LINES,
                                                       MUTED_INK, NOTE, RANK_INSET, READING, SMALL, STACK_WIDTH, TAG, TITLE_DROP,
                                                       TITLE_LINE, arrangement, cut_note, dot, draw_cards, facets, gauge, head,
                                                       legend_at, legend_rows, legend_width, level_values, mathtext_width, number_width,
                                                       places, plane_ticks, space_ticks, subscript, text_width, ticks, tint, titled,
                                                       true_wire, typeset, wire_handle, LABEL, NAME, X1, X2)
from statistical_fundamentals.explorers.responses import FORMULAS, formula
from statistical_fundamentals.functions import RESPONSES, Response
from statistical_fundamentals.i18n import current_language, get_text
from statistical_fundamentals.measures import correlation, empty_intervals, smallest_distance
from statistical_fundamentals.prognosis import (FOLDS, coefficient_of_determination, coefficient_of_prognosis, cross_validation,
                                                 folds)
from statistical_fundamentals.sampling import scaled

MODELS = ("polynomial", "mls", "kriging")
ORDERS = regression.ORDERS
RADII = tuple(round(0.05 * 50 ** (k / 23), 2) for k in range(24))             # D: 0.05 to 2.5 in geometric steps
THETAS = tuple(float(f"{0.25 * 1600 ** (k / 24):.2g}") for k in range(25))    # theta: 0.25 to 400 in geometric steps
FIRST_MODEL, FIRST_ORDER = "polynomial", "linear"     # the simplest metamodel: the controls' first values, the student's
                                                      # metamodel, the teacher's when no candidate can be computed
COACHED = ("tune", "contest")         # the commands that calibrate for the reader: not offered to a student
FIRST_RADIUS = min(RADII, key=lambda D: abs(D - 0.3))
FIRST_THETA = min(THETAS, key=lambda theta: abs(theta - 7.4))
FIRST_FUNCTION = next(iter(RESPONSES))    # the bench of a lab made without one: the first response
FIRST_PROBE = (0.62, 0.42)            # the query point, in the unit square
STEP = 0.02                           # an arrow key moves the query point this far in the unit square
GRID = 31                             # samples per axis of the surfaces: the metamodel's and the true response's
MARGIN = 0.15                         # the vertical window: the range of the true response and this share of it on each side
CANDIDATES = 7                        # of the competition: three polynomials, three moving least squares, one Kriging
AREA = 620.0                          # points squared: the disc of a design whose weight a_i is 1
PROBE_RADIUS = 14                     # pixels: how close the mouse must come to the query point to take hold of it
QUERY = palette.YELLOW                # the query point, its prediction, the circle of its radius
POINT = palette.BLUE                  # a design, and its weight where positive
NEGATIVE = palette.PURPLE             # a negative weight (hollow, too)
TRUE = palette.SLATE                  # the true response: a reference
WINNER = palette.TEAL                 # the largest CoP of the competition
WARNING = palette.GOLD
MARK = "▲"                            # beside the warning's colour (never colour alone): a CoP at or below 0, a cut surface
DASH = "—"                            # a value that cannot be computed
SUPERSCRIPTS = {"-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹"}
BOXED = {"boxstyle": "round,pad=0.25", "facecolor": palette.CARD, "edgecolor": "none", "alpha": 0.8}
HALO = [withStroke(linewidth=2.6, foreground=palette.CARD)]      # a text over the surface: read on any of its colours
TAG_BOX = {"boxstyle": "round,pad=0.2", "facecolor": CARD_TONE, "edgecolor": "none", "alpha": 0.85}     # under the query point's
                                                                  # values in the 3D view: read over f's light wire too
REFUSED = (ArithmeticError, ValueError)   # how the cores refuse: a matrix not positive definite, a logarithm of nothing
# The third card: the CoP as its hero, the check beside it or under it (composed), in layout pixels
DEFINED = r"$\mathrm{CoP} = 1 - SS_E^{\,\mathrm{pred}}\,/\,SS_T$"     # prognosis.coefficient_of_prognosis, as it computes it
COP_INK = POINT                       # the CoP's gauge: the colour of a CoP's bar in the competition
REFERENCE_INK = MUTED_INK             # the gauges of the references beside it (the CoD at the designs, against f): one ink,
                                      # muted
WIDEST = "−0.000"                     # the widest number a row of the hero keeps room for (quality near 1 and below 0)
HERO_GAP = 16.0                       # from the hero to the check's tick labels (beside) or its axes (over)
HERO_MOST = 260.0                     # the hero is never wider
HERO_FEWEST = 140.0                   # nor narrower
ROW_GAP = 10.0                        # in a row of the hero, between its name and its number
GAUGE_HIGH, ROW_HIGH = 8.0, 6.0       # the CoP's gauge, a reference's gauge (a gauge, not a rule)
DROPS = {"formula": 26.0, "gauge": 9.0, "row": 17.0, "under": 5.0, "scale": 13.0}    # from a line of the hero to the next
SCALE_FOOT = 4.0                      # under the scale's baseline: the last thing the hero draws
CHECK_FEW = 160.0                     # a check smaller than this has at most three intervals on each axis (two under half)
RANKING_LEAST = 8.0                   # points: a candidate's name too wide for a phone's card steps down to this, never below
CHECK_LEAST = 90.0                   # a check smaller than this is left out: the hero alone in its card (composed)
CHECK_GAP = 8.0                       # from the check's legend down to its axes (its top tick label rises half its height)
CHECK_TIGHT, BELOW_TIGHT = 44.0, 26.0     # a check too small to name its axes: its tick labels' gutter and foot alone

# ------------------------------------------------------------------------------
# What is computed, by the cores, and kept by the experiment and the candidate
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Candidate:
    """A metamodel to fit: its type, its basis (None for Kriging) and its parameter (D of the moving least squares,
    theta of Kriging; None for a polynomial, and for a candidate none of whose values can be computed)."""
    model: str
    order: str | None
    value: float | None

@dataclass(frozen=True)
class Surrogate:
    """Step 2's result, handed to the optimization: the metamodel `candidate` fitted to the designs of `experiment`.
    Everything else is computed from it (fit(candidate, experiment)), so two surrogates are the same when equal."""
    experiment: Experiment
    candidate: Candidate

@dataclass(frozen=True)
class Sample:
    unit: tuple[tuple[float, float], ...]       # the designs in the unit square: step 1's experiment
    points: tuple[tuple[float, float], ...]     # the same, mapped to the bounds of the response
    values: tuple[float, ...]                   # y = f at every design: the simulations
    subsets: tuple[tuple[int, ...], ...]        # the designs dealt into the subsets of the cross-validation

@dataclass(frozen=True)
class Truth:
    """The true response on the grid of the surfaces: what a metamodel is drawn beside, and measured against."""
    axis: tuple[float, ...]                     # the grid of one axis, in the unit square
    x1: np.ndarray
    x2: np.ndarray
    y: np.ndarray
    flat: tuple[float, ...]                     # y row by row, as the cores take it
    low: float                                  # the vertical window of the 3D view
    high: float

@dataclass(frozen=True)
class Fit:
    model: Callable                             # the metamodel, a function of the point of the unit square (from the cores)
    fitted: tuple[float, ...]                   # its values at the designs
    cod: float
    surface: np.ndarray                         # its values on the grid: the surface drawn
    against: float                              # the coefficient of determination of the true response on the grid

@dataclass(frozen=True)
class Validation:
    predictions: tuple[float, ...]              # every design predicted by a metamodel fitted without it
    cop: float

@dataclass(frozen=True)
class Entry:
    """A candidate of the competition with its CoP (None: it cannot be computed)."""
    candidate: Candidate
    cop: float | None

@cache
def sample(experiment: Experiment) -> Sample:
    """The designs of step 1 and their simulations (doe.simulated), and the subsets of the cross-validation, dealt from
    the experiment's seed."""
    simulations = simulated(experiment)
    subsets = tuple(tuple(subset) for subset in folds(experiment.n, FOLDS, Random(experiment.seed)))
    return Sample(simulations.unit, simulations.points, simulations.values, subsets)

@cache
def truth(function: str) -> Truth:
    response = RESPONSES[function]
    (a1, b1), (a2, b2) = response.bounds
    axis = tuple(k / (GRID - 1) for k in range(GRID))
    u1, u2 = np.meshgrid(np.array(axis), np.array(axis))
    x1, x2 = a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2
    y = np.asarray(response.f(x1, x2), dtype=float)
    low, high = float(y.min()), float(y.max())
    margin = MARGIN * (high - low)
    return Truth(axis, x1, x2, y, tuple(float(v) for v in y.ravel()), low - margin, high + margin)

def maker(candidate: Candidate) -> Callable:
    """The candidate as the cross-validation asks for it: from points and values, a function of the point."""
    if candidate.model == "polynomial":
        return lambda points, values: regression.metamodel(points, values, candidate.order)
    if candidate.model == "mls":
        return lambda points, values: moving_least_squares.metamodel(points, values, candidate.order, candidate.value)
    return lambda points, values: kriging.metamodel(points, values, candidate.value)

def influence_of(candidate: Candidate, u, points) -> list[float]:
    """The a_i(u) of the candidate: how much each simulated value counts in its prediction at u."""
    if candidate.model == "polynomial":
        return regression.influence(u, points, candidate.order)
    if candidate.model == "mls":
        return moving_least_squares.influence(u, points, candidate.order, candidate.value)
    return kriging.influence(u, points, candidate.value)

@lru_cache(maxsize=256)
def fit(candidate: Candidate, experiment: Experiment) -> Fit | None:
    """The candidate fitted to the designs of the experiment, at the designs and on the whole grid; None when it cannot
    be computed somewhere (a matrix that is not positive definite: too few designs for its terms, too few carrying
    weight there, or two designs too close)."""
    if candidate.model != "polynomial" and candidate.value is None:
        return None
    data, true = sample(experiment), truth(experiment.function)
    try:
        model = maker(candidate)(data.unit, data.values)
        fitted = tuple(model(u) for u in data.unit)
        rows = [[model((u1, u2)) for u1 in true.axis] for u2 in true.axis]
        cod = coefficient_of_determination(data.values, fitted)
        against = coefficient_of_determination(true.flat, [value for row in rows for value in row])
    except REFUSED:
        return None
    surface = np.array(rows)
    if not (np.isfinite(surface).all() and all(math.isfinite(v) for v in fitted) and math.isfinite(cod) and math.isfinite(against)):
        return None
    return Fit(model, fitted, cod, surface, against)

@lru_cache(maxsize=2048)
def validation(candidate: Candidate, experiment: Experiment) -> Validation | None:
    """The cross-validation of the candidate and its CoP; None when one of its fits cannot be computed."""
    if candidate.model != "polynomial" and candidate.value is None:
        return None
    data = sample(experiment)
    try:
        predictions = cross_validation(data.unit, data.values, data.subsets, maker(candidate))
        cop = coefficient_of_prognosis(data.values, predictions)
    except REFUSED:
        return None
    if not (math.isfinite(cop) and all(math.isfinite(p) for p in predictions)):
        return None
    return Validation(tuple(predictions), cop)

@cache
def best_order(experiment: Experiment) -> str | None:
    """The basis of the polynomial with the largest CoP (None: no basis can be computed)."""
    scores = [(checked.cop, order) for order in ORDERS
              if (checked := validation(Candidate("polynomial", order, None), experiment)) is not None
              and fit(Candidate("polynomial", order, None), experiment) is not None]
    return max(scores, key=lambda score: score[0])[1] if scores else None

@cache
def best_radius(order: str, experiment: Experiment) -> float | None:
    """The D with the largest CoP among the slider's values, for a basis: the values in the order of their CoP, the
    first whose metamodel can also be computed on the whole grid (None: none can)."""
    scores = [(checked.cop, D) for D in RADII if (checked := validation(Candidate("mls", order, D), experiment)) is not None]
    for _cop, D in sorted(scores, key=lambda score: -score[0]):
        if fit(Candidate("mls", order, D), experiment) is not None:
            return D
    return None

@cache
def best_theta(experiment: Experiment) -> float | None:
    """The theta with the largest concentrated log-likelihood among the slider's values (None: none can be computed)."""
    data = sample(experiment)
    scores = []
    for theta in THETAS:
        try:
            likelihood = kriging.log_likelihood(data.unit, data.values, theta)
        except REFUSED:
            continue
        if math.isfinite(likelihood):
            scores.append((likelihood, theta))
    for _likelihood, theta in sorted(scores, reverse=True):             # the likeliest whose surface can be computed:
        if fit(Candidate("kriging", None, theta), experiment) is not None:     # usually the first, one fit
            return theta
    return None

@cache
def entry(k: int, experiment: Experiment) -> Entry:
    """Candidate k of the competition: the three polynomials, the three moving least squares, each at its best D, and
    Kriging at its theta of largest likelihood."""
    if k < len(ORDERS):
        candidate = Candidate("polynomial", ORDERS[k], None)
    elif k < 2 * len(ORDERS):
        order = ORDERS[k - len(ORDERS)]
        candidate = Candidate("mls", order, best_radius(order, experiment))
    else:
        candidate = Candidate("kriging", None, best_theta(experiment))
    if candidate.model != "polynomial" and candidate.value is None:
        return Entry(candidate, None)
    checked = validation(candidate, experiment)
    computed = checked is not None and fit(candidate, experiment) is not None
    return Entry(candidate, checked.cop if computed else None)

def winner(entries) -> int | None:
    """The index of the entry with the largest CoP (the first of them), or None when none was computed."""
    scored = [k for k, item in enumerate(entries) if item.cop is not None]
    return max(scored, key=lambda k: entries[k].cop) if scored else None

@cache
def champion(experiment: Experiment) -> Entry | None:
    """The winner of the competition on the designs of the experiment, the entry of largest CoP; None when no candidate
    can be computed. Computed once per experiment (about a second at N = 60): the first settings, the experiments
    received and the featured command's line ask for it often."""
    entries = [entry(k, experiment) for k in range(CANDIDATES)]
    first = winner(entries)
    return None if first is None else entries[first]

def candidate_of(settings: dict) -> Candidate:
    """The metamodel the controls choose."""
    model = settings["model"]
    if model == "polynomial":
        return Candidate(model, settings["order"], None)
    if model == "mls":
        return Candidate(model, settings["order"], settings["radius"])
    return Candidate(model, None, settings["theta"])

def chosen(candidate: Candidate) -> dict:
    """The settings of the controls that choose a candidate."""
    if candidate.model == "polynomial":
        return {"model": candidate.model, "order": candidate.order}
    if candidate.model == "mls":
        return {"model": candidate.model, "order": candidate.order, "radius": candidate.value}
    return {"model": candidate.model, "theta": candidate.value}

def first_surrogate(function: str, mode: str = TEACHER) -> Surrogate:
    """The surrogate a stand-alone optimization lab opens on: the first experiment of the bench, with the metamodel the
    step 2 of the mode opens on: the teacher's, the winner of its competition (the simplest one, should no candidate be
    computed); the student's, the simplest one (no competition is run)."""
    experiment = first_experiment(function)
    best = champion(experiment) if mode != STUDENT else None
    return Surrogate(experiment, Candidate(FIRST_MODEL, FIRST_ORDER, None) if best is None else best.candidate)

# ------------------------------------------------------------------------------
# The state
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class MetamodelState:
    model: str
    experiment: Experiment
    response: Response
    candidate: Candidate
    data: Sample
    fit: Fit | None                             # None: the metamodel cannot be computed with these designs
    check: Validation | None                    # None: the cross-validation cannot be computed (nor without a fit)
    probe: tuple[float, float]                  # the query point, in the unit square
    point: tuple[float, float]                  # the same, in the bounds of the response
    influence: tuple[float, ...] | None         # a_i(u): how much each simulated value counts in the prediction there
    prediction: float | None                    # the metamodel at the query point (None with the influences)
    truth: float                                # the true response there
    ranking: tuple[Entry, ...]                  # the candidates of the competition shown so far
    language: str
    refused: str = ""                           # why the metamodel (or its value at the query point) cannot be computed

    @property
    def n(self) -> int:
        return self.experiment.n

    @property
    def scene(self) -> tuple:
        """Everything the figure shows that does not depend on the query point."""
        return (self.candidate, self.experiment, len(self.ranking), self.language)

    @property
    def complete(self) -> bool:
        """Every candidate of the competition is shown."""
        return len(self.ranking) == CANDIDATES

class MetamodelLab(Lab):
    """Three metamodels of the designs of step 1: the weight of each design at a point, the surface beside the true response, and
    what the prediction is worth where nothing was simulated; the one on screen is handed to the optimization."""
    keys_text = "lab.mm.keys"                                   # what press does, for assistive technology (Lab.keyboard)

    def __init__(self, function: str = FIRST_FUNCTION, mode: str = TEACHER):
        self.function = function
        self.mode = mode
        self.controls = (
            Control("model", get_text("lab.mm.model"), MODELS, MODELS.index(FIRST_MODEL),
                    names=tuple(get_text(f"lab.mm.model.{m}") for m in MODELS), tip=get_text("lab.mm.model_tip"), alone=True,
                    icons={"polynomial": "polynomial", "mls": "mls", "kriging": "kriging"}),
            Control("order", get_text("lab.mm.order"), ORDERS, ORDERS.index(FIRST_ORDER),
                    names=tuple(get_text(f"lab.mm.order.{o}") for o in ORDERS), tip=get_text("lab.mm.order_tip"),
                    visible=lambda settings: settings["model"] in ("polynomial", "mls"),
                    icons={"linear": "linear", "pure_quadratic": "pure_quadratic", "quadratic": "quadratic"}),
            Control("radius", get_text("lab.mm.radius"), RADII, RADII.index(FIRST_RADIUS), show=lambda D: f"D = {D:.2f}",
                    tip=get_text("lab.mm.radius_tip"), visible=lambda settings: settings["model"] == "mls"),
            Control("theta", get_text("lab.mm.theta"), THETAS, THETAS.index(FIRST_THETA), show=lambda theta: f"θ = {theta:g}",
                    tip=get_text("lab.mm.theta_tip"), visible=lambda settings: settings["model"] == "kriging"),
        )
        self.actions = (
            page_link(),
            Action("tune", get_text("lab.mm.tune.polynomial"), get_text("lab.mm.tune_tip"), mark="best"),
            Action("contest", get_text("lab.mm.contest"), get_text("lab.mm.contest_tip"), motion="run",
                   playing_label=get_text("lab.mm.pause"), featured=True, mark="ranking"),
            Action("advance", get_text("lab.mm.advance"), get_text("lab.mm.advance_tip"), forward=True),
        )
        self.data = {"probe": FIRST_PROBE, "contest": 0}
        self.restore = True
        self.height = HEIGHT                   # the least height of the three steps (doe.HEIGHT)
        self.frame_ms = 700                    # a candidate of the competition is read before the next one
        self.view = VIEW                       # the 3D view as the reader left it (a view, not a setting; the window carries it)
        self.turned = None                     # the angle the 3D view had when this lab last drew it: another one, the mouse turned it
        self.layout_key = None                 # the axes on the figure are reused while their layout holds
        self.cards = {}                        # the cards of the right column (panels.draw_cards), drawn once per layout
        self.scene = None                      # what the axes hold, but the query point: drawn again only when it changes
        self.plan = None
        self.axes: dict = {}
        self.moving: list = []                 # the artists that follow the query point and the mouse
        self.written = None                    # the formula of the response, typeset once per layout

    def settings(self) -> dict:
        """The experiment first (the bench's first one, so the lab works alone), then the controls and the data: the
        teacher's on the winner of the competition, the student's on the simplest metamodel."""
        settings = {"experiment": first_experiment(self.function)} | super().settings()
        return crowned(settings) if self.mode != STUDENT else settings

    def opening(self, handed: Experiment | None = None) -> dict:
        """The first settings given an experiment: the controls and the data on it, the teacher's on the winner of ITS
        competition only (the first experiment's is never run for nothing), the student's on the simplest metamodel."""
        if handed is None:
            return self.settings()
        settings = {"experiment": handed} | Lab.settings(self)
        return crowned(settings) if self.mode != STUDENT else settings

    def height_for(self, width: int) -> int:
        """In a row or side by side, the lab's own height; stacked, the three blocks one under the other."""
        if width >= STACK_WIDTH:
            return self.height
        return round(arrangement(width, None, pair="space").room)

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """For the key BENCH, the formula of the bench's response (one line of mathtext; the figure typesets it); nothing
        for a control."""
        return formula(self.function) if key == BENCH else ((), "")

    # ------------------------------------------------------------------ a step of the study
    def output(self, state: MetamodelState) -> Surrogate | None:
        """The metamodel on screen, for the optimization; None while it cannot be computed with these designs."""
        return None if state.fit is None else Surrogate(state.experiment, state.candidate)

    def missing(self, state: MetamodelState) -> str:
        return "" if state.fit is not None else get_text("lab.mm.missing")

    def receive(self, settings: dict, handed: Experiment) -> dict:
        """The experiment on screen again: nothing changes (the reader's choice is kept). Another experiment from step 1:
        the competition closes and the query point stays; the teacher's lab puts the winner of the new competition on
        screen (the settings as they were when none can be computed), the student's keeps the model, the basis, D and
        theta the reader chose (the state says when they cannot be computed with the new designs)."""
        if handed == settings.get("experiment"):
            return settings
        received = settings | {"experiment": handed, "contest": 0}
        return crowned(received) if self.mode != STUDENT else received

    def received(self, state: MetamodelState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """What came from step 1, measured on its designs by measures.py: the sampling, N, the empty intervals of each
        axis, Pearson's correlation (from N = 3) and the smallest distance, in the unit square. The empty intervals carry
        the kind step 1's strip paints them with ("error" when an interval is empty, "ok" when none is); the other rows
        are plain."""
        n, unit = state.n, state.data.unit
        xs, ys = [u[0] for u in unit], [u[1] for u in unit]
        try:
            rho = f"{correlation(xs, ys):+.3f}".replace("-", "−") if n >= 3 else DASH
        except ZeroDivisionError:
            rho = DASH
        spread_ = f"{smallest_distance([list(u) for u in unit]):.3f}" if n >= 2 else DASH
        empty = (empty_intervals(xs, n), empty_intervals(ys, n))
        rows = ((get_text("lab.mm.received.sampling"), get_text(f"lab.mm.received.{state.experiment.method}"), "plain"),
                (get_text("lab.mm.received.designs"), get_text("lab.mm.received.designs_value", n=n), "plain"),
                (get_text("lab.mm.received.empty"), f"{empty[0]}  ·  {empty[1]}", "error" if sum(empty) else "ok"),
                (get_text("lab.mm.received.correlation"), rho, "plain"),
                (get_text("lab.mm.received.distance"), spread_, "plain"))
        return get_text("lab.mm.received"), rows

    def summary(self, state: MetamodelState) -> tuple[str, str]:
        """What the step is worth, for the cover's track and the pill's tooltip: the CoP of the metamodel on screen, a
        warning at or below 0 (no better than the mean of the simulated values) and when it cannot be computed (a
        dash)."""
        if state.check is None:
            return get_text("lab.mm.summary", cop=DASH), "warning"
        return get_text("lab.mm.summary", cop=quality(state.check.cop)), "warning" if poor(state.check.cop) else "plain"

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> MetamodelState:
        """The state of the settings; never raises: what cannot be computed is None, and `refused` says why."""
        experiment = settings["experiment"]
        candidate = candidate_of(settings)
        response = RESPONSES[experiment.function]
        data = sample(experiment)
        fitted = fit(candidate, experiment)
        probe = (float(settings["probe"][0]), float(settings["probe"][1]))
        point = tuple(scaled([list(probe)], list(response.bounds))[0])
        influence = prediction = None
        refused = ""
        if fitted is None:
            refused = cannot(candidate, "fit", experiment.n)
        else:
            try:
                influence = tuple(influence_of(candidate, probe, data.unit))
                prediction = fitted.model(probe)
            except REFUSED:
                influence = prediction = None
            if influence is not None and not (math.isfinite(prediction) and all(math.isfinite(a) for a in influence)):
                influence = prediction = None
            if influence is None:
                refused = cannot(candidate, "probe", experiment.n)
        check = validation(candidate, experiment) if fitted is not None else None
        shown = 0 if self.mode == STUDENT else min(settings["contest"], CANDIDATES)     # a student never sees the competition
        ranking = tuple(entry(k, experiment) for k in range(shown))
        return MetamodelState(settings["model"], experiment, response, candidate, data, fitted, check, probe, point, influence,
                              prediction, float(response.f(*point)), ranking, current_language(), refused)

    def adjust(self, settings: dict, key: str, old) -> dict:
        """A control changed: the competition closes. And the moving least squares come on screen with a radius that
        can be computed for these designs (its slider was not on show while another model was chosen)."""
        settings = settings | {"contest": 0}
        if key == "model" and settings["model"] == "mls":
            within = next((D for D in RADII[RADII.index(settings["radius"]):]
                           if fit(Candidate("mls", settings["order"], D), settings["experiment"]) is not None), None)
            if within is not None:
                settings = settings | {"radius": within}
        return settings

    def act(self, key: str, state: MetamodelState, settings: dict) -> dict:
        experiment = settings["experiment"]
        if key in COACHED and not self.offered(key, settings):          # a student's lab: nothing chosen for the reader
            return settings
        if key == "tune":
            if settings["model"] == "polynomial":                     # only the search of the model on screen
                name, best = "order", best_order(experiment)
            elif settings["model"] == "mls":
                name, best = "radius", best_radius(settings["order"], experiment)
            else:
                name, best = "theta", best_theta(experiment)
            return settings | {"contest": 0} | ({} if best is None else {name: best})
        return super().act(key, state, settings)

    def enabled(self, key: str, state: MetamodelState) -> bool:
        """The optimization can be reached only with a metamodel that can be computed."""
        return state.fit is not None if key == "advance" else True

    def offered(self, key: str, settings: dict) -> bool:
        """A student calibrates by hand, reading the CoP: neither the optimal prognosis nor the Best command."""
        return self.mode != STUDENT or key not in COACHED

    def rewind(self, key: str, state: MetamodelState, settings: dict) -> dict:
        """The competition already at its end begins again, from no candidate."""
        if key == "contest" and settings["contest"] >= CANDIDATES:
            return settings | {"contest": 0}
        return settings

    def advance(self, state: MetamodelState, settings: dict) -> dict | None:
        """One more candidate; with the last one, the candidate of largest CoP becomes the model on screen (none for a
        student, who has no competition)."""
        shown = settings["contest"]
        if shown >= CANDIDATES or self.mode == STUDENT:
            return None
        following = settings | {"contest": shown + 1}
        return crowned(following) if shown + 1 == CANDIDATES else following

    def cue(self, key: str, state: MetamodelState) -> str:
        """The competition played to its end: "complete"; a Best command: "apply"; nothing else sounds."""
        if key == "contest" and state.complete:
            return "complete"
        return "apply" if key == "tune" and self.mode != STUDENT else ""

    def link(self, key: str, state: MetamodelState) -> str:
        """"View code" asks the window for the reading of the model on screen (gui/lab_code.py)."""
        return state.model if key == LINK else ""

    def naming(self, key: str, state: MetamodelState) -> str:
        """The command Best says what it looks for: the basis, D or theta. The featured command's second line: while its
        frames play, the candidate shown; otherwise the winner and its CoP, a check mark before it when it is the model
        on screen, the word "winner" when the reader chose another (and what a competition that judges none says)."""
        if key == "tune":
            return get_text(f"lab.mm.tune.{state.model}")
        if key != "contest" or self.mode == STUDENT:
            return ""
        if 0 < len(state.ranking) < CANDIDATES:
            return get_text("lab.mm.contest.playing", shown=len(state.ranking), total=CANDIDATES)
        best = champion(state.experiment)
        if best is None:
            return get_text("lab.mm.contest.none")
        cop = f"{MARK} {quality(best.cop)}" if poor(best.cop) else quality(best.cop)
        place = "on_screen" if best.candidate == state.candidate else "winner"
        return get_text(f"lab.mm.contest.{place}", name=named(best.candidate), cop=cop)

    # ------------------------------------------------------------------ what to read
    def lead(self, state: MetamodelState) -> str:
        """One short sentence, the figure's accessible description: the model on screen, or the competition."""
        if state.complete and (first := winner(state.ranking)) is not None:
            item = state.ranking[first]
            return get_text("lab.mm.lead.winner", total=CANDIDATES, name=named(item.candidate), cop=quality(item.cop))
        if state.complete:
            return get_text("lab.mm.lead.none", total=CANDIDATES)
        if state.ranking:
            item = state.ranking[-1]
            return get_text("lab.mm.lead.contest", shown=len(state.ranking), total=CANDIDATES, name=named(item.candidate),
                            cop=DASH if item.cop is None else quality(item.cop))
        if state.fit is None:                                         # why: on the figure, in the 3D view's place
            return get_text("lab.mm.lead.cannot")
        return get_text(f"lab.mm.lead.{state.model}")

    def metrics(self, state: MetamodelState) -> list[Metric]:
        """The CoP first and emphasised (strong: the one the step is judged by), then the CoD and the coefficient
        against the true response, each with a tip of one sentence that defines it (why a value cannot be computed is
        said on the figure). A student calibrates by the CoP, never by the answer: the coefficient against the true
        response, which a study never has, is not shown to him until the bench is complete (won)."""
        fitted = state.fit is not None
        measures = [Metric(get_text("lab.mm.m.cop"), cop_written(state), kind="warning" if cop_warned(state) else "plain",
                           detail=get_text("lab.mm.m.cop_detail", folds=FOLDS), tip=get_text("lab.mm.m.cop_tip"),
                           strong=True),
                    Metric(get_text("lab.mm.m.cod"), quality(state.fit.cod) if fitted else DASH, kind="plain" if fitted else "warning",
                           detail=get_text("lab.mm.m.cod_detail"), tip=get_text("lab.mm.m.cod_tip"))]
        if not self.truth_shown():
            return measures
        return measures + [Metric(get_text("lab.mm.m.true"), quality(state.fit.against) if fitted else DASH,
                                  kind="plain" if fitted else "warning", detail=get_text("lab.mm.m.true_detail", grid=GRID),
                                  tip=get_text("lab.mm.m.true_tip", grid=GRID))]

    def truth_shown(self) -> bool:
        """Whether the coefficient against the true response is shown (the strip, the hero): to a teacher, and to a
        student once the bench is complete."""
        return self.mode != STUDENT or self.won

    def references(self, state: MetamodelState) -> list[tuple[str, float | None, str]]:
        """What the hero sets beside the CoP, smaller and muted, each with its name, its value (None: not computed) and
        the ink of its gauge: the CoD at the designs, and the coefficient against the true response where it is shown."""
        fitted = state.fit is not None
        rows = [(get_text("lab.mm.hero.cod"), state.fit.cod if fitted else None, REFERENCE_INK)]
        if self.truth_shown():
            rows.append((get_text("lab.mm.hero.true"), state.fit.against if fitted else None, REFERENCE_INK))
        return rows

    # ------------------------------------------------------------------ the mouse and the keys
    def hit(self, figure, state: MetamodelState, event):
        """The query point ("probe") or the design (its index) under the mouse, in the design space or in the check."""
        if event is None:
            return None
        plane, check = self.axes.get("plane"), self.axes.get("check")
        if plane is not None and event.inaxes is plane:
            if nearest(plane, [state.point], event, radius=PROBE_RADIUS) is not None:
                return "probe"
            return nearest(plane, state.data.points, event)
        if check is not None and event.inaxes is check and state.check is not None:
            return nearest(check, checked_points(state), event)
        return None

    def grabbable(self, hovered) -> bool:
        return hovered == "probe"

    def grab(self, figure, state: MetamodelState, event):
        """A press anywhere in the design space takes the query point there; one on the competition closes it."""
        if event is None or event.inaxes is None:
            return None
        if event.inaxes is self.axes.get("plane"):
            return "probe"
        if event.inaxes is self.axes.get("ranking") and state.ranking:
            return "ranking"
        return None

    def drag(self, figure, state: MetamodelState, handle, event, settings: dict) -> dict | None:
        if handle == "ranking":
            return settings | {"contest": 0} if settings["contest"] else None
        plane = self.axes.get("plane")
        if handle != "probe" or plane is None or not plane.get_visible():
            return None
        x1, x2 = plane.transData.inverted().transform((event.x, event.y))      # also from over another panel: kept on the border
        (a1, b1), (a2, b2) = state.response.bounds
        return moved(settings, (x1 - a1) / (b1 - a1), (x2 - a2) / (b2 - a2))

    def press(self, key: str, state: MetamodelState, settings: dict) -> dict | None:
        """The arrow keys move the query point."""
        du1, du2 = {"left": (-STEP, 0.0), "right": (STEP, 0.0), "up": (0.0, STEP), "down": (0.0, -STEP)}.get(key, (0.0, 0.0))
        return moved(settings, settings["probe"][0] + du1, settings["probe"][1] + du2)

    # ------------------------------------------------------------------ the figure
    def boxes(self, figure) -> dict:
        """The panels' boxes and the places of their titles, in figure fractions, from the plan the three steps share
        (panels.arrangement with pair="space"), in layout pixels; on the third card, the hero and the check where
        composed puts them."""
        width, height = size(figure)
        plan = arrangement(width, height, pair="space")

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)     # a box is never empty
        boxes = {"plane": frac(*plan.plane), "space": frac(*plan.space), "ranking": frac(*plan.ranking)}
        third = composed(plan)
        if third is not None:
            boxes["check"], boxes["hero"] = frac(*third.check), frac(*third.hero)
        boxes["heads"] = places(plan, width, height)
        return boxes

    def prepare(self, figure, state: MetamodelState) -> dict:
        """The axes of the figure: made again when the layout changes, reused otherwise (the panels keep what they
        hold). The 3D view turned with the mouse since this lab drew it gives its angle to `view`."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height), state.language)     # the hero's width is measured in its language
        space = self.axes.get("space")
        if space is not None and space.figure is figure and self.turned is not None and (space.elev, space.azim) != self.turned:
            self.view = (space.elev, space.azim)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = arrangement(width, height, pair="space")
            self.cards = draw_cards(figure, self.plan)                   # the 3D view's and the third panel's, once per layout
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "check", "hero", "ranking") if name in boxes}
            self.ranking_box = boxes["ranking"]                       # the competition's box, before it rises (draw_ranking)
            self.axes["space"] = figure.add_axes(boxes["space"], projection="3d")
            self.axes["plane"].set_zorder(1)                          # its last x1 tick label overhangs the 3D box, which
                                                                      # begins 2 px later: drawn above it, the label is whole
            self.heads = boxes["heads"]
            self.written = typeset(figure, self.heads, FORMULAS[self.function])      # once per layout: it never changes here
            self.layout_key = key
            self.scene = None
            self.moving = []
        return self.axes

    def draw(self, figure, state: MetamodelState, hovered) -> None:
        axes = self.prepare(figure, state)
        scene = (state.scene, self.truth_shown())                     # a bench completed shows the student the truth
        if self.scene != scene:                                       # anything but the query point: the whole figure
            self.draw_scene(figure, axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        if axes["plane"].get_visible():
            self.draw_voices(axes["plane"], state, hovered)
        self.draw_query(axes["space"], state, hovered)
        if "check" in axes and axes["check"].get_visible():
            self.draw_found(axes["check"], state, hovered)
        space = axes["space"]
        if (space.elev, space.azim) != tuple(self.view):              # the angle the window carried from another step
            space.view_init(*self.view)
        self.turned = (space.elev, space.azim)

    def draw_scene(self, figure, axes: dict, state: MetamodelState) -> None:
        """Everything that stays while the query point moves: the designs, the surfaces, the check or the competition,
        the titles and the legends."""
        for ax in axes.values():
            ax.clear()
        for text in list(figure.texts):
            if text is not self.written:                              # the formula stays: drawn once per layout
                text.remove()
        for legend in list(figure.legends):
            legend.remove()
        self.moving = []
        contest = bool(state.ranking)
        alone = (third := composed(self.plan)) is not None and third.alone          # a phone's narrow card: the hero alone
        shown = {"plane": not (contest and "check" not in axes), "space": True, "check": not contest and not alone,
                 "hero": not contest, "ranking": contest}
        for name, ax in axes.items():
            ax.set_visible(shown[name])
        if shown["plane"]:
            self.draw_plane(axes["plane"], state)
            handles = [dot(POINT, get_text("lab.mm.legend.positive"), soft=True),
                       dot(NEGATIVE, get_text("lab.mm.legend.negative"), hollow=True),
                       dot(QUERY, get_text("lab.mm.legend.probe"), marker="D", size=6.5)]
            if state.fit is not None:
                handles.append(Line2D([], [], color=LINES["colors"], linewidth=1.0, alpha=0.8, label=get_text("lab.mm.legend.levels")))
            head(figure, self.heads, self.axes, "plane", get_text("lab.mm.plane_title"), handles)
        self.draw_space(axes["space"], state)
        head(figure, self.heads, self.axes, "space", get_text("lab.mm.space_title"), [
            Patch(facecolor=palette.SURFACE_RAMP[3], label=get_text("lab.mm.legend.surface")),
            wire_handle(get_text("lab.mm.legend.truth")),
            dot(POINT, get_text("lab.mm.legend.designs"))])
        if contest:
            rows = head(figure, self.heads, self.axes, "ranking", get_text("lab.mm.ranking_title"), [
                Patch(facecolor=POINT, label=get_text("lab.mm.legend.cop")),
                Patch(facecolor=WINNER, label=get_text("lab.mm.legend.largest"))])
            self.draw_ranking(axes["ranking"], state, rows)
        elif "check" in axes:
            if not alone:
                self.draw_check(axes["check"], state)
            self.draw_hero(axes["hero"], state)
            head(figure, self.heads, self.axes, "check", get_text("lab.mm.check_title"), [])      # its title alone: the
            third = composed(self.plan)                                                          # check's legend over it
            if third is not None and third.legend is not None and state.check is not None and not alone:
                x, top, room = third.legend
                width, height = size(figure)
                legend_at(figure, x / width, top / height, room, check_handles(), 4 if self.plan.head > HEAD else 2)

    def draw_plane(self, ax, state: MetamodelState) -> None:
        """The design space with every design where step 1 placed it and simulated it, over the faint level lines of
        the metamodel y^ (its values on the grid of the surfaces, the levels and the look step 3 draws them with, where
        it searches on them); none when the metamodel cannot be computed. They belong to the scene: the query point
        moving leaves them."""
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        (a1, b1), (a2, b2) = state.response.bounds
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        plane_ticks(ax)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        xs, ys = zip(*state.data.points)
        ax.scatter(xs, ys, s=min(marker_size(state.n), 16.0), c=POINT, edgecolors=palette.CARD, linewidths=0.7, zorder=6)
        if state.fit is not None and (levels := level_values(state.fit.surface)):     # under everything (zorder), drawn
            true = truth(state.response.key)                                         # after the designs: the first
            ax.contour(true.x1, true.x2, state.fit.surface, levels=levels, **LINES)    # collection stays theirs
        ax.set_xlabel(X1, **NAME, labelpad=2)
        ax.set_ylabel(X2, **NAME, labelpad=9, rotation=0, va="center")

    def draw_voices(self, ax, state: MetamodelState, hovered) -> None:
        """The weight of each design in y^ at the query point: on each design a disc of area |a_i(u)|, filled where a_i is positive, hollow
        where it is negative; the query point and, around it, the distance where a weight or a correlation is 1/e. When
        the metamodel cannot be computed there, the query point alone (and, the metamodel computed, why: on the panel)."""
        (a1, b1), (a2, b2) = state.response.bounds
        x, y = state.point
        if state.influence is not None:
            placed = sorted(zip(state.influence, state.data.points), key=lambda pair: -abs(pair[0]))     # the small ones on top
            for sign, face, edge, width in ((1, tint(POINT, 0.42), POINT, 0.9), (-1, "none", NEGATIVE, 1.5)):
                voices = [(abs(a), point) for a, point in placed if a * sign > 0]
                if voices:
                    areas, points = zip(*voices)
                    xs, ys = zip(*points)
                    self.moving.append(ax.scatter(xs, ys, s=[AREA * area for area in areas], facecolors=face, edgecolors=edge,
                                                  linewidths=width, zorder=4 if sign > 0 else 5))
            reach = reach_of(state.candidate)
            if reach is not None:
                radius, name = reach
                circle = Ellipse((x, y), 2 * radius * (b1 - a1), 2 * radius * (b2 - a2), fill=False, edgecolor=QUERY, linewidth=1.1,
                                 linestyle=(0, (4, 3)), alpha=0.9, zorder=7)
                self.moving.append(ax.add_patch(circle))
                for angle in (45, 135, 315, 225):                     # its name, on the first place of its rim inside the panel
                    u1 = state.probe[0] + radius * math.cos(math.radians(angle))
                    u2 = state.probe[1] + radius * math.sin(math.radians(angle))
                    if 0.06 < u1 < 0.94 and 0.06 < u2 < 0.94:
                        right, above = math.cos(math.radians(angle)) > 0, math.sin(math.radians(angle)) > 0
                        place = (a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2)
                        self.moving.append(ax.annotate(name, place, xytext=(4 if right else -4, 3 if above else -3),
                                                       textcoords="offset points", ha="left" if right else "right",
                                                       va="bottom" if above else "top", color=QUERY, **TAG, zorder=9))
                        break
        elif state.fit is not None:                                   # the metamodel exists, not at this point
            columns = max(int(ax.get_position().width * size(ax.figure)[0] / 6.6), 12)
            self.moving.append(ax.text(0.5, 0.04, fill(state.refused, columns), transform=ax.transAxes, ha="center", va="bottom",
                                       color=WARNING, **TAG, zorder=10, bbox=BOXED))
        if isinstance(hovered, int) and hovered < state.n:
            hx, hy = state.data.points[hovered]
            self.moving.append(ax.scatter([hx], [hy], s=150, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4, zorder=8))
            if state.influence is not None:
                right, above = state.data.unit[hovered][0] < 0.62, state.data.unit[hovered][1] < 0.86
                label = f"a{subscript(hovered + 1)} = {state.influence[hovered]:+.3f}".replace("-", "−")
                self.moving.append(ax.annotate(label, (hx, hy), xytext=(9 if right else -9, 8 if above else -8),
                                               textcoords="offset points", ha="left" if right else "right",
                                               va="bottom" if above else "top", color=palette.WHITE, **TAG, zorder=10,
                                               bbox=BOXED))
        self.moving.append(ax.scatter([x], [y], s=95 if hovered == "probe" else 70, marker="D", c=QUERY, edgecolors=palette.CARD,
                                      linewidths=1.0, zorder=9))

    def draw_space(self, ax, state: MetamodelState) -> None:
        """The metamodel as a surface, cut at the vertical window (said at the top of the card, under its legend:
        panels.cut_note), the true response as a wire over it, and the designs at their simulated values; without
        a metamodel, the wire, the designs and one clause on the card's tone saying there is no surface (why: the CoP's
        card)."""
        ax.set_facecolor("none")                                       # its card shows
        ax.computed_zorder = False                                    # the wire and the designs stay in front of the surface
        true = truth(state.response.key)
        low, high = true.low, true.high
        if state.fit is not None:
            polygons, heights, cut = facets(true.x1, true.x2, state.fit.surface, low, high)
            if polygons:
                colors = RAMP(np.clip((np.array(heights) - float(true.y.min())) / float(true.y.max() - true.y.min()), 0.0, 1.0))
                ax.add_collection3d(Poly3DCollection(polygons, facecolors=colors, edgecolors="none", linewidths=0, antialiaseds=False,
                                                     alpha=0.9, zorder=1))
            if cut:
                cut_note(ax, self.heads, "space", f"{MARK} " + get_text("lab.mm.cut", low=short(float(state.fit.surface.min()), 4),
                                                                         high=short(float(state.fit.surface.max()), 4)),
                         WARNING)
        else:                                                         # one clause, on the card's tone: why is the CoP card's
            width = size(ax.figure)[0]                                # in the room of its card, centred on it
            left, _, wide, _ = self.plan.cards["space"]
            room = min(wide - 2 * RANK_INSET, 0.8 * ax.get_position().width * width) - 12.0
            said = f"{MARK}  " + wrapped(get_text("lab.mm.space.cannot"), NOTE["fontsize"], room - 20.0)    # (no CoP card, the pair,
            if "check" not in self.axes or composed(self.plan).alone:     # a phone's card: why under the clause)
                said += "\n" + wrapped(state.refused[:1].upper() + state.refused[1:] + ".", NOTE["fontsize"], room)
            box = ax.get_position()
            ax.text2D(((left + wide / 2) / width - box.x0) / box.width, 0.62, said, transform=ax.transAxes, ha="center", va="center",
                      color=WARNING, **NOTE, zorder=10, bbox=BOXED | {"facecolor": CARD_TONE, "alpha": 1.0, "boxstyle": "round,pad=0.5"})
        true_wire(ax, true.x1, true.x2, true.y)
        (a1, b1), (a2, b2) = state.response.bounds
        ax.plot([a1, b1, b1, a1, a1], [a2, a2, b2, b2, a2], [low] * 5, color=palette.DARK_GREY, linewidth=0.8, zorder=1)
        xs, ys = zip(*state.data.points)
        ax.scatter(xs, ys, state.data.values, s=marker_size(state.n) * 0.7, c=POINT, edgecolors=palette.CARD, linewidths=0.7,
                   depthshade=False, zorder=4)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        ax.set_zlim(low, high)
        style_space(ax)
        space_ticks(ax)
        ax.set_box_aspect((1.0, 1.0, 0.72), zoom=SPACE_ZOOM)
        ax.view_init(*self.view)

    def draw_query(self, ax, state: MetamodelState, hovered) -> None:
        """At the query point: a vertical line, the prediction on it (a triangle on the edge of the window when it is
        beyond) and the true value (a ring); and the design under the mouse."""
        true = truth(state.response.key)
        low, high = true.low, true.high
        x, y = state.point
        self.moving += ax.plot([x, x], [y, y], [low, high], color=QUERY, linewidth=0.9, linestyle=(0, (3, 2)), alpha=0.8, zorder=5)
        self.moving.append(ax.scatter([x], [y], [state.truth], s=74, facecolors="none", edgecolors=TRUE, linewidths=1.6,
                                      depthshade=False, zorder=6))
        if state.prediction is None:
            values = ((state.truth, "f", TRUE, True),)
        else:
            inside = low <= state.prediction <= high
            marker = "o" if inside else ("^" if state.prediction > high else "v")
            self.moving.append(ax.scatter([x], [y], [min(max(state.prediction, low), high)], s=46, marker=marker, c=QUERY,
                                          edgecolors=palette.CARD, linewidths=0.8, depthshade=False, zorder=7))
            above = state.prediction >= state.truth                   # the two values, each on its side of the other
            values = ((state.prediction, "ŷ", QUERY, above), (state.truth, "f", TRUE, not above))
        for value, name, color, over in values:
            self.moving.append(ax.text(x, y, min(max(value, low), high), f"  {name} = {short(value, 4)}", color=color, **TAG,
                                       ha="left", va="bottom" if over else "top", zorder=5.8, bbox=TAG_BOX))     # under the
                                                                                # marks (6, 7), over the wire and the line
        if isinstance(hovered, int) and hovered < state.n:
            (hx, hy), value = state.data.points[hovered], state.data.values[hovered]
            self.moving.append(ax.scatter([hx], [hy], [value], s=marker_size(state.n) * 2.4, facecolors="none", edgecolors=palette.WHITE,
                                          linewidths=1.4, depthshade=False, zorder=7))
            self.moving.append(ax.text(hx, hy, value, f"   y{subscript(hovered + 1)} = {short(value, 4)}", color=palette.WHITE,
                                       **TAG, ha="left", va="bottom", zorder=8, path_effects=HALO))

    def draw_check(self, ax, state: MetamodelState) -> None:
        """Every design predicted by a metamodel fitted without it, against its simulated value: on the diagonal the two
        agree. A prediction beyond the window is a triangle on its edge. The CoP it gives is the hero's, beside it. What
        cannot be computed is said on the panel, across the square and its tick labels' room, with nothing to plot."""
        style_axes(ax)
        ax.set_facecolor(CARD_TONE)
        low, high = spread(state.data.values)
        ax.set_xlim(low, high)
        ax.set_ylim(low, high)
        side = ax.get_position().width * size(ax.figure)[0]
        third = composed(self.plan)
        named = third is None or third.names                          # a square too small for its names: its tick labels
        gutter, under = (CHECK_LEFT, BELOW) if named else (CHECK_TIGHT, BELOW_TIGHT)     # alone, a tighter gutter
        if state.check is None:
            if state.fit is None:                                     # why, once: the 3D view says only that there is no
                why = state.refused[:1].upper() + state.refused[1:] + "."     # surface, the foot that it cannot hand
            else:
                why = get_text("lab.mm.check.cannot." + ("mls" if state.model == "mls" else "fit"))
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            room = side + gutter - 12.0                              # the square and the room of its tick labels and names
            ax.text(0.5 - gutter / 2 / side, 0.5 - (under - 6.0) / 2 / side, wrapped(why, NOTE["fontsize"], room),
                    transform=ax.transAxes, ha="center", va="center", color=WARNING, **NOTE, zorder=5, linespacing=1.15)
            return
        bins = 5 if side >= CHECK_FEW else 3 if side >= CHECK_FEW / 2 else 2
        ax.xaxis.set_major_locator(MaxNLocator(bins))
        ax.yaxis.set_major_locator(MaxNLocator(bins))
        if named:                                                     # its full names, or its short ones (composed)
            x_name, y_name = check_names("full" if third is None else third.names)
            ax.set_xlabel(x_name, **LABEL, labelpad=3)
            ax.set_ylabel(y_name, **LABEL, labelpad=4)
        ax.plot([low, high], [low, high], color=TRUE, linewidth=1.1, alpha=0.8, zorder=2)
        area = marker_size(state.n) * 0.8
        for marker, keep in (("o", lambda p: low <= p <= high), ("^", lambda p: p > high), ("v", lambda p: p < low)):
            points = [(value, min(max(p, low), high)) for value, p in zip(state.data.values, state.check.predictions) if keep(p)]
            if points:
                xs, ys = zip(*points)
                ax.scatter(xs, ys, s=area, marker=marker, c=POINT, edgecolors=palette.CARD, linewidths=0.7, zorder=4, clip_on=marker == "o")

    def draw_hero(self, ax, state: MetamodelState) -> None:
        """The CoP, the hero of the third card: its number large (the warning's colour and mark at or below 0, poor; a
        dash while it cannot be computed), its definition typeset small as prognosis.py computes it, and a gauge from 0
        to 1 filled to it (empty below 0: the number says how far); under it, smaller and muted, the CoD at the designs
        and, where it is shown, the coefficient against the true response, each on a gauge of the same scale (one ink,
        REFERENCE_INK), every gauge with a tick at 0 and at 1, and the scale's ends written. In layout pixels from the
        hero's lower left corner (hero_lines), the lines hung from the top of its box (the row a legend starts on, under
        the card's title: composed); drawn once per scene."""
        ax.set_axis_off()
        ax.set_xticks([])                                             # no tick labels left in matplotlib's own face
        ax.set_yticks([])
        wide, tall =(ax.get_position().width * size(ax.figure)[0], ax.get_position().height * size(ax.figure)[1])
        ax.set_xlim(0.0, wide)
        ax.set_ylim(0.0, tall)
        rows = self.references(state)
        lines = hero_lines(HERO["fontsize"], len(rows))
        top = tall                                                    # hung from the top (one reference row, or two)
        written = cop_written(state)
        points = HERO["fontsize"]
        while points > HERO_LEAST and text_width(written, points, HERO["fontweight"]) > wide:
            points -= 1
        ink = WARNING if state.check is None or cop_warned(state) else palette.WHITE
        ax.text(0.0, top - lines["number"], written, ha="left", va="baseline", color=ink, **(HERO | {"fontsize": points}))
        ax.text(0.0, top - lines["formula"], DEFINED, ha="left", va="baseline", color=palette.PROSE, **DEFINITION)
        cop = None if state.check is None else state.check.cop
        gauge(ax, 0.0, top - lines["gauge"] - GAUGE_HIGH, wide, GAUGE_HIGH, cop, COP_INK, ends=True)
        for (name, value, color), (base, under) in zip(rows, lines["rows"]):
            number = DASH if value is None else quality(value)
            room = wide - number_width(number, READING["fontsize"]) - ROW_GAP     # a number far below 0 is wider than WIDEST
            ax.text(0.0, top - base, clipped(name, LABEL["fontsize"], room), ha="left", va="baseline", **LABEL)
            ax.text(wide, top - base, number, ha="right", va="baseline", color=WARNING if value is None else palette.PROSE, **READING)
            gauge(ax, 0.0, top - under - ROW_HIGH, wide, ROW_HIGH, value, color, ends=True)
        ax.text(0.0, top - lines["scale"], "0", ha="left", va="baseline", **LABEL)
        ax.text(wide, top - lines["scale"], "1", ha="right", va="baseline", **LABEL)

    def draw_found(self, ax, state: MetamodelState, hovered) -> None:
        """The design under the mouse, in the check."""
        if state.check is None or not isinstance(hovered, int) or hovered >= state.n:
            return
        x, y = checked_points(state)[hovered]
        self.moving.append(ax.scatter([x], [y], s=marker_size(state.n) * 2.6, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4,
                                      zorder=6, clip_on=False))

    def draw_ranking(self, ax, state: MetamodelState, rows: int = 2) -> None:
        """The competition: a row per candidate, its name and, once shown, a bar as long as its CoP between 0 and 1 (a
        negative CoP has no bar: its number is written). Every candidate shown, the largest CoP is marked. Its legend on
        one row (`rows`, head's), the competition rises into the room of the second: air between a bar and the next name
        in the small window."""
        left, bottom, wide, tall = self.ranking_box
        rise = LEGEND_ROW / 2 / size(ax.figure)[1] if rows <= 1 else 0.0
        ax.set_position((left, bottom, wide, tall + rise))
        ax.set_facecolor(CARD_TONE if "check" in self.axes else palette.CARD)     # on the card, or on the page at the plane's place
        for side in ("left", "top", "right"):
            ax.spines[side].set_visible(False)
        ax.spines["bottom"].set_color(palette.DARK_GREY)
        ax.set_yticks([])
        ax.set_xticks([0.0, 0.25, 0.5, 0.75, 1.0], ["0", "", "0.5", "", "1"])
        ticks(ax)
        ax.tick_params(length=3)
        ax.set_xlabel(get_text("lab.mm.m.cop"), **LABEL, labelpad=3)
        box = ax.get_position()
        height = box.height * size(ax.figure)[1]
        hint = "check" not in self.axes                               # the competition stands where the design space was
        written, small, foot = get_text("lab.mm.ranking.back"), 8.5, 18.0 if hint else 0.0
        if hint:                                                      # in the room the panel has: smaller, then on two lines
            room = 0.976 * box.width * size(ax.figure)[0]
            while small > 7.5 and text_width(written, small) > room:
                small -= 0.5
            if text_width(written, small) > room:
                written, foot = fill(written, max(int(len(written) * room / text_width(written, small)), 12)), 30.0
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, height)
        row = (height - foot) / CANDIDATES
        thick = min(10.0, 0.2 * row)
        first = winner(state.ranking) if state.complete else None
        for k in range(CANDIDATES):
            top = height - k * row
            item = state.ranking[k] if k < len(state.ranking) else None
            bar = top - 0.70 * row - thick / 2
            if item is None:                                          # still to come: its name, without the value it will take
                ax.text(0.012, top - 0.28 * row, named(entry_to_come(k)), ha="left", va="center", **TAG, color=palette.DARK_GREY)
                continue
            leading = k == first
            if leading:
                ax.add_patch(Rectangle((0.0, top - row + 1.0), 1.0, row - 2.0, facecolor=palette.PILL, edgecolor="none", zorder=1))
            ink, weight = (palette.WHITE, "semibold") if leading else (palette.SLATE, "normal")
            said = named(item.candidate)                              # a narrow card: the name without its D or theta
            beside = 0.976 * box.width * size(ax.figure)[0] - number_width(WIDEST, READING["fontsize"]) - 8.0     # where it
            if text_width(said, TAG["fontsize"], weight) > beside and " · " in said and item.candidate.value is not None:  # would
                said = said.rsplit(" · ", 1)[0]                                                                     # meet its CoP
            small = TAG["fontsize"]                                   # then a step smaller (no parameter to leave out)
            while small > RANKING_LEAST and text_width(said, small, weight) > beside:
                small -= 0.5
            ax.text(0.012, top - 0.28 * row, said, ha="left", va="center", **(TAG | {"fontsize": small}), color=ink, fontweight=weight,
                    zorder=3)
            gauge(ax, 0.0, bar, 1.0, thick, item.cop, WINNER if leading else POINT, zorder=2)     # the hero's scale and track
            if item.cop is None:
                ax.text(0.988, top - 0.28 * row, get_text("lab.mm.ranking.cannot"), ha="right", va="center", **TAG,
                        color=MUTED_INK, zorder=3)
                continue
            ax.text(0.988, top - 0.28 * row, quality(item.cop), ha="right", va="center", **READING, color=ink, fontweight=weight,
                    zorder=3)
        if hint:
            ax.text(0.988, foot / 2, written, ha="right", va="center", color=MUTED_INK, zorder=3, linespacing=1.1,
                    **(SMALL | {"fontsize": small}))

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def crowned(settings: dict) -> dict:
    """The settings with the winner of the competition on their experiment chosen (its model, basis, D or theta); as
    they were when no candidate can be computed."""
    best = champion(settings["experiment"])
    return settings if best is None else settings | chosen(best.candidate)

@dataclass(frozen=True)
class Composition:
    """The third card of the step, in layout pixels (left, bottom, width, height): the hero's column and the check's
    square (its axes; its tick labels in its gutter at its left and under it, with the names of its axes as long as its
    side holds: `names`, "full", "short" or None), side by side or the hero over the check; the check's legend over the
    check (`legend`: its left, on the check's left spine, its top, and its room, in layout pixels; None with no check);
    `alone`, the hero by itself, where the check would be smaller than CHECK_LEAST (a phone's narrow card: the strip and
    the hero say the CoP, a check that small says nothing)."""
    hero: tuple[float, float, float, float]
    check: tuple[float, float, float, float]
    beside: bool
    alone: bool = False
    legend: tuple[float, float, float] | None = None
    names: str | None = "full"

def check_handles() -> list:
    """The check's legend: a design predicted without it, and the diagonal of a perfect prediction."""
    return [dot(POINT, get_text("lab.mm.legend.design"), short=get_text("lab.mm.legend.design_short")),
            Line2D([], [], color=TRUE, linewidth=1.1, label=get_text("lab.mm.legend.diagonal"))]

def composed(plan) -> Composition | None:
    """The third card under its title shared by the hero and the check, on lines they share: the hero hung from the
    row where a legend starts under the card's title (the number's capitals on it), left-aligned with the title; the
    check's legend on the same row, its left on the check's left spine; the check a square hung CHECK_GAP under its
    legend, as large as the room under it allows (its foot at the card's foot where the height binds), beside the hero
    (the corner and the stack) or under it (a row), whichever leaves the larger square. Its gutter and its foot keep the
    room of its axis names where it is large enough for them, their full names or their short ones (CHECK_LEFT and
    BELOW; CHECK_TIGHT and BELOW_TIGHT for its tick labels alone, where even the short ones do not fit along its side).
    The hero block stays whole at the top. None where the plan has no third card (the pair)."""
    if plan.check is None or "check" not in plan.cards:
        return None
    card, foot, wide, tall = plan.cards["check"]
    left, right = card + RANK_INSET, card + wide - RANK_INSET
    narrow = plan.head > HEAD                                         # a phone's head: two lines of title, four rows of legend
    most = 4 if narrow else 2
    row = foot + tall - TITLE_DROP - LEGEND_DROP                      # the legend's row under a title on one line
    if narrow:                                                        # (on two where it breaks)
        said, _ = titled(get_text("lab.mm.check_title"), wide - RANK_INSET - HEAD_GAP, 2)
        row -= (len(said) - 1) * TITLE_LINE
    need, high = hero_wide(), hero_lines(HERO["fontsize"])["tall"]
    pitch = LEGEND_PITCH * LEGEND_SIZE / 72 * LAYOUT_DPI
    edge = card + wide - HEAD_GAP                                     # a legend ends HEAD_GAP before the card's edge

    def legend(spine: float, gutter: float) -> tuple[float, float, int]:
        """The check's legend: its left on the check's spine, where its rows hold in the room to the card's edge; else
        moved left over the check's gutter, just as far as its widest row needs. Its left, its room, its rows."""
        for left_, flush in ((spine, False), (spine - gutter, True)):
            rows, small = legend_rows(check_handles(), edge - left_, most)
            rows = [one for one in rows if one]
            widest = max(legend_width([handle.get_label() for handle in one], small) for one in rows)
            if widest <= edge - left_ or flush:
                x = max(min(spine, edge - widest), spine - gutter)
                return x, edge - x, len(rows)
        return spine, edge - spine, most

    def square(hang_from: float, across: float, beside: bool) -> tuple[float, str | None, int]:
        """The side of the check under its legend hung from `hang_from`, `across` layout pixels wide with its gutter
        (its spine at the card's right beside the hero, centred under it), the names of its axes ("full", "short" or
        None), its legend's rows."""
        rows = most
        for _ in range(3):
            top = hang_from - rows * pitch - CHECK_GAP
            full, tight = (max(min(top - foot - CARD_FOOT - under, across - gutter), 1.0)
                           for gutter, under in ((CHECK_LEFT, BELOW), (CHECK_TIGHT, BELOW_TIGHT)))
            names = next((kind for kind in ("full", "short") if full >= names_least(kind)), None)
            side, gutter = (full, CHECK_LEFT) if names else (tight, CHECK_TIGHT)
            spine = right - side if beside else left + (right - left - gutter - side) / 2 + gutter
            drawn = legend(spine, gutter)[2]
            if drawn >= rows:
                break
            rows = max(drawn, 1)
        return side, names, rows
    by, by_names, by_rows = square(row, right - left - need - HERO_GAP, True)
    under, under_names, under_rows = square(row - high - HERO_GAP, right - left, False)
    if by >= under:
        side, names, rows = by, by_names, by_rows
        spine = right - side
        top = row - rows * pitch - CHECK_GAP
        hero = min(spine - (CHECK_LEFT if names else CHECK_TIGHT) - HERO_GAP - left, HERO_MOST)
        x, room, _ = legend(spine, CHECK_LEFT if names else CHECK_TIGHT)
        return Composition((left, row - high, hero, high), (spine, top - side, side, side), True, legend=(x, row, room),
                           names=names)
    side, names, rows = under, under_names, under_rows
    hero = min(right - left, HERO_MOST)
    hero_box = (left, row - high, hero, high)
    if side < CHECK_LEAST and plan.head > HEAD:                       # a phone's card with no room for a check that reads:
        return Composition(hero_box, (left, foot, 1.0, 1.0), False, True)     # the hero alone
    gutter = CHECK_LEFT if names else CHECK_TIGHT
    spine = left + (right - left - gutter - side) / 2 + gutter        # the check centred in the card under the hero
    top = row - high - HERO_GAP - rows * pitch - CHECK_GAP
    x, room, _ = legend(spine, gutter)
    return Composition(hero_box, (spine, top - side, side, side), False, legend=(x, row - high - HERO_GAP, room), names=names)

def check_names(kind: str) -> tuple[str, str]:
    """The names of the check's axes, x then y: their full names ("full") or their short ones ("short")."""
    if kind == "full":
        return get_text("lab.mm.check.x"), get_text("lab.mm.check.y")
    return get_text("lab.mm.check.x_short"), get_text("lab.mm.check.y_short")

def names_least(kind: str = "full") -> float:
    """The least side of a check that names its axes with these names (in the language on screen): the longer, along
    its side, with room to spare."""
    return max(text_width(name, LABEL["fontsize"]) for name in check_names(kind)) + 8.0

def hero_lines(points: float, rows: int = 2) -> dict:
    """Where the lines of the hero stand, in layout pixels down from its top, for a number of `points`: the number's
    baseline, the formula's, the top of the CoP's gauge, each reference row's baseline and the top of its gauge, the
    scale's baseline under the last gauge, and the height the whole takes (tall)."""
    number = 0.76 * points * LAYOUT_DPI / 72
    formula = number + DROPS["formula"]
    gauge_top = formula + DROPS["gauge"]
    below = gauge_top + GAUGE_HIGH
    lines = []
    for _ in range(rows):
        base = below + DROPS["row"]
        lines.append((base, base + DROPS["under"]))
        below = base + DROPS["under"] + ROW_HIGH
    scale = below + DROPS["scale"]
    return {"number": number, "formula": formula, "gauge": gauge_top, "rows": tuple(lines), "scale": scale, "tall": scale + SCALE_FOOT}

def hero_wide() -> float:
    """The width the hero needs, in layout pixels, in the language on screen: its formula, and a reference row's name,
    its gap and the widest number it keeps room for (WIDEST); between HERO_FEWEST and HERO_MOST."""
    names = (get_text("lab.mm.hero.cod"), get_text("lab.mm.hero.true"))
    rows = max(text_width(name, LABEL["fontsize"]) for name in names) + ROW_GAP + number_width(WIDEST, READING["fontsize"])
    formula = mathtext_width(DEFINED, DEFINITION["fontsize"] * LAYOUT_DPI / 72)
    return min(max(formula + 2.0, rows, HERO_FEWEST), HERO_MOST)

def cop_written(state: MetamodelState) -> str:
    """The CoP as the strip and the hero write it: its value (quality), with the warning's mark at or below 0 (poor),
    a dash while it cannot be computed."""
    if state.check is None:
        return DASH
    return f"{MARK} {quality(state.check.cop)}" if poor(state.check.cop) else quality(state.check.cop)

def cop_warned(state: MetamodelState) -> bool:
    """The CoP warns: it cannot be computed, or it is at or below 0."""
    return state.check is None or poor(state.check.cop)

def clipped(text: str, points: float, room: float) -> str:
    """A name as wide as `room` layout pixels at most in the figure's face at `points`: whole, or cut with an ellipsis
    (beside a number far below 0, wider than the room the hero keeps; the strip names it whole)."""
    if text_width(text, points) <= room:
        return text
    while len(text) > 1 and text_width(text.rstrip() + "…", points) > room:
        text = text[:-1]
    return text.rstrip() + "…"

def wrapped(text: str, points: float, room: float) -> str:
    """A sentence broken into lines no wider than `room` layout pixels in the figure's face at `points` (a word longer
    than the room stands alone on its line)."""
    lines: list[str] = []
    for word in text.split():
        if lines and text_width(f"{lines[-1]} {word}", points) <= room:
            lines[-1] = f"{lines[-1]} {word}"
        else:
            lines.append(word)
    return "\n".join(lines)

def moved(settings: dict, u1: float, u2: float) -> dict | None:
    """The settings with the query point at (u1, u2), kept inside the unit square; None when it does not move."""
    probe = (round(min(max(float(u1), 0.0), 1.0), 3), round(min(max(float(u2), 0.0), 1.0), 3))
    return None if probe == tuple(settings["probe"]) else settings | {"probe": probe}

def terms(order: str) -> int:
    """The number of terms of a polynomial basis: the least number of designs a fit of that basis needs."""
    return len(regression.basis((0.5, 0.5), order))

def cannot(candidate: Candidate, where: str, n: int) -> str:
    """Why a choice cannot be computed with n designs, as a sentence for the figure and the lead (where: "fit",
    somewhere on the grid; "probe", at the query point). A basis with more terms than designs; the moving least squares
    with a radius that leaves some point with too few designs carrying weight; Kriging's R singular to the working
    precision (theta so small, or two designs so close, that two rows of R are nearly the same); a polynomial whose
    designs do not determine its coefficients."""
    if candidate.order is not None and n < terms(candidate.order):
        return get_text("lab.mm.cannot.terms", basis=get_text(f"lab.mm.order.{candidate.order}").lower(), terms=terms(candidate.order),
                        n=n)
    if candidate.model == "mls" and candidate.value is not None:
        return get_text(f"lab.mm.cannot.{'probe' if where == 'probe' else 'mls'}", radius=f"{candidate.value:.2f}")
    if candidate.model == "kriging" and candidate.value is not None:
        return get_text("lab.mm.cannot.kriging", theta=f"{candidate.value:g}")
    return get_text("lab.mm.cannot.fit", model=get_text(f"lab.mm.model.{candidate.model}"))

def named(candidate: Candidate) -> str:
    """A candidate in words: its model, its basis and its parameter (once known)."""
    parts = [get_text(f"lab.mm.model.{candidate.model}")]
    if candidate.order is not None:
        parts.append(get_text(f"lab.mm.order.{candidate.order}").lower())
    if candidate.value is not None:
        parts.append(f"D = {candidate.value:.2f}" if candidate.model == "mls" else f"θ = {candidate.value:g}")
    return " · ".join(parts)

def entry_to_come(k: int) -> Candidate:
    """Candidate k of the competition before it is computed: its model and its basis, not yet its parameter."""
    if k < len(ORDERS):
        return Candidate("polynomial", ORDERS[k], None)
    if k < 2 * len(ORDERS):
        return Candidate("mls", ORDERS[k - len(ORDERS)], None)
    return Candidate("kriging", None, None)

def reach_of(candidate: Candidate) -> tuple[float, str] | None:
    """The distance, in the unit square, at which a design's weight (moving least squares) or its correlation with the
    point (Kriging) is 1/e, and its name; None for a polynomial, which has no such distance."""
    if candidate.model == "mls":
        return candidate.value, "D"
    if candidate.model == "kriging":
        return 1 / math.sqrt(candidate.value), "1/√θ"
    return None

def checked_points(state: MetamodelState) -> list[tuple[float, float]]:
    """The points of the check as they are drawn: (simulated, predicted without it), a prediction beyond the window on
    its edge."""
    low, high = spread(state.data.values)
    return [(value, min(max(prediction, low), high)) for value, prediction in zip(state.data.values, state.check.predictions)]

def spread(values, share: float = 0.12) -> tuple[float, float]:
    """A window that holds the values, with a margin."""
    low, high = min(values), max(values)
    margin = share * ((high - low) or abs(high) or 1.0)
    return low - margin, high + margin

def poor(cop: float) -> bool:
    """A CoP at or below 0: CoP = 1 - SS_E/SS_T, so the metamodel predicts the designs it did not see no better than
    their mean. An exact meaning, not a threshold: the strip, the check and the summary warn of it."""
    return cop <= 0.0

def quality(value: float) -> str:
    """A coefficient (CoD, CoP) as the lab writes it: three decimals near 1, fewer far below 0, a power of ten beyond."""
    if abs(value) < 10:
        text = f"{value:.3f}"
    elif abs(value) < 1000:
        text = f"{value:.1f}"
    else:
        mantissa, exponent = f"{value:.1e}".split("e")
        text = f"{mantissa} × 10{''.join(SUPERSCRIPTS[c] for c in str(int(exponent)))}"
    return "0.000" if text == "-0.000" else text.replace("-", "−")
