# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: objectives.py
# ==============================================================================
"""
The OBJECTIVE SPACE of a bench of two objectives (explorers/outputs.py: beam_pareto's mass m across, its RMS deflection
δ up), as the three steps of that bench draw it, without Qt. With two objectives the response is no longer a height
over the design space but a POINT of a plane: the first card of the right column, where the benches of one response
have their 3D view, holds this plane instead, in the same box in the three steps (panels.objective_box: box), with the
head and the step's measures beside it as the beams have them. Every design is a point in both spaces, the design plane
at the left (its projection, explorers/section.py) and this one; the marks are the same in both, one meaning per colour
(palette.py) and never colour alone.

ONE WINDOW for the three steps, the bench's own, never the sample's (window, cached per bench): what the step shows
moves in a frame that does not. Each objective's RANGE runs from the least of the true front's ideal and of the
objective's least value on the design space to the largest of the reference point of the hypervolume and of the
objective's largest value there, that largest value held to the true front's nadir plus REACH_UP of the front's extent
(the designs far from every compromise, the light and badly placed cross-beams that bend 25 mm, would take the frame:
they are counted at the edge instead); then MARGIN of the range on each side. The values on the design space are its
grid of game.GRID_MANY points per input, simulated once (the mass is linear in the areas: its range, 1099 to 2198 kg,
is exact on that grid). On beam_pareto: m from 1099 to 2285 kg (the reference's), δ from 3.93 (the ideal's) to 12.19 mm
(the nadir 9.43 plus half its extent 5.50), each widened by 4 %. A design beyond the window is drawn at the edge it left by, as a
triangle pointing out of the frame (placed), and the designs beyond one edge are counted there, "3 ↑" (counts): never
drawn out of place, never lost.

The frame (frame, once per scene): the card's tone, four spines, few round ticks (ticks_of: the smallest step of
STEPS times a power of ten whose labels keep TICK_GAP apart across, UP_PITCH up, and at most FEW_TICKS of them on an
axis shorter than FEW, MOST_TICKS else: fewer, coarser ticks in a small box, finer in a large one; the values follow the
box, measured, never a table of window sizes), the axes named by their symbols and units in the NAME role ("$m$ [kg]" under it, "$\\delta$"
over "[mm]" across at its left, right-aligned on its tick labels, as the design space names x₂).

The MARKS (Look, a named style each; mark draws one, projections draws one on the design plane with section's fade):
    FEASIBLE        a feasible simulated design: the blue disc (the designs' colour, as in every bench);
    INFEASIBLE      an infeasible one (a constraint past its limit): hollow, red (what is wrong; hollow: never colour alone);
    NONDOMINATED    the ring around a feasible design no other one dominates, teal (what is right), and the staircase
                    that joins them (nondominated: the front of a set, the lower left boundary of what it dominates);
    VALIDATED       a design validated, a simulation of a point of the predicted front: a disc inside a ring, blue;
    REFUSED         a validated design that the simulation found infeasible: hollow, red, inside a red ring;
    PREDICTION      an evaluation of the metamodels that is not a simulation: a white cross (the other benches' mark of
                    an evaluation of ŷ); RANKED, a member of the predicted front (rank 1 on the metamodels): a teal cross,
                    and the predicted front itself its dashed teal line (FRONT_DASH: a dash is a model's);
    QUERY           step 2's query point's prediction: the yellow diamond (what is computed now), its two values beside
                    it on the card's tone, kept inside the frame (query);
    TRUTH           the TRUE front: a slate line over a dark casing (panels.true_wire's look: a reference a real study
                    never has), through the bench's stored front (game.front);
    REFERENCE       the reference point r of the hypervolume (game.REFERENCE of the true front's extent past its ideal): a
                    hollow slate square named "r"; the HYPERVOLUME of a set (hypervolume) a quiet blue area, the exact
                    staircase from the set's points to r (staircase: its area in the normalized objectives is
                    pareto.hypervolume of the same points);
    POINTED         the design under the pointer: a white ring (Ring, made once per scene and moved, for the live layer).
The joining line (joined): the thin light line from a design's prediction to its validation. The legends' entries
(handle, by the names of LEGENDS, the catalog's lab.objectives.*, a short label where the long one crowds a small head;
limit_handle the hatched patch of the predicted limits, named by the constraints' symbols).

On the DESIGN PLANE (projections, designs_on_plane, limits): the same looks at the designs' projections, with the fade
of a bench of more than two inputs (section.opacity, section.grown for a design, section.shrunk for a mark of a search,
the farthest drawn first), and the LIMIT of the constraints on the slice: the level line g = limit of each constraint's
grid (red, solid), and the side where ANY constraint passes its limit lightly CROSS-hatched once (the union: a pattern
of the limit's own, never step 1's single hatch of an empty interval, which shares the plane). A tie, g exactly
at its limit, is feasible (outputs.feasible: g <= limit), so the hatch is where the largest excess g / limit - 1 is
positive, its edge the line itself.

The pointer (hit): the design of a set under the pointer in this space, at the place it is drawn (an edge's for one
beyond the window), within base.HIT_RADIUS layout pixels (the same reach at any screen density), so that a laboratory
answers its own hit for this axes as it does for the plane.

What a laboratory draws when: `box(plan, function)` once per layout (the axes made on it); `frame` and `truth` once per
scene (they depend on the bench, the language and the box only), with the step's fixed sets (the experiment in steps 2
and 3, the reference and the predicted front of a complete run); what moves at every draw (a free point placed, the
query point's diamond, a stage of the run, the validated designs and their hypervolume as they come) with the functions
above, each returning the artists it added, which the lab removes before the next draw; the Ring's artist, moved on a
pointer's move and handed to the live layer (live.Layer.hold). Everything is laid out in layout pixels and drawn by the
roles of panels.py: no face, weight or size is typed here.
"""
import math
from dataclasses import dataclass
from functools import cache

import numpy as np
from matplotlib import rc_context
from matplotlib.collections import LineCollection
from matplotlib.legend import Legend
from matplotlib.legend_handler import HandlerBase
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Polygon

from statistical_fundamentals import palette
from statistical_fundamentals.explorers import game, outputs, panels, section
from statistical_fundamentals.explorers.sketch import LABEL_BOX
from statistical_fundamentals.explorers.base import HIT_RADIUS, nearest, style_axes
from statistical_fundamentals.explorers.lab import LAYOUT_DPI, size
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.i18n import get_text

# The window, the bench's own (window)
MARGIN = 0.04                         # of each objective's range, on each side: a mark at the range's end stays off the frame
REACH_UP = 0.5                        # an objective's largest value counts up to the true front's nadir plus this share of
                                      # the front's extent (beyond it a design is counted at the edge)
GRID = game.GRID_MANY                 # points per input of the grid on which an objective's range is read (9^4 for four)
DIGITS = 3                            # a value of an objective written with this many digits of its range (decimals)
# The frame's ticks (ticks_of), in layout pixels
STEPS = (1.0, 2.0, 3.0, 5.0)          # a tick's step is one of these times a power of ten: round values
FEW, FEW_TICKS, MOST_TICKS = 200.0, 4, 6      # an axis shorter than FEW has at most FEW_TICKS ticks, a longer one MOST_TICKS
TICK_GAP = 14.0                       # across: between two tick labels, at least
UP_PITCH = 30.0                       # up: from a tick to the next, at least (two lines of tick labels' height)
# The marks (areas in points², line widths in points)
FAINT_LINE = 0.7                      # the joining line from a prediction to its validation: the light ink at this share
HATCH, HATCH_ALPHA, HATCH_WIDTH = "xx", 0.32, 0.7     # the infeasible side of a predicted limit: red at this share,
HATCH_LEGEND = "xxxx"                 # cross-hatched (the empty interval of step 1 has the single hatch); its swatch
LIMIT_WIDTH = 1.4                     # a limit's line
AREA_FILL = 0.08                      # the hypervolume's area: the designs' colour at this share over the card
AREA_LEGEND = 0.25                    # its legend's patch (an area at 8 % reads as nothing in a 12-pixel swatch)
FRONT_WIDTH, FRONT_DASH = 1.1, (0, (4.0, 2.0))       # a set's staircase; the predicted front's dash (a model's)
TRUTH_WIDTH = 1.2                     # the true front's line (panels.WIRE's)
EDGE_MARKS = {"top": "^", "bottom": "v", "right": ">", "left": "<"}       # a design beyond the window, at the edge it left by
ARROWS = {"top": "↑", "bottom": "↓", "right": "→", "left": "←"}           # and the count beside its marks
COUNT_OFFSET = (6.0, 3.0)             # points: the count from the outermost mark of its edge, inside the frame
QUERY_OFFSET = 8.0                    # points: the query point's values from its diamond, up and to its right (away from
                                      # the front, which lies at the lower left of every design)
QUERY_TALL = 16.0                     # layout pixels: the values' line on its tag, the room it needs over the diamond
GREEK = {"δ": r"\delta", "σ": r"\sigma", "θ": r"\theta", "μ": r"\mu"}     # a symbol of outputs.py as mathematics
SUBSCRIPTS = "₀₁₂₃₄₅₆₇₈₉"
PAIRED_AT = (0.25, 0.8)               # a legend's entry of two kinds: where its two marks stand in the handle's room

@dataclass(frozen=True)
class Look:
    """How a mark is drawn: its colour (a meaning of palette.py), its marker, hollow or filled, its area (points², in
    the objective space; the plane gives its own), its line (a filled disc's edge, a ring's line, a cross's strokes),
    a ring around it of `ring` times its area (0: none) and its order."""
    color: str
    marker: str = "o"
    hollow: bool = False
    area: float = 16.0
    width: float = 0.6
    ring: float = 0.0
    ring_width: float = 1.1
    zorder: float = 5.0

FEASIBLE = Look(palette.BLUE)
INFEASIBLE = Look(palette.RED, hollow=True, width=1.2)
NONDOMINATED = Look(palette.TEAL, hollow=True, area=44.0, width=1.2, zorder=6.0)
VALIDATED = Look(palette.BLUE, area=22.0, ring=2.6, zorder=7.0)
REFUSED = Look(palette.RED, hollow=True, area=22.0, width=1.3, ring=2.6, zorder=7.0)
PREDICTION = Look(palette.WHITE, marker="+", area=30.0, width=1.1, zorder=6.0)
RANKED = Look(palette.TEAL, marker="+", area=30.0, width=1.2, zorder=6.0)
QUERY = Look(palette.YELLOW, marker="D", area=40.0, width=0.8, zorder=9.0)
REFERENCE = Look(palette.SLATE, marker="s", hollow=True, area=26.0, width=1.1, zorder=4.0)
POINTED = Look(palette.WHITE, hollow=True, area=58.0, width=1.4, zorder=8.0)
LEGENDS = ("feasible", "infeasible", "nondominated", "validated", "predicted", "ranked", "front", "truth", "hypervolume",
           "query")                   # the legends' entries (handle): the catalog's lab.objectives.<name>

# ------------------------------------------------------------------------------ the window
@dataclass(frozen=True)
class Window:
    """The objective space's window of a bench (window): the range drawn of each objective (across: the first, up: the
    second), the true front's ideal and nadir, the reference point of the hypervolume, and the decimals each objective
    is written with (DIGITS of its range)."""
    across: tuple[float, float]
    up: tuple[float, float]
    ideal: tuple[float, float]
    nadir: tuple[float, float]
    reference: tuple[float, float]
    decimals: tuple[int, int]

    def placed(self, point) -> tuple[float, float, str | None]:
        """Where a point of the objectives is drawn: itself inside the window; else at the edge it left by (the
        vertical edge first where it left by two), with that edge's name."""
        x, y = float(point[0]), float(point[1])
        (a, b), (c, d) = self.across, self.up
        side = "top" if y > d else "bottom" if y < c else "right" if x > b else "left" if x < a else None
        return min(max(x, a), b), min(max(y, c), d), side

def window(function: str) -> Window:
    """The window of the bench's objective space, the same in its three steps (module docstring: the rule); refused
    (ValueError) for a bench that has not exactly two objectives, as game.stored refuses its front."""
    if len(outputs.objectives(function)) != 2:
        raise ValueError(f"the bench {function!r} has no objective space of two objectives")
    return windowed(RESPONSES[function])

@cache
def windowed(response) -> Window:
    """window's, cached by the Response (a bench registered again is read again)."""
    function = response.key
    first, second = outputs.objectives(function)
    front = game.front(function)
    axes = np.meshgrid(*(np.linspace(low, up, GRID) for low, up in response.bounds), indexing="ij")
    rows = outputs.simulate(function, list(zip(*(axis.ravel() for axis in axes))))
    ranges, decimals, reference = [], [], []
    for j, k in enumerate((first, second)):
        values = [row[k] for row in rows]
        ideal, nadir = front.ideal[j], front.nadir[j]
        extent = nadir - ideal
        r = ideal + game.REFERENCE * extent
        low = min(ideal, min(values))
        high = max(min(max(nadir, max(values)), nadir + REACH_UP * extent), r)
        pad = MARGIN * (high - low)
        ranges.append((low - pad, high + pad))
        decimals.append(max(0, DIGITS - 1 - math.floor(math.log10(high - low))))
        reference.append(r)
    return Window(ranges[0], ranges[1], tuple(front.ideal), tuple(front.nadir), tuple(reference), tuple(decimals))

def written(function: str, point) -> str:
    """A point of the objectives written as the figure writes it, "1171 · 6.78": each value with its decimals."""
    places = window(function).decimals
    return " · ".join(f"{float(v):.{n}f}".replace("-", "−") for v, n in zip(point, places))

def points_of(function: str, rows) -> list[tuple[float, float]]:
    """The objectives of rows of simulated outputs (outputs.rows), one point per design."""
    return [tuple(float(v) for v in outputs.objective_values(function, row)) for row in rows]

# ------------------------------------------------------------------------------ the frame
def box(plan, function: str) -> tuple[float, float, float, float] | None:
    """The frame's box in layout pixels (panels.objective_box), its left measured on the bench's vertical axis' name
    and its widest tick label."""
    return panels.objective_box(plan, name_lines(function, 1), widest_label(function))

def name_lines(function: str, j: int) -> tuple[str, ...]:
    """The lines of objective j's axis name: its symbol (mathematics) and its unit in brackets."""
    k = outputs.objectives(function)[j]
    unit = outputs.unit(function, k)
    return (math_symbol(function, k), f"[{unit}]") if unit else (math_symbol(function, k),)

def math_symbol(function: str, k: int, hat: bool = False) -> str:
    """Output k's symbol as mathematics ("$\\delta$", "$\\hat{\\sigma}_1$"), set in STIX as every symbol of the figure."""
    plain = outputs.symbol(function, k)
    letter, tail = plain[0], plain[1:]
    base = GREEK.get(letter, letter)
    base = rf"\hat{{{base}}}" if hat else base
    digits = "".join(str(SUBSCRIPTS.index(c)) for c in tail if c in SUBSCRIPTS)
    return f"${base}_{{{digits}}}$" if digits else f"${base}$"

def steps(low: float, high: float) -> list[float]:
    """The steps a frame's ticks may take over a range, from the finest to the coarsest: STEPS times powers of ten."""
    power = math.floor(math.log10(high - low))
    return [step * 10.0 ** exponent for exponent in range(power - 2, power + 2) for step in STEPS]

def multiples(low: float, high: float, step: float) -> list[float]:
    """The multiples of a step inside a range, rounded off the arithmetic's last digits."""
    return [round(k * step, 9) for k in range(math.ceil(low / step - 1e-9), math.floor(high / step + 1e-9) + 1)]

def ticks_of(low: float, high: float, length: float, room, most: int) -> tuple[list[float], float]:
    """The ticks of an axis from `low` to `high` drawn `length` layout pixels long, and their step: the multiples of
    the finest step (steps) of which the range holds at most `most`, standing at least `room(values)` layout pixels
    apart (their labels' room); the coarsest step's where none holds."""
    found = ([high], 1.0)
    for step in steps(low, high):
        values = multiples(low, high, step)
        if values:
            found = (values, step)
            if len(values) <= most and length * step / (high - low) >= room(values, step):
                return found
    return found

def label(value: float, step: float) -> str:
    """A tick's label: the decimals its step has ("2.5", "1000"), a minus sign."""
    digits = f"{step:.9f}".rstrip("0")
    decimals = len(digits.split(".")[1])
    return f"{value:.{decimals}f}".replace("-", "−")

def across_room(values: list[float], step: float) -> float:
    """Across, the room a tick needs: its widest label and TICK_GAP."""
    return max(panels.text_width(label(v, step), panels.TICK) for v in values) + TICK_GAP

def up_room(values: list[float], step: float) -> float:
    """Up, the room a tick needs: UP_PITCH (labels of one line each)."""
    return UP_PITCH

def widest_label(function: str) -> str:
    """The widest tick label the vertical axis may write, among every set of ticks of at most MOST_TICKS a frame may
    choose (the box is measured on it: it holds whichever the frame takes)."""
    low, high = window(function).up
    labels = [label(v, step) for step in steps(low, high) for values in [multiples(low, high, step)]
              if 2 <= len(values) <= MOST_TICKS for v in values]
    return max(labels or ["8"], key=lambda text: panels.text_width(text, panels.TICK))

def frame(ax, function: str) -> None:
    """The objective space's frame on its axes (once per scene, after the axes are cleared): the card's tone, four
    spines, the window's limits, few round ticks for the room the box has (ticks_of), the axes named by their symbols
    and units in the NAME role (the first under the frame, the second across at its left, its unit under its symbol)."""
    style_axes(ax)
    ax.set_facecolor(panels.CARD_TONE)
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color(palette.DARK_GREY)
    shown = window(function)
    ax.set_xlim(*shown.across)
    ax.set_ylim(*shown.up)
    width, height = size(ax.figure)
    position = ax.get_position()
    wide, tall = position.width * width, position.height * height
    for axis, span, length, room in ((ax.xaxis, shown.across, wide, across_room), (ax.yaxis, shown.up, tall, up_room)):
        values, step = ticks_of(*span, length, room, FEW_TICKS if length < FEW else MOST_TICKS)
        axis.set_ticks(values, [label(v, step) for v in values])
    panels.ticks(ax)
    first, second = name_lines(function, 0), name_lines(function, 1)
    ax.set_xlabel(" ".join(first), labelpad=2, **panels.NAME)
    stacked = {"linespacing": 1.0, "multialignment": "center"} if len(second) > 1 else {}
    ax.set_ylabel("\n".join(second), labelpad=panels.OBJECTIVE_LABELPAD, rotation=0, va="center", ha="right", **panels.NAME,
                  **stacked)

# ------------------------------------------------------------------------------ the marks
def mark(ax, look: Look, xs, ys, ground: str = panels.CARD_TONE, sizes=None, alphas=None, zorder: float | None = None,
         width: float | None = None) -> list:
    """Marks of one look at (xs, ys) in the data of `ax`: filled ones edged in `ground` (the tone they stand on: the
    card's in the objective space, the figure's on the plane), hollow ones a ring of the look's colour, crosses their
    strokes; `sizes` (points², one per mark; default the look's area) and `alphas` (one per mark; default 1) from the
    fade of a plane (projections); and the look's ring around each, as large as `ring` times its size. Not clipped by the
    frame (a mark at the edge stays whole). Returns the artists added (one, or two with the ring)."""
    xs, ys = list(xs), list(ys)
    if not xs:
        return []
    sizes = [look.area] * len(xs) if sizes is None else list(sizes)
    alphas = [1.0] * len(xs) if alphas is None else list(alphas)
    inks = [panels.tint(look.color, a) for a in alphas]
    order = look.zorder if zorder is None else zorder
    line = look.width if width is None else width
    if look.marker == "+" or look.marker == "x":
        drawn = [ax.scatter(xs, ys, s=sizes, marker=look.marker, color=inks, linewidths=line, zorder=order, clip_on=False)]
    elif look.hollow:
        drawn = [ax.scatter(xs, ys, s=sizes, marker=look.marker, facecolors="none", edgecolors=inks, linewidths=line,
                            zorder=order, clip_on=False)]
    else:
        drawn = [ax.scatter(xs, ys, s=sizes, marker=look.marker, color=inks, edgecolors=[panels.tint(ground, a) for a in alphas],
                            linewidths=line, zorder=order, clip_on=False)]
    if look.ring:
        drawn.append(ax.scatter(xs, ys, s=[look.ring * s for s in sizes], marker="o", facecolors="none", edgecolors=inks,
                                linewidths=look.ring_width, zorder=order, clip_on=False))
    return drawn

def at_edges(ax, function: str, look: Look, points, alpha: float = 1.0) -> tuple[list, dict]:
    """Points of the objectives in the window: those inside as `look`'s marks, those beyond at the edge they left by,
    as triangles pointing out of the frame (EDGE_MARKS), filled or hollow as the look is. Returns the artists and the
    edge points by edge (for counts)."""
    shown = window(function)
    inside, beyond = [], {}
    for point in points:
        x, y, side = shown.placed(point)
        (inside if side is None else beyond.setdefault(side, [])).append((x, y))
    drawn = mark(ax, look, [p[0] for p in inside], [p[1] for p in inside], alphas=[alpha] * len(inside))
    for side, placed in beyond.items():
        edge = Look(look.color, EDGE_MARKS[side], look.hollow, look.area * 1.3, look.width, 0.0, look.ring_width, look.zorder)
        drawn += mark(ax, edge, [p[0] for p in placed], [p[1] for p in placed], alphas=[alpha] * len(placed))
    return drawn, beyond

def counts(ax, beyond: dict, alpha: float = 1.0) -> list:
    """How many designs stand beyond each edge, "3 ↑", inside the frame beside the outermost of their marks (the TAG
    role, the muted ink): a count of designs, of every kind."""
    drawn = []
    (a, b), (c, d) = ax.get_xlim(), ax.get_ylim()
    for side, placed in beyond.items():
        if not placed:
            continue
        if side in ("top", "bottom"):
            x = max(p[0] for p in placed)
            right = (x - a) / (b - a) > 0.8
            spot = (x if not right else min(p[0] for p in placed), d if side == "top" else c)
            offset = (-COUNT_OFFSET[0] if right else COUNT_OFFSET[0], -COUNT_OFFSET[1] if side == "top" else COUNT_OFFSET[1])
            ha, va = ("right" if right else "left"), ("top" if side == "top" else "bottom")
        else:
            y = max(p[1] for p in placed)
            high = (y - c) / (d - c) > 0.8
            spot = (b if side == "right" else a, y if not high else min(p[1] for p in placed))
            offset = (-COUNT_OFFSET[1] if side == "right" else COUNT_OFFSET[1], -COUNT_OFFSET[0] if high else COUNT_OFFSET[0])
            ha, va = ("right" if side == "right" else "left"), ("top" if high else "bottom")
        drawn.append(ax.annotate(f"{len(placed)} {ARROWS[side]}", spot, xytext=offset, textcoords="offset points", ha=ha, va=va,
                                 color=panels.tint(panels.MUTED_INK, alpha), zorder=9, annotation_clip=False, **panels.TAG))
    return drawn

def designs(ax, function: str, rows, alpha: float = 1.0) -> list:
    """Every simulated design of rows (outputs.rows) at its objectives: feasible ones as FEASIBLE's blue discs,
    infeasible ones as INFEASIBLE's hollow red rings; those beyond the window at its edge and counted there. `alpha`:
    the set faded (step 3's experiment under the run). Returns the artists added."""
    feasible = [outputs.feasible(function, row) for row in rows]
    points = points_of(function, rows)
    drawn, beyond = at_edges(ax, function, FEASIBLE, [p for p, ok in zip(points, feasible) if ok], alpha)
    more, failed = at_edges(ax, function, INFEASIBLE, [p for p, ok in zip(points, feasible) if not ok], alpha)
    for side, placed in failed.items():
        beyond.setdefault(side, []).extend(placed)
    return drawn + more + counts(ax, beyond, alpha)

def staircase(points) -> list[tuple[float, float]]:
    """The staircase that joins points of two minimized objectives (a front: none dominates another), sorted by the
    first objective: from each point across to the next one's first objective at its own second, then down to the next
    (the lower left boundary of what they dominate)."""
    ordered = sorted((float(x), float(y)) for x, y in points)
    path = []
    for k, (x, y) in enumerate(ordered):
        if k:
            path.append((x, ordered[k - 1][1]))
        path.append((x, y))
    return path

def nondominated(ax, function: str, rows, alpha: float = 1.0) -> list:
    """The feasible designs of rows that no other one dominates (outputs.front_of): a teal ring around each
    (NONDOMINATED) and the staircase that joins them (staircase). Returns the artists added."""
    shown = window(function)
    front = [shown.placed(p)[:2] for p in points_of(function, [rows[i] for i in outputs.front_of(function, rows)])]
    if not front:
        return []
    path = staircase(front)
    drawn = ax.plot([p[0] for p in path], [p[1] for p in path], color=panels.tint(palette.TEAL, 0.9 * alpha), linewidth=FRONT_WIDTH,
                    zorder=NONDOMINATED.zorder - 1, clip_on=False)
    return drawn + mark(ax, NONDOMINATED, [p[0] for p in front], [p[1] for p in front], alphas=[alpha] * len(front))

def validated(ax, function: str, rows, predicted=None) -> list:
    """Designs validated (rows: their simulated outputs, in the order of `predicted`): VALIDATED, a disc in a ring,
    where feasible, REFUSED, hollow in a ring, where the simulation finds a constraint past its limit; with `predicted`
    (their predictions, points of the objectives, in the same order), the thin line from each prediction to its
    validation first (joined). Returns the artists added."""
    shown = window(function)
    points = [shown.placed(p)[:2] for p in points_of(function, rows)]
    drawn = joined(ax, function, predicted, points) if predicted is not None else []
    ok = [outputs.feasible(function, row) for row in rows]
    drawn += mark(ax, VALIDATED, [p[0] for p, good in zip(points, ok) if good], [p[1] for p, good in zip(points, ok) if good])
    drawn += mark(ax, REFUSED, [p[0] for p, good in zip(points, ok) if not good], [p[1] for p, good in zip(points, ok) if not good])
    return drawn

def joined(ax, function: str, predicted, simulated) -> list:
    """The thin lines from each prediction (a point of the objectives) to the simulation of the same design, in the
    light ink at FAINT_LINE: how far the metamodels' promise lands from what the simulation finds."""
    shown = window(function)
    segments = [(shown.placed(a)[:2], shown.placed(b)[:2]) for a, b in zip(predicted, simulated, strict=True)]
    if not segments:
        return []
    return [ax.add_collection(LineCollection(segments, colors=panels.tint(panels.LEGEND_INK, FAINT_LINE), linewidths=0.8,
                                             zorder=VALIDATED.zorder - 0.5))]

def predictions(ax, function: str, points, look: Look = PREDICTION) -> list:
    """Evaluations of the metamodels, points of the objectives that no simulation gave: crosses (PREDICTION's white,
    or RANKED's teal for the members of the predicted front). Returns the artists added."""
    drawn, beyond = at_edges(ax, function, look, points)
    return drawn + counts(ax, beyond)

def truth(ax, function: str) -> list:
    """The TRUE front (game.front: the bench's stored designs, simulated), sorted by the first objective: a slate line
    over a dark casing (panels.WIRE's look: the reference a real study never has). Returns the artists added."""
    points = sorted(game.front(function).points)
    line = ax.plot([p[0] for p in points], [p[1] for p in points], color=palette.SLATE, linewidth=TRUTH_WIDTH, alpha=panels.WIRE["alpha"],
                   solid_capstyle="round", zorder=3)
    line[0].set_path_effects(list(panels.WIRE_CASING))
    return line

def reference(ax, function: str) -> list:
    """The reference point r of the hypervolume: a hollow slate square, named "r" at its upper left (the TAG role)."""
    x, y = window(function).reference
    drawn = mark(ax, REFERENCE, [x], [y])
    drawn.append(ax.annotate("r", (x, y), xytext=(-5.0, 4.0), textcoords="offset points", ha="right", va="bottom",
                             color=palette.SLATE, zorder=REFERENCE.zorder, annotation_clip=False, **panels.TAG))
    return drawn

def staircase_area(function: str, points) -> list[tuple[float, float]]:
    """The region the points dominate up to the reference point r, as a polygon in the objectives (data coordinates):
    the points that dominate r, sorted by the first objective, each kept where it lowers the second (pareto.hypervolume's
    walk), the steps between them and r's corner. Its area, in the objectives normalized by the true front (game), is
    pareto.hypervolume of the same points; empty where no point dominates r."""
    shown = window(function)
    rx, ry = shown.reference
    inside = sorted((float(x), float(y)) for x, y in points if x < rx and y < ry)
    kept, previous = [], ry
    for x, y in inside:
        if y < previous:
            kept.append((x, y))
            previous = y
    if not kept:
        return []
    polygon = [(kept[0][0], ry)]
    for k, (x, y) in enumerate(kept):
        polygon += [(x, kept[k - 1][1])] if k else []
        polygon.append((x, y))
    return polygon + [(rx, kept[-1][1]), (rx, ry)]

def hypervolume(ax, function: str, points) -> list:
    """The hypervolume of a set of points of the objectives (a study's simulated feasible designs that no other one
    dominates): the quiet area of staircase_area, the designs' colour at AREA_FILL, under every mark. Returns the
    artists added (none where nothing dominates r)."""
    polygon = staircase_area(function, points)
    if not polygon:
        return []
    return [ax.add_patch(Polygon(polygon, closed=True, facecolor=panels.tint(palette.BLUE, AREA_FILL), edgecolor="none", zorder=1))]

def query(ax, function: str, point) -> list:
    """Step 2's query point's prediction (a point of the objectives): QUERY's yellow diamond and its two values beside
    it ("1171 · 6.78", written), on the card's tone in the TAG role and the diamond's ink, up and to its right (away
    from the front, at the lower left of what it dominates), at its left where they would pass the frame's right edge,
    under it near the top: inside the frame. Returns the artists added."""
    shown = window(function)
    x, y, _ = shown.placed(point)
    drawn = mark(ax, QUERY, [x], [y])
    text = written(function, point)
    width, height = size(ax.figure)
    position = ax.get_position()
    (a, b), (c, d) = shown.across, shown.up
    across = (x - a) / (b - a) * position.width * width
    room = position.width * width - across
    gap = QUERY_OFFSET * LAYOUT_DPI / 72
    right = room >= gap + panels.text_width(text, panels.TAG["fontsize"]) + 4.0
    high = (y - c) / (d - c) * position.height * height > position.height * height - gap - QUERY_TALL
    drawn.append(ax.annotate(text, (x, y), xytext=(QUERY_OFFSET if right else -QUERY_OFFSET, -QUERY_OFFSET if high else QUERY_OFFSET),
                             textcoords="offset points", ha="left" if right else "right", va="top" if high else "bottom",
                             color=QUERY.color, zorder=QUERY.zorder, bbox=LABEL_BOX, annotation_clip=False, **panels.TAG))
    return drawn

class Ring:
    """The design under the pointer in the objective space: a white ring (POINTED), made once on the axes (after a
    scene's clear: a new one) and moved, never made again, from a design to the next, hidden with none; its artist is
    the live layer's (live.Layer.hold), as the crosshair's are."""

    def __init__(self, ax, function: str):
        self.function = function
        self.artist = ax.scatter([np.nan], [np.nan], s=POINTED.area, facecolors="none", edgecolors=POINTED.color,
                                 linewidths=POINTED.width, zorder=POINTED.zorder, clip_on=False)
        self.artist.set_visible(False)

    def show(self, point) -> list:
        """The ring on a point of the objectives (where it is drawn: an edge's for one beyond the window), or hidden
        (None). Returns its artist, for the live layer."""
        if point is None:
            self.artist.set_visible(False)
        else:
            x, y, _ = window(self.function).placed(point)
            self.artist.set_offsets([[x, y]])
            self.artist.set_visible(True)
        return [self.artist]

def hit(ax, function: str, points, event) -> int | None:
    """The point of the objectives under the pointer (an index of `points`), at the place it is drawn, within
    base.HIT_RADIUS layout pixels (the same reach at any density); None off every point or off these axes."""
    if event is None or event.inaxes is not ax or not len(points):
        return None
    shown = window(function)
    return nearest(ax, [shown.placed(p)[:2] for p in points], event, HIT_RADIUS * ax.figure.dpi / LAYOUT_DPI)

# ------------------------------------------------------------------------------ the design plane
def kinds(function: str, rows) -> tuple[Look, ...]:
    """The look of each simulated design on the plane: FEASIBLE or INFEASIBLE."""
    return tuple(FEASIBLE if outputs.feasible(function, row) else INFEASIBLE for row in rows)

def projections(ax, look: Look, cut, points, unit, area: float, ground: str = palette.CARD, grow: bool = True,
                zorder: float | None = None, alpha: float = 1.0) -> list:
    """Marks of one look at the projections of designs on the plane's slice (`points` in the bounds, `unit` their unit
    points): with two inputs at their places and `area`; with more, the fade of section.py, the farthest first, each as
    opaque as it is near (section.opacity) and grown on the plane (section.grown; `grow` False: shrunk, a mark of a
    search, section.shrunk), its edge EDGE_THIN. `alpha`: the whole set faded once more (step 3's experiment under the
    run; 1, the default, leaves every mark as the fade draws it). Returns the artists added."""
    if not len(points):
        return []
    if cut.plain:
        return mark(ax, look, [p[0] for p in points], [p[1] for p in points], ground, [area] * len(points),
                    alphas=None if alpha == 1.0 else [alpha] * len(points), zorder=zorder)
    near = [cut.closeness(u) for u in unit]
    order = sorted(range(len(points)), key=lambda k: near[k])
    xy = [cut.project(points[k]) for k in order]
    sizes = [section.grown(area, near[k]) if grow else section.shrunk(area, near[k]) for k in order]
    alphas = [alpha * section.opacity(near[k]) for k in order]
    width = section.EDGE_THIN if not look.hollow and look.marker not in ("+", "x") else None
    return mark(ax, look, [p[0] for p in xy], [p[1] for p in xy], ground, sizes, alphas, zorder, width)

def designs_on_plane(ax, function: str, cut, points, unit, rows, area: float, zorder: float = 6.0) -> list:
    """The simulated designs on the plane's slice by their kind (kinds: feasible discs, infeasible hollow rings), with
    the fade, and the ring of NONDOMINATED around the feasible ones no other one dominates. Returns the artists added."""
    looks = kinds(function, rows)
    drawn = []
    for look in (FEASIBLE, INFEASIBLE):
        chosen = [k for k, kind in enumerate(looks) if kind is look]
        drawn += projections(ax, look, cut, [points[k] for k in chosen], [unit[k] for k in chosen], area, zorder=zorder)
    front = outputs.front_of(function, rows)
    ring = Look(NONDOMINATED.color, "o", True, 1.0, NONDOMINATED.width)
    near = [1.0 if cut.plain else cut.closeness(unit[k]) for k in front]
    sizes = [2.6 * (area if cut.plain else section.grown(area, c)) for c in near]
    xy = [cut.project(points[k]) for k in front]
    drawn += mark(ax, ring, [p[0] for p in xy], [p[1] for p in xy], sizes=sizes,
                  alphas=[section.opacity(c) for c in near], zorder=zorder + 0.5)
    return drawn

def limits(ax, x, y, values, bounds, zorder: float = 2.0) -> list:
    """The predicted (or true) LIMITS of constraints on a slice of the plane: `values`, one grid of g per constraint
    on the mesh (x, y) (2D arrays of one shape), `bounds` their limits. Where ANY constraint passes its limit (the
    largest excess g / limit - 1 positive: a tie is feasible) the plane is cross-hatched once, lightly, in the red of what is
    wrong (HATCH, at HATCH_ALPHA): the union; each constraint's level line g = limit drawn solid in red over it, where
    its grid crosses its limit. Returns the artists added."""
    values = [np.asarray(v, dtype=float) for v in values]
    excess = np.max([v / limit - 1.0 for v, limit in zip(values, bounds, strict=True)], axis=0)
    drawn = []
    if (excess > 0).any():
        with rc_context({"hatch.color": panels.tint(palette.RED, HATCH_ALPHA), "hatch.linewidth": HATCH_WIDTH}):
            filled = ax.contourf(x, y, excess, levels=[0.0, float(excess.max()) + 1.0], colors="none", hatches=[HATCH], zorder=zorder)
        filled.set_edgecolor(panels.tint(palette.RED, HATCH_ALPHA))
        filled.set_linewidth(0.0)
        drawn.append(filled)
    for v, limit in zip(values, bounds):
        if v.min() < limit < v.max():
            drawn.append(ax.contour(x, y, v, levels=[limit], colors=[palette.RED], linewidths=LIMIT_WIDTH, zorder=zorder + 0.5))
    return drawn

# ------------------------------------------------------------------------------ the legends
def handle(name: str) -> Line2D | Patch:
    """A legend's entry of the objective space (LEGENDS), its label the catalog's lab.objectives.<name> in the
    language chosen, the short label a crowded head takes where it has one (panels.legend_rows)."""
    text = get_text(f"lab.objectives.{name}")
    if name == "hypervolume":
        made = Patch(facecolor=panels.tint(palette.BLUE, AREA_LEGEND), edgecolor="none", label=text)
        made.short = get_text("lab.objectives.hypervolume_short")
        return made
    if name == "truth":
        made = Line2D([], [], label=text, path_effects=list(panels.WIRE_CASING), **panels.WIRE)
        made.short = None
        return made
    if name == "nondominated":
        made = Line2D([], [], color=palette.TEAL, linewidth=FRONT_WIDTH, marker="o", markersize=7, markerfacecolor="none",
                      markeredgecolor=palette.TEAL, markeredgewidth=NONDOMINATED.width, label=text)
    elif name == "front":
        made = Line2D([], [], color=palette.TEAL, linewidth=FRONT_WIDTH, linestyle=FRONT_DASH, marker="+", markersize=7,
                      markeredgewidth=RANKED.width, label=text)
    elif name == "validated":
        made = Line2D([], [], linestyle="none", marker=r"$\odot$", markersize=10, color=palette.BLUE, label=text)
    else:
        look = {"feasible": FEASIBLE, "infeasible": INFEASIBLE, "predicted": PREDICTION, "ranked": RANKED, "query": QUERY}[name]
        hollow = look.hollow or look.marker in ("+", "x")
        made = panels.dot(look.color, text, hollow=hollow, marker=look.marker, size=8.5 if look.marker != "D" else 6.5)
        if look.marker in ("+", "x"):
            made.set_markeredgewidth(look.width + 0.2)
    made.short = None
    return made

class Paired(Line2D):
    """A legend's entry of a set drawn in two kinds (step 3's experiment: feasible discs and infeasible hollow rings):
    both marks side by side in its handle (PairedHandler), one label. `marks` are two Line2D of the legend's marks."""

    def __init__(self, marks: tuple, label: str, short: str | None = None):
        super().__init__([], [], linestyle="none", label=label)
        self.marks = marks
        self.short = short

class PairedHandler(HandlerBase):
    """Draws a Paired entry: its first mark at the left of the handle's room, its second at the right."""

    def create_artists(self, legend, orig_handle, xdescent, ydescent, width, height, fontsize, trans):
        made = []
        for mark, share in zip(orig_handle.marks, PAIRED_AT, strict=True):
            artist = Line2D([], [])
            artist.update_from(mark)
            artist.set_data([width * share - xdescent], [height / 2 - ydescent])
            artist.set_transform(trans)
            made.append(artist)
        return made

Legend.update_default_handler_map({Paired: PairedHandler()})

def kinds_handle(label: str, short: str | None = None, alpha: float = 1.0) -> Paired:
    """The legend's entry of simulated designs of both kinds: the feasible blue disc and the infeasible hollow red ring
    side by side (`alpha`: the set as faint as it is drawn)."""
    disc = panels.dot(FEASIBLE.color, label, size=6.5)
    disc.set_markerfacecolor(panels.tint(FEASIBLE.color, alpha))
    ring = panels.dot(INFEASIBLE.color, label, hollow=True, size=6.5)
    ring.set_markeredgecolor(panels.tint(INFEASIBLE.color, alpha))
    ring.set_markeredgewidth(INFEASIBLE.width)
    return Paired((disc, ring), label, short)

def limit_handle(function: str, hat: bool = True) -> Patch:
    """The legend's entry of the limits on the plane: the red cross-hatch, named by the constraints and the limit
    with its unit ("σ̂₁ > 120 MPa"; two of them, "σ̂₁ or σ̂₂ > 120 MPa", lab.objectives.limits); a crowded head's
    short label without the unit (panels.legend_rows)."""
    found = outputs.constraints(function)
    if not 1 <= len(found) <= 2:
        raise ValueError(f"the legend names one or two constraints, not {len(found)}")
    limit = f"{outputs.shared_limit(function):g} {outputs.unit(function, found[0])}".strip()
    names = [math_symbol(function, k, hat) for k in found]
    text = f"{names[0]} > {limit}" if len(names) == 1 else get_text("lab.objectives.limits", first=names[0], second=names[1],
                                                                       limit=limit)
    made = Patch(facecolor="none", edgecolor=palette.RED, hatch=HATCH_LEGEND, label=text)
    bare = f"{outputs.shared_limit(function):g}"                      # a crowded head's: the limit without its unit
    made.short = f"{names[0]} > {bare}" if len(names) == 1 else get_text("lab.objectives.limits", first=names[0],
                                                                          second=names[1], limit=bare)
    return made
