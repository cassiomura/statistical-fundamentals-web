# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                              Title: lab.py
# ==============================================================================
"""
The laboratory of a step, without Qt: the interactive experiment of one step of a bench's study (benches.STEPS,
explorers/study.py). The window shows every Lab with one widget (gui/lab_views.LabView), as a workbench that fills the
window under the bar of the benches and the steps:

    Lab title (one line)  | figure (mouse, drag, keyboard), from the top of the stage            [alert]
    [ the card: received  |
      from step k, or the |
      problem (5 rows)  ] |
    ───────────────────── |
    [ featured command  ] |
    control               |
      its widget          |
      (its muted line)    |
    (▶) (⏭) (↺)           |
    stage on screen       |
    [command] [command]   |
    [ filled command    ] |
    Restore               | results strip: metric | metric | metric                      View code

The column at the left has the lab's title, the card of what the step works on (received: what it received from the one
before, or, for the first step, the problem) in a slot of the same height in every step, a rule, and then the controls'
block: a featured command when the lab has one (Action.featured), the controls, each a label over its widget, the
commands drawn as icons in one transport row (Action.icon) with the name of the stage on screen on a line under them
(naming under the key TRANSPORT), and the other commands as quiet chips (or in the row of a typed control, at the right of
its field: Action.beside); pinned at its foot, the lab's one filled command
(Action.forward: it hands the step's result to the next step, output, and the window answers it; or Action.primary: the
last step's own, the validation) over Restore. The title, the card's slot, the rule, the top of the controls' block, the
filled command and Restore stand at the same place in every step. The figure takes every pixel left, and draws its
panels for the size it is given (height_for: its least height). No sentence stands over it, and none waits on demand
either: the measures of the strip define themselves in their tooltips (Metric.tip), the lead is the figure's accessible
description (followed by keyboard, the keys that act on the figure, for assistive technology only: keys_text), and the
secondary commands (Action.top: "View code") close the strip. In a narrow lab (the code panel open
in a small window) the window puts the controls in rows above the figure instead.

A step of a study: output is what the step hands on (a frozen value, None while there is nothing to hand, and missing
says why), receive puts what the previous step handed into the settings (opening: the first settings of a step handed a
result, without computing what receiving replaces), received says it to the reader; hint, a sentence over the filled
button when it can be pressed (where to go after a validation that does not complete the bench); charged and paid, the
simulations a study paid for that no setting keeps (the window keeps them, so that Restore or a visit never makes a
validation free again). The three
steps of a bench draw one picture in the same places (explorers/panels.py): view, the angle of the 3D view, is carried
by the window from a step to the next.

A command with motion "step" plays the frames of one step, one with motion "run" plays them to the end and reads Pause
while it plays (advance gives the next frame, at_rest says when a step is complete; frame_time, how long a frame stays).
Frames show stages of a computed construction, never values nobody computed. A command may name what it will do next
(naming), and a command carried out may ask for a discreet sound (cue: the window plays it). Two hooks serve the
controls: showing, the text beside a slider when it depends on other settings ("7 of 20"), and formula,
mathtext lines and a plain line for a control (the window shows the plain line, muted, under the control's widget:
step 3's family of the method) or, for BENCH, the formula of the response and its design space (explorers/responses.py),
which the figure draws.

A Lab declares its controls (explorers.base.Control: a slider, a number field with its quick picks, which may come empty
(Control.empty: its setting None until a number is typed, a student's N), buttons, a check box; shown only for the
settings where they apply; a value of buttons that locked names is drawn locked and never set), computes a state for
the settings, draws it, finds what is under the mouse, and says what to read: compact metrics, each with a tooltip of
one sentence that defines it, an alert when part of the result is outside the window, and a notice when the scale
follows the curve. Settings are a plain dict, so the
window can keep them while the reader visits other steps and benches (state preservation) and give them back.

Two things about room on the figure. The view writes its own alert on the figure's top-right corner: a lab whose figure
has a panel at the right says its alert and its notice on the plot instead. A legend at the top needs a top margin of
32 px (44 px with a titled panel at the right). And a new hook must not take the name of a helper some lab already has
(a command's text is the hook naming; the forward command's key is "advance", which the hook advance, the next frame,
has nothing to do with; the hook cue is the sound's, never a helper's name).
"""
from dataclasses import dataclass
from typing import Any

from statistical_fundamentals.explorers.base import Control
from statistical_fundamentals.explorers.game import TEACHER
from statistical_fundamentals.i18n import get_text

LINK = "why"                               # contextual code access; the key is kept for laboratory state compatibility

@dataclass(frozen=True)
class Metric:
    """One item of the results strip: a small title over a value (rich text). kind: plain, accent, error, ok, warning.
    color: a dot before the title, the colour of the curve or panel the value belongs to; detail: a second, smaller
    line under the value (rich text; detail_kind as kind); strong: the measure the step is judged by, its value drawn
    larger and heavier than the others' within the strip's two lines (a view that ignores it draws it as the others)."""
    title: str
    value: str
    kind: str = "plain"
    tip: str = ""
    color: str = ""
    detail: str = ""
    detail_kind: str = "plain"
    strong: bool = False

@dataclass(frozen=True)
class Table:
    """A small table under the results strip: column headings, rows of formatted numbers, an optional total row, and
    the row to highlight (the item under the mouse). Texts may hold rich text (subscripts)."""
    columns: tuple[str, ...]
    rows: tuple[tuple[str, ...], ...]
    total: tuple[str, ...] = ()
    chosen: int | None = None

@dataclass(frozen=True)
class Action:
    """A command of the lab: it changes the settings, never the data. toggle: an on/off command whose state is
    settings[key] (step 3's validation: on, x* simulated and shown; off, taken back)."""
    key: str
    label: str
    tip: str = ""
    toggle: bool = False
    motion: str = ""                       # "step": plays one step's frames; "run": plays every frame to the end
    playing_label: str = ""                # a "run" command's label while the frames play (Pause)
    top: bool = False                      # a secondary command at the right end of the strip ("View code"), not in the column
    primary: bool = False                  # the lab's main command: filled with the accent, at the column's foot
    quiet: bool = False                    # a discreet command (grey text, like Restore): what is pressed once to land somewhere
    opens: bool = False                    # a command that opens a page (Lab.link), drawn as a link and named by Lab.naming
    forward: bool = False                  # the command that hands the step's result to the next step (Lab.output): the
                                           # window answers it, Lab.act is not called. It is the footer's filled button,
                                           # as a primary command is: a lab has at most one command forward or primary
    icon: str = ""                         # an icon of gui/assets/icons: the command is an icon button of the transport
                                           # row, in the order of Lab.actions; its label is its tooltip and accessible name
    playing_icon: str = ""                 # a "run" command's icon while its frames play ("pause")
    featured: bool = False                 # a prominent command right under the rule, before the controls: outlined in the
                                           # accent and as wide as the column, never filled, with a second muted line
                                           # (Lab.naming of its key)
    mark: str = ""                         # an icon of gui/assets/icons drawn before the text of a chip or of a featured
                                           # command (the text stays: never the icon alone); not `icon`, which makes the
                                           # command an icon button of the transport row. A view may ignore it
    beside: str = ""                       # the key of a typed control in whose row the command stands, at the right of its
                                           # field, instead of among the chips (step 1's New sample beside N: the row is
                                           # hidden with its control); a view that ignores it shows the command as a chip

BENCH = "bench"                            # Lab.formula(BENCH, settings): the formula of the bench's response (the figure's)
TRANSPORT = "transport"                    # Lab.naming(TRANSPORT, state): the name of the stage on screen, under the icons

def page_link() -> Action:
    """Contextual code access. Lab.link identifies the concept for internal compatibility;
    the window opens the active real-Python reading alongside the same experiment."""
    return Action(LINK, get_text("lab.link"), get_text("lab.link_tip"), top=True, opens=True)

class Lab:
    """The base of every laboratory; subclasses set the fields and override the methods they need."""
    controls: tuple[Control, ...] = ()
    actions: tuple[Action, ...] = ()
    height: int = 380                      # pixels: the least height of the figure
    metrics_inside: bool = False          # computed readouts are drawn inside the figure instead of duplicated below
    restore: bool = True                   # the Restore command (a lab may offer its own, e.g. Restart)
    stretch: bool = True                   # the figure takes the height the page gives it; False: it keeps height_for(width)
    frame_ms: int = 600                    # milliseconds between two frames of a motion
    keys_text: str = ""                    # the catalog key of the sentence saying which keys act on the figure (keyboard)
    data: dict = {}                        # settings that are not controls (dragged values, the scale, ...)
    function: str = ""                     # the bench: the key of the response (functions.RESPONSES) the lab works on
    view: tuple[float, float] = (26.0, -58.0)      # the 3D view's elevation and azimuth as the reader left them: a view, not
                                                   # a setting; the window carries it from a step of a study to the next
    mode: str = TEACHER                    # how the application is used (explorers/game.py): given when the lab is made,
                                           # Lab(function, mode); a student's lab offers less and opens on less
    won: bool = False                      # the bench was already completed (the window says so, it is not a setting):
                                           # what a student's lab keeps locked until then (locked) opens
    paid: dict = {}                        # what the study already paid for that no setting keeps (charged), by its key:
                                           # the window keeps it through Restore, a language, a visit, and gives it back
                                           # (a new dict each time: never mutated)

    # ------------------------------------------------------------------ a step of a study (explorers/study.py)
    def output(self, state) -> Any:
        """What this step hands to the next one: a frozen value, compared with ==, from which the next step computes
        everything it needs; None while there is nothing to hand (a metamodel that cannot be computed), and for the
        last step."""
        return None

    def missing(self, state) -> str:
        """One short sentence: why the step cannot hand its result yet; "" when it can."""
        return ""

    def missing_line(self, state) -> str:
        """What the foot's line over the disabled filled button says: missing itself, or a shorter phrase when the
        whole sentence (the button's tooltip) would take the column more than one line it does not have."""
        return self.missing(state)

    def receive(self, settings: dict, handed: Any) -> dict:
        """The settings with the result the previous step handed (never None) in, and whatever must follow it."""
        return settings

    def received(self, state) -> tuple[str, tuple[tuple, ...]]:
        """What the step works on, received from the step before (for the first step, the problem it is given): a
        heading and at most five rows of (label, value) or (label, value, kind), the values in rich text, the kind one
        of Metric's (plain when absent: "warning" or "error" for a quality the step inherits and should be wary of, an
        empty interval, a CoP at or below 0); ("", ()) for no card (its slot in the column stays, empty)."""
        return "", ()

    def summary(self, state) -> tuple[str, str]:
        """What the step is worth in one short plain text, for the cover's track and the pill's tooltip ("empty 0 · 0",
        "CoP 0.858", "f(x*) - f* = 3.16"), and its kind (Metric's); ("", "plain") while there is nothing to say."""
        return "", "plain"

    def finished(self, state) -> int:
        """The stars the state on screen is worth (explorers/game.py): 0 while it does not complete the bench. Only the
        last step of a study answers: the window keeps the best answer of a bench and opens the next one with it."""
        return 0

    def charged(self, state) -> tuple | None:
        """(key, item): a simulation the state on screen paid for that its settings will not keep (step 3: the x*
        validated, by its experiment), which the window adds to paid[key] when it is not there yet; None for none."""
        return None

    def opening(self, handed: Any = None) -> dict:
        """The first settings of the step given `handed` (None: a lab alone): settings with the result received in them
        (receive). A lab whose first settings compute what receiving replaces (a competition) computes only what will
        be shown."""
        settings = self.settings()
        return settings if handed is None else self.receive(settings, handed)

    def hint(self, state) -> str:
        """One short sentence the foot's line says over the filled button while it can be pressed: where to go next
        (a validated study that does not complete the bench); "" for none. The line says missing while it cannot."""
        return ""

    def locked(self, key: str, value: Any, settings: dict) -> str:
        """One short sentence: why the value `value` of the control `key` cannot be chosen now (a student's lab keeps
        some until the bench is complete, won); "" when it can. The window draws a locked value disabled, with a
        padlock and this sentence as its tooltip, and never sets it."""
        return ""

    def height_for(self, width: int) -> int:
        """The least height of the figure, in pixels, for a figure `width` pixels wide (panels stacked when narrow)."""
        return self.height

    def settings(self) -> dict:
        """The initial state: every control at its initial value, and the initial data."""
        return {c.key: c.values[c.initial] for c in self.controls} | {k: v for k, v in self.data.items()}

    def adjust(self, settings: dict, key: str, old: Any) -> dict:
        """The settings after the control `key` changed from `old` (a lab may keep track of what was shown before)."""
        return settings

    def shown(self, control: Control, settings: dict) -> bool:
        return control.visible is None or control.visible(settings)

    def state(self, settings: dict) -> Any:
        raise NotImplementedError

    def draw(self, figure, state, hovered: Any) -> None:
        raise NotImplementedError

    def hit(self, figure, state, event) -> Any:
        """What the mouse is over (an index, a piece), or None."""
        return None

    def grab(self, figure, state, event) -> Any:
        """What a mouse press takes hold of (a point or a handle to drag), or None."""
        return None

    def grabbable(self, hovered) -> bool:
        """Whether what is under the mouse can be dragged (the pointer then becomes a hand)."""
        return False

    def clickable(self, hovered) -> bool:
        """Whether what is under the mouse answers a click (the pointer then becomes a pointing hand)."""
        return False

    def drag(self, figure, state, handle, event, settings: dict) -> dict | None:
        """The settings after moving what was grabbed to the mouse, or None to keep them."""
        return None

    def press(self, key: str, state, settings: dict) -> dict | None:
        """The settings after a key ("left", "right", "up", "down") pressed on the figure, or None."""
        return None

    def act(self, key: str, state, settings: dict) -> dict:
        """The settings after the command `key`; a toggle flips settings[key]."""
        if any(action.key == key and action.toggle for action in self.actions):
            return settings | {key: not settings[key]}
        return settings

    def enabled(self, key: str, state) -> bool:
        return True

    def offered(self, key: str, settings: dict) -> bool:
        """Whether the command `key` is shown for these settings."""
        return True

    def limit(self, key: str, settings: dict) -> int | None:
        """The largest index the slider `key` may take for these settings (its values past it are not offered), or None."""
        return None

    def showing(self, key: str, settings: dict) -> str:
        """The text beside the slider `key` when it depends on other settings ("7 of 20"), or "": the window then
        writes control.show(value)."""
        return ""

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """The formula of the control `key`, or, for the key BENCH, of the bench's response (which the figure draws):
        lines of matplotlib mathtext (the first one the formula, the others its constants) and a plain line (for BENCH
        the design space; for a control, what the window writes muted under its widget, on one line), or ((), "") for
        nothing. The window shows no mathtext of a control."""
        return (), ""

    def rewind(self, key: str, state, settings: dict) -> dict:
        """The settings a "run" command starts from (the run already at its end begins again)."""
        return settings

    def naming(self, key: str, state) -> str:
        """The text of the command `key` for this state, or "" for its own label (a command that names the next step).
        For a featured command, its second, muted line ("Kriging · CoP 0.858"); for the key TRANSPORT, the short name of
        the stage on screen under the transport icons ("iteration 3 of 12 · gradient": a name, not a sentence)."""
        return ""

    def cue(self, key: str, state) -> str:
        """The sound of the command `key` just carried out, given the state after it: "apply", "complete", "better",
        "worse", or "" for none (the window plays it, gui/sounds.py). A command with a motion is asked when its frames
        reach their end (by themselves, or shown at once), never when they start nor on Pause."""
        return ""

    def frame_time(self, settings: dict) -> int:
        """Milliseconds the frame of these settings stays on screen (a short move, or a stage to be read)."""
        return self.frame_ms

    def link(self, key: str, state) -> str:
        """The page the command `key` opens (a fundamentals page), or "" for a command that changes the settings."""
        return ""

    def advance(self, state, settings: dict) -> dict | None:
        """The settings one frame later, or None when there is nothing more to show."""
        return None

    def at_rest(self, settings: dict) -> bool:
        """True between steps: every frame of the last step shown."""
        return True

    def lead(self, state) -> str:
        """One short sentence: what the chosen method does. The window gives it as the figure's accessible
        description."""
        return ""

    def keyboard(self, state) -> str:
        """One sentence for assistive technology only, never on screen: which keys act on the figure in this step (what
        press does), the catalog's text `keys_text`; "" for none. The window gives it after the lead in the figure's
        accessible description, the page as the canvas's aria-describedby."""
        return get_text(self.keys_text) if self.keys_text else ""

    def metrics_in_figure(self, state) -> bool:
        """Whether the figure already displays its computed readouts; omit the duplicate strip."""
        return self.metrics_inside

    def metrics(self, state) -> list[Metric]:
        return []

    def alert(self, state) -> str:
        return ""

    def notice(self, state) -> str:
        """A neutral remark on the figure's corner when there is no alert (the scale follows the curve, for example)."""
        return ""

    def table(self, state, hovered) -> Table | None:
        """The numbers behind the figure, row by row (the item under the mouse highlighted), or None."""
        return None

# ------------------------------------------------------------------------------
# The unit of the labs' layouts
# ------------------------------------------------------------------------------
LAYOUT_DPI = 100                           # the labs' layout pixels: a screen's at 100 % scaling

def size(figure) -> tuple[float, float]:
    """The figure's width and height in layout pixels, the unit of every margin and width the labs lay out with. On a
    denser screen (125 %, 200 %) the canvas raises the figure's dpi and the fonts grow with it; measured at LAYOUT_DPI,
    the margins grow with them, so tick labels, titles and legends keep their room at any scaling."""
    return figure.get_figwidth() * LAYOUT_DPI, figure.get_figheight() * LAYOUT_DPI
