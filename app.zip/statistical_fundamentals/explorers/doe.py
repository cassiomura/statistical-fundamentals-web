# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                              Title: doe.py
# ==============================================================================
"""
Step 1 of a bench, the design of experiments: how the N designs of a study are placed in the design space before any
simulation runs, by the Latin hypercube (sampling.latin_hypercube), by plain random sampling (sampling.monte_carlo), or
by the reader's own hand (the free sampling, FREE: no algorithm at all), on the design space of the bench's response
y = f(x1, x2) (functions.RESPONSES). The laboratory is made for its bench and its reader, SamplingLab(function, mode): the
bench IS the response, so there is no control to choose it. The figure typesets its formula over the 3D view
(panels.typeset, from explorers/responses.py), and the card of the column, received, states the problem the study starts
from (the first step receives nothing from another): the response's name, the interval of x1 and of x2, the goal, to
minimize y.

    The problem          |                                           | f(x1, x2) = ... (the formula, as a paper sets it)
    Sampling             | design space x1, x2: N x N cells, the     | the response y = f(x1, x2), the designs on it
      Latin hypercube    | designs, and along its top and right      | (each one a simulation), their stems down to
      Monte Carlo · Free | edges the count of designs in each        | the floor (dragged with the mouse: it turns)
    Sampling points  N   | interval of x1 and of x2                  |---------------------------------------------
      10 20 40 60        |                                           | design i: its interval on x1 and on x2
    Construction  k of N |                                           | (the rows around the one being placed)
    (undo)  k of N placed|                                           |
    [New sample | Clear] | strip: points | empty intervals | correlation | smallest distance
    [Go to the metamodel ->]
    Restore

The step's result (output) is the Experiment: the bench's response, the sampling, N, the seed and, for the free sampling,
its points, from which the next step computes the designs and their N simulations (simulated, the one source of the
values: the lab's state takes them from it too). For an algorithm it is always available and it is the whole design,
whatever k the Construction slider shows; for the free sampling only once its N points are placed (before, output is
None and missing says how many are left to place). The forward command "Go to the metamodel" hands it on (the window
answers it). Simulated, these N designs are everything the metamodel will know about f: how well they spread (no empty
interval, low correlation, a good smallest distance) is what the next step inherits. The step's summary (the cover's
track, the pill's tooltip) is the empty intervals of the whole design, "empty 0 · 0", an error when any interval is
empty (nothing while a free sample is incomplete).

The free sampling (the owner's "Livre"): N is typed as for the others; the reader then places each point by clicking on
the design space, in the order of the clicks, until N are placed (a click with N placed adds nothing; one on a point
takes it, and a drag moves it; grab, drag). The transport row's icon "undo" removes the last point placed, and the chip
"Clear" (in the place of "New sample", which has nothing to draw again) removes them all. The keyboard does it too: with
the figure focused the arrow keys move a cursor from interval to interval (the centre of a cell) and Enter or Space
places a point there (press). The points are kept in the settings ("points": unit points, in the order placed, rounded
to DECIMALS) and mapped to the bounds only by simulated (sampling.scaled), like every sample; they stay there while the
reader looks at an algorithm's sample, so coming back to "free" finds them; Restore forgets them. N made smaller keeps
the first N points placed (the others are dropped); N made larger keeps them all, and the rest are to place. While
points are being placed, the cell under the pointer (or under the keyboard's cursor) is drawn lightly in the yellow of
the point being placed, with its column, its row and its intervals in the bands, and its row of the table lit: the
reader sees the intervals he is filling. The Construction slider has nothing to replay (the points are the reader's, in
the order he placed them): it stands disabled at 0 and reads a dash; the count is the transport row's "k of N placed"
and the strip's. "View code" reads the measures that judge the sample (gui/lab_code.py, the reading "free"): no
algorithm places it. Two points on the same place are the reader's right: the measures say it (a smallest distance of
0), and the metamodels that cannot be computed on them say so in step 2.

The figure is the bench's shared picture (explorers/panels.py, arrangement with pair="space"): for the same figure size
the design space and the 3D view stand in the same boxes, to the pixel, in the three steps, with the same limits (the
bounds of the response), ticks, axis names and titles' places as the metamodel's and the optimization's; the 3D view has
the metamodel's vertical window (metamodel.truth: the range of f on its grid and 15 % of it on each side) and the angle
the reader left (Lab.view). The design space adds this step's intervals: the grid of N x N cells, the columns and rows
already taken, the cell of the design being placed, and the counts of designs per interval of each axis, as two bands
just inside its top edge (x1) and its right edge (x2), mitred where they meet, so that they never move its box: teal one
design, gold two or more, red and hatched none once the design is complete (never colour alone). The third panel, where
the arrangement has one (the corner, the row and the stack), is the table of the designs: design i takes the i-th entry
of the shuffled list of each axis, intervals numbered from 1, in as many columns of rows as the panel holds, set closer
(TABLE_DENSE) when that lets every design be read at once (the teacher's 40 and 60 in the corner of a large window);
when N is larger than even that, the page of rows that holds the design being placed, and a last line says which rows
are shown. Its legend is one row in every arrangement: the room the plan keeps for a second (the plane's and the 3D
view's legends need it in step 3, so they keep it in every step) is the table's (TABLE_RISE). In the pair (the code
panel open beside the lab) the table is left out.

A teacher's lab (explorers/game.py) opens on the Latin hypercube of the bench's own N (FIRST_POINTS, an N at which the
forward buttons alone complete the bench robustly, chosen by a sweep) with its quick picks; Free is one click away. A
student's N comes EMPTY, with no quick pick (they would suggest the answer): settings["n"] is None, and there is no
design yet. The plane is drawn with its frame, axes and titles but no interval, band or design; the 3D view shows the
response without designs; the table keeps its title and its headings over no row; the strip shows dashes;
Construction stands at 0, its range empty (the window then disables it); New
sample does nothing; output is None and missing says, in one sentence, to type the number of sampling points. Once a
number is typed everything works as for a teacher; Restore and a snapshot with no N give the empty step back.

The two algorithms never look at f: the same sample serves any response, and only its mapping to the bounds changes
with the bench. The free sampling is the reader's, and it sees whatever the reader looks at, the response included: its
lead says so. The 3D view is what the sample is for: each design is evaluated (a simulation, here a call of f), and the
points sit on the surface they will be used to learn.

The slider Construction walks through the one sample computed, never another: at k, the first k designs are placed
(a prefix of the sample, in the order it was drawn) and, for the Latin hypercube while 0 < k < N, point k is shown
inside its marked cell (the k-th entries of the two shuffled lists: its column and row tinted, its row of the table
lit). Two controls on purpose: N chooses the plan, Construction walks through it (a Latin hypercube's first 6 points
are not a Latin hypercube of 6: each axis of the plan has N intervals). The lab opens, and Restore returns, with the
whole design placed (k = N): the reader sees at once what is handed on, and drags Construction back to watch it being
built. Any other change shows the whole design too. The arrow keys on the figure move Construction. The measures are
those of the points placed so far, each with a tip of one sentence that defines it; the lead is one short sentence, the
figure's accessible description. A new sample asks for the sound "apply" (cue), and so do, for the free sampling,
"undo", "Clear", a point placed by Enter or Space and a drag ended ("drag": the window asks for it once a drag that
changed the settings is released).

A student's N comes empty in every sampling: the free sampling needs N typed first (missing says to type it, and a click
places nothing). In a student's empty step, and whenever no design is drawn, the legends list nothing of the designs (no
entry for what is not on the figure).

Margins are layout pixels (explorers/lab.size), never figure.dpi; the axes are reused between redraws while the
figure's size holds, so the 3D view keeps the angle the reader turned it to, and the formula is typeset once per layout.
What depends only on N, on whether any design is shown and on the language (the frames, the intervals, the response's
surface, the titles and legends: scene_of) is the scene, drawn once; the designs, the cells and bands, the table's rows
are drawn again at every draw (moving), as steps 2 and 3 do: the pointer going from cell to cell redraws only them.
"""
from dataclasses import dataclass
from functools import cache, lru_cache
from math import ceil
from random import Random

import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch, Polygon, Rectangle

from statistical_fundamentals import palette
from statistical_fundamentals.benches import TITLES
from statistical_fundamentals.explorers.base import Control, nearest, short, style_axes
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.lab import BENCH, LINK, TRANSPORT, Action, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.panels import (LEGEND_ROW, STACK_WIDTH, arrangement, dot, head, places, space_ticks,
                                                       typeset)
from statistical_fundamentals.explorers.responses import FORMULAS, formula
from statistical_fundamentals.functions import RESPONSES, Response
from statistical_fundamentals.i18n import current_language, get_text
from statistical_fundamentals.measures import correlation, empty_intervals, interval_counts, smallest_distance
from statistical_fundamentals.sampling import latin_hypercube, monte_carlo, scaled

ALGORITHMS = ("lhs", "mc")            # the samplings an algorithm draws (sampling.py)
FREE = "free"                         # the reader's own sampling: every point placed by hand, no algorithm
METHODS = (*ALGORITHMS, FREE)
DECIMALS = 4                          # a point placed by hand is kept to this many decimals of the unit square
POINTS = tuple(range(5, 101))         # N, the number of designs: 5 at least, one per subset of step 2's cross-validation
CONSTRUCTION = tuple(range(0, 101))   # k, the designs placed so far: 0 to N (Lab.limit)
SHORTCUTS = (10, 20, 40, 60)
FIRST_POINTS = {"branin": 60, "himmelblau": 40, "rosenbrock": 40}     # the teacher's N of each bench, from a sweep of N over
                                      # ten samples (2026-11-15), chosen for robustness, not as the least N that completes:
                                      # the share of the ten samples that the forward buttons alone complete
                                      # (explorers/game.py) holds over N ± 5 around it (Branin 8 of 10 from N = 55,
                                      # Himmelblau 10 of 10 from N = 30; Rosenbrock has no robust N: 40, 4 of 10, is its
                                      # best share), the first seed among those that complete
FUNCTIONS = tuple(RESPONSES)          # the benches, by the key of their response
FIRST_SEED = 27                       # the first sample: kept from the first cover's picture (its N = 6 sample has no design
                                      # on a grid line): chosen to be read, not for its statistics
GRID = 46                             # samples per axis of the drawn surface
HEIGHT = 440                          # layout pixels: the least height of the figure, the same in the three steps (400 before the
                                      # formula's block and the legends' two rows: the design space keeps about its side)
LABEL_MOST = 30                       # the counts are written in the bands of the intervals up to this N
# The figure's layout, in layout pixels (explorers/lab.size); the panels' boxes are explorers/panels.py's
BAND = 12.0                           # the bands of the counts, inside the top and right edges of the design space
CELL_LEAST = 8.0                      # a count is written only in an interval at least this wide
TABLE_ROW, TABLE_COLUMN, TABLE_MOST = 19.0, 112.0, 150.0     # the table: a row; a column of rows (i, x1, x2) at least, at most
TABLE_FONT = 9.5                      # points: the table's numbers
TABLE_DENSE = (15.0, 82.0, 8.5)       # the table set closer (a row, a column at least, the font) when that holds every design
TABLE_RISE = LEGEND_ROW / 2           # the table's legend is one row, in every arrangement: the room of the second is the table's
DASH = "—"                            # a measure that has nothing to measure yet
VIEW = (26.0, -58.0)                  # elevation and azimuth of the 3D view, until the reader turns it
SPACE_ZOOM = 1.0                      # the 3D box in its square (panels.reach gives the square its room): a larger one puts
                                      # its tick labels on the third panel's title, or out of the figure at the right
RAMP = LinearSegmentedColormap.from_list("response", palette.SURFACE_RAMP)
CHOSEN = palette.YELLOW               # the point being placed, its cell, its row of the table
POINT = palette.BLUE
ONE, MORE, EMPTY = palette.TEAL, palette.GOLD, palette.RED
LABEL = {"color": palette.GREY, "fontsize": 10}

@dataclass(frozen=True)
class Design:
    """One sample of the unit square, in the order it was drawn (or, for the free sampling, placed), and the interval
    of each point on each axis."""
    method: str
    n: int
    seed: int
    unit: tuple[tuple[float, float], ...]
    cells: tuple[tuple[int, int], ...]

@lru_cache(maxsize=4096)
def design(method: str, n: int, seed: int, points: tuple = ()) -> Design:
    """The sample of a sampling: an algorithm's N points drawn from the seed, or the free sampling's points as the reader
    placed them (at most N of them: fewer while they are being placed)."""
    if method == FREE:
        sample = points[:n]
    else:
        sample = latin_hypercube(n, 2, Random(seed)) if method == "lhs" else monte_carlo(n, 2, Random(seed))
    unit = tuple((float(u1), float(u2)) for u1, u2 in sample)
    cells = tuple((min(int(u1 * n), n - 1), min(int(u2 * n), n - 1)) for u1, u2 in unit)
    return Design(method, n, seed, unit, cells)

@dataclass(frozen=True)
class Experiment:
    """Step 1's result, handed to the metamodel: which response was sampled, how, with how many designs, from which
    seed (step 2's cross-validation deals its subsets from it, whatever the sampling) and, for the free sampling, at
    which points of the unit square (in the order they were placed; () for an algorithm, whose points the seed gives).
    Everything else is computed from it (design, simulated), so two experiments are the same study when they are equal:
    two free samples only when their points are."""
    function: str
    method: str
    n: int
    seed: int
    points: tuple[tuple[float, float], ...] = ()

@dataclass(frozen=True)
class Simulated:
    """The N simulations of an experiment: its designs in the unit square, in the order they were drawn, the same
    mapped to the bounds of the response, and y = f at each one."""
    unit: tuple[tuple[float, float], ...]
    points: tuple[tuple[float, float], ...]
    values: tuple[float, ...]

def first_experiment(function: str) -> Experiment:
    """The experiment a bench opens on: the first sample of the laboratory."""
    return Experiment(function, METHODS[0], FIRST_POINTS[function], FIRST_SEED)

@lru_cache(maxsize=4096)
def simulated(experiment: Experiment) -> Simulated:
    """The designs of the experiment, simulated: no algorithm looks at f, the response is called only here, once per
    design (a free experiment's points as the reader placed them; bounded, since every move of a dragged point is
    another experiment)."""
    response = RESPONSES[experiment.function]
    unit = design(experiment.method, experiment.n, experiment.seed, experiment.points).unit
    points = tuple((x1, x2) for x1, x2 in scaled([list(u) for u in unit], list(response.bounds)))
    values = tuple(float(response.f(x1, x2)) for x1, x2 in points)
    return Simulated(unit, points, values)

@cache
def surface(key: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """The response on a GRID x GRID grid of its design space: the surface drawn, never a value measured."""
    response = RESPONSES[key]
    (a1, b1), (a2, b2) = response.bounds
    x1, x2 = np.meshgrid(np.linspace(a1, b1, GRID), np.linspace(a2, b2, GRID))
    return x1, x2, response.f(x1, x2)

def window(key: str) -> tuple[float, float, float]:
    """The vertical window of the 3D view, the metamodel's (metamodel.truth: the range of f on its grid and a share of it
    on each side), the same in the three steps of a bench; and that share."""
    from statistical_fundamentals.explorers.metamodel import truth      # here: metamodel imports this module
    true = truth(key)
    low, high = float(true.y.min()), float(true.y.max())
    return true.low, true.high, (low - true.low) / (high - low)

@dataclass(frozen=True)
class SampleState:
    experiment: Experiment | None               # None while no N is typed (a student's step opens so): nothing to hand
    method: str
    n: int | None
    response: Response
    design: Design | None
    points: tuple[tuple[float, float], ...]     # every design, mapped to the bounds (simulated)
    values: tuple[float, ...]                   # y = f at every design (simulated)
    shown: int                                  # k, the points placed so far (the free sampling: those the reader placed)
    cursor: tuple[float, float] | None = None   # the free sampling: the keyboard's cursor in the unit square, or None

    @property
    def empty(self) -> bool:
        """No design yet: N is not typed."""
        return self.n is None

    @property
    def free(self) -> bool:
        """The reader places the points (the free sampling)."""
        return self.method == FREE

    @property
    def filling(self) -> bool:
        """Points are still to place by hand: the free sampling, N typed, fewer than N placed."""
        return self.free and not self.empty and self.shown < self.n

    @property
    def placing(self) -> int | None:
        """The index of the point shown inside its marked cell (point k, the last one placed, counted from 0): a Latin
        hypercube halfway built; None at k = 0, at k = N and for Monte Carlo (its points have no cell drawn in advance)."""
        return self.shown - 1 if self.method == "lhs" and not self.empty and 0 < self.shown < self.n else None

    @property
    def complete(self) -> bool:
        return not self.empty and self.shown == self.n

    def column(self, axis: int) -> list[float]:
        """The coordinates in [0, 1) of the points placed, on one axis."""
        return [] if self.empty else [u[axis] for u in self.design.unit[:self.shown]]

class SamplingLab(Lab):
    """Step 1 of a bench: the Latin hypercube against Monte Carlo, point by point, or the reader's own points, beside
    the response the points will be used to learn; the whole design handed to the metamodel."""

    def __init__(self, function: str = FUNCTIONS[0], mode: str = TEACHER):
        """The lab of a bench, opening on its first experiment with the whole design placed (Construction at k = N); a
        student's, on no design at all (its N empty, no quick pick)."""
        self.function = RESPONSES[function].key
        self.mode = mode
        first = FIRST_POINTS[self.function]
        student = mode == STUDENT
        self.controls = (
            Control("method", get_text("lab.lhs.method"), METHODS, 0,
                    names=tuple(get_text(f"lab.lhs.method.{m}") for m in METHODS), tip=get_text("lab.lhs.method_tip")),
            Control("n", get_text("lab.lhs.points"), POINTS, POINTS.index(first), show=lambda n: f"N = {n}",
                    shortcuts=() if student else SHORTCUTS, typed=True, symbol="N", tip=get_text("lab.lhs.points_tip"),
                    empty=student),
            Control("shown", get_text("lab.lhs.construction"), CONSTRUCTION, CONSTRUCTION.index(first), show=str,
                    tip=get_text("lab.lhs.construction_tip")),
        )
        self.actions = (
            page_link(),
            Action("undo", get_text("lab.lhs.undo"), get_text("lab.lhs.undo_tip"), icon="undo"),
            Action("new", get_text("lab.lhs.new"), get_text("lab.lhs.new_tip")),
            Action("clear", get_text("lab.lhs.clear"), get_text("lab.lhs.clear_tip")),
            Action("advance", get_text("lab.lhs.advance"), get_text("lab.lhs.advance_tip"), forward=True),
        )
        self.data = {"seed": FIRST_SEED, "points": (), "cursor": None}     # the free sampling's points and keyboard cursor
        self.by_hand = False                   # the state drawn last is a free sample with N typed: its points are dragged
        self.restore = True
        self.height = HEIGHT                   # the least height, the metamodel's: the three steps get the same figure
        self.tip = get_text("lab.lhs.figure_tip")
        self.view = VIEW                       # the 3D view as the reader left it (a view, not a setting)
        self.layout_key = None                 # the axes on the figure are reused while their layout holds
        self.axes: dict = {}
        self.plan = None
        self.heads: dict = {}
        self.written = None                    # the formula of the response, typeset once per layout
        self.scene = None                      # what the axes hold that stays while the pointer moves (scene_of)
        self.moving: list = []                 # the artists drawn again at every draw: the designs, the cells, the bands

    def height_for(self, width: int) -> int:
        """Side by side, in a row or in the corner, the lab's own height; stacked, the three blocks one under the other
        (the shared plan's)."""
        if width >= STACK_WIDTH:
            return self.height
        return round(arrangement(width, None, pair="space", fill=True).room)

    def settings(self) -> dict:
        """The first settings: the bench's first experiment, whole; a student's, no N and nothing placed."""
        first = super().settings()
        return first | {"n": None, "shown": 0} if self.mode == STUDENT else first

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> SampleState:
        """The state of the settings: the experiment they describe and its simulations, or no design while N is None (a
        "choosing" left by the snapshot of an older laboratory, or a "function", is ignored: the bench is the lab's)."""
        n = settings.get("n")
        method = settings["method"]
        cursor = settings.get("cursor")
        cursor = None if cursor is None else (float(cursor[0]), float(cursor[1]))
        if n is None:
            return SampleState(None, method, None, RESPONSES[self.function], None, (), (), 0, cursor)
        if method == FREE:                                          # the points the reader placed, the first N of them
            placed = placed_points(settings)
            experiment = Experiment(self.function, FREE, n, settings["seed"], placed)
            shown = len(placed)
        else:
            experiment = Experiment(self.function, method, n, settings["seed"])
            shown = min(settings["shown"], n)
        simulations = simulated(experiment)
        sample = design(experiment.method, experiment.n, experiment.seed, experiment.points)
        return SampleState(experiment, experiment.method, experiment.n, RESPONSES[self.function], sample, simulations.points,
                           simulations.values, shown, cursor)

    def output(self, state: SampleState) -> Experiment | None:
        """The whole design, whatever k the Construction slider shows: the experiment, from which the next step
        computes the designs and their simulations; None while there is no N, and while a free sample has fewer than N
        points."""
        if state.empty or state.filling:
            return None
        return state.experiment

    def missing(self, state: SampleState) -> str:
        """Why there is nothing to hand: no N typed yet, or the points of a free sample still to place."""
        if state.empty:
            return get_text("lab.lhs.missing")
        if state.filling:
            left = state.n - state.shown
            return get_text("lab.lhs.missing.free_one") if left == 1 else get_text("lab.lhs.missing.free", left=left)
        return ""

    def received(self, state: SampleState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """The card of the problem the study starts from (the first step receives nothing from another): the response
        by its name (a person's, never translated), the interval of x1 and of x2 (the design space, from the bounds of
        the response, written as the notation [a, b], the same in both languages) and the goal, to minimize y."""
        (a1, b1), (a2, b2) = state.response.bounds
        rows = ((get_text("lab.lhs.problem.response"), TITLES[state.response.key], "plain"),
                ("x₁", f"[{short(a1)}, {short(b1)}]", "plain"),
                ("x₂", f"[{short(a2)}, {short(b2)}]", "plain"),
                (get_text("lab.lhs.problem.goal"), get_text("lab.lhs.problem.minimize"), "plain"))
        return get_text("lab.lhs.problem"), rows

    def cue(self, key: str, state: SampleState) -> str:
        """The sound of a command just carried out: a new sample changed the study on screen ("apply"); in the free
        sampling, so did "undo", "Clear", a point placed by Enter or Space, and a drag ended ("drag": a point placed by
        a click or moved; the window asks once, when the button is released)."""
        if state.empty:
            return ""
        if key == "new":
            return "apply"
        return "apply" if state.free and key in ("undo", "clear", "drag", "enter", "space") else ""

    def enabled(self, key: str, state: SampleState) -> bool:
        """New sample needs a design to draw again; "undo" and "Clear", a point placed."""
        if key == "new":
            return not state.empty
        if key in ("undo", "clear"):
            return state.free and state.shown > 0
        return True

    def offered(self, key: str, settings: dict) -> bool:
        """New sample for an algorithm (there is something to draw again); "undo" and "Clear" for the free sampling."""
        if key == "new":
            return settings.get("method") != FREE
        if key in ("undo", "clear"):
            return settings.get("method") == FREE
        return True

    def naming(self, key: str, state: SampleState) -> str:
        """Under the transport row, in the free sampling, how many points are placed ("12 of 20 placed")."""
        if key == TRANSPORT and state.free and not state.empty:
            return get_text("lab.lhs.transport", k=state.shown, n=state.n)
        return ""

    def summary(self, state: SampleState) -> tuple[str, str]:
        """What the step is worth, for the cover's track and the pill's tooltip: the empty intervals of the complete
        design on x1 and x2 (what is handed on, whatever Construction shows), an error when any interval is empty, as
        the strip paints them once the design is complete; nothing while there is no design, nor while a free sample is
        incomplete."""
        if state.empty or state.filling:
            return "", "plain"
        n = state.n
        empty = tuple(empty_intervals([u[axis] for u in state.design.unit], n) for axis in (0, 1))
        return get_text("lab.lhs.summary", x1=empty[0], x2=empty[1]), "error" if sum(empty) else "ok"

    def adjust(self, settings: dict, key: str, old) -> dict:
        """Construction moved: only k changes (held at N). Another sampling or size: the whole design at once (k = N);
        no N, nothing placed. N typed smaller keeps the first N points of a free sample (the later ones are dropped);
        larger, every point placed, the rest to place. Another sampling keeps the free sample's points as they are: an
        algorithm's sample is computed as always, and coming back to "free" finds them."""
        n = settings.get("n") or 0
        if key == "shown":
            return settings | {"shown": min(settings["shown"], n)}
        if key == "n" and settings.get("n") is not None:
            settings = settings | {"points": placed_points(settings)}
        return settings | {"shown": n}

    def limit(self, key: str, settings: dict) -> int | None:
        """Construction runs over 0..N (its index is k); with no N, over 0 alone, and for the free sampling too (it has
        nothing to replay: the window then disables it)."""
        if key != "shown":
            return None
        return 0 if settings.get("method") == FREE else (settings.get("n") or 0)

    def showing(self, key: str, settings: dict) -> str:
        """Construction reads "k of N"; a dash while there is no N, and for the free sampling (its count is the
        transport row's and the strip's)."""
        if key != "shown":
            return ""
        if settings.get("n") is None or settings.get("method") == FREE:
            return DASH
        return get_text("lab.lhs.construction_value", k=min(settings["shown"], settings["n"]), n=settings["n"])

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """For the key BENCH, the formula of the bench's response (one line of mathtext; the figure typesets it,
        panels.typeset); nothing for a control."""
        return formula(self.function) if key == BENCH else ((), "")

    def press(self, key: str, state, settings: dict) -> dict | None:
        """The left and right arrow keys move Construction by one point; at its ends the key is still its own (the
        settings unchanged), never passed on to the field of N. In the free sampling the four arrow keys move the
        cursor by one interval (from the centre of a cell to the next; the first press shows it in the middle of the
        design space) and Enter or Space ("enter", "space") places a point at it, while fewer than N are placed; with no
        N the keys are still the figure's, and do nothing."""
        if settings.get("method") == FREE:
            return by_key(key, settings)
        if key not in ("left", "right"):
            return None
        k = settings["shown"] + (1 if key == "right" else -1)
        return settings | {"shown": max(0, min(k, settings.get("n") or 0))}

    def act(self, key: str, state, settings: dict) -> dict:
        """New sample: the next seed, the whole design at once (nothing while there is no N). The free sampling's
        "undo": the last point placed removed; "Clear": every point."""
        if key == "new":
            return settings if settings.get("n") is None else settings | {"seed": settings["seed"] + 1, "shown": settings["n"]}
        if key == "undo":
            return settings | {"points": placed_points(settings)[:-1]}
        if key == "clear":
            return settings | {"points": ()}
        return super().act(key, state, settings)

    def link(self, key: str, state) -> str:
        """"View code" asks the window for the reading of the sampling on screen (gui/lab_code.py): for the free
        sampling, "free", the measures that judge it (no algorithm places it)."""
        return state.method if key == LINK else ""

    # ------------------------------------------------------------------ what to read
    def lead(self, state: SampleState) -> str:
        if state.empty:
            return get_text("lab.lhs.lead.empty")
        if state.placing is not None:
            k1, k2 = state.design.cells[state.placing]
            return get_text("lab.lhs.lead.placing", i=state.placing + 1, k1=k1 + 1, k2=k2 + 1, n=state.n)
        return get_text(f"lab.lhs.lead.{state.method}")          # the free sampling's says it is the reader's, no algorithm's

    def metrics(self, state: SampleState) -> list[Metric]:
        """The designs placed, the empty intervals, the correlation and the smallest distance, of the points placed so
        far; dashes while there is no design."""
        if state.empty:
            return [Metric(get_text("lab.lhs.m.points"), DASH, tip=get_text("lab.lhs.m.points_tip")),
                    Metric(get_text("lab.lhs.m.empty"), DASH, detail=get_text("lab.lhs.m.empty_detail"),
                           tip=get_text("lab.lhs.m.empty_tip")),
                    Metric(get_text("lab.lhs.m.correlation"), DASH, tip=get_text("lab.lhs.m.correlation_tip")),
                    Metric(get_text("lab.lhs.m.distance"), DASH, detail=get_text("lab.lhs.m.distance_detail"),
                           tip=get_text("lab.lhs.m.distance_tip"))]
        n = state.n
        xs, ys = state.column(0), state.column(1)
        empty = (empty_intervals(xs, n), empty_intervals(ys, n))
        complete = state.complete
        result = [Metric(get_text("lab.lhs.m.points"), get_text("lab.lhs.m.points_value", shown=state.shown, n=n),
                         detail=get_text("lab.lhs.m.points_detail", count=state.shown), tip=get_text("lab.lhs.m.points_tip"))]
        result.append(Metric(get_text("lab.lhs.m.empty"), f"{empty[0]}  ·  {empty[1]}",
                             kind=("error" if sum(empty) else "ok") if complete else "plain",
                             detail=get_text("lab.lhs.m.empty_detail"), tip=get_text("lab.lhs.m.empty_tip")))
        rho = pearson(xs, ys) if state.shown >= 3 else None
        result.append(Metric(get_text("lab.lhs.m.correlation"), DASH if rho is None else f"{rho:+.3f}",
                             tip=get_text("lab.lhs.m.correlation_tip")))
        spread = smallest_distance([list(u) for u in state.design.unit[:state.shown]]) if state.shown >= 2 else None
        result.append(Metric(get_text("lab.lhs.m.distance"), DASH if spread is None else f"{spread:.3f}",
                             detail=get_text("lab.lhs.m.distance_detail"), tip=get_text("lab.lhs.m.distance_tip")))
        return result

    # ------------------------------------------------------------------ the mouse
    def hit(self, figure, state: SampleState, event):
        """The design under the mouse in the design space (its index); in a free sample still to fill, over an empty
        place, the cell a click would put the next point in, ("cell", k1, k2); or None."""
        ax = self.axes.get("plane")
        if ax is None or event is None or event.inaxes is not ax:
            return None
        found = nearest(ax, state.points[:state.shown], event) if state.shown else None
        if found is None and state.filling:
            k1, k2 = cell_of(unit_of(ax, state, event), state.n)
            return ("cell", k1, k2)
        return found

    def grabbable(self, hovered) -> bool:
        """A design of a free sample can be dragged."""
        return self.by_hand and design_index(hovered) is not None

    def clickable(self, hovered) -> bool:
        """An empty place of a free sample still to fill answers a click: a point is placed there."""
        return isinstance(hovered, tuple)

    def grab(self, figure, state: SampleState, event):
        """In the free sampling, a press on a design takes it (its index); one on an empty place, while fewer than N are
        placed, takes the next point, the index it will have (drag puts it under the mouse at once: a click places it,
        a drag places it and moves it); with N placed, nothing."""
        ax = self.axes.get("plane")
        if not state.free or state.empty or ax is None or event is None or event.inaxes is not ax:
            return None
        found = nearest(ax, state.points[:state.shown], event) if state.shown else None
        if found is not None:
            return found
        return state.shown if state.shown < state.n else None

    def drag(self, figure, state: SampleState, handle, event, settings: dict) -> dict | None:
        """The point grabbed moved under the mouse, kept inside the unit square (also from over another panel: on the
        border); the next point placed there; None when nothing moves."""
        ax = self.axes.get("plane")
        n = settings.get("n")
        if settings.get("method") != FREE or n is None or ax is None or design_index(handle) is None or event is None:
            return None
        u = unit_of(ax, state, event)
        points = list(placed_points(settings))
        if handle < len(points):
            if points[handle] == u:
                return None
            points[handle] = u
        elif handle == len(points) < n:
            points.append(u)
        else:
            return None
        return settings | {"points": tuple(points)}

    # ------------------------------------------------------------------ the figure
    def boxes(self, figure) -> dict:
        """The panels' boxes and the places of their titles, in figure fractions, from the shared plan in layout pixels:
        the design space and the 3D view where the other steps have theirs; the table in the third panel's block,
        where the arrangement has one."""
        width, height = size(figure)
        plan = arrangement(width, height, pair="space", fill=True)

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)     # a box is never empty
        boxes = {"plane": frac(*plan.plane), "space": frac(*plan.space)}
        heads = places(plan, width, height, ("plane", "space"))
        if plan.check is not None:                                   # the third panel's block (a table has no ticks: in a
            left, bottom, wide, tall = plan.check if plan.kind == "stack" else plan.ranking    # row or the corner it takes
            boxes["table"] = frac(left, bottom, wide, tall + TABLE_RISE)                        # their room too), and the
            heads["table"] = places(plan, width, height, ("check",))["check"]                  # room of a second row of legend
        boxes["heads"] = heads
        return boxes

    def prepare(self, figure, state: SampleState) -> dict:
        """The axes of the figure: made again when the figure's size changes, with the formula of the response typeset
        in its block (panels.typeset), and reused otherwise (the 3D view keeps the angle the reader turned it to); what
        they hold is the scene's, kept, and the moving artists', drawn again (draw)."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height))
        space = self.axes.get("space")
        if space is not None and space.figure is figure:               # turned with the mouse since the last draw
            self.view = (space.elev, space.azim)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = arrangement(width, height, pair="space", fill=True)
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "table") if name in boxes}
            self.axes["space"] = figure.add_axes(boxes["space"], projection="3d")
            self.axes["plane"].set_zorder(1)                          # its last x1 tick label overhangs the 3D box: above it
            self.heads = boxes["heads"]
            self.written = typeset(figure, self.heads, FORMULAS[self.function])      # once per layout: it never changes here
            self.layout_key = key
            self.scene = None                                         # new axes: nothing on them yet
            self.moving = []
        return self.axes

    def draw(self, figure, state: SampleState, hovered) -> None:
        """The three panels with their titles and legends; a legend lists only what the figure draws (no entry of the
        designs while none is placed: a student's empty step, a free sample not begun, Construction at 0). The scene
        (scene_of: what depends only on N, whether any design is shown and the language) is drawn once; the rest, the
        designs, the intervals taken, the cell under the pointer, the bands and the table's rows, at every draw
        (moving): a pointer going from cell to cell, a point placed or dragged and Construction redraw only them."""
        axes = self.prepare(figure, state)
        self.by_hand = state.free and not state.empty                # hit and grab answer for the axes drawn here
        scene = scene_of(state)
        if self.scene != scene:
            self.draw_scene(figure, axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        self.draw_plane(axes["plane"], state, hovered)
        self.draw_bands(axes["plane"], state, hovered)
        self.draw_space(axes["space"], state, hovered)
        if "table" in axes:
            self.draw_table(axes["table"], state, hovered)
        axes["space"].view_init(*self.view)

    def draw_scene(self, figure, axes: dict, state: SampleState) -> None:
        """What stays while the pointer moves and the points are placed: the design space's frame, axes and intervals,
        the response's surface and the floor of the 3D view, the table's frame, and every title and legend (the axes
        cleared first, unless they are new; the formula kept: it is drawn once per layout)."""
        if self.scene is not None:
            for ax in axes.values():
                ax.clear()
            for text in list(figure.texts):
                if text is not self.written:
                    text.remove()
            for legend in list(figure.legends):
                legend.remove()
        self.moving = []
        drawn = state.shown > 0
        self.frame_plane(axes["plane"], state)
        titled(figure, self.heads, axes, "plane", get_text("lab.lhs.plane_title"), [
            Patch(facecolor=ONE, edgecolor=palette.CARD, label=get_text("lab.lhs.legend.one")),
            Patch(facecolor=MORE, edgecolor=palette.CARD, label=get_text("lab.lhs.legend.more")),
            Patch(facecolor="none", edgecolor=EMPTY, hatch="////", label=get_text("lab.lhs.legend.empty"))] if drawn else [])
        self.frame_space(axes["space"], state)
        titled(figure, self.heads, axes, "space", get_text("lab.lhs.space_title"), [
            Patch(facecolor=palette.SURFACE_RAMP[3], label=get_text("lab.lhs.legend.surface")),
            *([dot(POINT, get_text("lab.lhs.legend.designs"))] if drawn else [])])
        if "table" in axes:
            frame_table(axes["table"])
            titled(figure, self.heads, axes, "table", get_text("lab.lhs.table_title"), [
                Patch(facecolor=palette.PILL, edgecolor=CHOSEN, label=get_text("lab.lhs.legend.lit"))] if not state.empty else [])

    def frame_plane(self, ax, state: SampleState) -> None:
        """The design space's frame, axes, ticks and names, those of the other steps' design space, and its N intervals
        per axis (none without N)."""
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        (a1, b1), (a2, b2) = state.response.bounds
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        ax.set_xlabel("x₁", **LABEL, labelpad=2)
        ax.set_ylabel("x₂", **LABEL, labelpad=9, rotation=0, va="center")
        if state.empty:                                               # no N: the frame and its axes, nothing in it
            return
        n = state.n
        h1, h2 = (b1 - a1) / n, (b2 - a2) / n
        grid ={"color": palette.DARK_GREY, "linewidth": 0.8 if n <= 30 else 0.5, "alpha": 0.9 if n <= 30 else 0.6, "zorder": 1}
        for k in range(1, n):
            ax.axvline(a1 + k * h1, **grid)
            ax.axhline(a2 + k * h2, **grid)

    def draw_plane(self, ax, state: SampleState, hovered) -> None:
        """In the design space, the points placed and the cell of the point being placed (in a free sample still to
        fill, the cell under the pointer or the keyboard's cursor, lighter, and the cursor itself): moving artists."""
        if state.empty:
            return
        moving = self.moving
        (a1, b1), (a2, b2) = state.response.bounds
        n = state.n
        h1, h2 = (b1 - a1) / n, (b2 - a2) / n
        if state.method in ("lhs", FREE) and not state.complete:    # the columns and rows already taken
            for k1, k2 in state.design.cells[:state.shown]:
                moving.append(ax.axvspan(a1 + k1 * h1, a1 + (k1 + 1) * h1, color=ONE, alpha=0.07, linewidth=0, zorder=0))
                moving.append(ax.axhspan(a2 + k2 * h2, a2 + (k2 + 1) * h2, color=ONE, alpha=0.07, linewidth=0, zorder=0))
        cell = target(state, hovered)
        if cell is not None:                                          # the column, the row and the cell of point k
            k1, k2 = cell
            light = state.free                                       # where the next click would put it: lighter
            moving.append(ax.axvspan(a1 + k1 * h1, a1 + (k1 + 1) * h1, color=CHOSEN, alpha=0.08 if light else 0.13, linewidth=0,
                                     zorder=2))
            moving.append(ax.axhspan(a2 + k2 * h2, a2 + (k2 + 1) * h2, color=CHOSEN, alpha=0.08 if light else 0.13, linewidth=0,
                                     zorder=2))
            moving.append(ax.add_patch(Rectangle((a1 + k1 * h1, a2 + k2 * h2), h1, h2, facecolor=CHOSEN, edgecolor=CHOSEN,
                                                 alpha=0.22 if light else 0.35, linewidth=1.0 if light else 1.5, zorder=3)))
        size_ = marker_size(n)
        if state.filling and state.cursor is not None:                # the keyboard's cursor: Enter places a point here
            u1, u2 = state.cursor
            moving.append(ax.scatter([a1 + (b1 - a1) * u1], [a2 + (b2 - a2) * u2], s=size_ * 2.2, marker="+", color=CHOSEN,
                                     linewidths=1.6, zorder=7))
        placed = state.points[:state.shown]
        if placed:
            xs, ys = zip(*placed)
            colors = [POINT] * len(placed)
            if not state.complete:
                colors[-1] = CHOSEN                                   # point k, the last one placed
            moving.append(ax.scatter(xs, ys, s=size_, c=colors, edgecolors=palette.CARD, linewidths=0.9, zorder=6))
        pointed = design_index(hovered)
        if pointed is not None and pointed < state.shown:
            x1, x2 = state.points[pointed]
            moving.append(ax.scatter([x1], [x2], s=size_ * 2.6, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4,
                                     zorder=7))

    def draw_bands(self, ax, state: SampleState, hovered=None) -> None:
        """How many points each interval holds, in two bands inside the design space's edges, BAND pixels thick: x1's
        intervals along the top, x2's along the right, mitred where they meet. One point teal, more gold (the count
        written while the intervals are wide enough), none red, hollow and hatched once the design is complete; the
        intervals of point k, while it is shown inside its cell (in a free sample still to fill, those of the cell under
        the pointer or the cursor), yellow. Drawn under the points; none without N. Moving artists."""
        if state.empty:
            return
        moving = self.moving
        side = ax.get_position().height * size(ax.figure)[1]
        t = min(BAND / max(side, 1.0), 0.2)                           # the band's thickness, in fractions of the plane's side
        n = state.n
        moving.append(ax.add_patch(Polygon([(0, 1), (1, 1), (1, 0), (1 - t, 0), (1 - t, 1 - t), (0, 1 - t)], closed=True,
                                           transform=ax.transAxes, facecolor=palette.TRACK, edgecolor="none", zorder=4)))
        marked = target(state, hovered)
        thin = 0.5 if side / n < 6 else 1.0
        for axis in (0, 1):
            counts = interval_counts(state.column(axis), n)
            for k, count in enumerate(counts):
                chosen = marked is not None and marked[axis] == k
                hatched = count == 0 and state.complete
                if chosen:
                    face, edge = CHOSEN, palette.CARD
                elif hatched:
                    face, edge = "none", EMPTY
                elif count == 0:
                    continue                                          # not yet visited: the band's own track
                else:
                    face, edge = (ONE if count == 1 else MORE), palette.CARD
                low, high = k / n, (k + 1) / n
                if axis == 0:
                    cell = mitred([(low, 1 - t), (high, 1 - t), (high, 1.0), (low, 1.0)], above=True)
                else:
                    cell = mitred([(1 - t, low), (1.0, low), (1.0, high), (1 - t, high)], above=False)
                if len(cell) < 3:
                    continue
                moving.append(ax.add_patch(Polygon(cell, closed=True, transform=ax.transAxes, facecolor=face, edgecolor=edge,
                                                   linewidth=thin, hatch="////" if hatched else None, zorder=5)))
                if count >= 2 and n <= LABEL_MOST and side / n >= CELL_LEAST:
                    x = sum(p[0] for p in cell) / len(cell)
                    y = sum(p[1] for p in cell) / len(cell)
                    moving.append(ax.text(x, y, str(count), transform=ax.transAxes, ha="center", va="center", fontsize=7,
                                          color=palette.CARD, fontweight="bold", zorder=5))

    def draw_table(self, ax, state: SampleState, hovered) -> None:
        """The designs as a table, one row each, read as the algorithm builds them: design i takes the i-th entry of the
        shuffled list of each axis (intervals numbered from 1; the code counts from 0). The lists of a Latin hypercube
        exist before any point; the intervals of a random point are known only once it is drawn. The rows run down
        columns of rows (i, x1, x2) side by side, as many as the panel holds, closer when that holds every design; a
        longer design shows the page of rows that holds the design in focus (table_page), and its last line says which
        rows those are. A free sample's rows are those of the points placed, and, while a cell is pointed at, the next
        row lit with the intervals a click there would give it. Without N, the headings of one column over no row. Moving
        artists, on the frame of frame_table."""
        moving = self.moving
        width, height = table_room(ax)
        n = state.n
        page = Page(0, -1, 1, 0, False) if state.empty else table_page(n, width, height, focus(state, hovered))
        row, font = page.row, page.font
        pitch = min(width / page.columns, TABLE_MOST)
        coming = target(state, hovered) if state.free else None       # the next point's intervals, where a click would go
        current = {i for i in (state.placing, design_index(hovered), state.shown if coming else None)
                   if i is not None and not state.empty and i < state.n}
        for c in range(page.columns):
            left = c * pitch
            places = (left + 0.18 * pitch, left + 0.50 * pitch, left + 0.80 * pitch)
            for x, name in zip(places, ("i", "x₁", "x₂")):
                moving.append(ax.text(x, height - row / 2, name, ha="center", va="center", fontsize=font, color=palette.GREY))
            moving += ax.plot([left + 4, left + pitch - 8], [height - row, height - row], color=palette.DARK_GREY, linewidth=0.8)
            for r in range(page.rows):
                i = page.first + c * page.rows + r
                if i > page.last:
                    break
                y = height - (r + 1.5) * row
                shown = i < state.shown
                lit = i in current
                color = CHOSEN if lit else (palette.WHITE if shown else palette.GREY)
                if lit:
                    moving.append(ax.add_patch(Rectangle((left + 2, y - row / 2 + 1), pitch - 8, row - 2, facecolor=palette.PILL,
                                                         edgecolor="none", zorder=1)))
                moving.append(ax.text(places[0], y, str(i + 1), ha="center", va="center", fontsize=font, color=palette.GREY,
                                      zorder=2))
                if state.method == "lhs" or shown or (coming and i == state.shown):
                    k1, k2 = state.design.cells[i] if shown or not coming else coming
                    moving.append(ax.text(places[1], y, str(k1 + 1), ha="center", va="center", fontsize=font, color=color,
                                          zorder=2))
                    moving.append(ax.text(places[2], y, str(k2 + 1), ha="center", va="center", fontsize=font, color=color,
                                          zorder=2))
        if page.partial:
            moving.append(ax.text(4, row / 2, get_text("lab.lhs.table_rows", first=page.first + 1, last=page.last + 1, n=n),
                                  ha="left", va="center", fontsize=8.5, color=palette.GREY))

    def frame_space(self, ax, state: SampleState) -> None:
        """The response over the design space, in the vertical window of the three steps, the rectangle of the design
        space on its floor, and the view's limits, panes, ticks and box."""
        ax.set_facecolor(palette.CARD)
        ax.computed_zorder = False                                    # the designs stay in front of the surface
        x1, x2, y = surface(state.response.key)
        low, high, _ = window(state.response.key)
        ax.plot_surface(x1, x2, y, cmap=RAMP, vmin=float(y.min()), vmax=float(y.max()), rstride=1, cstride=1, linewidth=0,
                        antialiased=False, alpha=0.9, zorder=1)
        (a1, b1), (a2, b2) = state.response.bounds
        ax.plot([a1, b1, b1, a1, a1], [a2, a2, b2, b2, a2], [low] * 5, color=palette.DARK_GREY, linewidth=0.8, zorder=1)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        ax.set_zlim(low, high)
        style_space(ax)
        space_ticks(ax)
        ax.set_box_aspect((1.0, 1.0, 0.72), zoom=SPACE_ZOOM)

    def draw_space(self, ax, state: SampleState, hovered) -> None:
        """On the response, the designs placed and their stems down to the floor (the design space), the cell of the
        point being placed on the floor, and the design under the mouse with its y: moving artists."""
        moving = self.moving
        low, high, _ = window(state.response.key)
        (a1, b1), (a2, b2) = state.response.bounds
        marked = target(state, hovered)
        if marked is not None:                                        # the cell of point k, on the floor
            k1, k2 = marked
            h1, h2 = (b1 - a1) / state.n, (b2 - a2) / state.n
            c1, c2 = a1 + k1 * h1, a2 + k2 * h2
            moving += ax.plot([c1, c1 + h1, c1 + h1, c1, c1], [c2, c2, c2 + h2, c2 + h2, c2], [low] * 5, color=CHOSEN,
                              linewidth=1.6, zorder=3)
        placed = state.points[:state.shown]
        if placed:
            xs, ys = zip(*placed)
            zs = state.values[:state.shown]
            for x, y_, z in zip(xs, ys, zs):
                moving += ax.plot([x, x], [y_, y_], [low, z], color=palette.GREY, linewidth=0.7, linestyle=(0, (2, 2)), zorder=2)
            moving.append(ax.scatter(xs, ys, [low] * len(xs), s=8, color=palette.GREY, depthshade=False, zorder=2))
            colors = [POINT] * len(placed)
            if not state.complete:
                colors[-1] = CHOSEN
            moving.append(ax.scatter(xs, ys, zs, s=marker_size(state.n), c=colors, edgecolors=palette.CARD, linewidths=0.8,
                                     depthshade=False, zorder=4))
        pointed = design_index(hovered)
        if pointed is not None and pointed < state.shown:
            (x, y_), z = state.points[pointed], state.values[pointed]
            moving.append(ax.scatter([x], [y_], [z], s=marker_size(state.n) * 2.6, facecolors="none", edgecolors=palette.WHITE,
                                     linewidths=1.4, depthshade=False, zorder=5))
            moving.append(ax.text(x, y_, z + 0.06 * (high - low), f"y = {short(z, 4)}", color=palette.WHITE, fontsize=9, zorder=6))

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Page:
    """The rows of the table on show: designs first..last (indices from 0), in `columns` columns of `rows` rows each;
    partial when the design has more rows than that (a last line then says which ones are shown). row: the height of a
    row, in layout pixels; font: the size of its numbers, in points."""
    first: int
    last: int
    columns: int
    rows: int
    partial: bool
    row: float = TABLE_ROW
    font: float = TABLE_FONT

def table_page(n: int, width: float, height: float, focus: int) -> Page:
    """The rows a table of `width` x `height` layout pixels holds: under a line of headings, rows of TABLE_ROW in
    columns at least TABLE_COLUMN wide, or, when that holds every design and the usual rows do not, the closer rows and
    columns of TABLE_DENSE. Every design when they fit (in as few columns as they need, of balanced lengths); otherwise,
    set close, the page of rows that holds the design `focus`, the pages following one another so that the table stays
    still while the focus walks inside its page, and a last line kept for the words that say which rows."""
    dense = TABLE_DENSE
    for row, column, font in ((TABLE_ROW, TABLE_COLUMN, TABLE_FONT), dense):
        columns = max(int(width // column), 1)
        rows = max(int(height // row) - 1, 1)
        if n <= columns * rows:
            used = ceil(n / rows)
            return Page(0, n - 1, used, ceil(n / used), False, row, font)
    rows = max(rows - 1, 1)
    capacity = columns * rows
    first = (min(max(focus, 0), n - 1) // capacity) * capacity
    return Page(first, min(first + capacity, n) - 1, columns, rows, True, row, font)

def focus(state: SampleState, hovered) -> int:
    """The design the table follows: the one being placed, or else the one under the mouse, or else, in a free sample
    still to fill, the next one, or else the last one drawn while the design is being built (Monte Carlo has no cell
    drawn in advance), or else the first."""
    if state.placing is not None:
        return state.placing
    pointed = design_index(hovered)
    if pointed is not None and 0 <= pointed < state.n:
        return pointed
    if state.filling:
        return state.shown
    return state.shown - 1 if 0 < state.shown < state.n else 0

def scene_of(state: SampleState) -> tuple:
    """What the scene of the figure depends on (SamplingLab.draw_scene): N (the intervals; none without it), whether
    any design is shown (the legends list the designs only then) and the language of its titles and legends."""
    return state.n, state.shown > 0, current_language()

def frame_table(ax) -> None:
    """The table's frame: no ticks, no spines, its data coordinates its layout pixels (table_room)."""
    ax.set_facecolor(palette.CARD)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    width, height = table_room(ax)
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)

def table_room(ax) -> tuple[float, float]:
    """The table's width and height, in layout pixels."""
    width, height = (extent * whole for extent, whole in zip(ax.get_position().size, size(ax.figure)))
    return width, height

def titled(figure, heads: dict, axes: dict, name: str, title: str, handles: list) -> None:
    """A panel's title and its legend (panels.head, which keeps the room of a legend with nothing to list)."""
    head(figure, heads, axes, name, title, handles)

def design_index(hovered) -> int | None:
    """The design a hovered item names (an index), or None (nothing, or the cell of an empty place: ("cell", k1, k2))."""
    return hovered if isinstance(hovered, int) and not isinstance(hovered, bool) else None

def target(state: SampleState, hovered) -> tuple[int, int] | None:
    """The cell drawn in yellow: point k's while a Latin hypercube is shown halfway (placing); in a free sample still
    to fill, the cell under the pointer, or else the keyboard cursor's; None otherwise."""
    if state.placing is not None:
        return state.design.cells[state.placing]
    if not state.filling:
        return None
    if isinstance(hovered, tuple) and len(hovered) == 3:
        return min(max(int(hovered[1]), 0), state.n - 1), min(max(int(hovered[2]), 0), state.n - 1)
    return cell_of(state.cursor, state.n) if state.cursor is not None else None

def placed_points(settings: dict) -> tuple[tuple[float, float], ...]:
    """The free sample's points in the settings, at most N of them (the first ones), as tuples of floats; none while
    N is not typed."""
    n = settings.get("n")
    points = settings.get("points") or ()
    return () if n is None else tuple((float(u1), float(u2)) for u1, u2 in tuple(points)[:n])

def cell_of(u, n: int) -> tuple[int, int]:
    """The cell of a point of the unit square: its interval on each axis, counted from 0 (as measures.interval_counts)."""
    return min(max(int(u[0] * n), 0), n - 1), min(max(int(u[1] * n), 0), n - 1)

def centre(cell: tuple[int, int], n: int) -> tuple[float, float]:
    """The centre of a cell, in the unit square, kept to DECIMALS."""
    return round((cell[0] + 0.5) / n, DECIMALS), round((cell[1] + 0.5) / n, DECIMALS)

def unit_of(ax, state: SampleState, event) -> tuple[float, float]:
    """The point of the unit square under the mouse (device pixels, the plane's data transform), kept inside it and to
    DECIMALS."""
    x1, x2 = ax.transData.inverted().transform((event.x, event.y))
    (a1, b1), (a2, b2) = state.response.bounds
    return (round(min(max((float(x1) - a1) / (b1 - a1), 0.0), 1.0), DECIMALS),
            round(min(max((float(x2) - a2) / (b2 - a2), 0.0), 1.0), DECIMALS))

def by_key(key: str, settings: dict) -> dict | None:
    """The free sampling's keys (SamplingLab.press): an arrow moves the cursor one interval (the first one shows it in
    the middle cell), Enter or Space places a point at it while fewer than N are placed; the settings unchanged when
    nothing can move (no N, an edge, N placed: the key is still the figure's); None for another key."""
    moves = {"left": (-1, 0), "right": (1, 0), "up": (0, 1), "down": (0, -1)}
    if key not in moves and key not in ("enter", "space"):
        return None
    n = settings.get("n")
    if n is None:
        return settings
    cursor = settings.get("cursor")
    cell = cell_of((0.5, 0.5) if cursor is None else cursor, n)
    if key in moves:
        d1, d2 = (0, 0) if cursor is None else moves[key]
        cell = (min(max(cell[0] + d1, 0), n - 1), min(max(cell[1] + d2, 0), n - 1))
        return settings | {"cursor": centre(cell, n)}
    points = placed_points(settings)
    if len(points) >= n:
        return settings
    return settings | {"points": points + (centre(cell, n),), "cursor": centre(cell, n)}

def pearson(xs: list[float], ys: list[float]) -> float | None:
    """Pearson's correlation (measures.correlation), or None where it is not defined: every point on one line parallel
    to an axis (a coordinate with no spread), as points placed by hand may be."""
    try:
        return correlation(xs, ys)
    except ZeroDivisionError:
        return None

def mitred(corners: list, above: bool) -> list:
    """A cell of a band, in fractions of the design space, cut at the diagonal of the corner where the two bands meet:
    the top band keeps what is above the line y = x, the right band what is below it (Sutherland-Hodgman)."""
    def inside(p):
        return p[1] - p[0] >= 0 if above else p[1] - p[0] <= 0
    kept = []
    for k in range(len(corners)):
        p, q = corners[k - 1], corners[k]
        if inside(p) != inside(q):
            s = (p[1] - p[0]) / ((p[1] - p[0]) - (q[1] - q[0]))
            kept.append((p[0] + s * (q[0] - p[0]), p[1] + s * (q[1] - p[1])))
        if inside(q):
            kept.append(q)
    return kept

def marker_size(n: int) -> float:
    """The area of a design's dot: large for a few points, smaller as they crowd."""
    return float(max(14, min(70, 900 / n)))

def style_space(ax) -> None:
    """The 3D view in the colours of the page: dark panes, faint grid, grey ticks, the axes named x1, x2 and y."""
    ink = palette.GREY
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_pane_color(_rgba(palette.BACKGROUND, 0.55))
        axis.pane.set_edgecolor(palette.DARK_GREY)
        axis.line.set_color(palette.DARK_GREY)
        axis._axinfo["grid"].update({"color": _rgba(palette.DARK_GREY, 0.55), "linewidth": 0.5})
        axis.label.set_color(ink)
    ax.tick_params(colors=ink, labelsize=8, pad=1)
    ax.set_xlabel("x₁", fontsize=10, labelpad=2)
    ax.set_ylabel("x₂", fontsize=10, labelpad=2)
    ax.set_zlabel("y", fontsize=10, labelpad=4)

def _rgba(color: str, alpha: float) -> tuple[float, float, float, float]:
    return tuple(int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)) + (alpha,)
