# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                              Title: doe.py
# ==============================================================================
"""
Step 1 of a bench, the design of experiments: how the designs of a study are placed in the design space before any
simulation runs, by the reader's own hand (the free sampling, FREE: no algorithm at all), by the Latin hypercube
(sampling.latin_hypercube) or by plain random sampling (sampling.monte_carlo), on the design space of the bench's
response y = f(x1, x2) (functions.RESPONSES). The laboratory is made for its bench and its reader, SamplingLab(function,
mode): the bench IS the response, so there is no control to choose it. The 3D view's card has the caption the three
steps draw (explorers/caption.py, once per layout): the formula of the response, typeset, or, for the beam, a
simulation with no formula, the living drawing of its problem with ONE simulated design in focus, the design under the
pointer, else the best design (least simulated y), else, with no design, the problem alone; the axes of the plane and
of the 3D view carry the response's units where it has them (panels.name_plane, style_space). The card of the column,
received, states the problem the study starts from (the first step receives nothing from another) in its standard
mathematical form (the owner's 2026-11-21): "minimize  y = f(x₁, x₂)", then "subject to" the bound of each input, one
a row, in its unit where it has one ("x₁ ∈ [0.5, 5] m"), and what the response is, quietly, at the right of the card's
heading (a simulation by what it is, "y: largest deflection [mm]"; nothing for a test function, which the bar names);
the window sets the goal larger and bright, the bounds readable (gui/lab_views.LabView.show_received).

    The problem              | design space x1, x2: N x N cells, the     | The response y = f(x1, x2)
    minimize  y = f(x1, x2)  | designs, and along its top and right      | the response, the designs on it (each one a
    subject to x1 ∈ [-5, 10] | edges the count of designs in each        | simulation), their stems down to the floor
               x2 ∈ [0, 15]  | interval of x1 and of x2                  | (dragged with the mouse: it turns)
    Sampling                 |                                           |
      Free · Latin hypercube |                                           |
      · Monte Carlo          |                                           |
    Sampling points          |                                           |
      N [60] [New sample]    |                                           |
      10 20 40 60            |                                           |---------------------------------------------
    The simulated designs    |                                           | f(x1, x2) = ... (the formula, as a paper sets it)
      i  x1  x2  y         | |                                           |
    [Go to the metamodel ->] |                                           |
    Restore        View code |                                           |

The diagram is the window's (columned): the table of the designs, with their simulated y, is the column's block under
the controls (a scroll bar beside it when its rows do not all fit), the 3D view takes the right column alone, its
caption the formula, and there is no strip (see the paragraph on the block, below). The web's figure (columned False)
has a third panel under the 3D view, the table of the designs' intervals ("design i: its interval on x1 and on x2"),
and a strip at its foot: designs | empty intervals | correlation | smallest distance.

The sampling's options read Free | Latin hypercube | Monte Carlo (METHODS). The two algorithms need N, the number of
sampling points: a number one knows, typed (with the teacher's quick picks on the line under it), and beside the field
the command "New sample" (Action.beside: it stands in the row of N, not among the chips; the next seed, another sample
of the same N). The free sampling has no N: the row of N is not shown (Control.visible), and the experiment is the
points placed, N their number at every moment.

The step's result (output) is the Experiment: the bench's response, the sampling, N, the seed and, for the free
sampling, its points (N = their number), from which the next step computes the designs and their N simulations
(simulated, the one source of the values: the lab's state takes them from it too). For an algorithm it is available
once N is typed; for the free sampling once LEAST = 5 points are placed (the least N of every sampling: one design per
subset of step 2's cross-validation), and at most MOST = 100 are (before 5, output is None and missing, the disabled
filled button's tooltip, says how many are left to reach 5; with none placed, where to click; the transport row's name
counts them). The forward command "Go to the metamodel" hands it on (the window answers it). Simulated, these N designs
are everything the metamodel will know about f: how well they spread (no empty interval, low correlation, a good
smallest distance) is what the next step inherits. The step's summary (the cover's track, the pill's tooltip) is the
empty intervals of the design, "empty 0 · 0", an error when any interval is empty (nothing while there is nothing to
hand).

The free sampling (the owner's "Livre"): the reader places each point by clicking on the design space, in the order of
the clicks (one on a point takes it, and a drag moves it; grab, drag); a click with MOST points placed places nothing
(the transport row's count says MOST; no grey sentence says it: the owner's minimalist 2026-11-21). The transport row's
icon "undo" removes the last point placed, and the chip "Clear" removes them all. The keyboard does it too: with the
figure focused the arrow keys move a cursor by CURSOR_STEP of the unit square (the first press shows it in the middle)
and Enter or Space places a point there (press). The points are kept in the settings ("points": unit points, in the
order placed, rounded to DECIMALS) and mapped to the bounds only by simulated (sampling.scaled), like every sample;
they stay there while the reader looks at an algorithm's sample, so coming back to "free" finds them; Restore forgets
them. Every measure of a free sample (the intervals of the plane and of the bands, the empty intervals, the table's
intervals) is computed with N = the points placed, so the plane's grid is the k x k of the k points placed; the empty
intervals are judged (ok or error, hatched) from LEAST points on, as for every sample. Over an empty place the pointer
itself shows where a click puts the next point (the pointing hand: no cell is lit, the grid changing with the click,
and moving the mouse never draws the figure again); the keyboard's cursor is a yellow ring and cross. The count is the
transport row's ("12 points placed") and the strip's. "View code" reads the measures that judge the sample
(gui/lab_code.py, the reading "free"): no algorithm places it. Two points on the same place are the reader's right: the
measures say it (a smallest distance of 0), and the metamodels that cannot be computed on them say so in step 2. A
snapshot of an older laboratory (a free sample with a typed N, the Construction slider's "shown") loads as it is: the
points win, N is ignored for the free sampling and "shown" by every one.

The figure is the bench's shared picture (explorers/panels.py, arrangement with pair="space"): for the same figure size
the design space and the 3D view stand in the same boxes, to the pixel, in the three steps, with the same limits (the
bounds of the response), ticks, axis names and titles' places as the metamodel's and the optimization's; the 3D view has
the metamodel's vertical window (metamodel.truth: the range of f on its grid and 15 % of it on each side) and the angle
the reader left (Lab.view). The design space adds this step's intervals: the grid of N x N cells and the counts of
designs per interval of each axis, as two bands just inside its top edge (x1) and its right edge (x2), mitred where
they meet, so that they never move its box: teal one design, gold two or more, red and hatched none once judged (never
colour alone). The third panel, where the arrangement has one (the corner, the row and the stack), is the table of the
designs: design i takes the i-th entry of the shuffled list of each axis, intervals numbered from 1, larger in one column
while every design fits in it (TABLE_LARGE: a free sample's first points), else in as many columns of rows as the panel
holds, set closer (TABLE_DENSE, then TABLE_TIGHT) when that lets every design be read at once (the teacher's 40, 50 and 60);
when N is larger than even that, the page of rows that holds the design in focus (the design pointed at, or a free
sample's last point), and a last line says which rows are shown; the columns of rows centred in the card, the headings'
line never lower than TABLE_HEAD_LEAST (headed: the symbols never touch the first row). The row of the
design under the pointer is lit. Under its title a caption says what its numbers are (the interval's number, 1 to N:
panels.subtitle), one row in every arrangement: the room the plan keeps for a second (the plane's and the 3D view's
legends need it in step 3, so they keep it in every step) is the table's (TABLE_RISE), and so is the
room the other steps keep under their third panel for its axes' names (a table has none). Its numbers are set in the
monospace, right-aligned on the digit (panels.NUMBER, TABLE_RIGHTS), the index muted, its headings symbols in STIX, muted
(panels.HEADING), as a matrix of CAE Fundamentals' guide. In the pair (the code panel open beside the lab) the table is
left out. Every text of the figure takes a role of the shared type system (panels.TITLE, LABEL, NAME, TAG, ...).

Where the window stands the step's own panel in its column (Lab.columned, the owner's design of 2026-11-21; the web
never does), the figure has no third panel (arranged: panels.arrangement's third=False, the right column ONE card, the
3D view's, the owner's 2A of 2026-11-21: its legend on one row, the formula as its subtitle, the 3D box filling the card
at the plan's aspect, the readout at its foot, readings: the design under the mouse, else the best, x_i and y_i, never
a tag over the surface; the design space filling the picture's height, its bands of counts BAND pixels thick in each
direction, mitred at their corner's own diagonal) and the step's block is the table of the simulated designs as Ansys
optiSLang shows them (blocks: DESIGNS, titled in words, the units of its columns in one muted line under the title,
units_line, never in its headings; its heading alone while there is no design, designs_block), drawn
by the lab on the block's own figure and axes (draw_block, draw_designs; Lab.block_axes, never the figure's axes): i,
the inputs and y, their VALUES (an input to two decimals, y to three: DESIGNS_DECIMALS), a row per design in the order
of the designs, the best design's y in the designs' blue and its row under the pill while nothing is pointed at, the
row of the design pointed at lit as in the table of intervals; when the rows do not all fit (table_page in one column
of rows, no last line kept), the rows from the first the window's scroll bar shows (the owner's 2026-11-21: a bar the
reader drags, gui/blocks.py): scroll_to sets it, scrolled hands it to the bar (Scroll), in_sight keeps the design in
focus in sight (a design pointed at, on the plane or on its row, as far as it takes; a new experiment or a block
resized, its best design or a free sample's last point; the pointer leaving moves nothing), rows_from lays the rows
out from it; no line under the rows (the bar says which). Its columns are measured in the face drawn (designs_layout: each as wide
as its widest text may be, table_columns' widest, the font stepped down to panels.TABLE_LEAST where they would not fit),
and table_columns is the seam a bench of several outputs adds its columns through; its rows stand a whole number of
device pixels apart (row_places: evenly spaced at any density). The mouse over a row names that
design (hit_block), as the plane does. No measure stands under the table.

The true response f (the owner's 2B): the 3D view draws f's surface, and its legend names it, only where it is shown
(Lab.truth_shown: always for a test function, whose formula is known; for a simulation, the beams, only once the reader
asked to see it, Lab.revealed: else the 3D view holds the designs alone, each at its simulated y, as a real study has
them). The 3D view's title stays the response's.

A teacher's lab (explorers/game.py) opens, and Restore returns, on the Latin hypercube of the bench's own N
(FIRST_POINTS, an N at which the forward buttons alone complete the bench robustly, chosen by a sweep) with its quick
picks; Free is one click away. A student's opens, and Restore returns, on the free sampling with no point placed; its N,
for the algorithms, comes EMPTY, with no quick pick (they would suggest the answer): settings["n"] is None, and an
algorithm then has no design yet. The plane is drawn with its frame, axes and titles but no interval, band or design;
the 3D view shows the response without designs; the table keeps its title alone (no heading over no row); the strip shows
dashes; New sample is disabled; output is None and missing says, in one sentence, to type the number of sampling points.
Once a number is typed everything works as for a teacher; a snapshot with no N gives the empty step back.

The two algorithms never look at f: the same sample serves any response, and only its mapping to the bounds changes
with the bench. The free sampling is the reader's, and it sees whatever the reader looks at, the response included: its
lead says so. The 3D view is what the sample is for: each design is evaluated (a simulation, here a call of f), and the
points sit on the surface they will be used to learn. The measures are those of the designs, each with a tip of one
sentence that defines it; the lead is one short sentence, the figure's accessible description. A new sample asks for the
sound "apply" (cue), and so do, for the free sampling, "undo", "Clear", a point placed by Enter or Space and a drag
ended ("drag": the window asks for it once a drag that changed the settings is released). Whenever no design is drawn,
the legends list nothing of the designs (no entry for what is not on the figure).

Margins are layout pixels (explorers/lab.size), never figure.dpi; the axes are reused between redraws while the
figure's size and the language hold (the caption's text column is measured in the language), so the 3D view keeps the
angle the reader turned it to, and the caption is made once per layout with the cards of the right column
(panels.draw_cards: the 3D view and the table each on its card, the table on the card's tone, the 3D view with no
background of its own); the caption's design in focus is drawn again only when it changes.
What depends only on N, on whether any design is shown and on the language (the frames, the intervals, the response's
surface, the titles and legends: scene_of) is the scene, drawn once; the designs, the bands, the keyboard's cursor and
the table's rows are drawn again at every draw (moving), as steps 2 and 3 do: a design pointed at redraws only them (a
free point placed changes N, and with it the scene).

A bench of more than two inputs (d of them: the beam on four cross-beams) is read through the same figure, by one rule
(explorers/section.py): a mark is a projection, a surface is a slice. Every coordinate goes through the slice on screen,
SampleState.section, made by section.of from the settings; for two inputs it is the whole design space and every step
below is the identity, so that benches 1 and 2 draw what they always drew (the same arrays, artists, boxes and column).
- The data: design(method, n, seed, points, d) draws the cores' Latin hypercube or Monte Carlo of dimension d (for two
  inputs the stream of numbers it always drew), the cells one per input; simulated calls f(*x); a free point is a
  d-tuple. Nothing of the view is part of the Experiment: output never depends on it.

A bench of several responses of one simulation (functions.Response.outputs) is simulated once per design for all of
them (simulations, keyed by the experiment with its output 0; Response.together when the bench has it): Simulated.outputs
holds every output of every design, a column per output, and Simulated.values the column of Experiment.output, the
response the experiment is seen through (0, the default, for a bench of one response: the one column, the values as
they always were). Its laboratories are their own (they read the experiment of each output with dataclasses.replace);
its step 1 (explorers/pareto_doe.py) is a SamplingLab whose plan is asked through two seams of this one: arranged(width,
height), the shared plan (panels.arrangement), and headings(), the titles and notes it measures for the slice's note
(here section.heading; there the titles of that bench's three steps).
- The view's controls: first among the lab's controls (section.controls: the two axes, x1 .. xd with their icons, and
  a slider per input held), then the sampling's; the window draws them, with the chip, in the band over the figure
  (gui/lab_views.ViewBand), never in the column, which stays the study's; the view's keys in the settings (section.first), adjust
  routing them to section.after (an axis swaps, a slider pins the slice), showing to section.showing; the chip of the
  slice (section.chip, key section.CHIP) offered while a slider pinned it, named by where it returns the slice (the best
  design, or the middle for the free sampling and with no design: naming). While nothing is pinned the slice passes
  through the best design of an algorithm's sample (automatic, through: the least simulated y, which then lies on the
  surface drawn), else through the middle of the ranges (the free sampling: nothing moves by itself), and the sliders
  stand there (viewed: section.synced after every settings the lab returns). slice_of, viewed, showing and the view's
  part of adjust (adjust_view) are section.Viewing's, the same in the three steps; the lab gives its automatic.
- The figure: the plane's axes, names and units are the pair's (section.pair_bounds, panels.name_plane with the pair), its
  N x N intervals and its two bands count the pair's two inputs (a Latin hypercube is Latin in every pair), every design
  at its projection, fainter off the slice and larger near it (Marks, section's fade: never colour alone; the farthest
  first; its dark edge thin). The
  3D view draws f's slice on the pair (surface(key, cut): the inputs held at the slice's values), its colours and its
  vertical window the bench's (extent: from the known minimum to the largest value on game.spread's grid; window: that
  range and metamodel.MARGIN of it on each side), the designs at their projections and their own simulated y, faded the
  same way and smaller off the slice (a mark there never grows). The heads of the plane and of the 3D view write the
  slice's note on their title's line (section.note, "x₃ = 5.68 m · x₄ = 6.94 m": panels.head's note); the 3D view's
  title is f of all the inputs (space_title). The table: i and the interval of each input (entries_share,
  table_rights: wider columns of rows). The caption is given the pair.
- The strip: the empty intervals of every input ("0 · 0 · 0 · 0"), the correlation of largest |ρ| among the pairs of
  inputs written with its pair (largest_correlation), the smallest distance in the unit hypercube; the summary, "empty
  0 · 0 · 0 · 0"; the card of the problem, "minimize y = f(x₁, …, x₄)" and the four bounds, one a row (inputs_of).
- The free sampling: a click or a drag gives the pair's two coordinates and the inputs held the slice's values
  (lifted: Section.lift); a point dragged keeps its own held coordinates; the keyboard's cursor moves in the pair's unit
  square and Enter places the lifted point (by_key, given the slice on screen); a slider never moves a point placed.
The scene's key holds the slice's (scene_of, Section.key: a new pair or held value draws the surface, the names and the
note again); the layout's key does not. The surface is cached by the same key (surface, surface_slice).

The pointer on a bench drawn (explorers/live.py, live.Pointing mixed in, the same in the three steps): away from a
design the place under it (Lab.pointer) is the drawing's focus, its cross-beams dashed and no y, and a crosshair through
it on the plane; the drawing's focus and the crosshair are the live layer, the last of every draw (live, with focused:
caption.pointed), which a move of the pointer paints alone. A press over a range of the band's drawing is a press at
that place of the plane (live.Pointing.aim): the free sampling places its point there (grab and drag, as on the plane).
"""
from dataclasses import dataclass, replace
from functools import lru_cache
import math
from math import ceil
from random import Random

import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch, Polygon, Rectangle

from statistical_fundamentals import palette
from statistical_fundamentals.explorers.base import Control, nearest, number, short, style_axes
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.lab import BENCH, LAYOUT_DPI, LINK, TRANSPORT, Action, Block, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.panels import (BELOW, BLOCK_TONE, BLOCK_TOP, CARD_TONE, COUNT, HEADING, LEGEND_ROW, MUTED_INK,
                                                       NUMBER, SMALL, STACK_WIDTH, TABLE_LEAST, TAG, Y, arrangement, dot, draw_cards,
                                                       head, head_room, input_name, legend_most, name_plane, name_space, number_width,
                                                       places, plane_ticks, read_point, read_value, readout, space_ticks, subscript,
                                                       subtitle, text_width, ticks, title_drop)
from statistical_fundamentals.explorers import caption, game, live, section
from statistical_fundamentals.explorers.responses import formula
from statistical_fundamentals.explorers.section import Section
from statistical_fundamentals.functions import RESPONSES, Response, many
from statistical_fundamentals.i18n import DEFAULT_LANGUAGE, current_language, get_text, has_text
from statistical_fundamentals.measures import correlation, empty_intervals, interval_counts, smallest_distance
from statistical_fundamentals.sampling import latin_hypercube, monte_carlo, scaled

ALGORITHMS = ("lhs", "mc")            # the samplings an algorithm draws (sampling.py)
FREE = "free"                         # the reader's own sampling: every point placed by hand, no algorithm
METHODS = (FREE, *ALGORITHMS)         # the order of the sampling's options: Free | Latin hypercube | Monte Carlo
DECIMALS = 4                          # a point placed by hand is kept to this many decimals of the unit square
POINTS = tuple(range(5, 101))         # N, the number of designs: 5 at least, one per subset of step 2's cross-validation
LEAST, MOST = POINTS[0], POINTS[-1]   # the free sampling hands its points from LEAST on, and places no more than MOST
CURSOR_STEP = 0.02                    # the free sampling's keyboard cursor moves by this much of the unit square (as step 3's
                                      # start)
SHORTCUTS = (10, 20, 40, 60)
FIRST_POINTS = {"branin": 60, "beam": 50, "beam4": 85,     # the teacher's N of each bench, from a sweep of N over
                "beam_pareto": 70}    # ten samples (2026-11-15; the beam's 2026-11-18, the beam on four cross-beams'
                                      # 2026-11-19, the beam sized for two objectives' 2026-11-21, on square sections of
                                      # area A), chosen for robustness,
                                      # not as the least N that completes: the share of the ten samples that the forward
                                      # buttons alone complete (explorers/game.py, the teacher's method) around it (Branin
                                      # 8 of 10 from N = 55, holding over N ± 5; the beam 9 of 10 at 50 with NLPQL, 6 at 45
                                      # and 7 at 55: a narrower peak than Branin's, its minimum on a kink where a high CoP
                                      # does not locate it; the beam on four cross-beams 9 of 10 at 85 with NLPQL, 9 at 80
                                      # and 8 at 90: the steadiest N of its grid; bench 4 9 of 10 at 70 with K = 20, as at
                                      # 65 and 75; seed 27 fails at 65, so 70), the first seed among those that complete
FIRST_METHOD = {TEACHER: "lhs", STUDENT: FREE}     # the sampling a lab opens on: the teacher's sample completes the bench,
                                                   # the student places his own points
FUNCTIONS = tuple(RESPONSES)          # the benches, by the key of their response
FIRST_SEED = 27                       # the first sample: kept from the first cover's picture (its N = 6 sample has no design
                                      # on a grid line): chosen to be read, not for its statistics
GRID = 46                             # samples per axis of the drawn surface
HEIGHT = 440                          # layout pixels: the least height of the figure, the same in the three steps (400 before the
                                      # formula's block and the legends' two rows: the design space keeps about its side)
LABEL_MOST = 30                       # the counts are written in the bands of the intervals up to this N
# The figure's layout, in layout pixels (explorers/lab.size); the panels' boxes are explorers/panels.py's
BAND = 12.0                           # the bands of the counts, inside the top and right edges of the design space
CELL_LEAST = 8.0                      # a count is written only in an interval at least this wide
TABLE_ROW, TABLE_COLUMN, TABLE_MOST = 19.0, 112.0, 150.0     # the table: a row; a column of rows (i, x1, x2) at least, at most
TABLE_FONT = 9.5                      # points: the table's numbers
TABLE_DENSE = (15.0, 82.0, 8.5)       # the table set closer (a row, a column at least, the font) when that holds every design
TABLE_TIGHT = (13.0, 82.0, 8.5)       # closer still, the same font, only when that holds every design (the teacher's 60 at 1280)
TABLE_HEAD_LEAST = 16.0               # layout pixels: the line of the headings, at least (headed)
TABLE_LARGE = (22.0, 10.5)            # a row and the font while every design fits one column (a free sample's first points)
TABLE_RIGHTS = (0.26, 0.58, 0.88)     # the right edges of a column of rows' i, x1 and x2, in shares of its pitch
TABLE_HEADING = 1.5                   # points: the headings (symbols in STIX italic, which sits small) larger than the numbers
TABLE_RISE = LEGEND_ROW / 2           # the table's legend is one row, in every arrangement: the room of the second is the table's
DASH = "—"                            # a measure that has nothing to measure yet
GOAL, BOUND, ASIDE = "goal", "bound", "aside"     # the kinds of the problem card's rows (received; gui/lab_views)
# The step's block in the window's column (Lab.columned: blocks, draw_block), in layout pixels of the block's own figure
DESIGNS = "designs"                   # the block's key: the table of the simulated designs, their inputs and their y
DESIGNS_LEAST = 120                   # the least height of its content that still reads (a heading and a few rows)
DESIGNS_DECIMALS = (2, 3)             # the table's decimals: of an input, of y
DESIGNS_GAP, DESIGNS_GAP_LEAST = 12.0, 6.0     # between two of its columns: the room left shared out, at least this
DESIGNS_SIDE = 4.0                    # from the block's sides to its table, at least
VIEW = (26.0, -58.0)                  # elevation and azimuth of the 3D view, until the reader turns it
SPACE_ZOOM = 1.0                      # the 3D box in its square (panels.reach gives the square its room): a larger one puts
                                      # its tick labels on the third panel's title, or out of the figure at the right
RAMP = LinearSegmentedColormap.from_list("response", palette.SURFACE_RAMP)
CHOSEN = palette.YELLOW               # the keyboard's cursor (where Enter puts the next free point), the row pointed at
PLACE = ("place",)                    # Lab.hit over an empty place of a free sample: a click there places a point
POINT = palette.BLUE
ONE, MORE, EMPTY = palette.TEAL, palette.GOLD, palette.RED

@dataclass(frozen=True)
class Design:
    """One sample of the unit hypercube (d coordinates a point: the unit square for two inputs), in the order it was
    drawn (or, for the free sampling, placed), and the interval of each point on each axis (of the N intervals per
    axis, N the number of points)."""
    method: str
    n: int
    seed: int
    unit: tuple[tuple[float, ...], ...]
    cells: tuple[tuple[int, ...], ...]

@lru_cache(maxsize=4096)
def design(method: str, n: int, seed: int, points: tuple = (), d: int = 2) -> Design:
    """The sample of a sampling in d inputs: an algorithm's N points drawn from the seed (the cores' Latin hypercube or
    Monte Carlo of dimension d: for two inputs the stream of numbers it always drew), or the free sampling's points as
    the reader placed them (the first N: all of them, N being their number)."""
    if method == FREE:
        sample = points[:n]
    else:
        sample = latin_hypercube(n, d, Random(seed)) if method == "lhs" else monte_carlo(n, d, Random(seed))
    unit = tuple(tuple(float(u) for u in point) for point in sample)
    cells = tuple(tuple(min(int(u * n), n - 1) for u in point) for point in unit)
    return Design(method, n, seed, unit, cells)

@dataclass(frozen=True)
class Experiment:
    """Step 1's result, handed to the metamodel: which response was sampled, how, with how many designs, from which
    seed (step 2's cross-validation deals its subsets from it, whatever the sampling) and, for the free sampling, at
    which points of the unit square (in the order they were placed, N their number; () for an algorithm, whose points
    the seed gives). Everything else is computed from it (design, simulated), so two experiments are the same study when
    they are equal: two free samples only when their points are. `output` is the response the experiment is seen
    through, for a bench of several (functions.Response.outputs, by its index: the designs and their one simulation are
    the same for every output, only the values read differ, so step 2's caches are per response); 0 for a bench of one
    response, the only one."""
    function: str
    method: str
    n: int
    seed: int
    points: tuple[tuple[float, ...], ...] = ()      # d coordinates each, in the unit hypercube
    output: int = 0                                 # the index of the response read (functions.Response.outputs)

@dataclass(frozen=True)
class Simulated:
    """The N simulations of an experiment: its designs in the unit hypercube (d coordinates each), in the order they
    were drawn, the same mapped to the bounds of the response, y = f at each one (the values of the experiment's output),
    and every output of every design, one column of N values per output (outputs[k][i]; for a bench of one response the
    one column, the values themselves)."""
    unit: tuple[tuple[float, ...], ...]
    points: tuple[tuple[float, ...], ...]
    values: tuple[float, ...]
    outputs: tuple[tuple[float, ...], ...]

def first_experiment(function: str) -> Experiment:
    """The experiment a teacher's bench opens on: the Latin hypercube of the bench's own N, from the first seed."""
    return Experiment(function, FIRST_METHOD[TEACHER], FIRST_POINTS[function], FIRST_SEED)

@lru_cache(maxsize=4096)
def simulated(experiment: Experiment) -> Simulated:
    """The designs of the experiment, simulated: no algorithm looks at f, the response is called only here (simulations:
    once per design, for every output at once on a bench of several, whatever the output read), and the values are the
    column of the experiment's output (bounded, since every move of a dragged free point is another experiment)."""
    unit, points, outputs = simulations(experiment if experiment.output == 0 else replace(experiment, output=0))
    return Simulated(unit, points, outputs[experiment.output], outputs)

@lru_cache(maxsize=4096)
def simulations(experiment: Experiment) -> tuple[tuple, tuple, tuple]:
    """The designs of an experiment (its output 0: the designs are the same for every output) in the unit hypercube and
    in the bounds, and every output of every design, a column per output: for a bench of one response f at each design,
    one call per design (a free experiment's points as the reader placed them); for a bench of several, its one call
    for every output and every design at once (functions.Response.together), else each output's f at each design."""
    response = RESPONSES[experiment.function]
    unit = design(experiment.method, experiment.n, experiment.seed, experiment.points, response.d).unit
    points = tuple(tuple(x) for x in scaled([list(u) for u in unit], list(response.bounds)))
    if not response.outputs:
        return unit, points, (tuple(float(response.f(*x)) for x in points),)
    if response.together is not None:
        columns = response.together(*(np.array([x[k] for x in points], dtype=float) for k in range(response.d)))
        return unit, points, tuple(tuple(float(v) for v in np.asarray(column, dtype=float).ravel()) for column in columns)
    return unit, points, tuple(tuple(float(output.f(*x)) for x in points) for output in response.outputs)

def surface(key: str, cut: Section | None = None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """The response on a GRID x GRID grid of its design space: the surface drawn, never a value measured. On a bench
    of more than two inputs, its slice `cut` (explorers/section.py): the grid of the pair's bounds, the inputs held at
    the slice's values; the two arrays of the pair's coordinates and f on them (for two inputs, or no slice given, the
    grid of the whole design space, as it always was). Cached by the slice's key (surface_slice: Section.key, so two
    Sections that differ only in the pair's coordinates of `held` are one entry): never mutate what it returns."""
    return surface_slice(key, None if cut is None or cut.plain else cut.key)

@lru_cache(maxsize=256)
def surface_slice(key: str, cut: tuple | None) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """surface, cached by the key of its slice (None: the whole design space of two inputs)."""
    response = RESPONSES[key]
    if cut is None:
        (a1, b1), (a2, b2) = response.bounds
        x1, x2 = np.meshgrid(np.linspace(a1, b1, GRID), np.linspace(a2, b2, GRID))
        return x1, x2, response.f(x1, x2)
    view = Section.from_key(cut)
    across, up = view.pair
    (a1, b1), (a2, b2) = response.bounds[across], response.bounds[up]
    arrays = view.mesh(np.linspace(a1, b1, GRID), np.linspace(a2, b2, GRID), section.mapped(response.bounds, view.held))
    return arrays[across], arrays[up], np.asarray(response.f(*arrays), dtype=float)

def extent(key: str) -> tuple[float, float]:
    """The range of f on the design space of a bench of more than two inputs: from its known global minimum
    (functions.Response.minimum) to its largest value on the grid of game.spread (GRID_MANY per axis, the corners
    among them). Every slice lies inside it: the 3D view's colours and its window are the bench's, the same for every
    slice, so that a flatter slice looks flatter."""
    response = RESPONSES[key]
    low = float(response.minimum)
    return low, low + game.spread(key)

def window(key: str) -> tuple[float, float, float]:
    """The vertical window of the 3D view, the same in the three steps of a bench, and the share of the range of f it
    adds on each side: for two inputs the metamodel's (metamodel.truth: the range of f on its grid and MARGIN of it on
    each side); for more, the range of f on the design space (extent) and MARGIN of it on each side. Steps 2 and 3 of a
    bench of more inputs take theirs from here."""
    from statistical_fundamentals.explorers.metamodel import MARGIN, truth      # here: metamodel imports this module
    if RESPONSES[key].d > 2:
        low, high = extent(key)
        margin = MARGIN * (high - low)
        return low - margin, high + margin, MARGIN
    true = truth(key)
    low, high = float(true.y.min()), float(true.y.max())
    return true.low, true.high, (low - true.low) / (high - low)

@dataclass(frozen=True)
class SampleState:
    experiment: Experiment | None               # None while an algorithm has no N typed (a student's step): nothing to hand
    method: str
    n: int | None                               # the designs: an algorithm's N, or the free points placed; None: no N typed
    response: Response
    design: Design | None
    points: tuple[tuple[float, ...], ...]       # every design, mapped to the bounds (simulated)
    values: tuple[float, ...]                   # y = f at every design (simulated)
    cursor: tuple[float, float] | None = None   # the free sampling: the keyboard's cursor in the pair's unit square, or None
    section: Section = Section(2)               # the slice the figure shows (explorers/section.py): the whole design space
                                                # for two inputs; a view, never a part of the experiment

    @property
    def empty(self) -> bool:
        """No design: an algorithm with no N typed, or a free sample with no point placed."""
        return not self.n

    @property
    def free(self) -> bool:
        """The reader places the points (the free sampling)."""
        return self.method == FREE

    @property
    def short(self) -> bool:
        """A free sample of fewer than LEAST points: nothing to hand yet."""
        return self.free and (self.n or 0) < LEAST

    @property
    def full(self) -> bool:
        """A free sample of MOST points: a click places no more."""
        return self.free and (self.n or 0) >= MOST

    @property
    def judged(self) -> bool:
        """The empty intervals are judged (ok or error, hatched): from LEAST designs on."""
        return (self.n or 0) >= LEAST

    def column(self, axis: int) -> list[float]:
        """The coordinates in [0, 1) of the designs, on one axis."""
        return [] if self.empty else [u[axis] for u in self.design.unit]

class SamplingLab(live.Pointing, section.Viewing, Lab):
    """Step 1 of a bench: the reader's own points, the Latin hypercube or Monte Carlo, beside the response the points
    will be used to learn; the whole design handed to the metamodel."""
    keys_text = "lab.lhs.keys"                                  # what press does, for assistive technology (Lab.keyboard)

    def __init__(self, function: str = FUNCTIONS[0], mode: str = TEACHER):
        """The lab of a bench: a teacher's opening on the bench's first experiment, a student's on the free sampling with
        no point placed (and, for the algorithms, its N empty, no quick pick)."""
        self.function = RESPONSES[function].key
        self.mode = mode
        self.d = RESPONSES[self.function].d                   # the inputs: more than two, the figure shows a slice
        first = FIRST_POINTS[self.function]
        student = mode == STUDENT
        self.controls = section.controls(self.function) + (     # the view's first (none for two inputs), then the sampling's
            Control("method", get_text("lab.lhs.method"), METHODS, METHODS.index(FIRST_METHOD[STUDENT if student else TEACHER]),
                    names=tuple(get_text(f"lab.lhs.method.{m}") for m in METHODS), tip=get_text("lab.lhs.method_tip"),
                    icons={"lhs": "lhs", "mc": "mc", "free": "free"}),
            Control("n", get_text("lab.lhs.points"), POINTS, POINTS.index(first), show=lambda n: f"N = {n}",
                    shortcuts=() if student else SHORTCUTS, typed=True, symbol="N", tip=get_text("lab.lhs.points_tip"),
                    empty=student, visible=lambda settings: settings.get("method") != FREE),
        )
        self.actions = (
            page_link(),
            Action("undo", get_text("lab.lhs.undo"), get_text("lab.lhs.undo_tip"), icon="undo"),
            Action("new", get_text("lab.lhs.new"), get_text("lab.lhs.new_tip"), mark="seed", beside="n"),
            *((section.chip("best"),) if self.d > 2 else ()),     # back to the automatic slice (named by the sampling: naming)
            Action("clear", get_text("lab.lhs.clear"), get_text("lab.lhs.clear_tip"), mark="clear"),
            Action("advance", get_text("lab.lhs.advance"), get_text("lab.lhs.advance_tip"), forward=True),
        )
        self.data = {"seed": FIRST_SEED, "points": (), "cursor": None}     # the free sampling's points and keyboard cursor
        self.by_hand = False                   # the state drawn last is a free sample: its points are dragged
        self.restore = True
        self.height = HEIGHT                   # the least height, the metamodel's: the three steps get the same figure
        self.view = VIEW                       # the 3D view as the reader left it (a view, not a setting)
        self.layout_key = None                 # the axes on the figure are reused while their layout holds
        self.cards = {}                        # the cards of the right column (panels.draw_cards), drawn once per layout
        self.axes: dict = {}
        self.plan = None
        self.heads: dict = {}
        self.drawing = caption.drawing(self.function)    # the caption's block: a drawing's height, or None (the formula's)
        self.caption = None                    # the caption of the 3D view's card (explorers/caption.py), once per layout
        self.written = None                    # the formula of the response, typeset once per layout (None: drawn)
        self.scene = None                      # what the axes hold that stays while the pointer moves (scene_of)
        self.moving: list = []                 # the artists drawn again at every draw: the designs, the bands, the rows
        self.block_keys: dict = {}             # by block (Lab.columned): the key of its axes' layout (blocked)
        self.block_shown: dict = {}            # by block: what it shows (the key draw_block compares) and its table's rows
        self.block_moving: dict = {}           # by block: its artists, removed at its next draw
        self.block_first: dict = {}            # by block: the first row its table shows (a view: the window's scroll bar
                                               # moves it, scroll_to; in_sight keeps the design in focus in sight)
        self.block_followed: dict = {}         # by block: the experiment and the design pointed at the table last followed

    def headings(self) -> dict | None:
        """The titles and notes the plan measures to place the slice's note (panels.arrangement's `notes`): the bench's
        own, section.heading (None for two inputs). A seam: a bench whose three steps have other titles (bench 4,
        explorers/pareto_doe.py) gives its own, the same in its three steps."""
        return section.heading(self.function)

    def arranged(self, width: float, height: float | None):
        """The shared plan of a figure `width` x `height` layout pixels (height None: as tall as it needs), the one the
        three steps of the bench lay out with (panels.arrangement: the third panel filling its rectangle); where the
        step's own panel stands in the window's column (Lab.columned: the block of the designs), without it (third False:
        the right column one card, the 3D view's, with the readout's room at its foot on a bench of one response)."""
        return arrangement(width, height, pair="space", fill=True, drawing=self.drawing, notes=self.headings(), hero=self.hero,
                           third=not self.columned, readout=not many(self.function))

    def height_for(self, width: int) -> int:
        """Side by side, in a row or in the corner, the lab's own height; stacked, the three blocks one under the other
        (the shared plan's)."""
        if width >= STACK_WIDTH:
            return self.height
        return round(self.arranged(width, None).room)

    def indicators(self, width: float, height: float) -> tuple | None:
        """The block of the step's measures beside the 3D view, under the beam's band (the plan's, Lab.indicators)."""
        return self.arranged(width, height).indicators

    def settings(self) -> dict:
        """The first settings: a teacher's, the bench's first experiment; a student's, the free sampling with nothing
        placed and no N for the algorithms."""
        first = super().settings() | section.first(self.function)          # the view's own: none for two inputs
        return self.viewed(first | {"n": None} if self.mode == STUDENT else first)

    def experiment_of(self, settings: dict) -> Experiment | None:
        """The experiment the settings describe: the free sampling's points (N their number, whatever N holds: a typed N
        left by an older laboratory, kept for the algorithms), or an algorithm's N and seed; None while an algorithm has
        no N. Nothing of the view (the pair, the values held) is part of it."""
        method = settings["method"]
        if method == FREE:                                          # the points the reader placed: N is their number
            placed = placed_points(settings, self.d)
            return Experiment(self.function, FREE, len(placed), settings["seed"], placed)
        if settings.get("n") is None:
            return None
        return Experiment(self.function, method, settings["n"], settings["seed"])

    def automatic(self, settings: dict) -> tuple[float, ...] | None:
        """Where the slice of a bench of more than two inputs stands while no slider pinned it (section.of's `auto`):
        through the best design (the least simulated y, the first of equals) of an algorithm's sample, which then lies
        on the surface drawn; None, the middle of the ranges, with no design and for the free sampling (the reader's
        hand: nothing moves by itself). None for two inputs (the slice is the whole design space)."""
        if self.d == 2 or settings.get("method") == FREE:
            return None
        experiment = self.experiment_of(settings)
        return None if experiment is None else through(simulated(experiment))

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> SampleState:
        """The state of the settings: the experiment they describe and its simulations, or no design while an algorithm
        has no N (experiment_of), and the slice the figure shows (section.of, through the automatic point while nothing
        is pinned; the whole design space for two inputs). A "shown", a "choosing" or a "function" left by an older
        snapshot is ignored (the design is always whole; the bench is the lab's)."""
        method = settings["method"]
        cursor = settings.get("cursor")
        cursor = None if cursor is None else (float(cursor[0]), float(cursor[1]))
        cut = self.slice_of(settings)
        experiment = self.experiment_of(settings)
        if experiment is None:
            return SampleState(None, method, None, RESPONSES[self.function], None, (), (), cursor, cut)
        simulations = simulated(experiment)
        sample = design(experiment.method, experiment.n, experiment.seed, experiment.points, self.d)
        return SampleState(experiment, experiment.method, experiment.n, RESPONSES[self.function], sample, simulations.points,
                           simulations.values, cursor, cut)

    def output(self, state: SampleState) -> Experiment | None:
        """The experiment, from which the next step computes the designs and their simulations; None while an algorithm
        has no N, and while a free sample has fewer than LEAST points."""
        if state.empty or state.short:
            return None
        return state.experiment

    def missing(self, state: SampleState) -> str:
        """Why there is nothing to hand: no N typed yet, or the points of a free sample still to place to reach LEAST."""
        if state.free and state.short:
            left = LEAST - state.n
            if not state.n:                                           # nothing placed: what to do, where the eye is
                return get_text("lab.lhs.missing.free_none", least=LEAST)
            if left == 1:
                return get_text("lab.lhs.missing.free_one", least=LEAST)
            return get_text("lab.lhs.missing.free", left=left, least=LEAST)
        if state.empty:
            return get_text("lab.lhs.missing")
        return ""

    def received(self, state: SampleState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """The card of the problem the study starts from (the first step receives nothing from another), written as an
        optimization problem in its standard form (the owner's 2026-11-21: the problem evident, in a type of more
        weight): the goal, "minimize  y = f(x₁, x₂)" (problem_goal: f of all its inputs, "y = f(x₁, …, x₄)" for more
        than two), then "subject to" the bound of each input, one a row ("x₁ ∈ [−5, 10]", the interval from the bounds
        of the response in the notation [a, b], the same in both languages, with the input's unit where it has one:
        functions.Response.units, "x₁ ∈ [0.5, 5] m"), and what the response is, quietly, at the right of the card's
        heading (the row of kind "aside"): a simulation by what it is in its unit (its catalogs' "lab.lhs.problem.<key>.
        response": "y: largest deflection [mm]"), a test function by nothing (the bar names the bench). The kinds tell
        the window how to set each row (gui/lab_views.LabView.show_received): "goal" larger and
        bright, "bound" readable, "aside" muted; the slot holds the goal and four bounds. The rows are problem()'s: the
        bench's, whatever the state."""
        return get_text("lab.lhs.problem"), self.problem()

    def problem(self) -> tuple[tuple, ...]:
        """The rows of the card of the problem (received), the bench's alone: no state needed, so that the window sizes
        the card's slot of the bench's three steps to the problem it will show (gui/lab_views.CardSlot)."""
        response = RESPONSES[self.function]
        rows = [problem_goal(get_text("lab.lhs.problem.minimize"), f"y = f({inputs_of(self.d)})")]
        for k, (low, high) in enumerate(response.bounds):
            rows.append(problem_bound(k, caption.with_unit(f"{section.symbol(k)} ∈ [{short(low)}, {short(high)}]",
                                                           response.units[k])))
        own = f"lab.lhs.problem.{response.key}.response"
        if has_text(own, DEFAULT_LANGUAGE):                       # a test function: none (the bar names the bench)
            rows.append(("", get_text(own, unit=response.units[-1]), ASIDE))
        return tuple(rows)

    def cue(self, key: str, state: SampleState) -> str:
        """The sound of a command just carried out (gui/sounds.py): a new sample drawn ("sample"); in the free sampling,
        a point placed by Enter or Space or a drag ended ("place": "drag", a point placed by a click or moved; the window
        asks once, when the button is released), and a point or all of them taken back by "undo" or "Clear"
        ("remove")."""
        if state.free:
            return "place" if key in ("drag", "enter", "space") else "remove" if key in ("undo", "clear") else ""
        return "sample" if key == "new" and not state.empty else ""

    def enabled(self, key: str, state: SampleState) -> bool:
        """New sample needs N to draw again; "undo" and "Clear", a point placed."""
        if key == "new":
            return not state.free and not state.empty
        if key in ("undo", "clear"):
            return state.free and not state.empty
        return True

    def offered(self, key: str, settings: dict) -> bool:
        """New sample for an algorithm (there is something to draw again); "undo" and "Clear" for the free sampling; the
        chip of the slice (a bench of more than two inputs) while a slider pinned it."""
        if key == "new":
            return settings.get("method") != FREE
        if key in ("undo", "clear"):
            return settings.get("method") == FREE
        if key == section.CHIP:
            return section.pinned(settings)
        return True

    def naming(self, key: str, state: SampleState) -> str:
        """Under the transport row, in the free sampling, how many points are placed: a counter up to the least an
        experiment needs ("3 of 5 points", from "0 of 5 points": a status that says why the forward command waits, never
        an instruction), then the count ("12 points placed"); the chip of the slice by where it returns it: to the
        middle of the ranges for the free sampling and with no design ("Slice at the middle"), else its own label (the
        best design)."""
        if key == TRANSPORT and state.free:
            if (state.n or 0) < LEAST:
                return get_text("lab.lhs.transport_short", k=state.n or 0, least=LEAST)
            return get_text("lab.lhs.transport", k=state.n)
        if key == section.CHIP and (state.free or state.empty):
            return get_text("lab.view.slice.middle")
        return ""

    def tip_of(self, key: str, state: SampleState) -> str:
        """The chip renamed by naming (the free sampling, no design: back to the middle) says what it does under that
        name."""
        if key == section.CHIP and (state.free or state.empty):
            return get_text("lab.view.slice.middle_tip")
        return ""

    def summary(self, state: SampleState) -> tuple[str, str]:
        """What the step is worth, for the cover's track and the pill's tooltip: the empty intervals of the design handed
        on, on x1 and x2 (on every input of a bench of more: "empty 0 · 0 · 0 · 0"), an error when any interval is
        empty, as the strip paints them; nothing while there is nothing to hand."""
        if state.empty or state.short:
            return "", "plain"
        n = state.n
        empty = tuple(empty_intervals(state.column(axis), n) for axis in range(self.d))
        kind = "error" if sum(empty) else "ok"
        if self.d > 2:
            return get_text("lab.lhs.summary_many", counts=" · ".join(str(intervals) for intervals in empty)), kind
        return get_text("lab.lhs.summary", x1=empty[0], x2=empty[1]), kind

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """For the key BENCH, the formula of the bench's response (one line of mathtext; the figure typesets it,
        panels.typeset); nothing for a control."""
        return formula(self.function) if key == BENCH else ((), "")

    def adjust(self, settings: dict, key: str, old) -> dict:
        """A control of the view (a bench of more than two inputs: an axis, a slider) follows section.after: an axis
        given the input the other shows swaps the two, a slider pins the slice there; nothing of the study changes (the
        experiment never reads the view). Then the sliders stand at the slice on screen (viewed): a change of the
        sampling moves the automatic slice with the best design."""
        viewed = self.adjust_view(settings, key, old)
        return self.viewed(settings) if viewed is None else viewed

    def press(self, key: str, state, settings: dict) -> dict | None:
        """In the free sampling the four arrow keys move the cursor by CURSOR_STEP of the unit square of the pair on the
        axes (the first press shows it in the middle of the design space) and Enter or Space ("enter", "space") places a
        point at it, the inputs held at the slice's values, while fewer than MOST are placed; an algorithm's sample has
        no key of its own."""
        if settings.get("method") == FREE:
            return by_key(key, settings, state.section if state is not None else self.slice_of(settings))
        return None

    def act(self, key: str, state, settings: dict) -> dict:
        """New sample: the next seed (nothing while there is no N). The free sampling's "undo": the last point placed
        removed; "Clear": every point. The chip of the slice: back to the automatic slice (section.released). The
        sliders then stand at the slice on screen (viewed)."""
        if key == "new":
            if settings.get("n") is None or settings.get("method") == FREE:
                return settings
            return self.viewed(settings | {"seed": settings["seed"] + 1})
        if key == "undo":
            return self.viewed(settings | {"points": placed_points(settings, self.d)[:-1]})
        if key == "clear":
            return self.viewed(settings | {"points": ()})
        if key == section.CHIP:
            return self.viewed(section.released(settings))
        return super().act(key, state, settings)

    def link(self, key: str, state) -> str:
        """"View code" asks the window for the reading of the sampling on screen (gui/lab_code.py): for the free
        sampling, "free", the measures that judge it (no algorithm places it)."""
        return state.method if key == LINK else ""

    # ------------------------------------------------------------------ what to read
    def lead(self, state: SampleState) -> str:
        if state.empty and not state.free:
            return get_text("lab.lhs.lead.empty")
        return get_text(f"lab.lhs.lead.{state.method}")          # the free sampling's says it is the reader's, no algorithm's

    def metrics(self, state: SampleState) -> list[Metric]:
        """The designs and their simulations, the empty intervals, the correlation and the smallest distance, of the
        designs (a free sample's with N = the points placed); dashes while there is no design. A bench of more than two
        inputs: the empty intervals of every input ("0 · 0 · 0 · 0"), the correlation of largest |ρ| among the pairs of
        inputs, written with its pair (ρ(x₁, x₃)), the smallest distance in the unit hypercube; none of them depends on
        the slice shown."""
        many = self.d > 2
        titles = {"empty": get_text("lab.lhs.m.empty_many", inputs=section.span(self.d))
                  if many else get_text("lab.lhs.m.empty"),
                  "correlation": get_text("lab.lhs.m.correlation_most" if many else "lab.lhs.m.correlation"),
                  "correlation_tip": get_text("lab.lhs.m.correlation_most_tip" if many else "lab.lhs.m.correlation_tip"),
                  "distance_detail": get_text("lab.lhs.m.distance_detail_many" if many else "lab.lhs.m.distance_detail"),
                  "distance_tip": get_text("lab.lhs.m.distance_many_tip" if many else "lab.lhs.m.distance_tip")}
        if state.empty:
            return [Metric(get_text("lab.lhs.m.points"), DASH, tip=get_text("lab.lhs.m.points_tip")),
                    Metric(titles["empty"], DASH, detail=get_text("lab.lhs.m.empty_detail"),
                           tip=get_text("lab.lhs.m.empty_tip")),
                    Metric(titles["correlation"], DASH, tip=titles["correlation_tip"]),
                    Metric(get_text("lab.lhs.m.distance"), DASH, detail=titles["distance_detail"], tip=titles["distance_tip"])]
        n = state.n
        empty = tuple(empty_intervals(state.column(axis), n) for axis in range(self.d))
        count = get_text("lab.lhs.m.points_detail_one") if n == 1 else get_text("lab.lhs.m.points_detail", count=n)
        result = [Metric(get_text("lab.lhs.m.points"), get_text("lab.lhs.m.points_value", n=n), detail=count,
                         tip=get_text("lab.lhs.m.points_tip"))]
        result.append(Metric(titles["empty"], "  ·  ".join(str(intervals) for intervals in empty),
                             kind=("error" if sum(empty) else "ok") if state.judged else "plain",
                             detail=get_text("lab.lhs.m.empty_detail"), tip=get_text("lab.lhs.m.empty_tip")))
        if many:
            found = largest_correlation([state.column(k) for k in range(self.d)]) if n >= 3 else None
            rho, pair = found if found is not None else (None, None)
            detail = "" if pair is None else f"ρ({section.symbol(pair[0])}, {section.symbol(pair[1])})"
            result.append(Metric(titles["correlation"], DASH if rho is None else f"{rho:+.3f}", detail=detail,
                                 tip=titles["correlation_tip"]))
        else:
            rho = pearson(state.column(0), state.column(1)) if n >= 3 else None
            result.append(Metric(titles["correlation"], DASH if rho is None else f"{rho:+.3f}", tip=titles["correlation_tip"]))
        spread = smallest_distance([list(u) for u in state.design.unit]) if n >= 2 else None
        result.append(Metric(get_text("lab.lhs.m.distance"), DASH if spread is None else f"{spread:.3f}",
                             detail=titles["distance_detail"], tip=titles["distance_tip"]))
        return result

    # ------------------------------------------------------------------ the mouse
    def hit(self, figure, state: SampleState, event):
        """The design under the mouse in the design space (its index); in a free sample, over an empty place while fewer
        than MOST points are placed, PLACE: a click there puts the next point under the pointer (the pointer itself
        shows where: nothing is drawn for it, so that moving the mouse over the plane never draws the figure again);
        or None."""
        ax = self.axes.get("plane")
        if ax is None or event is None or event.inaxes is not ax:
            return None
        found = nearest(ax, section.projected(state.section, state.points), event) if state.points else None
        if found is None and state.free and not state.full:
            return PLACE
        return found

    def grabbable(self, hovered) -> bool:
        """A design of a free sample can be dragged."""
        return self.by_hand and design_index(hovered) is not None

    def clickable(self, hovered) -> bool:
        """An empty place of a free sample answers a click: a point is placed there."""
        return isinstance(hovered, tuple)

    def grab(self, figure, state: SampleState, event):
        """In the free sampling, a press on a design takes it (its index); one on an empty place, while fewer than MOST
        are placed, takes the next point, the index it will have (drag puts it under the mouse at once: a click places
        it, a drag places it and moves it); with MOST placed, nothing."""
        ax = self.axes.get("plane")
        if not state.free or ax is None or event is None or event.inaxes is not ax:
            return None
        found = nearest(ax, section.projected(state.section, state.points), event) if state.points else None
        if found is not None:
            return found
        return state.n if not state.full else None

    def takes(self, state: SampleState) -> bool:
        """A press on the design space places a point: the free sampling, while fewer than MOST are placed."""
        return state.free and not state.full

    def drag(self, figure, state: SampleState, handle, event, settings: dict) -> dict | None:
        """The point grabbed moved under the mouse, kept inside the unit square of the pair on the axes (also from over
        another panel: on the border); the next point placed there, its other inputs at the slice's held values
        (Section.lift: to place a point in d inputs one prescribes d numbers); a point already placed keeps its own
        held coordinates (only the pair's follow the mouse). None when nothing moves."""
        ax = self.axes.get("plane")
        if settings.get("method") != FREE or ax is None or design_index(handle) is None or event is None:
            return None
        u = unit_of(ax, state, event)
        cut = state.section
        points = list(placed_points(settings, self.d))
        if handle < len(points):
            moved = u if cut.plain else tuple(u[cut.pair.index(k)] if k in cut.pair else v for k, v in enumerate(points[handle]))
            if points[handle] == moved:
                return None
            points[handle] = moved
        elif handle == len(points) < MOST:
            points.append(u if cut.plain else lifted(cut, *u))
        else:
            return None
        return settings | {"points": tuple(points)}

    # ------------------------------------------------------------------ the figure
    def boxes(self, figure) -> dict:
        """The panels' boxes and the places of their titles, in figure fractions, from the shared plan in layout pixels:
        the design space and the 3D view where the other steps have theirs; the table in the third panel's block,
        where the arrangement has one (never where the step's panel stands in the column: Lab.columned, its block)."""
        width, height = size(figure)
        plan = self.arranged(width, height)

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)     # a box is never empty
        boxes = {"plane": frac(*plan.plane), "space": frac(*plan.space)}
        heads = places(plan, width, height, ("plane", "space"))          # with the caption's block ("formula")
        if plan.check is not None:                                   # the third panel's block (a table has no ticks: in a
            left, bottom, wide, tall = plan.check if plan.kind == "stack" else plan.ranking    # row or the corner it takes
            boxes["table"] = frac(left, bottom - BELOW, wide, tall + TABLE_RISE + BELOW)        # their room too, and the
                                                                                                 # room of its axes' names under it)
            third = places(plan, width, height, ("check",))                                    # room of a second row of
            heads["table"], heads["card table"] = third["check"], third["card check"]          # legend; on its card
        boxes["heads"] = heads
        return boxes

    def prepare(self, figure, state: SampleState) -> dict:
        """The axes of the figure: made again when the figure's size or the language changes, with the caption of the
        3D view's card made in its block (explorers/caption.py: the formula of the response, or the drawing of a bench
        drawn, whose text column is measured in the language), and reused otherwise (the 3D view keeps the angle the
        reader turned it to); what they hold is the scene's, kept, and the moving artists', drawn again (draw)."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height), current_language(), self.columned)
        space = self.axes.get("space")
        if space is not None and space.figure is figure:               # turned with the mouse since the last draw
            self.view = (space.elev, space.azim)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = self.arranged(width, height)
            self.cards = draw_cards(figure, self.plan)                   # the 3D view's and the table's, once per layout
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "table") if name in boxes}
            self.axes["space"] = figure.add_axes(boxes["space"], projection="3d")
            self.axes["plane"].set_zorder(1)                          # its last x1 tick label overhangs the 3D box: above it
            self.heads = boxes["heads"]
            self.caption = caption.Caption(figure, self.plan, self.heads, self.function,     # once per layout: its axes
                                           state.section.pair, self.columned)     # 1A where columned
            self.written = self.caption.written                       # are the caption's own, never the lab's to clear
            self.layout_key = key
            self.scene = None                                         # new axes: nothing on them yet
            self.moving = []
        return self.axes

    def draw(self, figure, state: SampleState, hovered) -> None:
        """The three panels with their titles and legends; a legend lists only what the figure draws (no entry of the
        designs while none is placed: a student's empty step, a free sample not begun). The scene (scene_of: what
        depends only on N, whether any design is shown and the language) is drawn once; the rest, the designs, the
        keyboard's cursor, the bands and the table's rows, at every draw (moving): a design pointed at and a point
        dragged redraw only them."""
        axes = self.prepare(figure, state)
        self.by_hand = state.free                                    # hit and grab answer for the axes drawn here
        scene = (scene_of(state), self.truth_shown())                # f shown or hidden (Show f) is the scene's too
        if self.scene != scene:
            self.draw_scene(figure, axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        self.draw_plane(axes["plane"], state, hovered)
        self.draw_bands(axes["plane"], state)
        self.draw_space(axes["space"], state, hovered)
        if "table" in axes:
            self.draw_table(axes["table"], state, hovered)
        self.live(state, hovered)                                     # the drawing's focus and the crosshair, last
        axes["space"].view_init(*self.view)

    def focused(self, state: SampleState, hovered):
        """The drawing's focus: the design pointed at, the place under the pointer, or the best design."""
        return caption.pointed(state.points, state.values, hovered, self.pointer)

    def draw_scene(self, figure, axes: dict, state: SampleState) -> None:
        """What stays while the pointer moves: the design space's frame, axes and intervals, the response's surface and
        the floor of the 3D view, the table's frame, and every title and legend (the axes cleared first, unless they
        are new; the formula kept: it is drawn once per layout)."""
        if self.scene is not None:
            for ax in axes.values():
                ax.clear()
            for text in list(figure.texts):
                if text is not self.written:
                    text.remove()
            for legend in list(figure.legends):
                legend.remove()
        self.moving = []
        drawn = not state.empty
        note = section.note(self.function, state.section)                # the slice shown: "" for two inputs
        self.frame_plane(axes["plane"], state)
        titled(figure, self.heads, axes, "plane", get_text("lab.lhs.plane_title"), [
            Patch(facecolor=ONE, edgecolor=palette.CARD, label=get_text("lab.lhs.legend.one")),
            Patch(facecolor=MORE, edgecolor=palette.CARD, label=get_text("lab.lhs.legend.more")),
            Patch(facecolor="none", edgecolor=EMPTY, hatch="////", label=get_text("lab.lhs.legend.empty"))] if drawn else [], note,
            "plane" in self.plan.noted, legend_most(self.plan, "plane"))
        self.frame_space(axes["space"], state)
        titled(figure, self.heads, axes, "space", space_title(self.function), [
            *([Patch(facecolor=palette.SURFACE_RAMP[3], label=get_text("lab.lhs.legend.surface"))] if self.truth_shown() else []),
            *([dot(POINT, get_text("lab.lhs.legend.designs"))] if drawn else [])], note, "space" in self.plan.noted,
            legend_most(self.plan, "space"))
        if "table" in axes:
            frame_table(axes["table"])
            titled(figure, self.heads, axes, "table", get_text("lab.lhs.table_title"), [])
            if drawn:                                                 # what its numbers are: intervals, not coordinates
                subtitle(figure, self.heads, "table", get_text("lab.lhs.table_caption"), head_room(figure, self.heads, axes, "table"),
                         title_drop(figure, self.heads, axes, "table", get_text("lab.lhs.table_title")))

    def frame_plane(self, ax, state: SampleState) -> None:
        """The design space's frame, axes, ticks and names, those of the other steps' design space, and its N intervals
        per axis (none without a design)."""
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        plane_ticks(ax, self.plan is not None and self.plan.band is not None)
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        name_plane(ax, state.response.units, state.section.pair, many(self.function))     # the pair and its units, as in
                                                                      # the other steps (off a tick: several responses)
        if state.empty:                                               # no design: the frame and its axes, nothing in it
            return
        n = state.n
        h1, h2 = (b1 - a1) / n, (b2 - a2) / n
        grid ={"color": palette.DARK_GREY, "linewidth": 0.8 if n <= 30 else 0.5, "alpha": 0.9 if n <= 30 else 0.6, "zorder": 1}
        for k in range(1, n):
            ax.axvline(a1 + k * h1, **grid)
            ax.axhline(a2 + k * h2, **grid)

    def draw_plane(self, ax, state: SampleState, hovered) -> None:
        """In the design space, the designs, the ring of the design under the mouse and, in a free sample, the keyboard's
        cursor, where Enter would place the next point (a yellow ring and cross; the mouse's place is the pointer's own):
        moving artists."""
        moving = self.moving
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        if state.free and not state.full and state.cursor is not None:
            x, y = a1 + (b1 - a1) * state.cursor[0], a2 + (b2 - a2) * state.cursor[1]
            ring = marker_size((state.n or 0) + 1)
            moving.append(ax.scatter([x], [y], s=ring, facecolors="none", edgecolors=CHOSEN, linewidths=1.3, zorder=7))
            moving.append(ax.scatter([x], [y], s=ring * 2.2, marker="+", color=CHOSEN, linewidths=1.2, zorder=7))
        if state.empty:
            return
        size_ = marker_size(state.n)
        cut = state.section
        if cut.plain:
            xs, ys = zip(*state.points)
            moving.append(ax.scatter(xs, ys, s=size_, color=POINT, edgecolors=palette.CARD, linewidths=0.9, zorder=6))
        else:                                                          # projections, larger near the slice, fainter off it
            marks = Marks.of(cut, state.points, state.design.unit)
            moving.append(ax.scatter(marks.xs, marks.ys, s=marks.areas(size_), color=marks.inks(POINT),
                                     edgecolors=marks.inks(palette.CARD), linewidths=Marks.EDGE, zorder=6))
        pointed = design_index(hovered)
        if pointed is not None and pointed < state.n:
            x1, x2 = cut.project(state.points[pointed])
            ring = 2.6 * (size_ if cut.plain else section.grown(size_, cut.closeness(state.design.unit[pointed])))
            moving.append(ax.scatter([x1], [x2], s=ring, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4, zorder=7))

    def draw_bands(self, ax, state: SampleState) -> None:
        """How many designs each interval holds, in two bands inside the design space's edges, BAND pixels thick: x1's
        intervals along the top, x2's along the right (the pair's two inputs, on a bench of more than two: every design
        counted, a projection, wherever the slice stands), mitred where they meet. One design teal, more gold (the count
        written while the intervals are wide enough), none red, hollow and hatched once judged (LEAST designs on). Drawn
        under the points; none without a design. Moving artists."""
        if state.empty:
            return
        moving = self.moving
        across = ax.get_position().width * size(ax.figure)[0]         # the plane's sides: a plane that fills its room is
        side = ax.get_position().height * size(ax.figure)[1]          # taller than wide (panels.corner_alone)
        t, u = min(BAND / max(across, 1.0), 0.2), min(BAND / max(side, 1.0), 0.2)     # the bands' thickness, BAND pixels
        n = state.n                                                   # each: x2's in the width, x1's in the height
        moving.append(ax.add_patch(Polygon([(0, 1), (1, 1), (1, 0), (1 - t, 0), (1 - t, 1 - u), (0, 1 - u)], closed=True,
                                           transform=ax.transAxes, facecolor=palette.TRACK, edgecolor="none", zorder=4)))
        thin = 0.5 if min(side, across) / n < 6 else 1.0
        for axis in (0, 1):                                           # the pair's: its first input along the top
            counts = interval_counts(state.column(state.section.pair[axis]), n)
            for k, count in enumerate(counts):
                hatched = count == 0 and state.judged
                if hatched:
                    face, edge = "none", EMPTY
                elif count == 0:
                    continue                                          # not visited, not judged yet: the band's own track
                else:
                    face, edge = (ONE if count == 1 else MORE), palette.CARD
                low, high = k / n, (k + 1) / n
                if axis == 0:
                    cell = mitred([(low, 1 - u), (high, 1 - u), (high, 1.0), (low, 1.0)], above=True, t=t, u=u)
                else:
                    cell = mitred([(1 - t, low), (1.0, low), (1.0, high), (1 - t, high)], above=False, t=t, u=u)
                if len(cell) < 3:
                    continue
                moving.append(ax.add_patch(Polygon(cell, closed=True, transform=ax.transAxes, facecolor=face, edgecolor=edge,
                                                   linewidth=thin, hatch="////" if hatched else None, zorder=5)))
                if count >= 2 and n <= LABEL_MOST and min(side, across) / n >= CELL_LEAST:
                    x = sum(p[0] for p in cell) / len(cell)
                    y = sum(p[1] for p in cell) / len(cell)
                    moving.append(ax.text(x, y, str(count), transform=ax.transAxes, ha="center", va="center", color=palette.CARD,
                                          zorder=5, **COUNT))

    def draw_table(self, ax, state: SampleState, hovered) -> None:
        """The designs as a table, one row each: design i takes the i-th entry of the shuffled list of each axis
        (intervals numbered from 1; the code counts from 0), of the N intervals per axis (a free sample's N, its points
        placed). The rows run down columns of rows (i, x1, x2) side by side, as many as the panel holds, closer when
        that holds every design; a longer design shows the page of rows that holds the design in focus (table_page), and
        its last line says which rows those are. The row of the design under the pointer is lit. Without a design, the
        headings of one column over no row. Moving artists, on the frame of frame_table."""
        moving = self.moving
        width, height = table_room(ax)
        n = state.n
        if state.empty:                                               # no row: no headings over nothing either
            return
        d = self.d
        page = table_page(n, width, height, focus(state, hovered), d)
        row, font = page.row, page.font
        pitch = min(width / page.columns, TABLE_MOST * entries_share(d))
        start = (width - page.columns * pitch) / 2                    # the columns of rows centred in the card
        band = headed(row)                                            # the headings' line
        pointed = design_index(hovered)
        heading = HEADING | {"fontsize": font + TABLE_HEADING}
        number = NUMBER | {"fontsize": font}
        for c in range(page.columns):
            left = start + c * pitch
            places = tuple(left + share * pitch for share in table_rights(d))      # each column right-aligned on its digits
            for x, name in zip(places, ("$i$", *(input_name(k) for k in range(d)))):
                moving.append(ax.text(x, height - band / 2, name, ha="right", va="center", **heading))
            moving += ax.plot([left + 4, left + pitch - 8], [height - band, height - band], color=palette.DARK_GREY, linewidth=0.8)
            for r in range(page.rows):
                i = page.first + c * page.rows + r
                if i > page.last:
                    break
                y = height - band - (r + 0.5) * row
                lit = i == pointed
                color = CHOSEN if lit else palette.WHITE
                if lit:
                    moving.append(ax.add_patch(Rectangle((left + 2, y - row / 2 + 1), pitch - 8, row - 2, facecolor=palette.PILL,
                                                         edgecolor="none", zorder=1)))
                moving.append(ax.text(places[0], y, str(i + 1), ha="right", va="center", color=palette.GREY, zorder=2,
                                      **number))                                               # the index, muted
                for place, cell in zip(places[1:], state.design.cells[i]):
                    moving.append(ax.text(place, y, str(cell + 1), ha="right", va="center", color=color, zorder=2, **number))
        if page.partial:
            moving.append(ax.text(start + 4, row / 2, get_text("lab.lhs.table_rows", first=page.first + 1, last=page.last + 1, n=n),
                                  ha="left", va="center", color=MUTED_INK, **SMALL))

    def frame_space(self, ax, state: SampleState) -> None:
        """The response over the design space, in the vertical window of the three steps, the rectangle of the design
        space on its floor, and the view's limits, panes, ticks and box; no background of its own: its card shows. The
        surface of f only where the true response is shown (Lab.truth_shown: a test function's always; a simulation's,
        as in a real study, only once the reader asked to see it): else the designs alone stand in the view."""
        ax.set_facecolor("none")
        ax.computed_zorder = False                                    # the designs stay in front of the surface
        cut = state.section
        low, high, _ = window(state.response.key)
        if self.truth_shown():
            x1, x2, y = surface(state.response.key, cut)              # f's slice on the pair (the whole for two inputs)
            lowest, highest = (float(y.min()), float(y.max())) if cut.plain else extent(state.response.key)    # a slice's
            ax.plot_surface(x1, x2, y, cmap=RAMP, vmin=lowest, vmax=highest, rstride=1, cstride=1, linewidth=0,  # colours: the
                            antialiased=False, alpha=0.9, zorder=1)                                             # bench's range
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        ax.plot([a1, b1, b1, a1, a1], [a2, a2, b2, b2, a2], [low] * 5, color=palette.DARK_GREY, linewidth=0.8, zorder=1)
        ax.set_xlim(a1, b1)
        ax.set_ylim(a2, b2)
        ax.set_zlim(low, high)
        ax.set_box_aspect((1.0, 1.0, self.plan.aspect), zoom=SPACE_ZOOM)     # the plan's: filling its card, alone
        style_space(ax, state.response.units, cut.pair)
        space_ticks(ax, not cut.plain)

    def draw_space(self, ax, state: SampleState, hovered) -> None:
        """On the response, the designs and their stems down to the floor (the design space), and the design under the
        mouse with its y: moving artists. On a bench of more than two inputs each design stands at its projection on
        the pair and at its own simulated y, fainter and smaller the farther it is from the slice (Marks, grow=False): only a design
        on the slice lies on the surface drawn."""
        if state.empty:
            return
        moving = self.moving
        low, high, _ = window(state.response.key)
        cut = state.section
        if cut.plain:
            xs, ys = zip(*state.points)
            for x, y_, z in zip(xs, ys, state.values):
                moving += ax.plot([x, x], [y_, y_], [low, z], color=palette.GREY, linewidth=0.7, linestyle=(0, (2, 2)), zorder=2)
            moving.append(ax.scatter(xs, ys, [low] * len(xs), s=8, color=palette.GREY, depthshade=False, zorder=2))
            moving.append(ax.scatter(xs, ys, state.values, s=marker_size(state.n), color=POINT, edgecolors=palette.CARD,
                                     linewidths=0.8, depthshade=False, zorder=4))
        else:
            marks = Marks.of(cut, state.points, state.design.unit, state.values)
            for x, y_, z, share in zip(marks.xs, marks.ys, marks.values, marks.shares):
                moving += ax.plot([x, x], [y_, y_], [low, z], color=palette.GREY, alpha=share, linewidth=0.7, linestyle=(0, (2, 2)),
                                  zorder=2)
            moving.append(ax.scatter(marks.xs, marks.ys, [low] * len(marks.xs), s=marks.areas(8, grow=False),
                                     color=marks.inks(palette.GREY), depthshade=False, zorder=2))
            moving.append(ax.scatter(marks.xs, marks.ys, marks.values, s=marks.areas(marker_size(state.n), grow=False),
                                     color=marks.inks(POINT), edgecolors=marks.inks(palette.CARD), linewidths=Marks.EDGE,
                                     depthshade=False, zorder=4))
        pointed = design_index(hovered)
        if pointed is not None and pointed < state.n:
            (x, y_), z = cut.project(state.points[pointed]), state.values[pointed]
            ring = marker_size(state.n) * 2.6 * (1.0 if cut.plain else section.shrunk(1.0, cut.closeness(state.design.unit[pointed])))
            moving.append(ax.scatter([x], [y_], [z], s=ring, facecolors="none", edgecolors=palette.WHITE,
                                     linewidths=1.4, depthshade=False, zorder=5))
            if self.plan.readout is None:                             # the card alone (2A): the value in its readout
                moving.append(ax.text(x, y_, z + 0.06 * (high - low), f"y = {short(z, 4)}", color=palette.WHITE, zorder=6, **TAG))
        if self.plan.readout is not None:
            moving += readout(ax.figure, self.plan, readings(state, pointed))

    # ------------------------------------------------------------------ the step's block in the column (columned)
    def blocks(self, state, width: float) -> tuple[Block, ...]:
        """Where the step's own panel stands in the window's column (Lab.columned), its one block: the table of the
        simulated designs (DESIGNS), titled in words, the units of its columns in the muted line under its title
        (units_line: "x₁, x₂ [m]; y [mm]"; none for a test function), taking the column's room left, its heading alone
        while there is no design (designs_block); () otherwise."""
        if not self.columned:
            return ()
        return (designs_block(get_text("lab.lhs.designs_title"), units_line(RESPONSES[self.function]), state),)

    def table_columns(self, state: SampleState) -> "Columns":
        """The block's table as written (a seam: a bench of several outputs adds its own columns): the headings, i, the
        inputs and y; a row per design in the order of the designs, its index and its values (an input to
        DESIGNS_DECIMALS[0] decimals, y to DESIGNS_DECIMALS[1]); the widest text of each column (from the bounds, the
        vertical window of the 3D view and the values themselves: the columns hold still while the sample changes); the
        best design (the least simulated y, the first of equals), whose y is drawn in the designs' blue. No row without a
        design."""
        response = state.response
        places, decimals = DESIGNS_DECIMALS
        eights = str.maketrans("0123456789", "8888888888")
        heads = ("$i$", *(input_name(k) for k in range(self.d)), Y)
        rows = () if state.empty else tuple((str(i + 1), *(number(float(x), places) for x in point), number(float(y), decimals))
                                            for i, (point, y) in enumerate(zip(state.points, state.values)))
        low, high, _ = window(response.key)
        widest = [str(MOST), *(max((number(float(v), places) for v in response.bounds[k]), key=len).translate(eights)
                               for k in range(self.d)),
                  max((number(float(v), decimals) for v in (low, high)), key=len).translate(eights)]
        for row in rows:
            widest = [max(wide, cell.translate(eights), key=len) for wide, cell in zip(widest, row)]
        return Columns(heads, rows, tuple(widest), 1, best_of(state.values))

    def blocked(self, key: str, figure):
        """The axes of the block `key` on its own figure (Lab.block_axes, never the figure's axes): made again only when
        the figure, its size, its density or the language changes, the whole figure in BLOCK_TONE, its data coordinates
        its layout pixels; kept otherwise (what it holds is removed and drawn again by draw_block)."""
        width, height = size(figure)
        layout = (id(figure), round(width), round(height), figure.dpi, current_language())
        ax = self.block_axes.get(key)
        if ax is None or ax.figure is not figure or self.block_keys.get(key) != layout:
            figure.clear()
            figure.set_facecolor(BLOCK_TONE)
            ax = figure.add_axes((0.0, 0.0, 1.0, 1.0))
            ax.set_facecolor(BLOCK_TONE)
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            ax.set_xlim(0, max(width, 1.0))
            ax.set_ylim(0, max(height, 1.0))
            self.block_axes[key] = ax
            self.block_keys[key] = layout
            self.block_shown.pop(key, None)
            self.block_moving[key] = []
        return ax

    def draw_block(self, key: str, figure, state, hovered) -> bool:
        """The block of the designs on its own figure (draw_designs); whether anything changed: False when the rows on
        show, the design lit, the best one, the language and the figure's size are those drawn last (and for a key
        that is not this step's)."""
        if key != DESIGNS or state is None:
            return False
        return self.draw_designs(figure, state, hovered)

    def draw_designs(self, figure, state: SampleState, hovered) -> bool:
        """The table of the simulated designs, in the block's figure: under the line of its headings (symbols in STIX,
        muted: panels.HEADING), a row per design in the order of the designs, i muted, the inputs and y in the monospace,
        right-aligned on the digit (panels.NUMBER), each column as wide as its widest text may be (designs_layout), the
        best design's y in the designs' blue; the row of the design under the pointer lit (the pill, its values in the
        cursor's yellow), else the best design's row under the pill alone (the drawing's focus); when the rows do not all
        fit, the rows from the first the window's scroll bar shows (in_sight: the design in focus kept in sight, scrolled),
        and nothing under them (the scroll bar says which rows). Without a design, the headings alone."""
        ax = self.blocked(DESIGNS, figure)
        width, height = size(figure)
        made = self.table_columns(state)
        n = len(made.cells)
        pointed = design_index(hovered)
        pointed = pointed if pointed is not None and 0 <= pointed < n else None
        rest = None if not n else (n - 1 if state.free else made.best)
        layout = designs_layout(made, width, height - BLOCK_TOP, n, self.d)
        layout = rows_from(layout, self.in_sight(DESIGNS, state.experiment, n, layout.rows, pointed, rest), n)
        shown = (self.block_keys[DESIGNS], state.experiment, made.cells, made.best, pointed, layout.first, layout.last,
                 current_language())
        if self.block_shown.get(DESIGNS, (None,))[0] == shown:
            return False
        for artist in self.block_moving.get(DESIGNS, []):
            artist.remove()
        moving = self.block_moving[DESIGNS] = []
        top = height - BLOCK_TOP
        heading = HEADING | {"fontsize": layout.font + TABLE_HEADING}
        figures = NUMBER | {"fontsize": layout.font}
        for x, name in zip(layout.rights, made.heads):
            moving.append(ax.text(x, top - layout.band / 2, name, ha="right", va="center", **heading))
        moving += ax.plot([layout.left, layout.right], [top - layout.band] * 2, color=palette.DARK_GREY, linewidth=0.8)
        outputs = range(len(made.heads) - made.outputs, len(made.heads))
        first, pitch = row_places(layout, top, figure.dpi)           # whole device pixels apart: evenly spaced at any density
        for r, i in enumerate(range(layout.first, layout.last + 1)):
            y = first - r * pitch
            lit = i == pointed
            if lit or (pointed is None and i == made.best):
                moving.append(ax.add_patch(Rectangle((layout.left, y - pitch / 2 + 1), layout.right - layout.left,
                                                     pitch - 2, facecolor=palette.PILL, edgecolor="none", zorder=1)))
            ink = CHOSEN if lit else palette.WHITE
            for k, (x, text) in enumerate(zip(layout.rights, made.cells[i])):
                color = palette.GREY if k == 0 else POINT if i == made.best and k in outputs else ink
                moving.append(ax.text(x, y, text, ha="right", va="center", color=color, zorder=2, **figures))
        self.block_shown[DESIGNS] = (shown, layout)
        return True

    # ------------------------------------------------------------------ the block's table scrolled (the window's bar)
    def in_sight(self, key: str, experiment, n: int, rows: int, pointed: int | None, rest: int | None) -> int:
        """The first row the block `key`'s table shows, `rows` of its `n` on show: the row the reader scrolled to
        (scroll_to), moved only as far as it takes to bring a design into sight when the table must follow one: the design
        pointed at when it changes (on the plane, or a row under the mouse), else, for a new experiment (a new sample, a
        point placed), `rest` (the best design, or a free sample's last point); kept within the rows. A block resized
        keeps the reader's place (its first row, only clamped to the rows). A view, never a setting: the window's scroll
        bar reads it (scrolled)."""
        first = self.block_first.get(key, 0)
        seen, was = self.block_followed.get(key, (None, None))
        target = None
        if experiment != seen:                                        # a new experiment: the design in focus in sight
            target = pointed if pointed is not None else rest
        elif pointed is not None and pointed != was:
            target = pointed
        self.block_followed[key] = (experiment, pointed)
        if target is not None:
            if target < first:
                first = target
            elif target >= first + rows:
                first = target - rows + 1
        first = min(max(first, 0), max(n - rows, 0))
        self.block_first[key] = first
        return first

    def scroll_to(self, key: str, first: int) -> None:
        """The reader dragged the block `key`'s scroll bar (or turned the wheel over its table): its first row on show,
        drawn at the next draw_block (in_sight keeps it within the rows)."""
        self.block_first[key] = int(first)

    def scrolled(self, key: str) -> "Scroll | None":
        """What the window's scroll bar of the block `key` shows (Scroll: the designs, the rows on show, the first, and
        the band of the rows in the block's figure), from its last draw; None where every row is on show (no bar) or the
        block is not a table drawn."""
        drawn = self.block_shown.get(key)
        layout = drawn[1] if drawn is not None else None
        if layout is None or not hasattr(layout, "count") or layout.count <= layout.rows:
            return None
        return Scroll(layout.count, layout.rows, layout.first, BLOCK_TOP + layout.band, layout.rows * layout.row)

    def hit_block(self, key: str, figure, state, event):
        """The design whose row of the block's table is under the mouse (its index), else None: event.x and event.y are
        device pixels, read through the block's axes (at any density); nothing over the headings, under the rows, the
        room beside the table or a block drawn for another figure."""
        ax = self.block_axes.get(key)
        drawn = self.block_shown.get(key)
        if key != DESIGNS or ax is None or ax.figure is not figure or drawn is None or event is None or state is None:
            return None
        layout = drawn[1]
        x, y = ax.transData.inverted().transform((event.x, event.y))
        if not layout.left <= x <= layout.right:
            return None
        first, pitch = row_places(layout, size(figure)[1] - BLOCK_TOP, figure.dpi)
        r = (first + pitch / 2 - y) // pitch
        i = layout.first + int(r)
        return i if r >= 0 and i <= layout.last and i < (state.n or 0) else None

# ------------------------------------------------------------------------------
# The block's table of the designs (SamplingLab.blocks, draw_designs)
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Columns:
    """The block's table as written (SamplingLab.table_columns): the headings (mathematics), a row per design (its
    index, then its values, as written), the widest text each column may hold (measured: the columns never move), how
    many last columns are outputs (the best design's in the designs' blue) and the best design (an index, or None)."""
    heads: tuple[str, ...]
    cells: tuple[tuple[str, ...], ...]
    widest: tuple[str, ...]
    outputs: int = 1
    best: int | None = None

@dataclass(frozen=True)
class DesignsLayout:
    """The block's table laid out (designs_layout): the rows on show (first..last, from 0; partial when not all of
    them), a row's height and the line of the headings (layout pixels), the numbers' size (points), the right edge
    of each column and the table's ends; the rows its room holds and the designs it has (count: more than rows, the
    window's scroll bar moves first, Scroll)."""
    first: int
    last: int
    partial: bool
    row: float
    band: float
    font: float
    rights: tuple[float, ...]
    left: float
    right: float
    rows: int = 1
    count: int = 0

@dataclass(frozen=True)
class Scroll:
    """What the window's scroll bar of a block's table shows (SamplingLab.scrolled): the designs `count`, the `rows` on
    show and the `first` of them (from 0), and the band of the rows in the block's figure, `top` layout pixels under its
    top and `height` high (the bar stands beside them)."""
    count: int
    rows: int
    first: int
    top: float
    height: float

def rows_from(layout, first: int, n: int):
    """A table's layout (DesignsLayout, or bench 4's pareto_doe.BlockTable) showing its rows from `first`: as many as
    its room holds, partial when they are not all of its `n`."""
    last = min(first + layout.rows, n) - 1 if n else -1
    return replace(layout, first=first if n else 0, last=last, partial=n > layout.rows, count=n)

def row_places(layout: DesignsLayout, top: float, dpi: float) -> tuple[float, float]:
    """The middle of the block's first row on show and the pitch of its rows, in layout pixels, under a table whose top
    is `top`: the pitch a whole number of device pixels at the figure's density (layout.row's, rounded down: the rows
    never take more room than the page laid out for them) and every middle a quarter of a device pixel over a whole
    one, so that the renderer, which rounds a text's place to the pixel (half to even), sets every row at the same
    distance from the next (never 14 and 16 px in turn)."""
    scale = dpi / LAYOUT_DPI
    pitch = max(math.floor(layout.row * scale + 1e-9), 1)
    middle = math.floor((top - layout.band - layout.row / 2) * scale) + 0.25
    return middle / scale, pitch / scale

def designs_layout(columns: Columns, width: float, height: float, n: int, d: int = 2) -> DesignsLayout:
    """The block's table in a room `width` x `height` (layout pixels): the rows of table_page in one column of rows
    (most=1, no last line kept: the window's scroll bar says which rows), from the first (rows_from moves them); its
    font, table_page's, stepped down by half a point to panels.TABLE_LEAST while the columns (each as wide as its
    widest text or its heading: panels.number_width, text_width) with DESIGNS_GAP_LEAST between them do not fit the
    width less DESIGNS_SIDE a side; the room left shared out between the columns up to DESIGNS_GAP, the table centred."""
    page = table_page(max(n, 1), width - 2 * DESIGNS_SIDE, height, 0, d, most=1, footed=False)
    room = width - 2 * DESIGNS_SIDE

    def widths(font: float) -> list[float]:
        return [max(number_width(text, font), text_width(name, font + TABLE_HEADING))
                for text, name in zip(columns.widest, columns.heads)]
    font = page.font
    while sum(widths(font)) + DESIGNS_GAP_LEAST * len(columns.heads) > room and font - 0.5 >= TABLE_LEAST - 1e-9:
        font -= 0.5
    measured = widths(font)
    gap = min(max((room - sum(measured)) / len(measured), DESIGNS_GAP_LEAST), DESIGNS_GAP)
    block = sum(measured) + gap * len(measured)
    left = (width - block) / 2
    rights, x = [], left
    for wide in measured:
        x += gap + wide
        rights.append(x)
    rows = page.rows * page.columns
    return DesignsLayout(0, min(rows, n) - 1 if n else -1, n > rows, page.row, headed(page.row), font, tuple(rights),
                         left + gap / 2, left + block, rows, n)

def best_of(values) -> int | None:
    """The best design of simulated values: the least y, the first of equals; None without a design."""
    if not len(values):
        return None
    return min(range(len(values)), key=lambda k: values[k])

def problem_goal(verb: str, objective: str) -> tuple[str, str, str]:
    """The problem card's first row: the goal, "minimize" and what (gui/lab_views sets it larger and bright)."""
    return (verb, objective, GOAL)

def problem_bound(k: int, bound: str, tip: str = "") -> tuple:
    """A row of the problem card's constraints: "subject to" on the first one (k = 0) and nothing on the others, so that
    they stand in one column under it; a tip of its own where given (Lab.received's fourth)."""
    row = (get_text("lab.lhs.problem.subject") if k == 0 else "", bound, BOUND)
    return (*row, tip) if tip else row

def inputs_of(d: int) -> str:
    """The inputs of f as the figure's titles write them: "x₁, x₂", or "x₁, …, x₄" for more than two."""
    return ", ".join(section.symbol(k) for k in range(d)) if d <= 2 else f"{section.symbol(0)}, …, {section.symbol(d - 1)}"

def designs_block(title: str, note: str, state) -> Block:
    """The block of the table of the designs (SamplingLab.blocks, and bench 4's): taking the column's room left, or,
    with no design yet (a student's empty step 1), its heading alone (most 0: no blank card under it, and no note)."""
    if state is None or state.empty:
        return Block(DESIGNS, title, least=0, most=0)
    return Block(DESIGNS, title, note, least=DESIGNS_LEAST)

def units_line(response: Response) -> str:
    """The units of the block's table, in one muted line under its title, never in its headings, in the axes'
    brackets: the inputs of one unit named together ("x₁, x₂ [m]", "x₁…x₄ [m]"), then y's ("y [mm]"), joined by "; ";
    "" for a response with no units (a test function)."""
    units, d = response.units, response.d
    parts, k = [], 0
    while k < d:
        j = k
        while j + 1 < d and units[j + 1] == units[k]:
            j += 1
        if units[k]:
            named = section.symbol(k) if j == k else f"{section.symbol(k)}, {section.symbol(j)}" if j == k + 1 \
                else f"{section.symbol(k)}…{section.symbol(j)}"
            parts.append(get_text("lab.lhs.table_unit", inputs=named, unit=units[k]))
        k = j + 1
    if len(units) > d and units[-1]:
        parts.append(get_text("lab.lhs.table_unit", inputs="y", unit=units[-1]))
    return "; ".join(parts)

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Page:
    """The rows of the table on show: designs first..last (indices from 0), in `columns` columns of `rows` rows each;
    partial when the design has more rows than that (a last line then says which ones are shown). row: the height of a
    row, in layout pixels; font: the size of its numbers, in points."""
    first: int
    last: int
    columns: int
    rows: int
    partial: bool
    row: float = TABLE_ROW
    font: float = TABLE_FONT

def table_page(n: int, width: float, height: float, focus: int, d: int = 2, most: int | None = None,
               footed: bool = True) -> Page:
    """The rows a table of `width` x `height` layout pixels holds: under a line of headings, one column of the larger
    rows of TABLE_LARGE while every design fits in it; else rows of TABLE_ROW in columns at least TABLE_COLUMN wide, or,
    when that holds every design and the usual rows do not, the closer rows and columns of TABLE_DENSE, then of
    TABLE_TIGHT. Every design when they fit (in as few columns as they need, of balanced lengths); otherwise, set close
    (TABLE_DENSE), the page of rows that holds the design `focus`, the pages following one another so that the table
    stays still while the focus walks inside its page, and a last line kept for the words that say which rows. A
    design of d inputs has d + 1 entries a row: its columns of rows are wider by entries_share(d). `most`: at most that
    many columns of rows (the block's table of values, a row too wide for two: 1); None, as many as the width holds.
    `footed` False: no last line kept (the block's table, whose rows the window's scroll bar names)."""
    def across(column: float, share: float) -> int:
        fitted = max(int(width // (column * share)), 1)
        return fitted if most is None else min(fitted, max(most, 1))
    large, font = TABLE_LARGE
    if n <= int(height // large) - 1:
        return Page(0, n - 1, 1, n, False, large, font)
    share = entries_share(d)
    for row, column, font in ((TABLE_ROW, TABLE_COLUMN, TABLE_FONT), TABLE_DENSE, TABLE_TIGHT):
        columns = across(column, share)
        rows = max(int((height - headed(row)) // row), 1)
        if n <= columns * rows:
            used = ceil(n / rows)
            return Page(0, n - 1, used, ceil(n / used), False, row, font)
    row, column, font = TABLE_DENSE
    columns = across(column, share)
    rows = max(int((height - headed(row)) // row) - (1 if footed else 0), 1)
    capacity = columns * rows
    first = (min(max(focus, 0), n - 1) // capacity) * capacity
    return Page(first, min(first + capacity, n) - 1, columns, rows, True, row, font)

def headed(row: float) -> float:
    """The height of the table's line of headings over rows of `row` layout pixels: a row, or TABLE_HEAD_LEAST where the
    rows are set closer than that (the headings' symbols, a step larger, never touch the first row)."""
    return max(row, TABLE_HEAD_LEAST)

def focus(state: SampleState, hovered, rest: int | None = None) -> int:
    """The design the table follows: the one under the mouse, or else `rest` where given (the block's table: the best
    design, or a free sample's last point), or else a free sample's last point (the one just placed), or else the
    first."""
    pointed = design_index(hovered)
    if pointed is not None and 0 <= pointed < state.n:
        return pointed
    if rest is not None:
        return rest
    return state.n - 1 if state.free else 0

def entries_share(d: int) -> float:
    """How much wider a column of rows of the table is for designs of d inputs than for two: (d + 1) entries a row,
    the index and an interval per input, against three; 1 for two inputs."""
    return 1.0 if d == 2 else (d + 1) / 3

def table_rights(d: int) -> tuple[float, ...]:
    """The right edges of a column of rows' entries (i, then the interval on each input), in shares of its pitch:
    TABLE_RIGHTS for two inputs; for more, the entries spread evenly up to its last edge."""
    if d == 2:
        return TABLE_RIGHTS
    return tuple(TABLE_RIGHTS[-1] * (k + 1) / (d + 1) for k in range(d + 1))

def readings(state: SampleState, pointed: int | None) -> list:
    """The readout of step 1's 3D card alone (panels.readout, the owner's 2A): the design under the mouse, else the best
    design (the least simulated y), its place x_i and its simulated y_i, the units of the response after them; nothing
    without a design."""
    if state.empty:
        return []
    i = pointed if pointed is not None and pointed < state.n else best_of(state.values)
    if i is None:
        return []
    units, index = state.response.units, subscript(i + 1)
    return [[(f"x{index}", MUTED_INK, read_point(state.points[i], units[0])),
             (f"y{index}", POINT, read_value(short(state.values[i], 4), units[-1]))]]

def scene_of(state: SampleState) -> tuple:
    """What the scene of the figure depends on (SamplingLab.draw_scene): N (the intervals; none without it), whether
    any design is shown (the legends list the designs only then), the language of its titles and legends, and the slice
    shown by its key (Section.key: its pair names the axes; its held values the surface and the heads' note: the same
    key always for two inputs)."""
    return state.n, not state.empty, current_language(), state.section.key

def space_title(function: str) -> str:
    """The 3D view's title: "The response y = f(x₁, x₂)", or, for a bench of more inputs, f of all of them
    ("y = f(x₁, …, x₄)": the surface drawn is its slice, the note beside the title says where)."""
    d = RESPONSES[function].d
    if d == 2:
        return get_text("lab.lhs.space_title")
    return get_text("lab.lhs.space_title_many", inputs=f"{section.symbol(0)}, …, {section.symbol(d - 1)}")

def through(simulations: Simulated) -> tuple[float, ...] | None:
    """The unit point of the best design of simulated designs (the least y, the first of equals), where step 1's and
    step 2's automatic slice passes; None without a design."""
    if not simulations.values:
        return None
    best = min(range(len(simulations.values)), key=lambda k: simulations.values[k])
    return simulations.unit[best]

def lifted(cut: Section, p: float, q: float) -> tuple[float, ...]:
    """A free point placed at (p, q) of the pair: lifted onto the slice (Section.lift: the inputs held at its values),
    each coordinate to DECIMALS."""
    return tuple(round(float(v), DECIMALS) for v in cut.lift(p, q))

@dataclass(frozen=True)
class Marks:
    """Designs drawn as projections on a slice of a bench of more than two inputs (explorers/section.py: a mark is a
    projection): their pair's coordinates (xs, ys, in the bounds), their simulated values (if given) and each one's
    closeness to the slice (closeness: 1 on it, towards 0 far from it; section's fade), the farthest first, so that the
    nearest are drawn on top. Steps 2 and 3 draw their designs the same way: areas(area) gives a scatter's sizes on the
    plane (section.grown: near grows, far keeps the two-input size), areas(area, grow=False) in the 3D view
    (section.shrunk), inks(color) its colours (section.opacity), shares the opacities: the fade as opacity AND area,
    never colour alone; EDGE (section.EDGE_THIN) their dark edge. `order` maps them back to the designs' indices."""
    order: tuple[int, ...]
    xs: tuple[float, ...]
    ys: tuple[float, ...]
    values: tuple[float, ...]
    closeness: tuple[float, ...]
    EDGE = section.EDGE_THIN

    @classmethod
    def of(cls, cut: Section, points, unit, values=()) -> "Marks":
        """The marks of designs at `points` (bounds) whose unit points are `unit`, with their `values` (or none)."""
        near = [cut.closeness(u) for u in unit]
        order = tuple(sorted(range(len(near)), key=lambda k: near[k]))
        return cls(order, tuple(float(cut.project(points[k])[0]) for k in order),
                   tuple(float(cut.project(points[k])[1]) for k in order),
                   tuple(float(values[k]) for k in order) if len(values) else (), tuple(near[k] for k in order))

    @property
    def shares(self) -> tuple[float, ...]:
        """Each mark's opacity (section.opacity of its closeness)."""
        return tuple(section.opacity(c) for c in self.closeness)

    def areas(self, area: float, grow: bool = True) -> list[float]:
        """A scatter's sizes from the two-input area of a design: on the plane grown near the slice (section.grown),
        else (the 3D view) shrunk far from it (section.shrunk)."""
        return [section.grown(area, c) if grow else section.shrunk(area, c) for c in self.closeness]

    def inks(self, color: str) -> list[tuple[float, float, float, float]]:
        """A scatter's colours: `color` at each opacity."""
        return [_rgba(color, share) for share in self.shares]

def frame_table(ax) -> None:
    """The table's frame: no ticks, no spines, on its card's tone, its data coordinates its layout pixels (table_room)."""
    ax.set_facecolor(CARD_TONE)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    width, height = table_room(ax)
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)

def table_room(ax) -> tuple[float, float]:
    """The table's width and height, in layout pixels."""
    width, height = (extent * whole for extent, whole in zip(ax.get_position().size, size(ax.figure)))
    return width, height

def titled(figure, heads: dict, axes: dict, name: str, title: str, handles: list, note: str = "", below: bool = False,
           most: int = 0) -> None:
    """A panel's title and its legend (panels.head, which keeps the room of a legend with nothing to list; `most`, the
    rows the plan gives it beyond two: panels.legend_most), and the note of the slice on the title's line (none for two
    inputs)."""
    head(figure, heads, axes, name, title, handles, note, below, most)

def design_index(hovered) -> int | None:
    """The design a hovered item names (an index), or None (nothing, or an empty place: PLACE)."""
    return hovered if isinstance(hovered, int) and not isinstance(hovered, bool) else None

def placed_points(settings: dict, d: int = 2) -> tuple[tuple[float, ...], ...]:
    """The free sample's points in the settings, at most MOST of them (the first ones), as tuples of d floats (a
    point of another length, which no lab of this bench placed, is not one)."""
    points = settings.get("points") or ()
    return tuple(tuple(float(u) for u in point) for point in tuple(points)[:MOST] if len(point) == d)

def unit_of(ax, state: SampleState, event) -> tuple[float, float]:
    """The point of the pair's unit square under the mouse (device pixels, the plane's data transform), kept inside it
    and to DECIMALS."""
    x1, x2 = ax.transData.inverted().transform((event.x, event.y))
    (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
    return (round(min(max((float(x1) - a1) / (b1 - a1), 0.0), 1.0), DECIMALS),
            round(min(max((float(x2) - a2) / (b2 - a2), 0.0), 1.0), DECIMALS))

def by_key(key: str, settings: dict, cut: Section) -> dict | None:
    """The free sampling's keys (SamplingLab.press): an arrow moves the cursor by CURSOR_STEP of the unit square of the
    pair on the axes, held inside it (the first one shows it in the middle), Enter or Space places a point at it while
    fewer than MOST are placed (on a bench of more than two inputs, lifted onto the slice `cut`: its inputs held at the
    slice's values; the points kept are those of cut.d coordinates); the settings unchanged when nothing can move (an
    edge, MOST placed: the key is still the figure's); None for another key."""
    moves = {"left": (-1, 0), "right": (1, 0), "up": (0, 1), "down": (0, -1)}
    if key not in moves and key not in ("enter", "space"):
        return None
    cursor = settings.get("cursor")
    spot = (0.5, 0.5) if cursor is None else (float(cursor[0]), float(cursor[1]))
    if key in moves:
        d1, d2 = (0, 0) if cursor is None else moves[key]
        spot = tuple(round(min(max(u + d * CURSOR_STEP, 0.0), 1.0), DECIMALS) for u, d in zip(spot, (d1, d2)))
        return settings | {"cursor": spot}
    plain = cut.plain
    points = placed_points(settings, cut.d)
    if len(points) >= MOST:
        return settings
    return settings | {"points": points + (spot if plain else lifted(cut, *spot),), "cursor": spot}

def pearson(xs: list[float], ys: list[float]) -> float | None:
    """Pearson's correlation (measures.correlation), or None where it is not defined: every point on one line parallel
    to an axis (a coordinate with no spread), as points placed by hand may be."""
    try:
        return correlation(xs, ys)
    except ZeroDivisionError:
        return None

def largest_correlation(columns: list[list[float]]) -> tuple[float, tuple[int, int]] | None:
    """Among the pairs of inputs (i < j) of the designs (`columns`: the coordinates of every design on each input),
    Pearson's coefficient of largest |ρ| (the first of equals), with its pair: the worst linear trend between two
    inputs a sample has, whatever pair the figure shows (step 1's strip, step 2's card); None where no pair has one
    (every coordinate without spread)."""
    found = None
    for i in range(len(columns)):
        for j in range(i + 1, len(columns)):
            rho = pearson(columns[i], columns[j])
            if rho is not None and (found is None or abs(rho) > abs(found[0])):
                found = (rho, (i, j))
    return found

def mitred(corners: list, above: bool, t: float = 1.0, u: float = 1.0) -> list:
    """A cell of a band, in fractions of the design space, cut at the diagonal of the corner where the two bands meet
    (from (1 - t, 1 - u) to (1, 1): the right band t thick, the top band u; the line y = x where they are equal): the
    top band keeps what is above it, the right band what is below it (Sutherland-Hodgman)."""
    def over(p):
        return (1 - p[0]) * u - (1 - p[1]) * t                        # > 0: above the diagonal of the corner

    def inside(p):
        return over(p) >= 0 if above else over(p) <= 0
    kept = []
    for k in range(len(corners)):
        p, q = corners[k - 1], corners[k]
        if inside(p) != inside(q):
            s = over(p) / (over(p) - over(q))
            kept.append((p[0] + s * (q[0] - p[0]), p[1] + s * (q[1] - p[1])))
        if inside(q):
            kept.append(q)
    return kept

def marker_size(n: int) -> float:
    """The area of a design's dot: large for a few points, smaller as they crowd."""
    return float(max(14, min(70, 900 / n)))

def style_space(ax, units: tuple = ("", "", ""), pair: tuple[int, int] = (0, 1)) -> None:
    """The 3D view in the colours of the page: dark panes, faint grid, grey ticks, the axes named x1, x2 and y (the
    pair's two inputs on a bench of more: `pair`, the slice's), each with its unit where the response has one
    (panels.name_space; the three steps call it with the response's units)."""
    ink = palette.GREY
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_pane_color(_rgba(palette.BACKGROUND, 0.55))
        axis.pane.set_edgecolor(palette.DARK_GREY)
        axis.line.set_color(palette.DARK_GREY)
        axis._axinfo["grid"].update({"color": _rgba(palette.DARK_GREY, 0.55), "linewidth": 0.5})
        axis.label.set_color(ink)
    ticks(ax, small=True)
    ax.tick_params(pad=1)
    name_space(ax, units, pair)

def _rgba(color: str, alpha: float) -> tuple[float, float, float, float]:
    return tuple(int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)) + (alpha,)
