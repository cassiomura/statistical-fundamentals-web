# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: optimization.py
# ==============================================================================
"""
Step 3 of a bench's study, the optimization: the design of least response sought ON THE METAMODEL that step 2 handed,
y^(u) = metamodel.fit(candidate, experiment).model(u), by the best-known algorithm of each family of optimizers, built on
screen one stage at a time: NLPQL, the gradient-based method (sqp.py); the evolutionary algorithm, EA (evolutionary.py);
and the adaptive response surface method, ARSM (response_surface.py), which here is a response surface of a response
surface. The optimizer never calls f: its answer x* is worth what the metamodel is worth, and one real simulation, the
validation, says what it is worth.

    Optimize on                | the search in the design space: the level    | the metamodel y^ as a surface, f as a
    [MOP Solver | Real Run]    | lines of the function searched (y^; f in     | wire over it (a reference), the designs,
    Method                     | Real Run), the designs of step 1, f's minima | the search at its values, the method's
    [NLPQL | EA | ARSM]        | (rings, a reference), every point evaluated  | model; validated, f(x*) beside y^(x*)
      its family (muted line)  | (crosses on y^, discs on f), the best one,   |-----------------------------------------
    Step h -o- (NLPQL)         | the construction of the stage, the start x₀  | in real simulations, best y - f*: the
    Population (mu) (EA)       |                                              | route through the metamodel (never
    (play) (step) (restart) (seed)  iteration 3 of 12 · gradient              | rising; each x* validated its own dot,
    [Validate with one simulation]                                            | at N + 1, N + 2, ...) and the direct run
    Restore                    | strip: the method's number | f(x*) beside    | on f (from N when it starts at the best
                               |   y^(x*) | f(x*) - f* (verdict) | Bench      | design; a ring at the study's cost), the
                               |   (over the filled button: where to go next) | one on screen solid and blue

The solver (settings["solver"], first in the column): the MOP Solver ("mop") runs the method on the metamodel received;
Real Run ("real") runs the same method on f, the direct run (direct_of): the run on screen (on_screen, OptimizationState.
run) is one or the other, stepped and played by the same stages and frames. In Real Run every evaluation is a simulation,
drawn as the designs are (a blue disc), the plane shows the level lines of f (from the response on the lab's grid,
metamodel.truth) and is titled for f, and there is nothing to validate: the filled command is disabled and missing says
why. Real Run is a student's reward (explorers/game.py): locked while the bench is not won (locked); a snapshot or a
surrogate received that would leave a student on it falls back to the MOP Solver (allowed). The method's names are
"NLPQL", "EA", "ARSM", its family the plain line of formula("method"); then only its own controls.

The transport row (Action.icon, in this order): run (play, pause while it plays), next (one iteration, stage by stage),
restart (the start of the run, iteration 0, and stops there), a new seed (the EA and ARSM); beside them the name of the
stage on screen (naming TRANSPORT, transport_name: "iteration 3 of 12 · gradient", "complete · 51 evaluations").

The strip, four measures in both solvers. MOP Solver: the method's own measure, f(x*) once validated beside the lowest
y^ found, f(x*) - f* with the verdict (beside it the best design's and the direct run's at the same cost), and Bench:
the stars (★ filled, ☆ hollow) and the cost ("60 + 2 = 62") when the validated x* completes the bench (game.complete;
finished gives the same stars to the window), hollow stars and what is missing otherwise (not below the best design; or
far: in words, the distance to a minimum and how far f(x*) is above f*, in digits that never read as the most that
completes, game.REACH and game.tolerance, which the tip gives: apart), a dash before the validation; and then,
over the filled button, one sentence per condition missed, naming where to go (hint). Real Run: the method's own
measure, what its simulations cost so far of its whole cost (charged as its curve is: "60 + 33"), the lowest f found
and its gap to f* beside the best design's. Cues (cue): "complete" when a played run reaches its end, "better" or
"worse" for the validation, "apply" for a new seed.

The cost of the study through the metamodel (simulations) is N and one more for every DISTINCT x* validated on its
experiment, in the order they were validated: the window keeps them (Lab.paid, by experiment; charged gives it the one
on screen), so that validating again and again (other starts, seeds, methods, metamodels of the same experiment) is
paid for, Restore and a visit included, and the same x* again costs nothing; the stars follow that cost. price is what
it will be once the x* on screen is validated. The direct run on f is charged what it used (first_cost): from the best
design of step 1 (NLPQL and ARSM, the start not moved) the N simulations that found that start are charged and its
first evaluation, that very design, is not charged again: its curve begins at N, its cost reads N + k; from a start
the reader put, and the EA (its own population), it is charged from 1.

The bench IS the response (OptimizationLab(function); no control chooses it): the figure typesets its formula over the 3D
view (panels.typeset, explorers/responses.py), once per layout. What the step receives (receive, received): step 2's
metamodel.Surrogate (the experiment of step 1 and the candidate fitted to it), in settings["surrogate"]; the lab opens
on metamodel.first_surrogate(function), so that it works alone. The column says what came in, with the state colour of
each quality the step inherits: the metamodel, its CoP ("warning" at or below 0: y^ predicts no better than the mean of
the simulated values), the sampling and N, and step 1's empty intervals of each axis (measures.py; "error" when any). The
step hands nothing (output None): it is the last one; summary says what it is worth once validated, f(x*) - f*, with the
verdict's kind. Given a surrogate as it opens (opening), the lab never makes its first surrogate; alone, it makes the
first one of its mode (metamodel.first_surrogate: the teacher's runs the competition, the student's does not).

The verdict is an exact fact, no threshold: x* is better than the best design of step 1 when f(x*) is below the least
of step 1's simulated values ("ok", teal), else not ("error", red: worse, or the same), and never by colour alone: the
strip writes the sign of the comparison (3.16 > design 0.474), the lead the words (verdict).
The gaps to f* are written in three significant digits, their trailing zeros kept (gap: 4.80, 0.730), wherever they
are shown: f(x*) - f*, the best design's and the direct run's at the same cost (same_cost); the values of y in four
(short).

Two kinds of counts, never mixed. An evaluation of y^ is not a simulation: the run on y^ calls the metamodel only
(prediction, which records every call in order) and its count is the transport's name at the end. A simulation is
one call of f, standing for one run of the solver: the N designs of step 1, the validation f(x*), and the direct run,
the same method run DIRECTLY on f (simulation records them) from the same start, seed, h and mu: what the study would
have cost without a metamodel, on screen in Real Run (Run.simulated). Only simulations are drawn in the third panel.

The start of NLPQL and ARSM is the best design of step 1 (the design of lowest simulated y, doe.simulated) while
settings["start"] is None; dragged, pressed on the design space or moved by the arrow keys it is that point. A new
experiment received takes it back to None (a new metamodel of the same experiment keeps it). The EA starts from its own
population, a Latin hypercube of mu points drawn from the seed.

The validation ("Validate with one simulation", the lab's only primary command, a toggle: settings["validate"]) is
enabled when the run on screen is complete and can be computed: x*, the point of least y^ the method found, is
simulated once, and f(x*) is on screen beside y^(x*) and the true minimum f*, in the lead, the strip, the 3D view (the
two values joined by a stem, named in the legend: the numbers are the strip's) and the third panel (its own dot at the
cost it was first validated at, where it falls; the route there is the lower of it and the best so far); x* is ringed in blue in the
design space (a design simulated), never clipped by the frame. Any change (a control, a new seed, the start moved,
another surrogate received, Next or Run started) takes it back to False.

The run is computed whole by the core (outcome, cached by what it depends on: the objective, and the arguments its
method uses), and the frames reveal a prefix of it, never a value the core did not compute. An iteration has stages,
each read from the core's record of it:

    NLPQL  (1) the gradient of y^ by forward differences: its n evaluations and the direction of -g; (2) the quadratic
           model q(d) = y^ + g^T d + (1/2) d^T B d in dashed level lines around u, and the step d to its minimum in the
           box (an active bound marked); (3) the line search: the trials (rejected red and hollow, the accepted yellow)
           and the new iterate on the path. An iteration without a line search (the last one, converged) has only (1), (2).
    EA     (1) selection: the pairs of parents of the tournaments, joined; (2) crossover and mutation: the children as
           SBX made them (hollow), moved by the mutation (an arrow) to where y^ is evaluated; (3) survival: the mu best
           of parents and children kept, the others red and hollow.
    ARSM   (1) the subregion and its 9 points, evaluated on y^; (2) the quadratic fitted to those values, in dashed level
           lines inside the subregion, and its minimum, evaluated; (3) pan and zoom: the move d, the factors lambda, the
           next subregion.

Iteration 0 is the start. "Next" plays the stages of one iteration (rewind stores the motion in the settings, playing);
"Run" plays one frame per iteration, at its last stage; "Restart" shows the start and stops. A complete run begins again
BEFORE its start, so that the first frame the window draws is the start itself (a step stops there). Another solver, a
control changed, a new seed, a start moved or a
surrogate received shows the complete run (ended): its end is where the lesson is, where it stopped and why, and where
the validation can be asked for. The complete run draws no stage (no yellow, no red, no model): only the search (the
evaluations, the path), the best point, the start and, validated, x*; the stages are drawn while the reader steps
through them and while "Run" plays, up to its last frame, which is the complete run. The evaluations of a stage (Run.counts) are derived
from the history: NLPQL 1 + the probes and trials so far; the EA mu per generation; ARSM 1 + 10 per iteration.

The figure is the bench's shared picture (explorers/panels.py, arrangement(width, height, pair="space", fill=True)): for
the same figure size the design space and the 3D view stand in the same boxes, to the pixel, as in steps 1 and 2, with
the same limits, ticks, names and titles' places, the same vertical window of the 3D view (metamodel.truth) and the same
angle (Lab.view, which the window carries between the steps: read at every draw, updated when the reader turns the view).
The third panel is this step's (in the corner it fills its rectangle; in the pair it is left out). Colours, one meaning
each across the bench (palette.py), never colour alone: blue a design simulated (the N designs, f(x*), the route); white
crosses a point where y^ was evaluated (a cross, not a disc: no simulation); yellow what the stage computes now; teal
the best point found (a star); red and hollow what is rejected; purple the method's own model (dashed level lines, a
wire in 3D); slate the references a study never has: f (the wire), its minima (rings) and, in the third panel, the study
not on screen (dashed). In Real Run the evaluations are simulations: blue discs (yellow, now). The level lines are grey,
from Fit.surface on the metamodel's grid, or f's on the same grid in Real Run. What depends only on the surrogate, the
solver and the language (the level lines, y^'s surface, the designs, f's wire and minima) is drawn once (the scene), the
rest at every frame.

What cannot be computed is kept, never raised: a surrogate whose fit is refused (it should not be handed), y^ refused at
a point the method asked for (moving least squares where too few designs carry weight: prediction turns the metamodel's
ArithmeticError or ValueError into Refused) and ARSM's least squares refused by Cholesky (the core raises ArithmeticError)
make the run None, and the figure and the strip say why (refusal). An ArithmeticError of NLPQL or of the EA themselves is a
fault and is raised.
"""
import dataclasses
import itertools
import math
from dataclasses import dataclass
from functools import lru_cache
from random import Random
from textwrap import fill

import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from matplotlib.patheffects import withStroke
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter, NullLocator
from matplotlib.transforms import blended_transform_factory
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

from statistical_fundamentals import evolutionary, palette, regression, response_surface, sqp
from statistical_fundamentals.explorers import game
from statistical_fundamentals.explorers.base import Control, nearest, short, style_axes
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.doe import (FIRST_SEED, HEIGHT, LABEL, RAMP, SPACE_ZOOM, VIEW, marker_size, simulated,
                                                    style_space)
from statistical_fundamentals.explorers.lab import BENCH, LINK, TRANSPORT, Action, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.metamodel import (REFUSED, Surrogate, first_surrogate, fit, named, quality, truth,
                                                          validation)
from statistical_fundamentals.explorers.panels import (LINES, STACK_WIDTH, arrangement, beside, dot, facets, head, level_values,
                                                       places, space_ticks, typeset)
from statistical_fundamentals.explorers.responses import FORMULAS, formula
from statistical_fundamentals.functions import RESPONSES, Response
from statistical_fundamentals.i18n import current_language, get_text
from statistical_fundamentals.measures import empty_intervals
from statistical_fundamentals.quadratic import quadratic_value
from statistical_fundamentals.sampling import scaled

METHODS = ("nlpql", "ea", "arsm")
SOLVERS = ("mop", "real")             # the run on screen: on the metamodel received, or on the real function
SOLVER_NAMES = ("MOP Solver", "Real Run")     # the owner's words, optiSLang's, the same in both languages (as NLPQL)
FUNCTIONS = tuple(RESPONSES)          # the benches, by the key of their response
STEPS = tuple(float(f"1e-{k}") for k in range(1, 11))      # h: 10^-1 to 10^-10 of the range
FIRST_STEP = 1e-8                     # the square root of the machine precision: the usual rule of forward differences
POPULATIONS = (10, 20, 40)            # mu
FIRST_POPULATION = 20
FIRST_START = (0.45, 0.7)             # a start in the unit square from which NLPQL crosses Branin (the cover's picture); the lab
                                      # itself starts at the best design of step 1
BEFORE = -1                           # shown: a rewound run, before its start (its first frame is the start)
STOPS = {"nlpql": ("converged", "no_decrease", "iterations"), "ea": ("generations",), "arsm": ("converged", "iterations")}
REFUSALS = ("fit", "point", "arsm")   # why a run cannot be computed: the metamodel, y^ at a point, ARSM's least squares
MOVE = 0.02                           # an arrow key moves the start this far in the unit square
MODEL_GRID, WIRE_GRID = 25, 11        # of a model's level lines in the plane, of its wire in the 3D view
MODEL_LEVELS = 5                      # level lines of a model (even); those of y^ are panels.LEVELS, panels.level_values
MODEL_ROOM, MODEL_LEAST = 1.25, 0.1   # NLPQL's model is drawn on a square around u: half-side 1.25 |d|, at least 0.1
ARROW = 0.1                           # the arrow of -g, of the range: the gradient's direction, not its length
START_RADIUS = 14                     # pixels: how close the mouse must come to the start to take hold of it
FLOOR_LEAST = 1e-16                   # the lowest floor of the third panel's log axis
DESIGN = palette.BLUE                 # a design simulated: step 1's, f(x*), the route through the metamodel
SEARCH = palette.WHITE                # a point where y^ was evaluated (a cross: no simulation)
NOW = palette.YELLOW                  # what the stage computes now
BEST = palette.TEAL                   # the best point found so far
REJECTED = palette.RED                # a trial refused, a point that did not survive (hollow, too)
MODEL = palette.PURPLE                # the method's own model of y^
REFERENCE = palette.SLATE             # what a study never has: f, its minima, the direct run on f
WARNING = palette.GOLD
CURRENT = DESIGN                      # the route through the metamodel, in the third panel
DIRECT = "--"                         # the line of the direct run
SUPERSCRIPTS = {"-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹"}
BOXED = {"boxstyle": "round,pad=0.3", "facecolor": palette.CARD, "edgecolor": "none", "alpha": 0.85}
HALO = [withStroke(linewidth=2.6, foreground=palette.CARD)]      # a text over the surface: read on any of its colours
DASH = "—"                            # a value not computed (yet, or at all)
SIGNS = {"better": "&lt;", "worse": ">", "same": "="}     # f(x*) - f* against the best design's, in the strip (rich text:
                                                          # "<" is written as its entity, or it would begin a tag)
STAR, HOLLOW_STAR = "★", "☆"          # the stars of a bench: filled and hollow, never colour alone

# ------------------------------------------------------------------------------
# The runs, by the cores, recorded and kept by what they depend on
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Run:
    """A method's whole run on one objective (y^ or f): the core's records and why it stopped, every evaluation of the
    objective in the order the method asked for it, the lowest value after each, and the frames: the stages of each
    iteration (0 for the start) and the evaluations made by the end of each stage (counts[k][0]: before iteration k)."""
    method: str
    history: tuple                              # the core's records, one per iteration (never mutated)
    stop: str                                   # converged | no_decrease | iterations | generations (the EA has no other)
    evaluations: tuple                          # ((u1, u2), value), in call order
    best: tuple                                 # the lowest value after each evaluation
    stages: tuple                               # the number of stages of each iteration on screen
    counts: tuple                               # the evaluations made by the end of each stage of each iteration
    simulated: bool = False                     # the run on f: every evaluation is a simulation (else on y^: none is)

    @property
    def last(self) -> int:
        """The last iteration on screen (iteration 0 is the start)."""
        return len(self.stages) - 1

    @property
    def optimum(self) -> tuple:
        """x* and its value: the evaluation of least value of the whole run (the first of equals)."""
        return min(self.evaluations, key=lambda evaluated: evaluated[1])

class Refused(Exception):
    """The metamodel cannot be computed at a point the method asked for (not an ArithmeticError: a fault of a core
    stays one)."""

def simulation(function: str, simulations: list):
    """f as the cores call it, on the unit square: the point mapped to the bounds of the response, simulated, and the
    simulation (u, y) recorded."""
    response = RESPONSES[function]
    bounds = list(response.bounds)

    def f(u):
        x1, x2 = scaled([list(u)], bounds)[0]
        y = float(response.f(x1, x2))
        simulations.append(((float(u[0]), float(u[1])), y))
        return y
    return f

def prediction(model, evaluations: list):
    """y^ as the cores call it, on the unit square: the metamodel at the point, and the evaluation (u, y^) recorded. No
    simulation: f is never called. A point where the metamodel cannot be computed raises Refused."""
    def f(u):
        point = (float(u[0]), float(u[1]))
        try:
            value = float(model(point))
        except REFUSED as refused:
            raise Refused(point) from refused
        if not math.isfinite(value):
            raise Refused(point)
        evaluations.append((point, value))
        return value
    return f

def staged(method: str, history, mu) -> tuple[tuple, tuple]:
    """The stages of each iteration and the evaluations made by the end of each, from the history alone."""
    if method == "ea":
        stages = (0,) + (3,) * (len(history) - 1)
        counts = ((mu,),) + tuple((mu * k, mu * k, mu * (k + 1), mu * (k + 1)) for k in range(1, len(history)))
        return stages, counts
    stages, counts, total = [0], [(1,)], 1
    for record in history:
        if method == "nlpql":
            probed, trials = total + len(record["probes"]), len(record["trials"])
            made = (total, probed, probed) + ((probed + trials,) if trials else ())
        else:
            designed = total + len(record["designs"])
            made = (total, designed, designed + 1, designed + 1)
        stages.append(len(made) - 1)
        counts.append(made)
        total = made[-1]
    return tuple(stages), tuple(counts)

@lru_cache(maxsize=512)
def outcome(method: str, target, step, mu, seed, start) -> Run | str:
    """The run of the core on the target, a Surrogate (y^, evaluations) or the key of a response (f, simulations), its
    calls recorded; or why it cannot be computed (REFUSALS: "fit", "point", "arsm")."""
    evaluations = []
    if isinstance(target, Surrogate):
        fitted = fit(target.candidate, target.experiment)
        if fitted is None:
            return "fit"
        f = prediction(fitted.model, evaluations)
    else:
        f = simulation(target, evaluations)
    try:
        if method == "nlpql":
            history, stop = sqp.nlpql(f, list(start), step)
        elif method == "ea":
            history, stop = evolutionary.evolutionary(f, mu, Random(seed)), "generations"
        else:
            history, stop = response_surface.arsm(f, list(start), Random(seed))
    except Refused:
        return "point"
    except ArithmeticError:
        if method == "arsm":                                          # only ARSM's least squares can be refused
            return "arsm"
        raise
    stages, counts = staged(method, history, mu)
    best = tuple(itertools.accumulate((y for _, y in evaluations), min))
    return Run(method, tuple(history), stop, tuple(evaluations), best, stages, counts, not isinstance(target, Surrogate))

def arguments(method: str, step, mu, seed, start) -> tuple:
    """The arguments a method uses (the others are not part of its key, so the same run is found whatever they are)."""
    start = (float(start[0]), float(start[1]))
    if method == "nlpql":
        return step, None, None, start
    if method == "ea":
        return None, mu, seed, None
    return None, None, seed, start

def run(method: str, target, step: float, mu: int, seed: int, start) -> Run | None:
    """The run of a method on the target (a Surrogate: y^; the key of a response: f) with the step h (NLPQL), the
    population mu (EA), the seed (EA, ARSM) and the start (NLPQL, ARSM); None when it cannot be computed (refusal says
    why)."""
    result = outcome(method, target, *arguments(method, step, mu, seed, start))
    return result if isinstance(result, Run) else None

def refusal(method: str, target, step: float, mu: int, seed: int, start) -> str:
    """Why the run cannot be computed (REFUSALS), or "" when it can."""
    result = outcome(method, target, *arguments(method, step, mu, seed, start))
    return "" if isinstance(result, Run) else result

def best_design(surrogate: Surrogate) -> tuple[float, float]:
    """The design of least simulated y of step 1's experiment, in the unit square (the first of equals)."""
    designs = simulated(surrogate.experiment)
    k = min(range(len(designs.values)), key=lambda i: designs.values[i])
    return (float(designs.unit[k][0]), float(designs.unit[k][1]))

def start_of(settings: dict) -> tuple[float, float]:
    """The start of NLPQL and ARSM: the point the reader put, or else the best design of step 1."""
    if settings["start"] is None:
        return best_design(settings["surrogate"])
    return (float(settings["start"][0]), float(settings["start"][1]))

def searched(method: str, settings: dict) -> Run | None:
    """The run of a method on the metamodel received."""
    return run(method, settings["surrogate"], settings["step"], settings["population"], settings["seed"], start_of(settings))

def direct_of(method: str, settings: dict) -> Run | None:
    """The reference: the same method run directly on f, from the same start, seed, h and mu."""
    return run(method, settings["surrogate"].experiment.function, settings["step"], settings["population"], settings["seed"],
               start_of(settings))

def solver_of(settings: dict) -> str:
    """The solver of the settings: "mop" (on the metamodel received) or "real" (on f); settings from before the solver
    existed are the MOP Solver's."""
    return settings.get("solver", SOLVERS[0])

def target_of(settings: dict):
    """What the run on screen minimizes: the surrogate received (y^) or the key of the response (f)."""
    return settings["surrogate"] if solver_of(settings) == "mop" else settings["surrogate"].experiment.function

def on_screen(settings: dict) -> Run | None:
    """The run on screen: the method on the metamodel (MOP Solver) or the same method on f (Real Run)."""
    method = settings["method"]
    return searched(method, settings) if solver_of(settings) == "mop" else direct_of(method, settings)

def framed(current: Run | None, settings: dict) -> tuple[int, int]:
    """The frame of the settings brought into the run: an iteration that exists and one of its stages (BEFORE, where a
    rewound run waits for its first frame, is shown as the start)."""
    if current is None:
        return 0, 0
    shown = min(max(int(settings["shown"]), 0), current.last)
    if shown == 0:
        return 0, 0
    return shown, min(max(int(settings["stage"]), 1), current.stages[shown])

def ended(settings: dict) -> dict:
    """The settings with the complete run on screen shown (its last iteration, at its last stage), the validation off."""
    current = on_screen(settings)
    settings = settings | {"validate": False}
    if current is None:
        return settings | {"shown": 0, "stage": 0}
    return settings | {"shown": current.last, "stage": current.stages[current.last]}

# ------------------------------------------------------------------------------
# The state
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class OptimizationState:
    method: str                                 # the method on screen, and the key of its reading ("View code")
    response: Response
    surrogate: Surrogate                        # what step 2 handed: the experiment and the metamodel fitted to it
    fit: object                                 # metamodel.Fit, or None when the metamodel cannot be computed
    designs: object                             # doe.Simulated: step 1's designs and their N simulations
    step: float
    mu: int
    seed: int
    start: tuple[float, float]                  # the start of NLPQL and ARSM, in the unit square
    dragged: bool                               # the reader put it (else: the best design of step 1)
    run: Run | None                             # the run on screen (on y^, or on f in Real Run); None: it cannot be
                                                # computed (refused says why)
    refused: str                                # "" | "fit" | "point" | "arsm"
    direct: Run | None                          # the same method on f (simulations); None: ARSM refused there
    shown: int                                  # the iteration on screen, 0 the start
    stage: int                                  # its stage
    real: float | None                          # f(x*), the validation's one simulation; None while not validated
    language: str
    solver: str = "mop"                         # "mop": the run on screen is on y^; "real": it is the direct run on f
    searched: Run | None = None                 # the run on y^ (the MOP Solver's), drawn in the third panel in both
    validations: tuple = ()                     # every distinct x* validated on this experiment, (u, f(x*)), in order: the
                                                # ones paid before (Lab.paid) and the one on screen
    price: int = 0                              # the cost of the study through the metamodel once the x* of the run on y^ is
                                                # validated (N, the validations paid, and that one if it is new)

    @property
    def simulating(self) -> bool:
        """Real Run: the run on screen is on f, every evaluation a simulation."""
        return self.solver == "real"

    @property
    def count(self) -> int:
        """The evaluations made by the end of the stage on screen (of y^; in Real Run, simulations)."""
        return self.run.counts[self.shown][self.stage] if self.run is not None else 0

    @property
    def complete(self) -> bool:
        return self.run is None or (self.shown == self.run.last and self.stage == self.run.stages[self.run.last])

    @property
    def why(self) -> str:
        """Why the run cannot be computed (REFUSALS); a state made without a reason is taken as ARSM's refusal."""
        return self.refused if self.refused in REFUSALS else "arsm"

    @property
    def validated(self) -> bool:
        return self.real is not None

    @property
    def n(self) -> int:
        return self.surrogate.experiment.n

    @property
    def simulations(self) -> int:
        """The simulations of the study through the metamodel so far: step 1's N, and every distinct x* validated on
        this experiment (a validation is a simulation; the same x* again costs nothing)."""
        return self.n + len(self.validations)

    @property
    def first_cost(self) -> int:
        """The cost of the direct run's first simulation: from the best design of step 1 (NLPQL and ARSM with the start
        not moved) the N simulations that found that start are charged, and its first evaluation, that design, is not
        charged again (N); from a start the reader put, or the EA's own population, it is charged from 1."""
        return self.n if not self.dragged and self.method != "ea" else 1

    def direct_cost(self, count: int) -> int:
        """What the direct run cost after its first `count` simulations (count >= 1)."""
        return self.first_cost + count - 1

    @property
    def record(self) -> dict | None:
        """The core's record of the iteration on screen (the EA's start population is its record 0)."""
        if self.run is None or (self.shown == 0 and self.method != "ea"):
            return None
        return self.run.history[self.shown if self.method == "ea" else self.shown - 1]

    @property
    def scene(self) -> tuple:
        """What the figure draws once: the level lines of the function searched (y^, or f in Real Run), y^'s surface, the
        designs, f's wire and minima, in a language."""
        return (self.surrogate, self.language, self.solver)

class OptimizationLab(Lab):
    """Three optimizers on the metamodel of step 2, stage by stage: where each one looks on y^, the model it builds (or
    not), the one simulation that validates its answer, and the price of the study against the same method on f."""

    def __init__(self, function: str = FUNCTIONS[0], mode: str = TEACHER):
        self.function = RESPONSES[function].key               # the bench: the response of the study
        self.mode = mode
        self.controls = (
            Control("solver", get_text("lab.opt.solver"), SOLVERS, 0, names=SOLVER_NAMES, tip=get_text("lab.opt.solver_tip"), alone=True),
            Control("method", get_text("lab.opt.method"), METHODS, 0, names=tuple(get_text(f"lab.opt.method.{m}") for m in METHODS),
                    tip=get_text("lab.opt.method_tip"), alone=True),
            Control("step", get_text("lab.opt.step"), STEPS, STEPS.index(FIRST_STEP), show=lambda h: f"h = {decade(h)}",
                    tip=get_text("lab.opt.step_tip"), visible=lambda settings: settings["method"] == "nlpql"),
            Control("population", get_text("lab.opt.population"), POPULATIONS, POPULATIONS.index(FIRST_POPULATION),
                    names=tuple(f"μ = {mu}" for mu in POPULATIONS), tip=get_text("lab.opt.population_tip"),
                    visible=lambda settings: settings["method"] == "ea"),
        )
        self.actions = (                       # the transport row in this order: run, next, restart, new seed
            page_link(),
            Action("run", get_text("lab.opt.run"), get_text("lab.opt.run_tip"), motion="run", playing_label=get_text("lab.opt.pause"),
                   icon="play", playing_icon="pause"),
            Action("next", get_text("lab.opt.next"), get_text("lab.opt.next_tip"), motion="step", icon="step"),
            Action("restart", get_text("lab.opt.restart"), get_text("lab.opt.restart_tip"), icon="restart"),
            Action("new", get_text("lab.opt.new"), get_text("lab.opt.new_tip"), icon="seed"),
            Action("validate", get_text("lab.opt.validate"), get_text("lab.opt.validate_tip"), toggle=True, primary=True),
        )
        self.data = {"start": None, "seed": FIRST_SEED, "shown": 0, "stage": 0, "playing": "step", "validate": False}
        self.restore = True
        self.height = HEIGHT                   # the least height, the other steps': the three get the same figure
        self.frame_ms = 900                    # a stage is read before the next one
        self.tip = get_text("lab.opt.figure_tip")
        self.view = VIEW                       # the 3D view as the reader left it (a view, not a setting; the window carries it)
        self.turned = None                     # the angle the 3D view had when this lab last drew it: another one, the mouse turned it
        self.layout_key = None                 # the axes on the figure are reused while their layout holds
        self.scene = None                      # the surrogate drawn on them (y^'s level lines and surface, the designs)
        self.plan = None
        self.axes: dict = {}
        self.heads: dict = {}
        self.moving: list = []                 # the artists of the frame: everything but the scene
        self.floor = FLOOR_LEAST               # where the third panel draws a gap of 0
        self.written = None                    # the formula of the response, typeset once per layout

    def settings(self) -> dict:
        """The surrogate first (the bench's first one for the mode, so that the lab works alone: the teacher's the
        winner of its competition, the student's the simplest metamodel), then the controls and the data."""
        return {"surrogate": first_surrogate(self.function, self.mode)} | super().settings()

    def opening(self, handed: Surrogate | None = None) -> dict:
        """The first settings given a surrogate: the controls and the data with it received, and no first surrogate
        made for nothing (the teacher's would run a competition only to be replaced)."""
        if handed is None:
            return self.settings()
        return self.receive({"surrogate": None} | Lab.settings(self), handed)

    def height_for(self, width: int) -> int:
        """Side by side, in a row or in the corner, the lab's own height; stacked, the shared plan's three blocks."""
        if width >= STACK_WIDTH:
            return self.height
        return round(arrangement(width, None, pair="space", fill=True).room)

    def formula(self, key: str, settings: dict) -> tuple[tuple[str, ...], str]:
        """For the key BENCH, the formula of the bench's response (one line of mathtext; the figure typesets it); for
        the method, the family of the method on screen in a plain line (the muted line under the control); nothing for
        the other controls."""
        if key == BENCH:
            return formula(self.function)
        if key == "method":
            return (), get_text(f"lab.opt.family.{settings['method']}")
        return (), ""

    # ------------------------------------------------------------------ the solver a student earns
    def locked(self, key: str, value, settings: dict) -> str:
        """Real Run is a student's reward: locked until the bench is complete (won); a teacher has it always."""
        if key == "solver" and value == "real" and self.mode == STUDENT and not self.won:
            return get_text("lab.opt.locked.real")
        return ""

    def allowed(self, settings: dict) -> dict:
        """The settings, or, on a solver that is locked now (a snapshot of another time), the same on the MOP Solver."""
        if self.locked("solver", solver_of(settings), settings):
            return settings | {"solver": SOLVERS[0]}
        return settings

    # ------------------------------------------------------------------ a step of the study
    def receive(self, settings: dict, handed: Surrogate) -> dict:
        """Another surrogate from step 2: the validation off, the start back to the best design when the experiment
        changed (kept when only the metamodel did), a solver locked now back to the MOP Solver, and the complete run of
        the new settings shown."""
        old = settings.get("surrogate")
        start = settings.get("start") if old is not None and old.experiment == handed.experiment else None
        return ended(self.allowed(settings | {"surrogate": handed, "start": start}))

    def missing(self, state: OptimizationState) -> str:
        """Why the validation, the filled button, cannot be pressed: Real Run has nothing to validate (every evaluation
        is a simulation), a run that cannot be computed has no x*, and one on its way has not found it yet."""
        if state.simulating:
            return get_text("lab.opt.missing.real")
        if state.run is None:
            return get_text("lab.opt.missing.refused")
        return "" if state.complete else get_text("lab.opt.missing.running")

    def finished(self, state: OptimizationState) -> int:
        """The stars of the bench (explorers/game.py) when the run on screen is the MOP Solver's, complete and
        validated, and x* completes the bench: game.stars at the cost of the study, N and every distinct x* validated
        on its experiment; else 0 (earned)."""
        return earned(state)

    def charged(self, state: OptimizationState) -> tuple | None:
        """The validation on screen, a simulation: (the experiment, (x*, f(x*))), which the window keeps in paid."""
        if not state.validated or state.run is None:
            return None
        return state.surrogate.experiment, (state.run.optimum[0], state.real)

    def hint(self, state: OptimizationState) -> str:
        """A validated study that does not complete the bench: one short sentence per condition it misses, naming where
        to go (not below the best design of step 1; far from every global minimum by place and by value)."""
        if not state.validated or state.run is None or earned(state):
            return ""
        function = state.response.key
        said = []
        if not state.real < min(state.designs.values):
            said.append(get_text("lab.opt.hint.above"))
        if not (game.by_place(function, state.run.optimum[0]) or game.by_value(function, state.real)):
            said.append(get_text("lab.opt.hint.far"))
        return " ".join(said)

    def cue(self, key: str, state: OptimizationState) -> str:
        """A played run that reached its end, "complete"; the validation turned on, "better" when f(x*) is below the
        best design of step 1, else "worse"; a new seed, "apply"; nothing else."""
        if key in ("run", "next"):
            return "complete" if state.run is not None and state.complete else ""
        if key == "validate":
            return ("better" if verdict(state) == "better" else "worse") if state.validated else ""
        return "apply" if key == "new" else ""

    def received(self, state: OptimizationState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """What came from step 2, each row with the state colour of the quality it reports: the metamodel; its CoP (the
        cross-validation of step 2), "warning" at or below 0, where y^ predicts no better than the mean of the simulated
        values; the sampling and N; and step 1's empty intervals of each axis (measures.py), "error" when any."""
        checked = validation(state.surrogate.candidate, state.surrogate.experiment) if state.fit is not None else None
        experiment, n = state.surrogate.experiment, state.n
        empty = [empty_intervals([u[i] for u in state.designs.unit], n) for i in range(2)]
        rows = ((get_text("lab.opt.received.model"), named(state.surrogate.candidate), "plain"),
                (get_text("lab.opt.received.cop"), DASH if checked is None else quality(checked.cop),
                 "warning" if checked is not None and checked.cop <= 0 else "plain"),
                (get_text("lab.opt.received.design"), get_text(f"lab.opt.received.{experiment.method}", n=n), "plain"),
                (get_text("lab.opt.received.empty"), f"{empty[0]}  ·  {empty[1]}", "error" if any(empty) else "plain"))
        return get_text("lab.opt.received"), rows

    def summary(self, state: OptimizationState) -> tuple[str, str]:
        """Once validated, f(x*) - f* in the strip's digits, with the verdict's kind; ("", "plain") before."""
        if not state.validated:
            return "", "plain"
        return f"f(x*) − f* = {gap(state.real - state.response.minimum)}", verdict_kind(state)

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> OptimizationState:
        """The state of the settings; never raises: what cannot be computed is None, and `refused` says why. A solver
        locked now (a snapshot of another time) is shown as the MOP Solver."""
        settings = self.allowed(settings)
        method, surrogate, solver = settings["method"], settings["surrogate"], solver_of(settings)
        response = RESPONSES[surrogate.experiment.function]
        start = start_of(settings)
        on_metamodel = searched(method, settings)
        direct = direct_of(method, settings)
        current = on_metamodel if solver == "mop" else direct
        refused = refusal(method, target_of(settings), settings["step"], settings["population"], settings["seed"], start)
        shown, stage = framed(current, settings)
        real = None
        complete = current is not None and (shown, stage) == (current.last, current.stages[current.last])
        if settings.get("validate") and complete and solver == "mop":
            x1, x2 = mapped(response, current.optimum[0])
            real = float(response.f(x1, x2))                          # the validation: one simulation, at x*
        paid = tuple(self.paid.get(surrogate.experiment, ()))         # the validations made before, on this experiment
        known = {point for point, _ in paid}
        validations = paid if real is None or current.optimum[0] in known else paid + ((current.optimum[0], real),)
        fresh = on_metamodel is None or on_metamodel.optimum[0] not in known
        return OptimizationState(method, response, surrogate, fit(surrogate.candidate, surrogate.experiment),
                                 simulated(surrogate.experiment), settings["step"], settings["population"], settings["seed"],
                                 start, settings["start"] is not None, current, refused, direct, shown, stage, real,
                                 current_language(), solver, on_metamodel, validations,
                                 surrogate.experiment.n + len(paid) + (1 if fresh else 0))

    def adjust(self, settings: dict, key: str, old) -> dict:
        """Any control changed: the complete run of the new settings ("Next" and "Run" show it again from the start);
        another solver shows the complete run of the other; a solver locked now is not taken (the MOP Solver stays)."""
        return ended(self.allowed(settings))

    def act(self, key: str, state: OptimizationState, settings: dict) -> dict:
        """A new seed shows the complete run of the new one; restart shows the start of the run (iteration 0) and stops
        there; the validation turns on for a complete run of the MOP Solver that can be computed, and off."""
        if key == "new":
            return ended(settings | {"seed": settings["seed"] + 1})
        if key == "restart":
            return settings | {"shown": 0, "stage": 0, "playing": "step", "validate": False}
        if key == "validate":
            on = not settings.get("validate") and self.enabled("validate", state)
            return settings | {"validate": on}
        return super().act(key, state, settings)

    def enabled(self, key: str, state: OptimizationState) -> bool:
        """The validation once the MOP Solver's run on screen is complete (and can be computed; Real Run has nothing to
        validate); restart when the run on screen is not at its start."""
        if key == "validate":
            return not state.simulating and state.run is not None and state.complete
        if key == "restart":
            return state.run is not None and (state.shown, state.stage) != (0, 0)
        return True

    def offered(self, key: str, settings: dict) -> bool:
        """A new seed only where there are random numbers: the EA and ARSM."""
        return key != "new" or settings["method"] in ("ea", "arsm")

    def rewind(self, key: str, state: OptimizationState, settings: dict) -> dict:
        """The motion that plays is kept in the settings (advance is not told which), and the validation goes; a
        complete run begins again BEFORE its start: the window asks for the first frame at once (gui/lab_views.play),
        and that frame is the start, where a step stops and from which a run goes on."""
        if key not in ("next", "run"):
            return settings
        settings = self.allowed(settings) | {"playing": "step" if key == "next" else "run", "validate": False}
        current = on_screen(settings)
        if current is None:
            return settings | {"shown": 0, "stage": 0}
        if framed(current, settings) == (current.last, current.stages[current.last]):
            settings = settings | {"shown": BEFORE, "stage": 0}
        return settings

    def advance(self, state: OptimizationState, settings: dict) -> dict | None:
        """Stepping, the next stage (from the last stage of an iteration, the first of the next one); running, the last
        stage of the iteration under way, or of the next one; from BEFORE, the start (at rest); None at the end."""
        settings = self.allowed(settings)
        current = on_screen(settings)
        if current is None:
            return None
        if settings["shown"] < 0:
            return settings | {"shown": 0, "stage": 0}
        shown, stage = framed(current, settings)
        if stage < current.stages[shown]:
            return settings | {"shown": shown, "stage": current.stages[shown] if settings["playing"] == "run" else stage + 1}
        if shown >= current.last:
            return None
        following = shown + 1
        return settings | {"shown": following, "stage": current.stages[following] if settings["playing"] == "run" else 1}

    def at_rest(self, settings: dict) -> bool:
        """Between iterations: every stage of the iteration on screen shown."""
        current = on_screen(self.allowed(settings))
        if current is None:
            return True
        shown, stage = framed(current, settings)
        return stage == current.stages[shown]

    def frame_time(self, settings: dict) -> int:
        """A stage is read; a whole run plays in about ten seconds, one iteration per frame."""
        if settings["playing"] != "run":
            return self.frame_ms
        current = on_screen(self.allowed(settings))
        return max(80, min(350, 9000 // max(current.last if current is not None else 1, 1)))

    def link(self, key: str, state: OptimizationState) -> str:
        """"View code" asks the window for the reading of the method on screen."""
        return state.method if key == LINK else ""

    def naming(self, key: str, state: OptimizationState) -> str:
        """For TRANSPORT, the name of the stage on screen beside the icons (transport_name); the validation, on, says
        how to take it back; the other commands keep their labels."""
        if key == TRANSPORT:
            return transport_name(state)
        if key == "validate":
            return get_text("lab.opt.unvalidate") if state.validated else ""
        return ""

    # ------------------------------------------------------------------ what to read
    def lead(self, state: OptimizationState) -> str:
        if state.run is None:
            return get_text(f"lab.opt.cannot.{state.why}")
        if state.validated:
            minimum = state.response.minimum
            values = {"predicted": short(state.run.optimum[1], 4), "real": short(state.real, 4),
                      "gap": gap(state.real - minimum), "verdict": get_text(f"lab.opt.verdict.{verdict(state)}"),
                      "design": gap(min(state.designs.values) - minimum), "route": state.simulations}
            if state.direct is None:
                return get_text("lab.opt.lead.validated_alone", **values)
            return get_text("lab.opt.lead.validated", direct=len(state.direct.evaluations), **values)
        if state.complete:
            return stop_sentence(state.run)
        return {"nlpql": nlpql_lead, "ea": ea_lead, "arsm": arsm_lead}[state.method](state)

    def metrics(self, state: OptimizationState) -> list[Metric]:
        """MOP Solver: the method's own measure, f(x*) once validated beside the lowest y^ found, its gap with the
        verdict, and the bench (the stars, or what is missing). Real Run: the method's own measure, the simulations, the
        lowest f found and its gap to f*. Four measures in both, the method's first: they hold the strip of a 1280 x 720
        window (the count of the evaluations of y^ is the transport's name at the end of the run, transport_name)."""
        if state.simulating:
            return real_run_metrics(state)
        best = min(y for _, y in state.run.evaluations[:state.count]) if state.run is not None else None
        promised = get_text("lab.opt.m.real_detail", predicted=short(best, 4)) if best is not None else ""
        real = Metric(get_text("lab.opt.m.real"), short(state.real, 4) if state.validated else DASH, detail=promised,
                      tip=get_text("lab.opt.m.real_tip"))
        return [own_metric(state), real, verdict_metric(state), bench_metric(state)]

    # ------------------------------------------------------------------ the mouse and the keys
    def hit(self, figure, state: OptimizationState, event):
        """The start under the mouse (NLPQL and ARSM), or None."""
        plane = self.axes.get("plane")
        if event is None or plane is None or event.inaxes is not plane or state.method == "ea":
            return None
        return "start" if nearest(plane, [mapped(state.response, state.start)], event, radius=START_RADIUS) is not None else None

    def grabbable(self, hovered) -> bool:
        return hovered == "start"

    def grab(self, figure, state: OptimizationState, event):
        """A press anywhere in the design space takes the start there (NLPQL and ARSM; the EA starts from a population)."""
        if event is None or event.inaxes is None or state.method == "ea":
            return None
        return "start" if event.inaxes is self.axes.get("plane") else None

    def drag(self, figure, state: OptimizationState, handle, event, settings: dict) -> dict | None:
        plane = self.axes.get("plane")
        if handle != "start" or plane is None or settings["method"] == "ea":
            return None
        x1, x2 = plane.transData.inverted().transform((event.x, event.y))      # from over another panel: kept on the border
        (a1, b1), (a2, b2) = state.response.bounds
        return moved(settings, (x1 - a1) / (b1 - a1), (x2 - a2) / (b2 - a2))

    def press(self, key: str, state: OptimizationState, settings: dict) -> dict | None:
        """The arrow keys move the start (NLPQL and ARSM); at the edge of the box an arrow key is still theirs (the
        settings unchanged), never passed on to the step's slider."""
        arrows = {"left": (-MOVE, 0.0), "right": (MOVE, 0.0), "up": (0.0, MOVE), "down": (0.0, -MOVE)}
        if settings["method"] == "ea" or key not in arrows:
            return None
        du1, du2 = arrows[key]
        u1, u2 = start_of(settings)
        return moved(settings, u1 + du1, u2 + du2) or settings

    # ------------------------------------------------------------------ the figure: layout
    def boxes(self, figure) -> tuple:
        """The plan and the panels' boxes and the places of their titles, in figure fractions, from the plan the three
        steps share (panels.arrangement with pair="space"; the third panel fills its rectangle in the corner)."""
        width, height = size(figure)
        plan = arrangement(width, height, pair="space", fill=True)

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)     # a box is never empty
        boxes = {"plane": frac(*plan.plane), "space": frac(*plan.space)}
        if plan.check is not None:
            boxes["check"] = frac(*plan.check)
        return plan, boxes, places(plan, width, height, boxes)

    def prepare(self, figure) -> dict:
        """The axes of the figure: made again when the layout changes, reused otherwise. The 3D view turned with the
        mouse since this lab drew it gives its angle to `view`."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height))
        space = self.axes.get("space")
        if space is not None and space.figure is figure and self.turned is not None and (space.elev, space.azim) != self.turned:
            self.view = (space.elev, space.azim)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan, boxes, self.heads = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "check") if name in boxes}
            self.axes["space"] = figure.add_axes(boxes["space"], projection="3d")
            self.axes["plane"].set_zorder(1)                          # its last x1 tick label overhangs the 3D box, which
                                                                      # begins 2 px later: drawn above it, the label is whole
            self.written = typeset(figure, self.heads, FORMULAS[self.function])      # once per layout: it never changes here
            self.layout_key = key
            self.scene = None
            self.moving = []
        return self.axes

    def draw(self, figure, state: OptimizationState, hovered) -> None:
        axes = self.prepare(figure)
        if self.scene != state.scene:
            self.draw_scene(axes, state)
            self.scene = state.scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        for text in list(figure.texts):
            if text is not self.written:                              # the formula stays: drawn once per layout
                text.remove()
        for legend in list(figure.legends):
            legend.remove()
        self.draw_search(axes["plane"], state, hovered)
        self.draw_response(axes["space"], state)
        if "check" in axes:
            self.draw_cost(axes["check"], state)
        self.draw_heads(figure, state)
        space = axes["space"]
        if (space.elev, space.azim) != tuple(self.view):              # the angle the window carried from another step
            space.view_init(*self.view)
        self.turned = (space.elev, space.azim)

    def draw_heads(self, figure, state: OptimizationState) -> None:
        """Each panel's title and legend; the legend of the design space names what the stage on screen draws."""
        title = get_text("lab.opt.plane_title_real" if state.simulating else "lab.opt.plane_title")
        head(figure, self.heads, self.axes, "plane", title, plane_legend(state))
        handles = [Patch(facecolor=palette.SURFACE_RAMP[3], label=get_text("lab.opt.legend.surface")),
                   Line2D([], [], color=REFERENCE, linewidth=1.2, label=get_text("lab.opt.legend.truth")),
                   dot(DESIGN, get_text("lab.opt.legend.simulated"))]
        if state.validated:                                           # the promise and the truth at x*, on one stem
            handles += [dot(BEST, get_text("lab.opt.legend.predicted"), marker="*", size=10),
                        Line2D([], [], linestyle="none", marker="o", markersize=6, markerfacecolor=DESIGN, markeredgecolor=palette.WHITE,
                               markeredgewidth=1.0, label=get_text("lab.opt.legend.real"))]
        elif staged_model(state):                                     # the model's wire is drawn
            handles.append(Line2D([], [], color=MODEL, linewidth=1.2, label=get_text(f"lab.opt.legend.model.{state.method}")))
        head(figure, self.heads, self.axes, "space", get_text("lab.opt.space_title"), handles)
        if "check" in self.axes:                                      # the run on screen first, solid; the other dashed
            route_label = get_text("lab.opt.legend.route_open" if state.price > state.simulations else "lab.opt.legend.route",
                                   spent=tally(state.n, len(state.validations)))
            colour, width, style = routes(state)["route"]
            route = Line2D([], [], color=colour, linewidth=width, linestyle=style, label=route_label)
            if state.direct is None:
                direct = Line2D([], [], linestyle="none", label=get_text("lab.opt.legend.direct_cannot"))
            else:
                colour, width, style = routes(state)["direct"]
                direct = Line2D([], [], color=colour, linewidth=width, linestyle=style, marker="o", markersize=6, markerfacecolor="none",
                                markeredgecolor=colour, markeredgewidth=1.3,
                                label=get_text("lab.opt.legend.direct", total=direct_tally(state, len(state.direct.evaluations))))
            handles = [direct, route] if state.simulating else [route, direct]
            head(figure, self.heads, self.axes, "check", get_text("lab.opt.check_title"), handles)

    # ------------------------------------------------------------------ the figure: the scene
    def draw_scene(self, axes: dict, state: OptimizationState) -> None:
        """What depends on the surrogate and the solver only: in the design space, the level lines of the function
        searched (y^'s, from the metamodel's grid; in Real Run f's, from the response on the same grid), the designs of
        step 1 and f's minima; in the 3D view, y^ as a surface cut at the window, f as a wire over it and the designs at
        their values."""
        true = truth(state.response.key)
        (a1, b1), (a2, b2) = state.response.bounds
        plane = axes["plane"]
        plane.clear()
        style_axes(plane)
        plane.set_facecolor(palette.CARD)
        for spine in plane.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        searched_surface = true.y if state.simulating else state.fit.surface if state.fit is not None else None
        if searched_surface is not None:
            levels = level_values(searched_surface)
            if levels:                                                # the look step 2 shares: solid below 0 too
                plane.contour(true.x1, true.x2, searched_surface, levels=levels, **LINES)
        xs, ys = zip(*state.designs.points)
        plane.scatter(xs, ys, s=min(marker_size(state.n), 16.0), c=DESIGN, edgecolors=palette.CARD, linewidths=0.7, zorder=6)
        xs, ys = zip(*state.response.minima)
        plane.scatter(xs, ys, s=130, facecolors="none", edgecolors=REFERENCE, linewidths=1.3, zorder=2)
        plane.set_xlim(a1, b1)
        plane.set_ylim(a2, b2)
        plane.set_xlabel("x₁", **LABEL, labelpad=2)
        plane.set_ylabel("x₂", **LABEL, labelpad=9, rotation=0, va="center")
        space = axes["space"]
        space.clear()
        space.set_facecolor(palette.CARD)
        space.computed_zorder = False                                 # the wire, the designs and the search stay in front
        low, high = true.low, true.high
        if state.fit is not None:
            polygons, heights, cut = facets(true.x1, true.x2, state.fit.surface, low, high)
            if polygons:
                colors = RAMP(np.clip((np.array(heights) - float(true.y.min())) / float(true.y.max() - true.y.min()), 0.0, 1.0))
                space.add_collection3d(Poly3DCollection(polygons, facecolors=colors, edgecolors="none", linewidths=0, antialiaseds=False,
                                                        alpha=0.9, zorder=1))
            if cut:                                                   # as step 2 says it, in the room of the 3D box
                columns = max(int(0.94 * space.get_position().width * size(space.figure)[0] / 6.2), 24)
                said = fill(get_text("lab.opt.cut", low=short(float(state.fit.surface.min()), 4),
                                     high=short(float(state.fit.surface.max()), 4)), columns, initial_indent="▲  ")
                space.text2D(0.03, 0.03, said, transform=space.transAxes, ha="left", va="bottom", color=WARNING, fontsize=9, zorder=10)
        space.plot_wireframe(true.x1, true.x2, true.y, rstride=3, cstride=3, color=REFERENCE, linewidth=0.6, alpha=0.55, zorder=2)
        space.plot([a1, b1, b1, a1, a1], [a2, a2, b2, b2, a2], [low] * 5, color=palette.DARK_GREY, linewidth=0.8, zorder=1)
        xs, ys = zip(*state.designs.points)
        space.scatter(xs, ys, state.designs.values, s=marker_size(state.n) * 0.7, c=DESIGN, edgecolors=palette.CARD, linewidths=0.7,
                      depthshade=False, zorder=4)
        space.set_xlim(a1, b1)
        space.set_ylim(a2, b2)
        space.set_zlim(low, high)
        style_space(space)
        space_ticks(space)
        space.set_box_aspect((1.0, 1.0, 0.72), zoom=SPACE_ZOOM)
        space.view_init(*self.view)

    # ------------------------------------------------------------------ the figure: the design space
    def draw_search(self, ax, state: OptimizationState, hovered) -> None:
        """The points where the run on screen evaluated its function so far (y^: crosses; f in Real Run: discs, each a
        simulation), the construction of the stage (none at the end of the run), the best point, the start x₀, at the
        end why the run stopped, and x* once simulated. The marks of a point on a bound or a corner are drawn whole,
        over the frame."""
        response, current = state.response, state.run
        if state.method != "ea":
            x, y = mapped(response, state.start)
            self.moving.append(ax.scatter([x], [y], s=120 if hovered == "start" else 90, marker="D", facecolors="none",
                                          edgecolors=palette.WHITE, linewidths=1.4, zorder=11, clip_on=False))
            self.moving.append(ax.annotate("x₀", (x, y), color=palette.WHITE, fontsize=9, zorder=11, **beside(state.start)))
        if current is None:
            columns = max(int(ax.get_position().width * size(ax.figure)[0] / 6.6), 12)
            self.moving.append(ax.text(0.5, 0.5, fill(get_text(f"lab.opt.cannot.{state.why}"), columns), transform=ax.transAxes,
                                       ha="center", va="center", color=WARNING, fontsize=9.5, zorder=12, bbox=BOXED))
            return
        made = current.evaluations[:state.count]
        faint = state.method == "ea"
        self.evaluated(ax, response, state, [u for u, _ in made], s=14 if faint else 22, alpha=(0.55 if faint else 0.85) if
                       state.simulating else (0.4 if faint else 0.75), linewidths=0.9, zorder=4)
        {"nlpql": self.draw_nlpql, "ea": self.draw_ea, "arsm": self.draw_arsm}[state.method](ax, state)
        now, rejected = construction(state)
        self.points(ax, response, [u for u, _ in rejected], s=46, facecolors="none", edgecolors=REJECTED, linewidths=1.4, zorder=7)
        self.evaluated(ax, response, state, [u for u, _ in now], s=70, now=True, linewidths=1.8, zorder=8)
        best = min(range(len(made)), key=lambda i: made[i][1])
        self.points(ax, response, [made[best][0]], s=190, marker="*", c=BEST, edgecolors=palette.CARD, linewidths=0.8,
                    zorder=7.5, clip_on=False)                    # under what is computed now: the accepted trial shows on it
        if state.validated:                                       # x*, simulated: a design of the study, the last one
            self.points(ax, response, [current.optimum[0]], s=330, facecolors="none", edgecolors=DESIGN, linewidths=1.6, zorder=9,
                        clip_on=False)
        if state.complete:                                        # on two lines in a small design space
            columns = max(int(0.92 * ax.get_position().width * size(ax.figure)[0] / 6.6), 12)
            self.moving.append(ax.text(0.02, 0.02, fill(stop_mark(current), columns), transform=ax.transAxes, ha="left", va="bottom",
                                       color=palette.WHITE, fontsize=9.5, zorder=12, bbox=BOXED))

    def points(self, ax, response: Response, units, **style) -> None:
        if units:
            xs, ys = zip(*(mapped(response, u) for u in units))
            self.moving.append(ax.scatter(xs, ys, **style))

    def evaluated(self, ax, response: Response, state: OptimizationState, units, s: float, now: bool = False, **style) -> None:
        """Points the run on screen evaluated: crosses where y^ was evaluated (white; yellow what the stage computes
        now), or, in Real Run, discs where f was simulated (the designs' blue; yellow now)."""
        self.points(ax, response, units, s=s * mark_scale(state), **(style | mark_look(state, now)))

    def line(self, ax, response: Response, units, **style) -> None:
        if len(units) >= 2:
            xs, ys = zip(*(mapped(response, u) for u in units))
            self.moving += ax.plot(xs, ys, **style)

    def arrow(self, ax, response: Response, start, end, **style) -> None:
        self.moving.append(ax.annotate("", xy=mapped(response, end), xytext=mapped(response, start), annotation_clip=False,
                                       arrowprops={"arrowstyle": "-|>", "shrinkA": 0, "shrinkB": 0, "mutation_scale": 11} | style))

    def contours(self, ax, response: Response, grid) -> None:
        """A model's level lines, dashed purple, from its values on a grid of the unit square (u1, u2, values)."""
        u1, u2, values = grid
        low, high = float(np.min(values)), float(np.max(values))
        if not high - low > 1e-12 * max(abs(low), abs(high), 1.0):
            return
        (a1, b1), (a2, b2) = response.bounds
        levels = list(np.linspace(low, high, MODEL_LEVELS + 2)[1:-1])
        self.moving.append(ax.contour(a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2, values, levels=levels, colors=MODEL, linewidths=1.0,
                                      linestyles=[(0, (6, 3))], zorder=3))

    def draw_nlpql(self, ax, state: OptimizationState) -> None:
        """The path of the iterates; then, by stage, the gradient (its probes and the direction of -g), the model and its
        step d (an active bound marked), the line search along d."""
        response, history, k, stage = state.response, state.run.history, state.shown, state.stage
        path = [history[r]["point"] for r in range(k)]
        self.line(ax, response, path, color=SEARCH, linewidth=1.2, alpha=0.7, zorder=5)
        self.evaluated(ax, response, state, path, s=44, linewidths=1.4, zorder=6)
        record = state.record
        if record is None or state.complete:                          # the end of the run: the path, no stage
            return
        u, d = record["point"], record["step"]
        if stage == 1:
            for probe, _ in record["probes"]:
                self.line(ax, response, [u, probe], color=NOW, linewidth=1.0, zorder=6)
            g = record["gradient"]
            norm = math.hypot(*g)
            if norm > 0:
                tip = [u[i] - ARROW * g[i] / norm for i in range(2)]
                self.arrow(ax, response, u, tip, color=NOW, linewidth=1.6)
                self.moving.append(ax.annotate("−g", mapped(response, tip), xytext=(4, 4), textcoords="offset points", color=NOW,
                                               fontsize=9.5, zorder=9, annotation_clip=False))
            return
        self.contours(ax, response, nlpql_model(record, MODEL_GRID))
        end = [u[i] + d[i] for i in range(2)]
        if stage == 2:
            if math.hypot(*d) > 0:
                self.arrow(ax, response, u, end, color=NOW, linewidth=1.8)
            self.points(ax, response, [end], s=46, marker="x", c=NOW, linewidths=1.6, zorder=8)
            (a1, b1), (a2, b2) = response.bounds
            for i, side in active(u, d):
                if i == 0:
                    edge = ([a1, a1] if side == 0 else [b1, b1], [a2, b2])
                else:
                    edge = ([a1, b1], [a2, a2] if side == 0 else [b2, b2])
                self.moving += ax.plot(*edge, color=NOW, linewidth=3.5, solid_capstyle="butt", clip_on=False, zorder=7)
            return
        self.line(ax, response, [u, end], color=NOW, linewidth=1.0, linestyle=(0, (4, 3)), zorder=6)
        if record["alpha"] is not None:
            self.line(ax, response, [u, record["trials"][-1][0]], color=NOW, linewidth=1.8, zorder=6)

    def draw_ea(self, ax, state: OptimizationState) -> None:
        """The population; then, by stage, the pairs of parents, the children (made by SBX, moved by the mutation), the
        survivors."""
        response, record, stage = state.response, state.record, state.stage
        population = record["population"]
        if state.shown == 0:
            return                                                    # the start population: evaluated now, yellow
        if stage == 3:
            pool = population + record["children"]
            self.evaluated(ax, response, state, [pool[i] for i in record["kept"]], s=50, linewidths=1.5, zorder=6)
            return
        self.evaluated(ax, response, state, population, s=50, linewidths=1.5, zorder=6)
        if stage == 1:
            for i, j in record["pairs"]:
                self.line(ax, response, [population[i], population[j]], color=NOW, linewidth=0.9, alpha=0.8, zorder=5)
            return
        self.points(ax, response, record["crossed"], s=30, facecolors="none", edgecolors=NOW, linewidths=1.1, zorder=7)
        starts = np.array([mapped(response, c) for c in record["crossed"]])
        ends = np.array([mapped(response, c) for c in record["children"]])
        self.moving.append(ax.quiver(starts[:, 0], starts[:, 1], ends[:, 0] - starts[:, 0], ends[:, 1] - starts[:, 1], angles="xy",
                                     scale_units="xy", scale=1, color=NOW, width=0.004, headwidth=4, headlength=5, headaxislength=4.5,
                                     zorder=7))

    def draw_arsm(self, ax, state: OptimizationState) -> None:
        """The subregions so far and the path of their centres; then, by stage, the subregion and its points, the fitted
        quadratic and its minimum, the move d, the factors lambda and the next subregion."""
        response, history, k, stage = state.response, state.run.history, state.shown, state.stage
        past = k if state.complete else max(k - 1, 0)                 # the end of the run: every subregion is past, grey
        for record in history[:past]:
            self.region(ax, response, record["low"], record["width"], color=palette.GREY, linewidth=0.8, alpha=0.45)
        centres = [history[0]["anchor"]] + [history[r]["optimum"] for r in range(past)]
        self.line(ax, response, centres, color=SEARCH, linewidth=1.2, alpha=0.7, zorder=5)
        record = state.record
        if state.complete:                                            # the path, no stage
            return
        if record is None:
            self.region(ax, response, history[0]["low"], history[0]["width"], color=NOW, linewidth=1.6)
            return
        self.region(ax, response, record["low"], record["width"], color=NOW if stage == 1 else palette.WHITE,
                    linewidth=1.6 if stage == 1 else 1.0)
        if stage == 1:
            return
        self.contours(ax, response, arsm_model(record, MODEL_GRID))
        if stage == 2:
            return
        self.arrow(ax, response, record["anchor"], record["optimum"], color=NOW, linewidth=1.6)
        if k < len(history):                                          # the last iteration has no next subregion: its stop
            nearer = history[k]                                       # says the width it reached
            self.region(ax, response, nearer["low"], nearer["width"], color=NOW, linewidth=1.6, linestyle=(0, (5, 3)))
        d, factors = record["move"], record["factors"]
        said = f"d = ({signed(d[0])}, {signed(d[1])})\nλ = ({factors[0]:.2f}, {factors[1]:.2f})"
        self.moving.append(ax.text(0.98, 0.98, said, transform=ax.transAxes, ha="right", va="top", color=NOW, fontsize=9.5, zorder=12,
                                   bbox=BOXED))

    def region(self, ax, response: Response, low, width, **style) -> None:
        (a1, b1), (a2, b2) = response.bounds
        corner = (a1 + (b1 - a1) * low[0], a2 + (b2 - a2) * low[1])
        self.moving.append(ax.add_patch(Rectangle(corner, (b1 - a1) * width[0], (b2 - a2) * width[1], fill=False, zorder=4, **style)))

    # ------------------------------------------------------------------ the figure: the 3D view
    def draw_response(self, ax, state: OptimizationState) -> None:
        """The points evaluated so far at their values (on the surface of y^; in Real Run on f, its wire, as discs: each
        a simulation), the construction of the stage, the best point and the method's model as a wire over the region it
        is built on (cut at the vertical window); validated, the real value f(x*) beside y^(x*), joined by a stem, both
        named. A value beyond the window is drawn on its edge."""
        current = state.run
        if state.fit is None:
            columns = max(int(0.8 * ax.get_position().width * size(ax.figure)[0] / 6.6), 16)
            self.moving.append(ax.text2D(0.5, 0.62, fill(get_text("lab.opt.space.cannot"), columns), transform=ax.transAxes,
                                         ha="center", va="center", color=WARNING, fontsize=9.5, zorder=10, bbox=BOXED))
        if current is None:
            return
        response, true = state.response, truth(state.response.key)
        made = current.evaluations[:state.count]
        self.points3d(ax, response, made, s=10 * mark_scale(state), alpha=0.35 if state.method == "ea" else 0.8,
                      **({"linewidths": 0.8, "zorder": 4} | mark_look(state)))
        if state.method == "nlpql":
            path = [(r["point"], r["value"]) for r in current.history[:state.shown]]
            if len(path) >= 2:
                xs, ys = zip(*(mapped(response, u) for u, _ in path))
                self.moving += ax.plot(xs, ys, [within(y, true) for _, y in path], color=SEARCH, linewidth=1.2, alpha=0.8, zorder=5)
        now, rejected = construction(state)
        self.points3d(ax, response, rejected, s=40, facecolors="none", edgecolors=REJECTED, linewidths=1.3, zorder=6)
        self.points3d(ax, response, now, s=50 * mark_scale(state), **({"linewidths": 1.5, "zorder": 7} | mark_look(state, now=True)))
        best = min(made, key=lambda evaluated: evaluated[1])
        self.points3d(ax, response, [best], s=150, marker="*", c=BEST, edgecolors=palette.CARD, linewidths=0.7, zorder=5.5)
        wire = None
        if staged_model(state):                                       # never at the end of the run
            wire = (nlpql_model if state.method == "nlpql" else arsm_model)(state.record, WIRE_GRID)
        if wire is not None:
            (a1, b1), (a2, b2) = response.bounds
            u1, u2, values = wire
            polygons, _, _ = facets(a1 + (b1 - a1) * u1, a2 + (b2 - a2) * u2, values, true.low, true.high)
            if polygons:
                self.moving.append(ax.add_collection3d(Poly3DCollection(polygons, facecolors=(0.0, 0.0, 0.0, 0.0), edgecolors=MODEL,
                                                                        linewidths=0.8, zorder=3)))       # a wire: edges only
        if state.validated:
            self.draw_validation(ax, state)

    def draw_validation(self, ax, state: OptimizationState) -> None:
        """x*: y^(x*), the metamodel's promise (the teal star), and f(x*), the simulation (blue, a triangle on the edge of
        the window when beyond it), on one vertical stem, named in the legend: their numbers are the strip's."""
        true = truth(state.response.key)
        point, predicted = state.run.optimum
        x, y = mapped(state.response, point)
        real = state.real
        self.moving += ax.plot([x, x], [y, y], [within(predicted, true), within(real, true)], color=palette.WHITE, linewidth=1.1,
                               linestyle=(0, (3, 2)), zorder=8)
        marker = "o" if true.low <= real <= true.high else ("^" if real > true.high else "v")
        self.moving.append(ax.scatter([x], [y], [within(real, true)], s=60, marker=marker, c=DESIGN, edgecolors=palette.WHITE,
                                      linewidths=1.0, depthshade=False, zorder=9))

    def points3d(self, ax, response: Response, evaluated, **style) -> None:
        """Points (u, value) over the design space; a value beyond the vertical window on its edge."""
        if evaluated:
            true = truth(response.key)
            xs, ys = zip(*(mapped(response, u) for u, _ in evaluated))
            self.moving.append(ax.scatter(xs, ys, [within(v, true) for _, v in evaluated], depthshade=False, **style))

    # ------------------------------------------------------------------ the figure: the third panel
    def draw_cost(self, ax, state: OptimizationState) -> None:
        """In real simulations, best y - f* on log scales, both studies in both solvers, the one on screen solid and
        blue, the other dashed and slate (routes): the route through the metamodel (routed: the lowest y simulated so
        far, which never rises, through the N designs and every distinct x* validated on the experiment, each validated
        f(x*) its own dot at its own cost, N + 1, N + 2, ..., where it falls, above the line when that x* was worse than
        the best simulated before; the one on screen named f(x*)) and the same method run directly on f, charged what it
        used (first_cost: from the best design of step 1 its curve begins at N), with a ring at the cost of the study
        through the metamodel (same_cost); in Real Run the direct run is the one on screen, drawn up to the stage on
        screen. The axes hold both whole, so that they never move with the frames. A gap of 0 is drawn on the floor of
        the axis, and said."""
        ax.clear()
        style_axes(ax)
        ax.set_facecolor(palette.CARD)
        minimum, n = state.response.minimum, state.n
        route = [best - minimum for best in routed(state)]
        direct = [best - minimum for best in state.direct.best] if state.direct is not None else []
        shown = direct[:state.count] if state.simulating else direct          # Real Run: what the frames reached
        first = state.first_cost
        validated = [(n + k + 1, value - minimum) for k, (_, value) in enumerate(state.validations)]
        on_screen = next((place for place, (point, _) in zip(validated, state.validations, strict=True)
                          if state.validated and point == state.run.optimum[0]), None)
        same = same_cost(state)
        gaps = route + direct + [value for _, value in validated]
        positive = [gap for gap in gaps if gap > 0]
        lowest, highest = (min(positive), max(positive)) if positive else (1.0, 1.0)
        self.floor = max(10.0 ** (math.floor(math.log10(lowest)) - 1), FLOOR_LEAST)

        def drawn(gap):
            return gap if gap > 0 else self.floor
        longest = max(state.price, len(route), first + len(direct) - 1)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlim(0.8, longest * 1.6)
        ax.set_ylim(self.floor / 4, 10.0 ** (math.ceil(math.log10(highest)) + 0.4))
        looks = routes(state)
        colour, width, style = looks["direct"]
        if shown:
            ax.step(range(first, first + len(shown)), [drawn(gap) for gap in shown], where="post", color=colour, linewidth=width,
                    linestyle=style, alpha=1.0 if state.simulating else 0.9, zorder=4 if state.simulating else 3)
        if same is not None and first + len(shown) - 1 >= same[0]:          # the direct run at the route's cost
            ax.scatter([same[0]], [drawn(same[1] - minimum)], s=46, facecolors="none", edgecolors=colour, linewidths=1.3, zorder=5,
                       clip_on=False)
        colour, width, style = looks["route"]
        ax.step(range(1, len(route) + 1), [drawn(gap) for gap in route], where="post", color=colour, linewidth=width, linestyle=style,
                zorder=3 if state.simulating else 4)
        for place, value in validated:                                # each f(x*), not joined: the line is the best so far
            ax.scatter([place], [drawn(value)], s=52 if (place, value) == on_screen else 30, c=CURRENT, edgecolors=palette.WHITE,
                       linewidths=1.0, zorder=6, clip_on=False)
        if on_screen is not None:                                     # the one on screen, named
            ax.annotate("f(x*)", (on_screen[0], drawn(on_screen[1])), xytext=(7, 0), textcoords="offset points", ha="left", va="center",
                        color=CURRENT, fontsize=9, zorder=7, path_effects=HALO)
        if min(gaps) <= 0:
            ax.axhline(self.floor, color=palette.GREY, linewidth=0.8, linestyle=(0, (1, 2)), zorder=2)
            ax.text(0.97, self.floor, get_text("lab.opt.check.floor"), transform=blended_transform_factory(ax.transAxes, ax.transData),
                    ha="right", va="bottom", color=palette.GREY, fontsize=8.5, zorder=6)
        ax.xaxis.set_major_locator(LogLocator(base=10, numticks=6))
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.yaxis.set_major_locator(LogLocator(base=10, numticks=6))
        ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: decade(value)))
        ax.yaxis.set_minor_locator(NullLocator())
        ax.set_xlabel(get_text("lab.opt.check.x"), **LABEL, labelpad=3)

# ------------------------------------------------------------------------------
# The figure's helpers
# ------------------------------------------------------------------------------
def mapped(response: Response, u) -> tuple[float, float]:
    """A point of the unit square in the bounds of the response."""
    (a1, b1), (a2, b2) = response.bounds
    return a1 + (b1 - a1) * u[0], a2 + (b2 - a2) * u[1]

def within(value: float, true) -> float:
    """A value kept inside the vertical window of the 3D view (metamodel.truth): one beyond it, drawn on its edge."""
    return min(max(float(value), true.low), true.high)

def mark_look(state: OptimizationState, now: bool = False) -> dict:
    """The mark of a point the run on screen evaluated: a cross where y^ was evaluated (white; yellow when the stage
    computes it now: no simulation), a disc where f was simulated, in Real Run (the designs' blue; yellow now)."""
    if state.simulating:
        return {"marker": "o", "c": NOW if now else DESIGN, "edgecolors": palette.CARD, "linewidths": 0.6}
    return {"marker": "+", "c": NOW if now else SEARCH}

def mark_scale(state: OptimizationState) -> float:
    """A disc is drawn smaller than a cross of the same area, which is mostly empty."""
    return 0.6 if state.simulating else 1.0

def routes(state: OptimizationState) -> dict:
    """The look of the two studies in the third panel, (colour, width, line style): the one on screen solid and blue
    (the route through the metamodel, or in Real Run the direct run on f), the other dashed and slate."""
    on, off = (CURRENT, 2.0, "-"), (REFERENCE, 1.3, DIRECT)
    return {"route": off if state.simulating else on, "direct": on if state.simulating else off}

def construction(state: OptimizationState) -> tuple[list, list]:
    """The evaluations the stage on screen makes now (yellow) and those it rejects (red, hollow), as (u, y^); none at
    the end of the run (where it stopped, and x* once validated, are then what the figure shows)."""
    current, record, k, stage = state.run, state.record, state.shown, state.stage
    if state.complete:
        return [], []
    if state.method == "ea":
        if k == 0:
            return list(zip(record["population"], record["values"])), []
        if stage == 2:
            return list(zip(record["children"], record["children_values"])), []
        if stage == 3:
            pool = list(zip(record["population"] + record["children"], record["values"] + record["children_values"]))
            kept = set(record["kept"])
            return [], [pool[i] for i in range(len(pool)) if i not in kept]
        return [], []
    if k == 0:
        return [current.evaluations[0]], []
    if state.method == "nlpql":
        if stage == 1:
            return list(record["probes"]), []
        if stage == 3:
            trials = list(record["trials"])
            if record["alpha"] is None:
                return [], trials
            return trials[-1:], trials[:-1]
        return [], []
    if stage == 1:
        return list(zip(record["designs"], record["values"])), []
    if stage == 2:
        return [(record["optimum"], record["optimum_value"])], []
    return [], []

def active(u, d) -> list[tuple[int, int]]:
    """The bounds the step d ends on (the active set): (coordinate, 0 lower or 1 upper)."""
    found = []
    for i in range(2):
        end = u[i] + d[i]
        if end <= 1e-12:
            found.append((i, 0))
        elif end >= 1 - 1e-12:
            found.append((i, 1))
    return found

def nlpql_model(record: dict, n: int):
    """NLPQL's model y^_k + q_k(d) (quadratic.quadratic_value with the record's g and B) on a square around u_k, as
    large as the step (MODEL_ROOM |d|, at least MODEL_LEAST) and inside the box: (u1, u2, values) grids."""
    u, d = record["point"], record["step"]
    reach = max(MODEL_ROOM * max(abs(d[0]), abs(d[1])), MODEL_LEAST)
    axes = [np.linspace(max(u[i] - reach, 0.0), min(u[i] + reach, 1.0), n) for i in range(2)]
    u1, u2 = np.meshgrid(*axes)
    values = np.array([[record["value"] + quadratic_value(record["gradient"], record["matrix"], [p - u[0], q - u[1]])
                        for p, q in zip(row1, row2)] for row1, row2 in zip(u1, u2)])
    return u1, u2, values

def arsm_model(record: dict, n: int):
    """ARSM's quadratic polynomial (regression.polynomial with the record's coefficients, in the subregion's own
    coordinates t) on its subregion: (u1, u2, values) grids."""
    low, width = record["low"], record["width"]
    t = np.linspace(0.0, 1.0, n)
    t1, t2 = np.meshgrid(t, t)
    values = np.array([[regression.polynomial(record["coefficients"], [p, q], "quadratic") for p, q in zip(row1, row2)]
                       for row1, row2 in zip(t1, t2)])
    return low[0] + width[0] * t1, low[1] + width[1] * t2, values

def plane_legend(state: OptimizationState) -> list:
    """The legend of the design space: the designs and the search, the best point, what the stage on screen draws (or
    x* validated), then f's minima, a reference (the last entries go first when the panel is narrow). In Real Run the
    level lines are named first (they are f's), and the search is the run's simulations, blue discs."""
    handles = [dot(DESIGN, get_text("lab.opt.legend.designs"))]
    if state.simulating:
        handles.insert(0, Line2D([], [], color=palette.GREY, linewidth=1.2, label=get_text("lab.opt.legend.levels_real")))
        if state.run is not None:
            handles += [dot(DESIGN, get_text("lab.opt.legend.simulations"), size=6),
                        dot(BEST, get_text("lab.opt.legend.best_real"), marker="*", size=11)]
    elif state.run is not None:
        handles += [Line2D([], [], linestyle="none", marker="+", markersize=8, markeredgewidth=1.5, color=SEARCH,
                           label=get_text("lab.opt.legend.evaluated")),
                    dot(BEST, get_text("lab.opt.legend.best"), marker="*", size=11)]
    if state.validated:
        handles.append(dot(DESIGN, get_text("lab.opt.legend.validated"), hollow=True))
    elif state.run is not None:
        now, rejected = construction(state)
        if now and state.simulating:
            handles.append(dot(NOW, get_text("lab.opt.legend.now"), size=6))
        elif now:
            handles.append(Line2D([], [], linestyle="none", marker="+", markersize=8, markeredgewidth=1.8, color=NOW,
                                  label=get_text("lab.opt.legend.now")))
        if rejected:
            handles.append(dot(REJECTED, get_text("lab.opt.legend.rejected"), hollow=True))
        if staged_model(state):
            handles.append(Line2D([], [], color=MODEL, linewidth=1.2, linestyle="--", label=get_text("lab.opt.legend.model")))
    return handles + [dot(REFERENCE, get_text("lab.opt.legend.minimum"), hollow=True)]

def staged_model(state: OptimizationState) -> bool:
    """Whether the stage on screen draws the method's model of y^ (NLPQL's q, ARSM's quadratic): from its second stage
    on, never at the end of the run."""
    return (state.run is not None and state.method != "ea" and state.record is not None and state.stage >= 2
            and not state.complete)

# ------------------------------------------------------------------------------
# The verdict, in real simulations
# ------------------------------------------------------------------------------
def routed(state: OptimizationState) -> list[float]:
    """The route through the metamodel in real simulations: the lowest y simulated after each of step 1's designs, in the
    order they were drawn, then after each distinct x* validated on the experiment, at N + 1, N + 2, ...: the lower of
    the best so far and that f(x*). It never rises."""
    values = list(state.designs.values) + [value for _, value in state.validations]
    return list(itertools.accumulate(values, min))

def same_cost(state: OptimizationState) -> tuple[int, float] | None:
    """The direct run on f at the cost of the study through the metamodel once x* is validated (price; at the direct
    run's end when it is shorter), the direct run charged what it used (first_cost): (its cost by then, its lowest y by
    then); None when it cannot be computed."""
    if state.direct is None:
        return None
    k = min(max(state.price - state.first_cost, 0), len(state.direct.best) - 1)
    return state.first_cost + k, state.direct.best[k]

def tally(n: int, more: int) -> str:
    """A cost as it is written: "60" alone, "60 + 2 = 62" with what came after the N simulations of step 1."""
    return f"{n} + {more} = {n + more}" if more else str(n)

def direct_tally(state: OptimizationState, count: int) -> str:
    """What the direct run cost after its first `count` simulations, written as its curve begins: "60 + 33 = 93" from
    the best design of step 1 (its N simulations charged), "51" from a start the reader put or the EA's population."""
    return tally(state.n, count - 1) if state.first_cost > 1 else str(count)

def verdict(state: OptimizationState) -> str:
    """x* against the best design of step 1, an exact fact: "better" when f(x*) is below the least simulated y of
    step 1, "worse" when above, "same" when equal ("" before the validation)."""
    if not state.validated:
        return ""
    design = min(state.designs.values)
    return "better" if state.real < design else ("worse" if state.real > design else "same")

def verdict_kind(state: OptimizationState) -> str:
    """The verdict's colour: "ok" (teal) when x* is better than the best design of step 1, "error" (red) when not."""
    return "ok" if verdict(state) == "better" else "error"

def verdict_metric(state: OptimizationState) -> Metric:
    """f(x*) - f*, with the verdict's kind, and beside it the best design's gap and the direct run's at the same cost
    (same_cost: the study's through the metamodel, the direct run charged what it used); once validated, the sign of
    the comparison first: 3.16 > design 0.474 (never colour alone; the lead says it in words); a dash before."""
    minimum = state.response.minimum
    same = same_cost(state)
    gaps = {"design": gap(min(state.designs.values) - minimum), "direct": gap(same[1] - minimum) if same is not None else DASH}
    detail = get_text("lab.opt.m.gap_detail" if same is not None else "lab.opt.m.gap_alone", **gaps)
    value, kind = DASH, "plain"
    if state.validated:
        value, kind = gap(state.real - minimum), verdict_kind(state)
        detail = f"{SIGNS[verdict(state)]} {detail}"
    return Metric(get_text("lab.opt.m.gap"), value, kind=kind, detail=detail,
                  tip=get_text("lab.opt.m.gap_tip", n=state.n, route=state.price))

def earned(state: OptimizationState) -> int:
    """The stars the state is worth (explorers/game.py): the MOP Solver's run, complete and validated, whose x* completes
    the bench, at the cost of the study (simulations: N and every distinct x* validated on the experiment); else 0."""
    if state.simulating or state.run is None or not state.complete or not state.validated:
        return 0
    if not game.complete(state.response.key, state.run.optimum[0], state.real, min(state.designs.values)):
        return 0
    return game.stars(state.response.key, state.simulations)

def bench_metric(state: OptimizationState) -> Metric:
    """The bench: the stars (filled and hollow, never colour alone) and the cost, "60 + 2 = 62", when x* completes it;
    validated but not complete, all hollow and what is missing (not below the best design; or far from a global
    minimum, in words: the distance in the unit square and f(x*) - f*, in digits that never read as the most that
    completes, game.REACH and game.tolerance, which the tip gives: apart); a dash before. The limits stay in the tip:
    the strip of a 1280 x 720 window has no room for them beside a stop said in words."""
    function = state.response.key
    tolerance = game.tolerance(function)
    tip = get_text("lab.opt.m.bench_tip", reach=f"{game.REACH:g}", share=f"{100 * game.REACH:g}", tolerance=short(tolerance, 3))
    if state.run is None or not state.validated:
        return Metric(get_text("lab.opt.m.bench"), DASH, tip=tip)
    stars = earned(state)
    value = STAR * stars + HOLLOW_STAR * (game.MOST - stars)
    if stars:
        return Metric(get_text("lab.opt.m.bench"), value, kind="ok", tip=tip,
                      detail=get_text("lab.opt.m.bench_cost", cost=tally(state.n, len(state.validations))))
    if not state.real < min(state.designs.values):
        return Metric(get_text("lab.opt.m.bench"), value, tip=tip, detail=get_text("lab.opt.m.bench_above"))
    distance, _ = apart(game.distance(function, state.run.optimum[0]), game.REACH)
    above, _ = apart(max(state.real - state.response.minimum, 0.0), tolerance)
    far = get_text("lab.opt.m.bench_far", distance=distance, gap=above)
    return Metric(get_text("lab.opt.m.bench"), value, tip=tip, detail=far)

def apart(value: float, limit: float) -> tuple[str, str]:
    """A value and the limit it is compared with, in three significant digits, more when the two would read alike
    (0.0308 against 0.0308: 0.030812 against 0.030801): a reader never sees two equal numbers said to differ. A value
    too large or too small for plain digits is written as gap writes it."""
    said = (gap(value), short(limit, 3))
    for digits in range(3, 13):
        plain = (f"{value:.{digits}g}", f"{limit:.{digits}g}")
        if "e" in plain[0] or "e" in plain[1]:
            return said
        said = plain
        if plain[0] != plain[1] or value == limit:
            break
    return said

def own_metric(state: OptimizationState) -> Metric:
    """The method's own measure at the stage on screen: NLPQL's step |d|, the EA's generation and its sigma, ARSM's
    subregion; at the end of the run, why it stopped, in neutral ink (a stop is no verdict)."""
    own = {"nlpql": "lab.opt.m.step", "ea": "lab.opt.m.generation", "arsm": "lab.opt.m.width"}[state.method]
    stopped = {"tolerance": power(sqp.TOLERANCE), "smallest": power(response_surface.SMALLEST)}
    tips = stopped | {"first": f"{evolutionary.SIGMA_FIRST:g}", "last": f"{evolutionary.SIGMA_LAST:g}"} | wording(state.simulating)
    tip = get_text(f"{own}_tip", **tips)
    current = state.run
    if current is None:
        return Metric(get_text(own), DASH, tip=tip)
    k, stage, record = state.shown, state.stage, state.record
    if state.method == "nlpql":
        value = power(math.hypot(*record["step"])) if record is not None and stage >= 2 else DASH
        detail = get_text("lab.opt.m.step_detail")
        if state.complete:
            name = {"converged": "step_converged", "no_decrease": "step_refused", "iterations": "step_iterations"}[current.stop]
            detail = get_text(f"lab.opt.m.{name}", iterations=sqp.ITERATIONS, **stopped)
        return Metric(get_text(own), value, tip=tip, detail=detail)
    if state.method == "ea":
        sigma = evolutionary.SIGMA_FIRST if k == 0 else record["sigma"]
        return Metric(get_text(own), get_text("lab.opt.m.generation_value", k=k, total=current.last), tip=tip,
                      detail=get_text("lab.opt.m.generation_detail", sigma=f"{sigma:.3g}"))
    width = current.history[0]["width"] if k == 0 else record["next_width" if stage == 3 else "width"]
    detail = get_text("lab.opt.m.width_detail")
    if state.complete:
        name = "width_converged" if current.stop == "converged" else "width_iterations"
        detail = get_text(f"lab.opt.m.{name}", iterations=response_surface.ITERATIONS, **stopped)
    return Metric(get_text(own), power(max(width)), tip=tip, detail=detail)

def real_run_metrics(state: OptimizationState) -> list[Metric]:
    """Real Run's strip: the method's own measure, what the simulations made by the stage on screen cost, of the run's
    whole cost (charged as its curve is: "60 + 33" from the best design of step 1, direct_tally), the lowest f simulated
    so far and its gap to f*, beside the best design's."""
    minimum = state.response.minimum
    design = get_text("lab.opt.m.gap_alone", design=gap(min(state.designs.values) - minimum))
    simulations = Metric(get_text("lab.opt.m.simulations"), DASH, tip=get_text("lab.opt.m.simulations_tip"))
    lowest = Metric(get_text("lab.opt.m.lowest"), DASH, tip=get_text("lab.opt.m.lowest_tip"))
    lowest_gap = Metric(get_text("lab.opt.m.lowest_gap"), DASH, detail=design, tip=get_text("lab.opt.m.lowest_gap_tip"))
    if state.run is not None:
        best = min(y for _, y in state.run.evaluations[:state.count])
        charged = state.first_cost > 1
        simulations = dataclasses.replace(simulations, value=f"{state.n} + {state.count - 1}" if charged else str(state.count),
                                          detail=get_text("lab.opt.m.evaluations_detail",
                                                          total=state.direct_cost(len(state.run.evaluations))))
        lowest = dataclasses.replace(lowest, value=short(best, 4) if best == 0 or abs(best) >= 1e-3 else power(best))
        lowest_gap = dataclasses.replace(lowest_gap, value=gap(best - minimum))
    return [own_metric(state), simulations, lowest, lowest_gap]

def transport_name(state: OptimizationState) -> str:
    """The name of the stage on screen, beside the transport icons: "iteration 3 of 12 · gradient", "generation 5 of
    30 · survival", "complete · 20 evaluations" (simulations, in Real Run); "" for a run that cannot be computed."""
    current = state.run
    if current is None:
        return ""
    if state.complete:                                                # in Real Run, what the run cost (direct_tally)
        count = len(current.evaluations)
        return get_text(f"lab.opt.transport.complete.{state.solver}", count=direct_tally(state, count) if state.simulating else count)
    stage = get_text("lab.opt.stage.start") if state.shown == 0 else get_text(f"lab.opt.stage.{state.method}.{state.stage}")
    name = "lab.opt.transport.generation" if state.method == "ea" else "lab.opt.transport.iteration"
    return get_text(name, k=state.shown, total=current.last, stage=stage)

def wording(simulating: bool) -> dict:
    """The words of what a run calls, for the texts: the function searched (y^, or f) and its calls (evaluations of y^,
    or simulations)."""
    kind = "real" if simulating else "mop"
    return {"objective": get_text(f"lab.opt.objective.{kind}"), "calls": get_text(f"lab.opt.calls.{kind}"),
            "call": get_text(f"lab.opt.call.{kind}")}

# ------------------------------------------------------------------------------
# The texts
# ------------------------------------------------------------------------------
def origin(state: OptimizationState) -> str:
    """Where the start comes from, in a few words: the best design of step 1, or where the reader put it."""
    return get_text("lab.opt.lead.dragged" if state.dragged else "lab.opt.lead.best")

def nlpql_lead(state: OptimizationState) -> str:
    k, stage, record, words = state.shown, state.stage, state.record, wording(state.simulating)
    if record is None:
        u, y = state.run.evaluations[0]
        x1, x2 = mapped(state.response, u)
        return get_text("lab.opt.lead.nlpql.start", x1=short(x1, 3), x2=short(x2, 3), y=short(y, 4), origin=origin(state), **words)
    if stage == 1:
        return get_text("lab.opt.lead.nlpql.gradient", k=k, probes=len(record["probes"]), h=decade(state.step), **words)
    if stage == 2:
        return get_text("lab.opt.lead.nlpql.active" if active(record["point"], record["step"]) else "lab.opt.lead.nlpql.model", k=k,
                        **words)
    if record["alpha"] is None:                                       # a search refused ends the run: its stop says why
        return stop_sentence(state.run)
    return get_text("lab.opt.lead.nlpql.search", k=k, trials=len(record["trials"]), alpha=fraction(record["alpha"]), **words)

def ea_lead(state: OptimizationState) -> str:
    k, stage, record, mu = state.shown, state.stage, state.record, len(state.record["population"])
    words = wording(state.simulating)
    if k == 0:
        return get_text("lab.opt.lead.ea.start", mu=mu, **words)
    if stage == 1:
        return get_text("lab.opt.lead.ea.selection", k=k, pairs=len(record["pairs"]), **words)
    if stage == 2:
        return get_text("lab.opt.lead.ea.children", k=k, mu=mu, sigma=f"{record['sigma']:.3g}", crossover=f"{evolutionary.CROSSOVER:g}",
                        **words)
    return get_text("lab.opt.lead.ea.survival", k=k, mu=mu, **words)

def arsm_lead(state: OptimizationState) -> str:
    k, stage, record, words = state.shown, state.stage, state.record, wording(state.simulating)
    if record is None:
        u, y = state.run.evaluations[0]
        x1, x2 = mapped(state.response, u)
        return get_text("lab.opt.lead.arsm.start", x1=short(x1, 3), x2=short(x2, 3), y=short(y, 4), origin=origin(state),
                        width=f"{state.run.history[0]['width'][0]:g}", **words)
    if stage == 1:
        return get_text("lab.opt.lead.arsm.designs", k=k, designs=len(record["designs"]), **words)
    if stage == 2:
        return get_text("lab.opt.lead.arsm.fit", k=k, designs=len(record["designs"]), **words)
    return get_text("lab.opt.lead.arsm.zoom", k=k, l1=f"{record['factors'][0]:.2f}", l2=f"{record['factors'][1]:.2f}",
                    zoom=f"{response_surface.ZOOM:g}", **words)

def stopped(current: Run) -> dict:
    """The numbers the words of a stop say."""
    values = {"evaluations": len(current.evaluations), "tolerance": power(sqp.TOLERANCE), "smallest": power(response_surface.SMALLEST),
              "iterations": sqp.ITERATIONS if current.method == "nlpql" else response_surface.ITERATIONS,
              "generations": len(current.history) - 1} | wording(current.simulated)
    if current.method == "arsm":
        values["width"] = power(max(current.history[-1]["next_width"]))
    return values

def stop_sentence(current: Run) -> str:
    """Why the run stopped (on y^, or on f), in a sentence: the lead at the end of the run, before the validation."""
    return get_text(f"lab.opt.stop.{current.method}.{current.stop}", **stopped(current))

def stop_mark(current: Run) -> str:
    """Why the run stopped, in a few words written on the design space."""
    return get_text(f"lab.opt.end.{current.method}.{current.stop}", **stopped(current))

def moved(settings: dict, u1: float, u2: float) -> dict | None:
    """The settings with the start at (u1, u2), kept in the unit square, the complete run shown; None when it does not
    move (the start where it is, to the 3 decimals a start is kept in)."""
    start = (round(min(max(float(u1), 0.0), 1.0), 3), round(min(max(float(u2), 0.0), 1.0), 3))
    here = start_of(settings)
    if start == (round(here[0], 3), round(here[1], 3)):
        return None
    return ended(settings | {"start": start})

def superscript(number: int) -> str:
    return "".join(SUPERSCRIPTS[c] for c in str(number))

def power(value: float) -> str:
    """A number in two significant digits, with a power of ten when it is small or large: 0.38, 1.2 × 10⁻⁷, 10⁻⁶."""
    if value == 0:
        return "0"
    if 100 <= abs(value) < 1e4:                                       # 310, 1200: two significant digits, no power
        return f"{round(value, 1 - math.floor(math.log10(abs(value)))):.0f}".replace("-", "−")
    text = f"{value:.2g}"
    if 1e-3 <= abs(value) < 1e3 and "e" not in text:
        return text.replace("-", "−")
    mantissa, exponent = f"{value:.1e}".split("e")
    if mantissa in ("1.0", "-1.0"):
        return mantissa[:-3].replace("-", "−") + "10" + superscript(int(exponent))
    return f"{mantissa.replace('-', '−')} × 10{superscript(int(exponent))}"

def gap(value: float) -> str:
    """A gap to f* as it is written wherever it is shown (the strip, the lead, the summary): three significant digits
    from 0.001 to 10⁵, their trailing zeros kept, so that two gaps written side by side have the same digits (4.80,
    0.730, 3.16, 156, 1230); beyond, two and a power of ten, 2.5 × 10⁻¹³, 10⁻⁶ (as power). A gap below 0 (rounding: f*
    is the least f) is 0."""
    value = max(float(value), 0.0)
    if value == 0:
        return "0"
    text = f"{value:#.3g}"                                           # "#": the trailing zeros kept (and a trailing point,
    text = text if "e" in text else text.rstrip(".")                  # "156.", dropped)
    if 1e-3 <= value < 1e5 and "e" not in text:
        return text
    if 1e-3 <= value < 1e5:                                           # 999.6, 1234: three digits, no power
        return f"{round(value, 2 - math.floor(math.log10(value))):.0f}"
    return power(value)

def decade(value: float) -> str:
    """A power of ten as it is read: 10⁻⁸ (1 and 10 as numbers); any other value as power writes it."""
    exponent = round(math.log10(value)) if value > 0 else 0
    if value <= 0 or not math.isclose(value, 10.0 ** exponent, rel_tol=1e-9):
        return power(value)
    return {0: "1", 1: "10"}.get(exponent, "10" + superscript(exponent))

def fraction(alpha: float) -> str:
    """A step of the line search, 1, 1/2, 1/4, ...: as the fraction it is."""
    halvings = round(-math.log2(alpha))
    return "1" if halvings == 0 else f"1/{2 ** halvings}"

def signed(value: float) -> str:
    """A move with its sign, in two decimals; one that rounds to zero has none."""
    text = f"{value:+.2f}"
    return "0.00" if text in ("+0.00", "-0.00") else text.replace("-", "−")
