# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: pareto_doe.py
# ==============================================================================
"""
Step 1 of a bench of SEVERAL responses (functions.many: bench 4, beam_pareto, the beam on two cross-beams placed and
sized, two objectives and two constraints), the design of experiments: ParetoSamplingLab(function, mode), reached by
explorers.lab_for("doe", "beam_pareto", mode). The study is step 1's own and stays the parent's code (explorers/doe.py,
SamplingLab): the three samplings (Free, the Latin hypercube, Monte Carlo), N and its quick picks, the seed and New
sample, a teacher's first experiment (doe.FIRST_POINTS: 70) and a student's free sampling with nothing placed, the view of
four inputs (explorers/section.py: the pair on the axes, the values held, the free points lifted onto the slice), the
free sampling by clicks, drags and keys, missing, opening, the snapshot, and the hand-off of the SAME doe.Experiment,
seen through its output 0 (steps 2 and 3 read each response with dataclasses.replace(experiment, output=k)). What this
laboratory adds is what one simulation of four responses shows:

    The problem  m: mass ... |  the beam's band: the design in focus, its two places and sizes, both objectives, the check
    minimize   m, δ          |------------------------------------------------------------------------------------------------
    subject to σ₁, σ₂ ≤ 120  | design space x_i, x_j: N x N    | objective space m [kg] across, | Objective space
               x₁ ∈ [2, 5] m | cells, the counts' bands, each  | δ [mm] up: every design, the   | legend (two rows)
               x₂ ∈ [5, 8] m | design by its kind (feasible    | non-dominated staircase, the   | ----------------------
               A₁, A₂ ∈ ...  | disc, infeasible ring, the      | true front (a teacher's, or    | N = 70 · 39 feasible
    Sampling ...             | non-dominated ringed), faded    | a student's once won)          | non-dominated, empty
                             | off the slice                   |--------------------------------------------------------
                             |                                 | The designs simulated: i, x₁ .. x₄, m, δ, σ₁, σ₂, mark

- One simulation per design gives every output (doe.simulations, once per experiment): ROWS, outputs.rows of
  doe.simulated(e).outputs; a design is FEASIBLE when both stresses are within their limit, exactly (outputs.feasible);
  the experiment's own FRONT is its feasible designs that no other one dominates (outputs.front_of); the COMPROMISE is
  the one of them nearest the ideal point, the objectives normalized by the front's own ends (outputs.compromise). They
  are computed once per experiment (outcomes, cached) and carried by the state (ParetoState: rows, feasible, front,
  compromise).
- The first card of the right column holds the OBJECTIVE SPACE (explorers/objectives.py: its box objectives.box, its
  window the bench's, the same in the three steps), not a 3D view: the designs, feasible and not, those beyond the window
  at its edge and counted, the experiment's non-dominated ones with their staircase; the TRUE front (the slate line, the
  reference a real study never has) only where the true response is shown (Lab.truth_shown, the owner's 2B: a
  simulation's once the reader asked to see it, Lab.revealed, a teacher's "Show f", a student's once the bench is won;
  the window offers it), never otherwise, its legend's entry with it. No true surface is drawn anywhere in this step:
  nothing of the simulation is shown that was not simulated (no doe.surface, doe.extent, doe.window, game.spread or
  doe.through is ever reached from here).
- The design plane as bench 3's (explorers/doe.py: the N x N intervals and the two bands of counts of the pair), each
  design at its projection by its kind (objectives.designs_on_plane: the feasible blue disc, the infeasible red ring,
  the non-dominated ring in teal, faded with the distance from the slice).
- The automatic slice (no slider pinned) passes through the compromise design of an algorithm's sample; through the
  middle of the ranges for the free sampling (the reader's hand: nothing moves by itself) and where no design is
  feasible. Its chip is section.chip("compromise") ("Slice at the compromise design", the place of section.PLACES of a
  bench of several responses), renamed "Slice at the middle" where the slice returns there (naming, tip_of).
- The design in focus on the beam's band (caption.simulated: its four outputs and its tag, "non-dominated" where it is
  one; a feasible or infeasible design is said by the check line itself, in words): the design under the pointer IN
  EITHER SPACE (the plane as bench 3, the objective space by objectives.hit), ringed in both (the plane's white ring, the
  objective space's objectives.Ring, a live artist); else, over the plane away from a design, the place under the
  pointer (caption.under: the cross-beams dashed, no outputs, the crosshair); else the compromise design; with no
  feasible design nor any design, the problem alone.
- The third panel, the table of the designs, shows VALUES: i, x₁ .. x₄, m, δ, σ₁, σ₂ and the design's own mark (the
  plane's), one row a design, the page that holds the design pointed at (else the compromise, else the first or a free
  sample's last point) and a last line that says which rows are shown; the units in the caption under its title, never
  in the headings; an excess stress in the failed colour AND by the row's hollow red mark (never colour alone); numbers
  in the monospace role, right-aligned on the digit, each column as wide as its widest value may be (table_layout:
  measured with panels.number_width at the font that lets the block fit the card, down to TABLE_SETS' smallest, then
  fewer decimals of the places and of δ, so that nothing is clipped); the places to the centimetre, the sizes and m
  whole, δ as the objective space writes it, a stress whole or with the decimals that keep it on its side of the limit
  (caption.against). The row pointed at is lit (yellow on the pill), the compromise's row under the pill alone.
- IN THE WINDOW'S COLUMN (Lab.columned, the owner's design of 2026-11-21; the web never sets it): the figure has no
  third panel (doe.SamplingLab.arranged's third=False, no readout on a bench of several responses: the objective space
  the right column's ONE card, larger, its head one row of legend, the design space filling its height) and the
  column holds two blocks (blocks): the card of the cross-beams, in this step alone, where the areas are chosen
  (crossbeams.Column: the design or the place the band shows, its table, or the cross-beam pointed at in the band in
  detail in the table's place; live), then the table of the designs (DESIGNS, titled
  lab.pareto.doe.table_title, the units in its note, lab.pareto.doe.table_caption), drawn by the same table_body on the
  block's own figure (draw_designs; table_columns the parent's seam, at the default decimals and coarse; block_table:
  the largest font and the most decimals whose nine columns fit 248 pixels, BLOCK_GAP_LEAST apart, a stress whole unless
  a design's needs its decimals, block_widest), the parent's hit_block naming the design of the row under the mouse;
  its rows from the first the window's scroll bar shows (the parent's in_sight, scroll_to, scrolled: the design pointed at
  kept in sight, and for a new experiment the compromise), with no line under them (the bar says which).
- The measures (the indicators' block beside the objective space under the band; the strip elsewhere), four: N with the
  feasible designs beside it, the non-dominated ones, the empty intervals of the four inputs and the largest correlation
  with its pair (both bench 3's); the smallest distance is left out on this bench. The card of the problem in its
  standard form, as every bench's (doe.SamplingLab.received): minimize m, δ subject to σ₁, σ₂ ≤ 120 MPa and the bounds
  of the places and of the areas (A₁, A₂), each in its unit, and what m and δ are, quietly at the right of its heading.
  The summary (the cover's track) is bench 3's: the empty intervals. "View code" reads the sampling, as the parent's.
- The plan's notes: the slice's note under or beside the plane's title is decided on the widest title of the plane in
  the THREE steps of this bench (heading: PLANE_TITLES, those of steps 2 and 3 where their catalogs have them, each
  place filled with every response's symbol), so that the three steps keep one rect. Step 2 and step 3 of this bench lay their figure
  out with the same notes: they call pareto_doe.heading(function).

The scene (what stays while the pointer moves) is drawn once per (scene_of, the kinds present, the true front shown); the
designs, their bands and marks in both spaces and the table's rows are drawn again at every draw (moving), the ring of
the objective space and the band's focus in the live layer (live).
"""
from dataclasses import dataclass, fields, replace
from functools import cache, lru_cache
from types import SimpleNamespace

from matplotlib.patches import Patch, Rectangle

from statistical_fundamentals import palette
from statistical_fundamentals.explorers import caption, crossbeams, objectives, outputs, section
from statistical_fundamentals.explorers.base import number, short
from statistical_fundamentals.explorers.doe import (DASH, DESIGNS, DESIGNS_SIDE, EMPTY, FREE, MORE, MOST, ONE,
                                                    TABLE_HEAD_LEAST, TABLE_HEADING, Columns, SampleState, SamplingLab,
                                                    ASIDE, design_index, designs_block, frame_table, marker_size, problem_bound,
                                                    problem_goal, row_places, rows_from, scene_of, simulated, table_room, titled)
from statistical_fundamentals.explorers.game import TEACHER
from statistical_fundamentals.explorers.lab import Action, Block, Metric, size
from statistical_fundamentals.explorers.panels import (BLOCK_TONE, BLOCK_TOP, CARD_TONE, HEADING, MUTED_INK, NUMBER, SMALL,
                                                       TABLE_LEAST, TABLE_SIZE, draw_cards, head_room, input_name, legend_most,
                                                       number_width, subtitle, text_width, title_drop)
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.i18n import DEFAULT_LANGUAGE, current_language, get_text, has_text, placeholders

FUNCTION = "beam_pareto"              # the bench this laboratory is made for (any bench of several responses would do)
PLANE_TITLES = ("lab.lhs.plane_title", "lab.pareto.mm.plane_title", "lab.pareto.opt.plane_title",     # the plane's head
                "lab.pareto.opt.plane_title_real")    # in the three steps of the bench (heading; step 3's in its two
                                      # solvers): those whose catalogs exist are measured
POINTED_RING = 4.2                    # the white ring of the design pointed at on the plane, in areas of the design's mark:
                                      # wider than the non-dominated ring (2.6), which it must not hide
LIT = palette.YELLOW                  # the row of the design pointed at (as step 1's table of intervals)
# The table of the designs, in layout pixels (and points for the fonts)
TABLE_SETS = ((TABLE_SIZE, 15.0), (TABLE_LEAST, 13.5))     # a font and its row: the largest whose block fits the card's width and shows
                                             # TABLE_ROWS_LEAST rows (or every design): nine columns of numbers, set as
                                             # the screen's mock sets them (step 1's intervals take 9.5 for three)
TABLE_ROWS_LEAST = 10
TABLE_GAP, TABLE_GAP_LEAST = 12.0, 6.0                    # between two columns: the room left shared out, at least this
TABLE_MARK = 18.0                     # the column of the design's mark
TABLE_SIDE = 4.0                      # the block's room from the table's sides, at least
MARK_AREA = 20.0                      # points²: a mark in the table (the objective space's designs are 16 to 22)

@dataclass(frozen=True)
class Outcomes:
    """What the simulations of an experiment give a study of several responses: the ROW of every output of each design
    (outputs.rows), whether each design is feasible, the indices of the experiment's front (its feasible designs that
    no other dominates, in their order) and the compromise among them (None: no feasible design)."""
    rows: tuple[tuple[float, ...], ...]
    feasible: tuple[bool, ...]
    front: tuple[int, ...]
    compromise: int | None

@lru_cache(maxsize=512)
def outcomes(experiment) -> Outcomes:
    """The Outcomes of an experiment (doe.Experiment, read through any output: the designs are the same), cached by it
    (step 2 and step 3 may read them too). Never mutate what it returns."""
    function = experiment.function
    rows = tuple(tuple(row) for row in outputs.rows(simulated(experiment).outputs))
    return Outcomes(rows, tuple(outputs.feasible(function, row) for row in rows), tuple(outputs.front_of(function, rows)),
                    outputs.compromise(function, rows))

@dataclass(frozen=True)
class ParetoState(SampleState):
    """Step 1's state of a bench of several responses: the parent's (doe.SampleState) and the Outcomes of its
    experiment (no design: all empty, compromise None)."""
    rows: tuple[tuple[float, ...], ...] = ()
    feasible: tuple[bool, ...] = ()
    front: tuple[int, ...] = ()
    compromise: int | None = None

    def point(self, i: int) -> tuple[float, float]:
        """Design i's objectives, a point of the objective space."""
        return tuple(float(v) for v in outputs.objective_values(self.response.key, self.rows[i]))

def heading(function: str) -> dict | None:
    """The plan's notes of a bench of several responses (panels.arrangement's `notes`; doe.SamplingLab.headings): the
    plane's titles of its three steps (PLANE_TITLES whose catalogs exist, each place of a title filled with every
    response's symbol, plain and with its hat, alone and of x: "σ̂₁(x)") and the notes its slice may write
    (section.heads_of): the same in its three steps, which call it, so that they decide the note's line alike and keep
    one rect. None for two inputs."""
    if RESPONSES[function].d == 2:
        return None
    return heads(function, current_language())

@cache
def heads(function: str, language: str) -> dict:
    """heading's, once per bench and language."""
    symbols = [outputs.symbol(function, k, hat) for k in range(len(outputs.of(function))) for hat in (False, True)]
    filled = [form for symbol in symbols for form in (symbol, f"{symbol}(x)")]
    titles = []
    for key in PLANE_TITLES:
        if has_text(key, DEFAULT_LANGUAGE):
            names = placeholders(get_text(key))                   # whatever the title's places: each response's symbol
            titles += [get_text(key, **{name: form for name in names}) for form in filled]
    return {"plane": (tuple(dict.fromkeys(titles)), section.heads_of(function, language)["plane"][1])}

class ParetoSamplingLab(crossbeams.Column, SamplingLab):
    """Step 1 of a bench of several responses: the parent's study, read through the four outputs of each simulation."""

    def __init__(self, function: str = FUNCTION, mode: str = TEACHER):
        """The parent's lab (its controls, its first settings by mode), its chip of the slice, its forward command's tip
        and the sampling's tip the bench's own (a sampling never looks at the responses: there is no f here)."""
        super().__init__(function, mode)
        self.controls = tuple(replace(control, tip=get_text("lab.pareto.doe.method_tip")) if control.key == "method" else control
                              for control in self.controls)
        own = {section.CHIP: section.chip("compromise")}
        self.actions = tuple(own.get(action.key, action) if action.key != "advance" else
                             Action(action.key, action.label, get_text("lab.pareto.doe.advance_tip"), forward=True)
                             for action in self.actions)
        self.ring = None                       # the objective space's ring of the design pointed at, once per scene
        self.over_space = False                # the last hit found a design in the objective space (not grabbed)

    def headings(self) -> dict | None:
        """The plan's notes: the bench's three steps' (heading)."""
        return heading(self.function)

    # ------------------------------------------------------------------ state
    def state(self, settings: dict) -> ParetoState:
        """The parent's state (the experiment, its designs, the slice), with the Outcomes of its experiment."""
        base = super().state(settings)
        found = outcomes(base.experiment) if base.experiment is not None and not base.empty else Outcomes((), (), (), None)
        return ParetoState(*(getattr(base, field.name) for field in fields(SampleState)), found.rows, found.feasible,
                           found.front, found.compromise)

    def automatic(self, settings: dict) -> tuple[float, ...] | None:
        """The slice while nothing is pinned: through the compromise design of an algorithm's sample (outputs.compromise:
        the experiment's non-dominated design nearest the ideal point); None, the middle of the ranges, for the free
        sampling (nothing moves by itself), with no design and with no feasible design."""
        if settings.get("method") == FREE:
            return None
        experiment = self.experiment_of(settings)
        if experiment is None or not experiment.n:
            return None
        found = outcomes(experiment).compromise
        return None if found is None else simulated(experiment).unit[found]

    def middle(self, state: ParetoState) -> bool:
        """The automatic slice stands at the middle of the ranges: the free sampling, no design, no feasible design."""
        return state.free or state.empty or state.compromise is None

    def naming(self, key: str, state: ParetoState) -> str:
        """The parent's (the free sampling's count under the transport row); the chip named by where it returns the
        slice: the middle (middle), else its own label (the compromise design)."""
        if key == section.CHIP:
            return get_text("lab.view.slice.middle") if self.middle(state) else ""
        return super().naming(key, state)

    def tip_of(self, key: str, state: ParetoState) -> str:
        if key == section.CHIP:
            return get_text("lab.view.slice.middle_tip") if self.middle(state) else ""
        return super().tip_of(key, state)

    def received(self, state: ParetoState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """The card of the problem in its standard form, as step 1's of every bench (doe.SamplingLab.received): the goal,
        "minimize  m, δ" (the objectives' symbols); "subject to" the constraints and their one limit ("σ₁, σ₂ ≤ 120
        MPa"), then the bound of each place in its unit ("x₁ ∈ [2, 5] m") and the areas in theirs, written once where
        they share it ("A₁, A₂ ∈ [175, 350] cm²": the names the band and the card of the cross-beams give x₃ and x₄,
        section.physical), each of these rows with a tip of its own, its fourth (what the inputs are:
        lab.pareto.doe.problem.places_tip, sizes_tip; the window shows it over the row); and, quietly at the right of
        the card's heading (the row of kind "aside"), each objective by its symbol and its unit in the axes' brackets
        ("m [kg] · δ [mm]": the card has no room for their names too, which the objective space's axes and the band
        give). The rows are problem()'s, the bench's alone."""
        return get_text("lab.lhs.problem"), self.problem()

    def problem(self) -> tuple[tuple, ...]:
        """The rows of the card of the problem (received), the bench's alone (doe.SamplingLab.problem)."""
        function = self.function
        response = RESPONSES[function]
        found = outputs.objectives(function)
        rows = [problem_goal(get_text("lab.lhs.problem.minimize"), ", ".join(outputs.symbol(function, k) for k in found))]
        limited = outputs.constraints(function)
        if limited:                                                  # one limit, one unit for all
            rows.append(problem_bound(0, f"{', '.join(outputs.symbol(function, k) for k in limited)} ≤ "
                                         f"{outputs.shared_limit(function):g} {outputs.unit(function, limited[0])}"))
        places_, sizes = caption.layout(function)
        for k in places_:
            rows.append(problem_bound(len(rows) - 1, caption.with_unit(f"{section.symbol(k)} ∈ {interval(response.bounds[k])}",
                                                                      response.units[k]),
                                      get_text("lab.pareto.doe.problem.places_tip")))
        if sizes:
            spans = dict.fromkeys(interval(response.bounds[k]) for k in sizes)
            named = ", ".join(section.physical(function, k) or section.symbol(k) for k in sizes)
            rows.append(problem_bound(len(rows) - 1, caption.with_unit(f"{named} ∈ {' · '.join(spans)}", response.units[sizes[0]]),
                                      get_text("lab.pareto.doe.problem.sizes_tip")))
        rows.append(("", " · ".join(f"{outputs.symbol(function, k)} [{outputs.unit(function, k)}]" for k in found), ASIDE))
        return tuple(rows)

    def metrics(self, state: ParetoState) -> list[Metric]:
        """Four measures: the designs, N, with the feasible ones beside it; the non-dominated ones (the experiment's
        front); the empty intervals of every input and the largest correlation with its pair (the parent's, bench 3's);
        dashes while there is no design. The smallest distance is left out on this bench."""
        points, empty, correlation, _ = super().metrics(state)
        tip = get_text("lab.pareto.doe.m.points_tip")
        front = (get_text("lab.pareto.doe.m.front"), get_text("lab.pareto.doe.m.front_detail"), get_text("lab.pareto.doe.m.front_tip"))
        if state.empty:
            return [Metric(points.title, DASH, tip=tip), Metric(front[0], DASH, detail=front[1], tip=front[2]), empty, correlation]
        count = sum(state.feasible)
        feasible = get_text("lab.pareto.doe.m.feasible_one") if count == 1 else get_text("lab.pareto.doe.m.feasible", count=count)
        return [Metric(points.title, points.value, detail=feasible, tip=tip),
                Metric(front[0], str(len(state.front)), detail=front[1], tip=front[2]), empty, correlation]

    # ------------------------------------------------------------------ the focus and the mouse
    def focused(self, state: ParetoState, hovered):
        """The band's design in focus: the design pointed at, in either space (its four outputs, tagged non-dominated
        where it is one); else the place under the pointer (not simulated); else the compromise design; else none."""
        pointed = design_index(hovered)
        if pointed is not None and 0 <= pointed < len(state.rows):
            return self.simulated_focus(state, pointed)
        if self.pointer is not None:
            return caption.under(self.pointer)
        if state.compromise is not None and state.compromise < len(state.rows):
            return self.simulated_focus(state, state.compromise)
        return None

    def simulated_focus(self, state: ParetoState, i: int):
        """Design i as the band shows it: "design i of N", its row, "non-dominated" where it is one of the front."""
        tag = "nondominated" if i in state.front else ""
        return caption.simulated("design", state.points[i], state.rows[i], i + 1, len(state.rows), tag)

    def hit(self, figure, state: ParetoState, event):
        """The design under the mouse in the objective space (objectives.hit, at the place it is drawn), else the
        parent's on the design space (a design, PLACE over an empty place of a free sample, or None)."""
        space = self.axes.get("space")
        self.over_space = space is not None and event is not None and event.inaxes is space
        if self.over_space:
            if state is None or not state.rows:
                return None
            return objectives.hit(space, self.function, [state.point(i) for i in range(len(state.rows))], event)
        return super().hit(figure, state, event)

    def grabbable(self, hovered) -> bool:
        """A design of a free sample can be dragged on the design space, never from the objective space."""
        return super().grabbable(hovered) and not self.over_space

    # ------------------------------------------------------------------ the figure
    def boxes(self, figure) -> dict:
        """The parent's boxes (the design space, the table, the heads), the first card's panel the objective space's
        frame (objectives.box: the same box in the three steps of the bench)."""
        boxes = super().boxes(figure)
        width, height = size(figure)
        x, y, w, h = objectives.box(self.arranged(width, height), self.function)
        boxes["space"] = (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)
        return boxes

    def prepare(self, figure, state: ParetoState) -> dict:
        """The axes of the figure, made again when its size or the language changes (with the cards and the band's
        caption, once per layout) and reused otherwise: the design space, the objective space (a 2D frame: no angle to
        keep) and the table."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height), current_language(), self.columned)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = self.arranged(width, height)
            self.cards = draw_cards(figure, self.plan)
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "space", "table") if name in boxes}
            self.axes["plane"].set_zorder(1)
            self.heads = boxes["heads"]
            self.caption = caption.Caption(figure, self.plan, self.heads, self.function, state.section.pair, geometric=self.columned)
            self.written = self.caption.written
            self.layout_key = key
            self.scene = None
            self.moving = []
            self.ring = None
        return self.axes

    def scene_key(self, state: ParetoState) -> tuple:
        """What the scene depends on: the parent's (N, a design shown, the language, the slice), the kinds of design
        present (the legends list only those) and whether the true front is shown."""
        kinds = (any(state.feasible), not all(state.feasible), bool(state.front))
        return scene_of(state), kinds, self.truth_shown()

    def draw(self, figure, state: ParetoState, hovered) -> None:
        """The three panels with their titles and legends: the scene once (draw_scene), then at every draw the designs
        on the plane and its bands, the designs in the objective space, the table's rows (moving), and last the live
        layer (the band's focus, the crosshair, the objective space's ring)."""
        axes = self.prepare(figure, state)
        self.by_hand = state.free
        scene = self.scene_key(state)
        if self.scene != scene:
            self.draw_scene(figure, axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        self.draw_plane(axes["plane"], state, hovered)
        self.draw_bands(axes["plane"], state)
        self.draw_objectives(axes["space"], state)
        if "table" in axes:
            self.draw_table(axes["table"], state, hovered)
        self.live(state, hovered)

    def draw_scene(self, figure, axes: dict, state: ParetoState) -> None:
        """What stays while the pointer moves: the design space's frame and intervals, the objective space's frame (and
        the true front where it is shown), the table's frame, every title, legend and caption (the axes cleared first,
        unless they are new)."""
        if self.scene is not None:
            for ax in axes.values():
                ax.clear()
            for text in list(figure.texts):
                if text is not self.written:
                    text.remove()
            for legend in list(figure.legends):
                legend.remove()
        self.moving = []
        drawn = not state.empty
        marks = self.legend_marks(state)
        self.frame_plane(axes["plane"], state)
        titled(figure, self.heads, axes, "plane", get_text("lab.lhs.plane_title"), [
            Patch(facecolor=ONE, edgecolor=palette.CARD, label=get_text("lab.lhs.legend.one")),
            Patch(facecolor=MORE, edgecolor=palette.CARD, label=get_text("lab.lhs.legend.more")),
            Patch(facecolor="none", edgecolor=EMPTY, hatch="////", label=get_text("lab.lhs.legend.empty")), *marks] if drawn else [],
            section.note(self.function, state.section), "plane" in self.plan.noted, legend_most(self.plan, "plane"))
        space = axes["space"]
        objectives.frame(space, self.function)
        truth = self.truth_shown()
        if truth:
            objectives.truth(space, self.function)
        self.ring = objectives.Ring(space, self.function)
        titled(figure, self.heads, axes, "space", get_text("lab.pareto.doe.space_title"),
               [*self.legend_marks(state), *([objectives.handle("truth")] if truth else [])], most=legend_most(self.plan, "space"))
        if "table" in axes:
            frame_table(axes["table"])
            title = get_text("lab.pareto.doe.table_title")
            titled(figure, self.heads, axes, "table", title, [])
            if drawn:                                                 # what its numbers are: their units, never in headings
                subtitle(figure, self.heads, "table", get_text("lab.pareto.doe.table_caption"),
                         head_room(figure, self.heads, axes, "table"), title_drop(figure, self.heads, axes, "table", title))

    def legend_marks(self, state: ParetoState) -> list:
        """The legends' entries of the designs present: feasible, infeasible, non-dominated (none without a design)."""
        present = (("feasible", any(state.feasible)), ("infeasible", not all(state.feasible)), ("nondominated", bool(state.front)))
        return [] if state.empty else [objectives.handle(name) for name, shown in present if shown]

    def draw_plane(self, axes_, state: ParetoState, hovered) -> None:
        """In the design space: the free sampling's keyboard cursor (the parent's yellow ring and cross), the designs at
        their projections by their kind (objectives.designs_on_plane: feasible, infeasible, the non-dominated ringed,
        faded off the slice), and the white ring of the design pointed at (in either space). Moving artists."""
        moving = self.moving
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        if state.free and not state.full and state.cursor is not None:
            x, y = a1 + (b1 - a1) * state.cursor[0], a2 + (b2 - a2) * state.cursor[1]
            ring = marker_size((state.n or 0) + 1)
            moving.append(axes_.scatter([x], [y], s=ring, facecolors="none", edgecolors=palette.YELLOW, linewidths=1.3, zorder=7))
            moving.append(axes_.scatter([x], [y], s=ring * 2.2, marker="+", color=palette.YELLOW, linewidths=1.2, zorder=7))
        if state.empty:
            return
        area = marker_size(state.n)
        cut = state.section
        moving += objectives.designs_on_plane(axes_, self.function, cut, state.points, state.design.unit, state.rows, area)
        pointed = design_index(hovered)
        if pointed is not None and pointed < state.n:
            x, y = cut.project(state.points[pointed])
            grown = area if cut.plain else section.grown(area, cut.closeness(state.design.unit[pointed]))
            moving.append(axes_.scatter([x], [y], s=POINTED_RING * grown, facecolors="none", edgecolors=palette.WHITE,
                                        linewidths=1.4, zorder=8))

    def draw_objectives(self, ax, state: ParetoState) -> None:
        """In the objective space: every design at its objectives by its kind (beyond the window at its edge, counted)
        and the experiment's non-dominated designs ringed and joined by their staircase. Moving artists."""
        if state.empty:
            return
        self.moving += objectives.designs(ax, self.function, state.rows)
        self.moving += objectives.nondominated(ax, self.function, state.rows)

    def live(self, state: ParetoState, hovered) -> None:
        """The live layer: the band's design in focus, the crosshair of the place under the pointer (live.Pointing's)
        and the objective space's white ring on the design pointed at, all handed to the window's Layer."""
        if self.caption is not None:
            self.caption.show(self.focused(state, hovered), state.section.pair)
        crossed = self.crossing(state)
        ringed = []
        if self.ring is not None:
            pointed = design_index(hovered)
            ringed = self.ring.show(state.point(pointed) if pointed is not None and 0 <= pointed < len(state.rows) else None)
        if self.layer is not None:
            self.layer.hold([*(self.caption.drawn if self.caption is not None else ()), *crossed, *ringed])

    def draw_table(self, ax, state: ParetoState, hovered) -> None:
        """The designs as a table of values (module docstring): under the headings' line, the rows of the page that holds
        the design in focus, the row pointed at lit, a stress past its limit in the failed colour, the design's mark at
        the row's end, a quiet rule between the inputs and the responses, and, for a partial page, a last line saying
        which rows are shown. Nothing without a design. Moving artists, on the frame of frame_table."""
        if state.empty:
            return
        width, height = table_room(ax)
        n = len(state.rows)
        made = table_layout(self.function, width, height, n)
        focus = table_focus(state, hovered)
        first = (min(max(focus, 0), n - 1) // made.rows) * made.rows
        last = min(first + made.rows, n) - 1
        self.moving += self.table_body(ax, state, made, first, last, height, design_index(hovered), CARD_TONE)

    def table_body(self, ax, state: ParetoState, made, first: int, last: int, top: float, pointed, ground: str,
                   footed: bool = True) -> list:
        """The table of values from `top` down (layout pixels, y up), in the figure's third card (draw_table) or in the
        column's block (draw_designs) alike: the headings' line, the rows first..last (none for an empty sample: the
        headings alone), the row pointed at lit, else the compromise's under the pill, a stress past its limit in the
        failed colour, each row's mark on the tone it stands on (`ground`), a quiet rule between the inputs and the
        outputs and, for a partial page of the figure's table (`footed`; the block's has the window's scroll bar), a
        last line saying which rows. The rows whole device pixels apart (doe.row_places,
        as the parent's block and its hit_block read them): evenly spaced at any density. Returns the artists drawn."""
        moving = []
        n = len(state.rows)
        heading = HEADING | {"fontsize": made.font + TABLE_HEADING}
        figures = NUMBER | {"fontsize": made.font}
        band = max(made.row, TABLE_HEAD_LEAST)
        for x, name in zip(made.rights, made.headings):
            moving.append(ax.text(x, top - band / 2, name, ha="right", va="center", **heading))
        moving += ax.plot([made.left, made.right], [top - band, top - band], color=palette.DARK_GREY, linewidth=0.8)
        shown = last - first + 1
        if shown <= 0:
            return moving
        middle, pitch = row_places(SimpleNamespace(row=made.row, band=band), top, ax.figure.dpi)
        moving += ax.plot([made.rule, made.rule], [middle + pitch / 2 - shown * pitch, top - 2], color=palette.DARK_GREY, linewidth=0.6)
        for r in range(shown):
            i = first + r
            y = middle - r * pitch
            lit = i == pointed
            if lit or (pointed is None and i == state.compromise):
                moving.append(ax.add_patch(Rectangle((made.left, y - pitch / 2 + 1), made.right - made.left, pitch - 2,
                                                     facecolor=palette.PILL, edgecolor="none", zorder=1)))
            ink = LIT if lit else palette.WHITE
            texts = cells(self.function, state.points[i], state.rows[i], made.places)
            failed = {self.d + 1 + k for k in caption.failing(self.function, state.rows[i])}     # their columns
            for k, (x, text) in enumerate(zip(made.rights, (str(i + 1), *texts))):
                color = palette.GREY if k == 0 else palette.RED if k in failed else ink
                moving.append(ax.text(x, y, text, ha="right", va="center", color=color, zorder=2, **figures))
            moving += self.row_mark(ax, state, i, made.mark, y, ground)
        if shown < n and footed:
            moving.append(ax.text(made.left + 2, made.row / 2, get_text("lab.lhs.table_rows", first=first + 1, last=last + 1, n=n),
                                  ha="left", va="center", color=MUTED_INK, **SMALL))
        return moving

    def row_mark(self, ax, state: ParetoState, i: int, x: float, y: float, ground: str = CARD_TONE) -> list:
        """A row's mark, the plane's: the feasible blue disc (ringed in teal where non-dominated), or the infeasible
        hollow red ring, on the tone the table stands on."""
        if not state.feasible[i]:
            return objectives.mark(ax, objectives.INFEASIBLE, [x], [y], ground=ground, sizes=[MARK_AREA], zorder=3)
        drawn = objectives.mark(ax, objectives.FEASIBLE, [x], [y], ground=ground, sizes=[MARK_AREA], zorder=3)
        if i in state.front:
            drawn += objectives.mark(ax, objectives.NONDOMINATED, [x], [y], ground=ground, sizes=[2.6 * MARK_AREA], zorder=3)
        return drawn

    # ------------------------------------------------------------------ the blocks of the column (Lab.columned)
    def blocks(self, state, width: float) -> tuple[Block, ...]:
        """Where the window sets columned, two blocks: the card of the cross-beams (crossbeams.Column: the design or the
        place in focus, the cross-beam pointed at in the band), then the step's own, the table of the designs simulated
        with the four outputs of each (DESIGNS, the units of its columns in its note: lab.pareto.doe.table_caption, never
        in its headings), taking the column's room left, its heading alone while there is no design (doe.designs_block);
        () otherwise."""
        if not self.columned:
            return ()
        return (self.beams_block(width), designs_block(get_text("lab.pareto.doe.table_title"),
                                                       get_text("lab.pareto.doe.table_caption"), state))

    def draw_block(self, key: str, figure, state, hovered) -> bool:
        """The card of the cross-beams (draw_beams), or the parent's block of the designs (this lab's draw_designs)."""
        if key == crossbeams.KEY:
            return self.columned and self.draw_beams(figure, state, hovered)
        return super().draw_block(key, figure, state, hovered)

    def table_columns(self, state: ParetoState, coarse: bool = False) -> Columns:
        """The block's table as written (doe.SamplingLab's seam): the headings (i, the four inputs, m, δ, σ₁, σ₂: the
        figure's table's, headings_of), a row per design in the order of the designs, its index and its values as the
        figure's table writes them (cells, at places_of's decimals; `coarse`, the places and δ one fewer), and the widest
        text each column may hold (block_widest: the bounds, the objectives' window, a stress whole, and the values
        themselves); four outputs and no best design (two objectives: the compromise is the table's focus)."""
        places = places_of(self.function, coarse)
        rows = () if state.empty else tuple((str(i + 1), *cells(self.function, point, row, places))
                                            for i, (point, row) in enumerate(zip(state.points, state.rows)))
        return Columns(headings_of(self.function), rows, block_widest(self.function, places, rows), len(outputs.of(self.function)))

    def draw_designs(self, figure, state: ParetoState, hovered) -> bool:
        """The table of the designs in the block's own figure (the parent's axes, doe.SamplingLab.blocked: its layout
        pixels, BLOCK_TONE): laid out by block_table (the largest font and the most decimals whose columns fit the
        block's width), the rows from the first the window's scroll bar shows (the parent's in_sight: the design pointed at
        kept in sight, and for a new experiment the compromise, else a free sample's last point, else the first:
        table_focus), drawn by table_body as the figure's table is (the marks, the failed stresses in red, the row
        pointed at lit, the compromise's under the pill), nothing under them; the headings alone without a design. False
        when the rows on show, the design lit, the language and the figure are those drawn last."""
        ax = self.blocked(DESIGNS, figure)
        width, height = size(figure)
        top = height - BLOCK_TOP
        n = 0 if state.empty else len(state.rows)
        pointed = design_index(hovered)
        pointed = pointed if pointed is not None and 0 <= pointed < n else None
        made = block_table(self.function, [(self.table_columns(state, coarse), places_of(self.function, coarse))
                                           for coarse in (False, True)], width, top, n)
        made = rows_from(made, self.in_sight(DESIGNS, state.experiment, n, made.rows, pointed,
                                           table_focus(state, None) if n else None), n)
        shown = (self.block_keys[DESIGNS], state.experiment, n, state.compromise, pointed, made.first, made.last, made.font,
                 made.places, current_language())
        if self.block_shown.get(DESIGNS, (None,))[0] == shown:
            return False
        for artist in self.block_moving.get(DESIGNS, []):
            artist.remove()
        self.block_moving[DESIGNS] = self.table_body(ax, state, made, made.first, made.last, top, pointed, BLOCK_TONE,
                                                     footed=False)
        self.block_shown[DESIGNS] = (shown, made)
        return True

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def interval(bounds) -> str:
    """An input's bounds in the notation [a, b], the same in both languages: "[2, 5]"."""
    return f"[{short(bounds[0])}, {short(bounds[1])}]"

def table_focus(state: ParetoState, hovered) -> int:
    """The design the table's page follows: the one pointed at, else the compromise, else a free sample's last point,
    else the first."""
    pointed = design_index(hovered)
    if pointed is not None and 0 <= pointed < len(state.rows):
        return pointed
    if state.compromise is not None:
        return state.compromise
    return len(state.rows) - 1 if state.free else 0

def places_of(function: str, coarse: bool = False) -> tuple[int, ...]:
    """The decimals of each input in the table (the caption's: places to the centimetre, sizes whole; `coarse`, the
    places to the decimetre) and of each output (the objectives as the objective space writes them, coarse δ one fewer;
    the constraints None: caption.against's own)."""
    _, sizes = caption.layout(function)
    d = RESPONSES[function].d
    inputs = tuple(caption.SIZE_DECIMALS if k in sizes else caption.DECIMALS - (1 if coarse else 0) for k in range(d))
    decimals = dict(zip(outputs.objectives(function), objectives.window(function).decimals))
    found = tuple(max(decimals[k] - (1 if coarse else 0), 0) if k in decimals else None for k in range(len(outputs.of(function))))
    return inputs + found

def cells(function: str, point, row, places: tuple) -> tuple[str, ...]:
    """A design's values as the table writes them: its inputs and its outputs (a constraint by caption.against: whole,
    or with the decimals that keep it on its side of its limit)."""
    d = len(point)
    written = [number(float(x), places[k]) for k, x in enumerate(point)]
    for k, value in enumerate(row):
        limit = outputs.limit(function, k)
        written.append(caption.against(float(value), limit) if places[d + k] is None else number(float(value), places[d + k]))
    return tuple(written)

def widest(function: str, places: tuple) -> tuple[str, ...]:
    """The widest text each column of values may hold, every digit an 8: the inputs' bounds, the objectives' window
    (and the designs beyond it: two digits before the point for δ, whose design space reaches about 27 mm) and a stress of
    three digits with the two decimals near its limit."""
    response = RESPONSES[function]
    eights = str.maketrans("0123456789", "8888888888")
    d = response.d
    texts = [max((number(v, places[k]) for v in response.bounds[k]), key=len).translate(eights) for k in range(d)]
    shown = objectives.window(function)
    reach = dict(zip(outputs.objectives(function), (max(abs(v) for v in shown.across), max(abs(v) for v in shown.up))))
    for k in range(len(outputs.of(function))):
        if places[d + k] is None:
            texts.append(number(888.88, caption.LIMIT_DECIMALS))
        else:
            texts.append(number(max(reach[k], 10.0), places[d + k]).translate(eights))
    return tuple(texts)

@dataclass(frozen=True)
class TableLayout:
    """The table of values as laid out in a room (table_layout): its font and row (points, layout pixels), the rows a
    page holds, the right edge of each column (the index, the inputs, the outputs), the mark's centre, the rule between
    the inputs and the outputs, the block's left and right ends, the headings and the decimals of each column."""
    font: float
    row: float
    rows: int
    rights: tuple[float, ...]
    mark: float
    rule: float
    left: float
    right: float
    headings: tuple[str, ...]
    places: tuple

def page_rows(height: float, row: float, n: int, footed: bool = True) -> int:
    """The rows a page of the table holds in `height` layout pixels under its headings' line, rows `row` high: every
    design where they fit, else one row fewer than the room holds, its line kept for the words that say which rows
    (`footed`; the block's table, whose rows the window's scroll bar names, keeps none)."""
    room = height - max(row, TABLE_HEAD_LEAST)
    rows = int(room // row)
    return max(rows if rows >= n or not footed else int((room - row) // row), 1)

def headings_of(function: str) -> tuple[str, ...]:
    """The table's headings, symbols in mathematics: i, the inputs, the outputs (m, δ, σ₁, σ₂)."""
    return ("$i$", *(input_name(k) for k in range(RESPONSES[function].d)),
            *(objectives.math_symbol(function, k) for k in range(len(outputs.of(function)))))

def table_layout(function: str, width: float, height: float, n: int) -> TableLayout:
    """The table in a room `width` x `height` (layout pixels): the largest font of TABLE_SETS whose columns, each as
    wide as its widest value or its heading (panels.number_width, text_width), with TABLE_GAP_LEAST between them and
    the mark's column, fit the width and whose rows show TABLE_ROWS_LEAST rows (or every design); where none fits the
    width at the default decimals, the places and δ one decimal fewer (places_of's coarse). The room left is shared
    out between the columns up to TABLE_GAP, the block centred; a page keeps its last line for the words that say which
    rows (a partial page)."""
    names = headings_of(function)
    candidates = []                                               # the default decimals first, the largest font first
    for coarse in (False, True):
        places = places_of(function, coarse)
        texts = ("888", *widest(function, places))
        for font, row in TABLE_SETS:
            columns = [max(number_width(text, font), text_width(name, font + TABLE_HEADING)) for text, name in zip(texts, names)]
            fits = sum(columns) + TABLE_GAP_LEAST * len(columns) + TABLE_MARK <= width - 2 * TABLE_SIDE
            rows = page_rows(height, row, n)
            candidates.append((fits, rows >= min(n, TABLE_ROWS_LEAST), font, row, rows, columns, places))
    fitting = [found for found in candidates if found[0]]
    chosen = next((found for found in fitting if found[1]), fitting[0] if fitting else candidates[-1])
    _, _, font, row, rows, columns, places = chosen
    room = width - 2 * TABLE_SIDE - sum(columns) - TABLE_MARK
    gap = min(max(room / len(columns), TABLE_GAP_LEAST), TABLE_GAP)
    block = sum(columns) + gap * len(columns) + TABLE_MARK
    left = (width - block) / 2
    rights, x = [], left
    for column in columns:
        x += gap + column
        rights.append(x)
    d = RESPONSES[function].d
    rule = rights[d] + gap / 2                                     # between the last input and the first output
    return TableLayout(font, row, rows, tuple(rights), rights[-1] + gap / 2 + TABLE_MARK / 2, rule, left + gap / 2,
                       left + block, names, places)

# ------------------------------------------------------------------------------
# The table as the block of the column (ParetoSamplingLab.blocks, draw_designs), in layout pixels of its own figure
# ------------------------------------------------------------------------------
BLOCK_GAP_LEAST = 5.0                 # between two of the block's columns, at least: nine columns in 248 pixels, apart
BLOCK_GAP_TIGHT = 1.0                 # where even the coarse decimals at the least font leave less (DejaVu, wider): the
                                      # room there is, never less than this
BLOCK_MARK = 12.0                     # the column of the design's mark in the block

def block_widest(function: str, places: tuple, rows) -> tuple[str, ...]:
    """The widest text each column of the block's table may hold, every digit an 8: the index (doe.MOST designs), the
    inputs' bounds and the objectives' window at `places` (widest's), a stress of three digits WHOLE (a stress near its
    limit takes its decimals only where a design has one: caption.against), grown by the values of `rows` themselves,
    so that the columns hold still while the pointer moves and are as narrow as the experiment allows."""
    eights = str.maketrans("0123456789", "8888888888")
    d = RESPONSES[function].d
    found = [str(MOST).translate(eights), *widest(function, places)]
    for k in range(len(outputs.of(function))):
        if places[d + k] is None:
            found[1 + d + k] = "888"
    for row in rows:
        found = [max(wide, cell.translate(eights), key=len) for wide, cell in zip(found, row)]
    return tuple(found)

@dataclass(frozen=True)
class BlockTable:
    """The block's table laid out (block_table), with the names the parent's hit_block reads (first, last, band, row,
    left, right: doe.DesignsLayout's) and those table_body draws with (font, rights, mark, rule, headings, places)."""
    first: int
    last: int
    partial: bool
    row: float
    band: float
    font: float
    rights: tuple[float, ...]
    left: float
    right: float
    mark: float
    rule: float
    headings: tuple[str, ...]
    places: tuple
    rows: int = 1                     # the rows its room holds, and the designs it has (count: more than rows, the
    count: int = 0                    # window's scroll bar moves first; doe.Scroll, rows_from)

def block_table(function: str, candidates: list, width: float, height: float, n: int) -> BlockTable:
    """The block's table in a room `width` x `height` (layout pixels, the height under the block's top): of the
    `candidates` ((columns, places): table_columns at the default decimals, then coarse) and of the fonts of TABLE_SETS,
    the first whose columns (each as wide as its widest text or its heading: panels.number_width, text_width), with
    BLOCK_GAP_LEAST between them and the mark's column, fit the width less doe.DESIGNS_SIDE a side (else the last:
    coarse, the least font, its columns as close as the width needs, BLOCK_GAP_TIGHT at least); the room left shared
    out between the columns up to TABLE_GAP, the table centred; the rows its room holds (page_rows, no last line kept:
    the window's scroll bar names them), from the first (doe.rows_from moves them)."""
    room = width - 2 * DESIGNS_SIDE

    def measured(columns, font) -> list[float]:
        return [max(number_width(text, font), text_width(name, font + TABLE_HEADING)) for text, name in zip(columns.widest, columns.heads)]
    options = [(columns, places, font, row) for columns, places in candidates for font, row in TABLE_SETS]
    columns, places, font, row = next((option for option in options if sum(measured(option[0], option[2]))
                                       + BLOCK_GAP_LEAST * len(option[0].heads) + BLOCK_MARK <= room), options[-1])
    widths = measured(columns, font)
    free = (room - sum(widths) - BLOCK_MARK) / len(widths)                # the room left, a column's share
    gap = min(max(free, BLOCK_GAP_LEAST if free >= BLOCK_GAP_LEAST else BLOCK_GAP_TIGHT), TABLE_GAP)
    block = sum(widths) + gap * len(widths) + BLOCK_MARK
    left = (width - block) / 2
    rights, x = [], left
    for wide in widths:
        x += gap + wide
        rights.append(x)
    rows = page_rows(height, row, max(n, 1), footed=False)
    d = RESPONSES[function].d
    return BlockTable(0, min(rows, n) - 1 if n else -1, n > rows, row, max(row, TABLE_HEAD_LEAST), font, tuple(rights),
                      left + gap / 2, left + block, rights[-1] + gap / 2 + BLOCK_MARK / 2, rights[d] + gap / 2, columns.heads, places,
                      rows, n)
