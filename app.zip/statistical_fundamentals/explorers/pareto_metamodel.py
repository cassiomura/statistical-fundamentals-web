# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                       Title: pareto_metamodel.py
# ==============================================================================
"""
Step 2 of a bench of SEVERAL responses (functions.Response.outputs: beam_pareto, the beam whose two cross-beams are
placed and sized; its mass m and RMS deflection δ the two objectives, the stresses σ₁ and σ₂ of the cross-beams the
constraints, σ <= 120 MPa), the metamodel: ONE METAMODEL PER RESPONSE. One simulation gave every response at each
design of step 1 (doe.Simulated.outputs), and each response gets its own metamodel, judged by its own CoP, as optiSLang's
MOP does: the mass is exactly linear in the sizes (the linear polynomial reproduces it, CoP 1), the deflection and the
stresses need more. The laboratory is explorers/metamodel.py's MetamodelLab per response (the models, the bases, D and
theta, the Best commands, the query point, the weights, the check, the frames, what a student is not offered stay its
code), with what differs here:

- THE RESPONSE ON SCREEN (outputs.control, key outputs.RESPONSE): the first control of the column (after the featured
  command). The controls under it (model, basis, D or theta) and the Best commands are that response's, the figure's
  plane and third card are drawn for it, and EACH RESPONSE KEEPS ITS OWN choice in the settings (METAMODELS: per output,
  the values of the controls CHOICE), so that it survives a snapshot, Restore's rules, a language and a mode as every
  setting does. Choosing another response changes nothing of the study: the controls show that response's choice, and
  nothing is discarded. The lab opens on the DEFLECTION (first_shown: the second objective, the response the study is
  about; the mass, exactly linear, needs no calibration).
- THE OPENING. A teacher's step (its first settings, Restore, an experiment received, the end of "Optimal prognosis")
  puts the winner of the competition of EVERY response on screen at once (crown: explorers/prognoses.py runs the four
  competitions together, the moving least squares' weights shared: about four seconds at the teacher's N = 70, the
  window's wait cursor); a response none of whose candidates can be computed keeps its choice. A student's opens on the
  linear polynomial for every response (already exact for the mass) and calibrates each by hand, reading its CoP: no
  optimal prognosis, no Best command, no coefficient against the true response until the bench is won (the parent's
  rules, per response). Every number of the moving least squares (the competition, Best D, the CoP on screen, the
  check's predictions) comes from prognoses.py, the models themselves from metamodel.fit, which step 3 evaluates.
- THE HAND-OFF (output): Surrogates(experiment, candidates), step 1's experiment (its output 0) and one Candidate per
  output in the outputs' order; None while ANY response's metamodel cannot be computed (missing says which, in one
  sentence). A change of any response's choice changes what is handed, and step 3 is discarded by ==. No least CoP is
  asked (the owner's rule 7B). Surrogates gives step 3 each response's experiment (experiment_of), its
  metamodel.Surrogate (surrogate), its fit (fit) and the four predictions at a point of the unit hypercube (predict),
  from which outputs.feasible, objective_values and violation read the predicted design.

The figure is the parent's arrangement with the beam's band (the plan the three steps of the bench share: the same
`notes`, explorers/pareto_doe.heading), the 3D view's card holding the OBJECTIVE SPACE (explorers/objectives.py) in its place:
- THE PLANE (the design space, a slice of four inputs: explorers/section.py): for the response on screen, as the parent
  draws it, y^'s faint level lines on the slice, the weights a_i(u) of each design at the query point and the query
  point itself (four coordinates, its held ones the slice's); the designs by their kind (feasible blue, infeasible
  hollow red: objectives.projections) under the weights, named in the legend after the rest where its rows hold them;
  when the response on screen is a CONSTRAINT, its predicted LIMIT on the slice, y^ = 120 MPa, a red line, the side past
  it lightly cross-hatched (objectives.limits on the slice drawn, the same grid as the level lines), named in the legend
  ("σ̂₁ > 120").
- THE FIRST CARD (the objective space, objectives.box: the same box in the three steps): the experiment's designs at
  their simulated objectives, feasible and infeasible, its non-dominated ones ringed and joined; the QUERY POINT'S
  PREDICTION (m^, δ^) by the metamodels of the two OBJECTIVES whatever response is on screen, the yellow diamond with its
  two values, moving with the query point (none while either cannot be computed there); the TRUE front only where the
  true response is shown (Lab.truth_shown, the owner's 2B: a simulation's once the reader asked to see it, Lab.revealed,
  a teacher's "Show f", a student's once the bench is won), as the coefficient against the true response (the parent's
  against_shown: where it is shown, to a teacher, to a student once won); no 3D view on this bench. Its head and the
  step's measures stand beside it under the band.
- THE THIRD CARD: the parent's coefficient of prognosis of the response on screen, the CoP the hero with its gauges
  (the CoD at the designs; the CoD against the true response where it is shown), the check of the designs predicted
  without them; for a constraint the check carries the limit as two thin red lines, σ simulated = 120 and σ^ = 120 (a
  design in the upper left or lower right quadrant is one the metamodel misjudges), named in its legend; or the
  competition's ranking of that response while it plays. The check is composed for the legend of three entries in
  every response, so that its square never moves when the response changes (composition).
- IN THE WINDOW'S COLUMN (Lab.columned, the owner's design of 2026-11-21; the web never sets it): the plan without its
  third panel (planned's third=False, also the parent's seam arranged: the objective space the right column's ONE card,
  larger; no check, hero or competition in the figure, boxes) and the column's one block (blocks; the card of the
  cross-beams is step 1's alone, explorers/crossbeams.py), the parent's block "prognosis" (metamodel's, taking the
  column's room left: the check of the response on screen with a constraint's limit lines but no legend, or its
  competition) under a LINE OF THE FOUR CoPs (draw_cops, COPS_TALL at the block's top, in every case: each response's
  symbol and CoP, the one on screen lit on the pill, as the strip's Metric.lit; the warning's mark at or below 0). That
  line stands for the parent's line of the number: under it the parent's slim scale from 0 to 1 filled to the lit CoP
  (the owner's 1C: metamodel.scale, SCALE_ALONE high, draw_block_hero), then the check in its well (block_composition,
  row SCALE_ALONE), no number repeated over the check, the four responses read alike and the lit one is the check's
  and the scale's. The block takes the room left up to its natural height (the card ends where its content ends), at
  least BLOCK_CHECK's square under those lines (blocks): on this bench the column holds more controls and cards, so its
  least check is smaller than the parent's. The objective space's head holds one row of legend (the plan's, the 3D
  card's of the other benches: panels.alone_card), no readout under it (arranged with readout=False). Drawn again
  when the response on screen or any CoP changes (draw_block). The least CoP stays the summary's (the cover's track).
- THE MEASURES (metrics; beside the objective space under the band, else the strip): the CoP of EACH response with its
  model under it ("CoP of δ  0.998  Kriging · θ = 0.34"), the chain of qualities a study through metamodels rests on;
  the one on screen is LIT (Metric.lit: the window draws it on the chosen option's tone with an accent edge), the four
  values of one size (none is the step's alone: each response is judged by its own).
- THE CARD "Received from step 1": the parent's rows in the order of every bench (the sampling, N, the largest
  correlation with its pair), then the feasible designs ("39 of 70").
- THE FEATURED COMMAND's second line (a teacher's "Optimal prognosis"): the parent's, the winner of the response on
  screen and its CoP, with no "winner:" where another model is on screen (winner_text: "CoP 0.998 · Kriging · θ = 0.34",
  the CoP first, so that a cut at the column's edge never hides it; the check mark says when it is the one on screen).
- summary (the cover's track, the pill's tooltip): the LEAST CoP among the responses rounded DOWN (floored: "CoP ≥
  0.990" for 0.99081, so that "≥" is true), a warning by the parent's rule (at or below 0, or one that cannot be computed).
- The automatic slice passes through the experiment's COMPROMISE design (outputs.compromise: among its feasible
  non-dominated designs the one nearest the ideal point; the middle without one), as step 1's on this bench; the beam's
  band draws the design under the pointer in either space (the objective space by objectives.hit), else the compromise
  design, never the query point (a prediction is never drawn on the beam); the place under the pointer over the plane
  as on benches 2 and 3.

The cost: the first entry of a teacher computes the four competitions (prognoses.competition, cached); everything after
(another response on screen, a control, a drag of the query point) is the parent's: a slice of the quadratic moving
least squares costs seconds, so the view's sliders are read on release (gui/lab_views). Nothing here reads the bench's
single-response helpers (game.spread, doe.extent, doe.window, doe.through, metamodel.truth): the objective space has its
own window (objectives.window), the level lines their own grid (plane_mesh).
"""
import math
from dataclasses import dataclass, fields, replace

import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Patch

from statistical_fundamentals import palette
from statistical_fundamentals.explorers import caption, objectives, outputs, panels, pareto_doe, prognoses, section
from statistical_fundamentals.explorers.doe import Experiment, simulated
from statistical_fundamentals.explorers.game import TEACHER
from statistical_fundamentals.explorers.lab import Block, Metric, size
from statistical_fundamentals.explorers.live import designed
from statistical_fundamentals.explorers.metamodel import (AXIS, BLOCK_FOOT, DASH, MARK, NEGATIVE, POINT, PROGNOSIS, QUERY,
                                                          RANK_BELOW, RANK_SIDE, REFUSED, SCALE_ALONE, SCALE_HIGH, TRUE, WARNING,
                                                          Candidate, Fit, pixel_axes, scale,
                                                          MetamodelLab, MetamodelState, Surrogate, block_composed, block_height,
                                                          candidate_of, chosen, composed, fit, named, poor, quality, surface_of)
from statistical_fundamentals.explorers.panels import HEAD, TAG, arrangement, draw_cards, head, legend_at, places
from statistical_fundamentals.i18n import get_text

CHOICE = ("model", "order", "radius", "theta")    # the controls that choose a response's metamodel
METAMODELS = "metamodels"                         # the settings key: per output, the values of CHOICE (each response's own)
LIMIT_INK = palette.RED                           # a constraint's limit: what is wrong past it
LIMIT_WIDTH, LIMIT_ALPHA = 0.9, 0.85              # the check's two lines of the limit: thin
COPS_TALL = 22.0                                  # layout pixels: the block's line of the four CoPs, over the parent's block
BLOCK_CHECK = 90.0                                # layout pixels: the block's least check (the parent's is larger): the
                                                  # column of 1536 x 864 holds it with no scroll in the teacher's steps

@dataclass(frozen=True)
class Surrogates:
    """Step 2's result on a bench of several responses, handed to the optimization: step 1's experiment (its output 0)
    and the metamodel of every output (a Candidate each, in the outputs' order), each fitted to the designs of the
    experiment of its own output. Everything else is computed from them (metamodel.fit, cached), so two are the same
    when equal."""
    experiment: Experiment
    candidates: tuple[Candidate, ...]

    def experiment_of(self, k: int) -> Experiment:
        """The experiment of output k: the same designs, the values of the k-th response."""
        return prognoses.of(self.experiment, k)

    def surrogate(self, k: int) -> Surrogate:
        """Output k's metamodel as step 2 of a bench of one response hands it (metamodel.Surrogate)."""
        return Surrogate(self.experiment_of(k), self.candidates[k])

    def fit(self, k: int) -> Fit | None:
        """Output k's metamodel fitted (metamodel.fit, cached: the cores' own model); None where it cannot be computed."""
        return fit(self.candidates[k], self.experiment_of(k))

    def predict(self, u) -> tuple[float, ...] | None:
        """The prediction of every output at u, a point of the unit hypercube (d coordinates), in the outputs' order: the
        row a simulation would give, from the metamodels (outputs.feasible and objective_values read it); None where a
        metamodel cannot be computed, refuses at u (metamodel.REFUSED) or gives a value that is not finite (step 3's
        run on the metamodels then cannot be computed: pareto_optimization.outcome)."""
        point = tuple(float(v) for v in u)
        try:
            row = tuple(float(self.fit(k).model(point)) for k in range(len(self.candidates)))
        except (AttributeError, *REFUSED):                            # no metamodel (fit None), or refused at u
            return None
        return row if all(math.isfinite(v) for v in row) else None

@dataclass(frozen=True)
class ParetoMetamodelState(MetamodelState):
    """MetamodelState of the response on screen (its experiment, candidate, fit, check, query point, weights), with
    every response's: the index on screen, each output's candidate, whether its metamodel can be computed (fitted) and
    its cross-validation (checks), the experiment's simulated rows (outputs.rows) and the query point's prediction of the
    two objectives (query: None where either cannot be computed there)."""
    shown: int = 0
    candidates: tuple[Candidate, ...] = ()
    fitted: tuple[bool, ...] = ()
    checks: tuple = ()
    rows: tuple[tuple[float, ...], ...] = ()
    query: tuple[float, float] | None = None

class ParetoMetamodelLab(MetamodelLab):
    """One metamodel per response of one simulation, each calibrated by its CoP: the weight of each design at a point,
    the experiment and the query point's prediction in the objective space, and what the response on screen's metamodel
    is worth; the four are handed to the optimization together."""
    winner_text = "lab.pareto.mm.contest.winner"     # another model on screen: the winner and its CoP, no "winner:" (the
                                                     # check mark says which one is on screen; the line fits the column)

    def __init__(self, function: str = "beam_pareto", mode: str = TEACHER):
        super().__init__(function, mode)
        viewed = len(section.controls(function))
        response = replace(outputs.control(function), initial=first_shown(function))
        self.controls = self.controls[:viewed] + (response,) + self.controls[viewed:]
        first = tuple(control.values[control.initial] for control in self.controls if control.key in CHOICE)
        self.data = self.data | {METAMODELS: (first,) * len(outputs.of(function))}
        handing = next(action for action in self.actions if action.key == "advance")
        own = {section.CHIP: section.chip("compromise"),                          # the bench's chip, and the hand-off's
               "advance": replace(handing, tip=get_text("lab.pareto.mm.advance_tip"))}     # tip: four metamodels, NSGA-II
        self.actions = tuple(own.get(action.key, action) for action in self.actions)
        self.ring = None                      # the design pointed at in the objective space (objectives.Ring, per scene)

    # ------------------------------------------------------------------ what the parent reaches through its hooks
    def fitted_to(self, settings: dict) -> Experiment:
        """The experiment of the response on screen (the one received is its output 0)."""
        return prognoses.of(settings["experiment"], shown_of(settings, self.function))

    def validation_of(self, candidate: Candidate, experiment: Experiment):
        return prognoses.validation(candidate, experiment)

    def entry_of(self, k: int, experiment: Experiment):
        return prognoses.entry(k, experiment)

    def champion_of(self, experiment: Experiment):
        return prognoses.champion(experiment)

    def best_radius_of(self, order: str, experiment: Experiment) -> float | None:
        return prognoses.best_radius(order, experiment)

    def crown(self, settings: dict) -> dict:
        """The winner of every response's competition chosen for it (prognoses: the four run together), the response on
        screen's in the controls; a response none of whose candidates can be computed keeps its choice."""
        experiment, made = settings["experiment"], list(choices_of(settings, self.function))
        for k in range(len(made)):
            best = prognoses.champion(prognoses.of(experiment, k))
            if best is not None:
                made[k] = tuple((dict(zip(CHOICE, made[k])) | chosen(best.candidate))[key] for key in CHOICE)
        return showing_choice(settings | {METAMODELS: tuple(made)}, self.function)

    def composition(self, plan):
        """The third card measured with the check's legend of three entries (a constraint's, its limit with them) for
        every response, so that the check's square stays where it is when the response on screen changes."""
        constraint = outputs.constraints(self.function)[0]
        return composed(plan, lambda: check_handles(self.function, constraint), legend_rows(plan))

    def plane_mesh(self, state: MetamodelState) -> tuple[np.ndarray, np.ndarray]:
        """The grid of the slice in the pair's bounds (the metamodels' surfaces are computed on it: Section.grid), made
        here from the bounds rather than from a true response's slice (metamodel.truth reads a bench's own window)."""
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, state.section)
        axis = np.array(AXIS)
        return tuple(np.meshgrid(a1 + (b1 - a1) * axis, a2 + (b2 - a2) * axis))

    # ------------------------------------------------------------------ the settings
    def adjust(self, settings: dict, key: str, old) -> dict:
        """Another response on screen: its own choice in the controls, nothing else (the study does not change: the
        competition shown stays, now that response's). Any other control: the parent's, then the choice kept as the
        response on screen's."""
        if key == outputs.RESPONSE:
            return self.viewed(showing_choice(settings, self.function))
        return kept(super().adjust(settings, key, old), self.function)

    def act(self, key: str, state, settings: dict) -> dict:
        """The parent's commands (Best for the response on screen), the choice kept as its own."""
        return kept(super().act(key, state, settings), self.function)

    def automatic(self, settings: dict) -> tuple[float, ...] | None:
        """The slice of four inputs passes, while no slider pinned it, through the COMPROMISE design of the experiment
        received (outputs.compromise: its feasible non-dominated design nearest the ideal point), as step 1's on this
        bench; the middle of the ranges without one (None)."""
        if settings.get("experiment") is None:
            return None
        experiment = prognoses.base(settings["experiment"])
        found = pareto_doe.outcomes(experiment).compromise
        return None if found is None else simulated(experiment).unit[found]

    def naming(self, key: str, state) -> str:
        """The chip of the slice (step 1's on this bench: section.chip("compromise"), the compromise design) named "Slice
        at the middle" where the slice returns there (no feasible design); the parent's for the rest."""
        if key == section.CHIP:
            return get_text("lab.view.slice.middle") if self.middle(state) else ""
        return super().naming(key, state)

    def tip_of(self, key: str, state) -> str:
        if key == section.CHIP:
            return get_text("lab.view.slice.middle_tip") if self.middle(state) else ""
        return super().tip_of(key, state)

    def middle(self, state) -> bool:
        """The automatic slice stands at the middle of the ranges: the experiment has no feasible design."""
        return pareto_doe.outcomes(prognoses.base(state.experiment)).compromise is None

    # ------------------------------------------------------------------ the state
    def state(self, settings: dict) -> ParetoMetamodelState:
        """The parent's state of the response on screen, with every response's candidate, whether it can be computed and
        its cross-validation, the experiment's rows and the query point's prediction of the two objectives; never
        raises."""
        found = super().state(settings)
        k = found.experiment.output
        experiment = prognoses.base(found.experiment)
        made = choices_of(settings, self.function)
        candidates = tuple(found.candidate if j == k else candidate_of(dict(zip(CHOICE, made[j]))) for j in range(len(made)))
        fits = tuple(found.fit if j == k else fit(candidates[j], prognoses.of(experiment, j)) for j in range(len(made)))
        checks = tuple(found.check if j == k else (prognoses.validation(candidates[j], prognoses.of(experiment, j))
                                                   if fits[j] is not None else None) for j in range(len(made)))
        rows = pareto_doe.outcomes(experiment).rows                   # step 1's (cached): rows, front, compromise
        query = None
        try:
            values = tuple(float(fits[j].model(found.probe)) for j in outputs.objectives(self.function))
            query = values if all(math.isfinite(v) for v in values) else None
        except (AttributeError, *REFUSED):                            # an objective without a metamodel, or refused there
            query = None
        base = {item.name: getattr(found, item.name) for item in fields(MetamodelState)}
        return ParetoMetamodelState(**base, shown=k, candidates=candidates, fitted=tuple(f is not None for f in fits),
                                    checks=checks, rows=rows, query=query)

    # ------------------------------------------------------------------ a step of the study
    def output(self, state: ParetoMetamodelState) -> Surrogates | None:
        """Every response's metamodel, for the optimization; None while any of them cannot be computed."""
        if not all(state.fitted):
            return None
        return Surrogates(prognoses.base(state.experiment), state.candidates)

    def missing(self, state: ParetoMetamodelState) -> str:
        """Which response's metamodel cannot be computed, in one sentence (the first of them)."""
        k = next((j for j, ok in enumerate(state.fitted) if not ok), None)
        return "" if k is None else get_text("lab.pareto.mm.missing", symbol=outputs.symbol(self.function, k))

    def enabled(self, key: str, state) -> bool:
        """The optimization can be reached only when every response's metamodel can be computed."""
        return self.output(state) is not None if key == "advance" else True

    def received(self, state: ParetoMetamodelState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """The parent's rows in the order of every bench (the sampling, N, the largest correlation with its pair), then
        this bench's own: the feasible designs ("39 of 70")."""
        heading_, rows = super().received(state)
        feasible = sum(outputs.feasible(self.function, row) for row in state.rows)
        said = get_text("lab.pareto.mm.received.feasible_value", feasible=feasible, n=state.n)
        return heading_, (*rows, (get_text("lab.pareto.mm.received.feasible"), said, "plain"))

    def summary(self, state: ParetoMetamodelState) -> tuple[str, str]:
        """The least CoP among the responses rounded DOWN to the decimals it is written with ("CoP ≥ 0.990" for 0.99081:
        floored, so that "≥" holds), a warning by the parent's rule on it (at or below 0), and a dash, a warning, while one
        cannot be computed."""
        cops = [None if check is None else check.cop for check in state.checks]
        if not cops or None in cops:
            return get_text("lab.pareto.mm.summary", cop=DASH), "warning"
        least = min(cops)
        return get_text("lab.pareto.mm.summary", cop=quality(floored(least))), "warning" if poor(least) else "plain"

    # ------------------------------------------------------------------ what to read
    def metrics(self, state: ParetoMetamodelState) -> list[Metric]:
        """The CoP of every response, its model under it: the chain of qualities a study through metamodels rests on;
        the response on screen's the lit one (Metric.lit). A dash where one cannot be computed, the warning's
        mark at or below 0. No coefficient against the true response here (the hero says it where it is shown)."""
        measures = []
        for k, (candidate, check) in enumerate(zip(state.candidates, state.checks)):
            symbol = outputs.symbol(self.function, k)
            value = DASH if check is None else (f"{MARK} {quality(check.cop)}" if poor(check.cop) else quality(check.cop))
            measures.append(Metric(get_text("lab.pareto.mm.m.cop", symbol=symbol), value,
                                   kind="warning" if check is None or poor(check.cop) else "plain",
                                   tip=get_text("lab.pareto.mm.m.cop_tip", symbol=symbol), detail=named(candidate),
                                   lit=k == state.shown))
        return measures

    def references(self, state: MetamodelState) -> list[tuple[str, float | None, str]]:
        """The hero's references, named for the response on screen: the CoD at the designs, and against the true
        response where it is shown."""
        rows = super().references(state)
        if len(rows) > 1:
            symbol = outputs.symbol(self.function, state.experiment.output)
            rows[1] = (get_text("lab.pareto.mm.hero.true", symbol=symbol), *rows[1][1:])
        return rows

    # ------------------------------------------------------------------ the pointer and the drawing's focus
    def hit(self, figure, state: ParetoMetamodelState, event):
        """The parent's (the query point, a design of the plane or of the check), or a design in the objective space."""
        space = self.axes.get("space")
        if space is not None and event is not None and event.inaxes is space and space.get_visible():
            return objectives.hit(space, self.function, objectives.points_of(self.function, state.rows), event)
        return super().hit(figure, state, event)

    def focused(self, state: ParetoMetamodelState, hovered):
        """The beam's focus: the design under the pointer in either space, else the place under the pointer, else the
        experiment's compromise design; never the query point (a prediction)."""
        n = len(state.rows)
        if designed(hovered) and 0 <= hovered < n:
            return self.simulated_focus(state, hovered)
        if self.pointer is not None:
            return caption.under(self.pointer)
        found = pareto_doe.outcomes(prognoses.base(state.experiment)).compromise
        return None if found is None else self.simulated_focus(state, found)

    def simulated_focus(self, state: ParetoMetamodelState, k: int):
        """Design k of the experiment as the beam draws it: its simulated row, its number, and "non-dominated" where no
        other design dominates it."""
        tag = "nondominated" if k in pareto_doe.outcomes(prognoses.base(state.experiment)).front else ""
        return caption.simulated("design", state.data.points[k], state.rows[k], k + 1, len(state.rows), tag)

    # ------------------------------------------------------------------ the figure
    def planned(self, width: float, height: float | None):
        """The plan the bench's three steps share: the beam's band where it has its room, the plane's note reserved
        alike: pareto_doe.heading, the notes of the bench's three steps (never section.heading here, which would note
        the objective space's head too and move its box). The parent's own seam for step 1 is doe.SamplingLab.arranged."""
        return arrangement(width, height, pair="space", drawing=self.drawing, notes=pareto_doe.heading(self.function),
                           hero=self.hero, third=not self.columned, readout=False)

    def arranged(self, width: float, height: float | None):
        """The parent's seam for its plan is this bench's (planned)."""
        return self.planned(width, height)

    def boxes(self, figure) -> dict:
        """The parent's boxes from the bench's plan, the first card's the objective space's frame (objectives.box) where
        the 3D view stands on the benches of one response; where the step's own panel stands in the column
        (Lab.columned), the design space and the objective space alone (the check, the hero and the competition are the
        block's)."""
        width, height = size(figure)
        plan = self.planned(width, height)

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)
        framed = objectives.box(plan, self.function)
        space = frac(*(framed or (0.0, 0.0, 1.0, 1.0)))
        if self.columned:
            return {"plane": frac(*plan.plane), "space": space, "heads": places(plan, width, height)}
        boxes = {"plane": frac(*plan.plane), "space": space, "ranking": frac(*plan.ranking)}
        third = self.composition(plan)
        if third is not None:
            boxes["check"], boxes["hero"] = frac(*third.check), frac(*third.hero)
        boxes["heads"] = places(plan, width, height)
        return boxes

    def prepare(self, figure, state: ParetoMetamodelState) -> dict:
        """The axes of the figure, made again when the layout changes (a 2D objective space where the parent has its 3D
        view), reused otherwise."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height), state.language, self.columned)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = self.planned(width, height)
            self.cards = draw_cards(figure, self.plan)
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "space", "check", "hero", "ranking")
                         if name in boxes}
            self.ranking_box = boxes.get("ranking")
            self.axes["plane"].set_zorder(1)
            self.heads = boxes["heads"]
            self.caption = caption.Caption(figure, self.plan, self.heads, self.function, state.section.pair, geometric=self.columned)
            self.written = self.caption.written
            self.layout_key = key
            self.scene = None
            self.moving = []
        return self.axes

    def draw(self, figure, state: ParetoMetamodelState, hovered) -> None:
        axes = self.prepare(figure, state)
        scene = (state.scene, self.truth_shown())
        if self.scene != scene:
            self.draw_scene(figure, axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        if axes["plane"].get_visible():
            self.draw_voices(axes["plane"], state, hovered)
        self.draw_objectives(axes["space"], state, hovered)
        if "check" in axes and axes["check"].get_visible():
            self.draw_found(axes["check"], state, hovered)
        self.live(state, hovered)

    def draw_scene(self, figure, axes: dict, state: ParetoMetamodelState) -> None:
        """Everything that stays while the query point moves: the plane of the response on screen (its level lines, its
        limit), the objective space and the experiment in it, the check and the hero or the competition, the heads."""
        for ax in axes.values():
            ax.clear()
        for text in list(figure.texts):
            if text is not self.written:
                text.remove()
        for legend in list(figure.legends):
            legend.remove()
        self.moving = []
        k, function = state.shown, self.function
        constraint = outputs.limit(function, k) is not None
        contest = bool(state.ranking) and not self.columned           # in the column, the competition is the block's
        third = self.composition(self.plan)
        alone = third is not None and third.alone
        shown = {"plane": not (contest and "check" not in axes), "space": True, "check": not contest and not alone,
                 "hero": not contest, "ranking": contest}
        for name, ax in axes.items():
            ax.set_visible(shown[name])
        symbol = objectives.math_symbol(function, k, hat=True)
        surface = surface_of(state)
        if shown["plane"]:
            self.draw_plane(axes["plane"], state, surface)
            most = panels.legend_most(self.plan, "plane")

            def handles_of(kinds: bool) -> list:
                made = [panels.dot(POINT, get_text("lab.mm.legend.positive"), soft=True),
                        panels.dot(NEGATIVE, get_text("lab.mm.legend.negative"), hollow=True),
                        panels.dot(QUERY, get_text("lab.mm.legend.probe"), marker="D", size=6.5)]
                if surface is not None and constraint:
                    made.append(limit_handle(function, k))
                elif surface is not None and panels.level_values(surface):  # none on a flat slice (the mass on the places)
                    made.append(Line2D([], [], color=panels.LINES["colors"], linewidth=1.0, alpha=0.8,
                                       label=get_text("lab.pareto.mm.legend.levels", symbol=symbol)))
                looks = objectives.kinds(function, state.rows) if kinds else ()
                return made + [objectives.handle(name) for name, look in (("feasible", objectives.FEASIBLE),
                                                                         ("infeasible", objectives.INFEASIBLE)) if look in looks]
            handles = handles_of(self.plan.band is not None and held_whole(figure, self.heads, self.axes, handles_of(True), most))
            head(figure, self.heads, self.axes, "plane", plane_title(function, k), handles,
                 section.note(function, state.section), "plane" in self.plan.noted, most)
        self.draw_space(axes["space"], state, None)
        handles = [objectives.handle("feasible"), objectives.handle("infeasible"), objectives.handle("query")]
        if self.truth_shown():
            handles.append(objectives.handle("truth"))
        handles.append(objectives.handle("nondominated"))
        head(figure, self.heads, self.axes, "space", get_text("lab.pareto.mm.space_title"), handles,
             most=panels.legend_most(self.plan, "space"))
        plain = outputs.symbol(function, k)                           # plain: its subscript never reaches the line under
        if contest:
            rows = head(figure, self.heads, self.axes, "ranking", get_text("lab.pareto.mm.ranking_title", symbol=plain), [
                Patch(facecolor=POINT, label=get_text("lab.mm.legend.cop")),
                Patch(facecolor=palette.TEAL, label=get_text("lab.mm.legend.largest"))])
            self.draw_ranking(axes["ranking"], state, rows)
        elif "check" in axes:
            if not alone:
                self.draw_check(axes["check"], state)
            self.draw_hero(axes["hero"], state)
            head(figure, self.heads, self.axes, "check", get_text("lab.pareto.mm.check_title", symbol=plain), [])
            if third is not None and third.legend is not None and state.check is not None and not alone:
                x, top, room = third.legend
                width, height = size(figure)
                legend_at(figure, x / width, top / height, room, check_handles(function, k if constraint else None),
                          legend_rows(self.plan))

    def plane_designs(self, ax, state: ParetoMetamodelState, area: float) -> None:
        """Every design on the plane by its kind (objectives: feasible blue discs, infeasible hollow red rings), at its
        projection with the fade of four inputs, under the weights' discs."""
        cut, points, unit = state.section, state.data.points, state.data.unit
        looks = objectives.kinds(self.function, state.rows)
        for look in (objectives.FEASIBLE, objectives.INFEASIBLE):
            chosen_ = [j for j, kind in enumerate(looks) if kind is look]
            if look is objectives.INFEASIBLE:                        # a ring as wide as the dot it stands for
                look = replace(look, width=0.9)
            objectives.projections(ax, look, cut, [points[j] for j in chosen_], [unit[j] for j in chosen_], area, zorder=6)

    def draw_plane(self, ax, state: ParetoMetamodelState, surface) -> None:
        """The parent's plane (the designs, y^'s level lines on the slice) and, for a constraint on screen, its predicted
        limit on the slice: y^ = limit, the side past it hatched (objectives.limits on the same grid)."""
        super().draw_plane(ax, state, surface)
        limit = outputs.limit(self.function, state.shown)
        if surface is not None and limit is not None:
            x1, x2 = self.plane_mesh(state)
            objectives.limits(ax, x1, x2, (surface,), (limit,))

    def draw_space(self, ax, state: ParetoMetamodelState, surface=None) -> None:
        """The objective space in the first card (once per scene): its frame, the true front where it is shown, the
        experiment's designs feasible and infeasible, its non-dominated ones ringed and joined; and the ring of the
        design pointed at, made for this scene."""
        objectives.frame(ax, self.function)
        if self.truth_shown():
            objectives.truth(ax, self.function)
        objectives.designs(ax, self.function, state.rows)
        objectives.nondominated(ax, self.function, state.rows)
        self.ring = objectives.Ring(ax, self.function)

    def draw_objectives(self, ax, state: ParetoMetamodelState, hovered) -> None:
        """What moves in the objective space: the query point's prediction (the two objectives' metamodels at it); the
        ring on the design pointed at is the live layer's (live)."""
        if state.query is not None:
            self.moving += objectives.query(ax, self.function, state.query)

    def live(self, state: ParetoMetamodelState, hovered) -> None:
        """The live layer, as steps 1 and 3 have it: the band's design in focus, the crosshair of the place under the
        pointer (live.Pointing's) and the objective space's white ring on the design pointed at (in either space), all
        handed to the window's Layer (objectives.Ring: a move of the pointer redraws nothing else)."""
        if self.caption is not None:
            self.caption.show(self.focused(state, hovered), state.section.pair)
        crossed = self.crossing(state)
        ringed = []
        if self.ring is not None:
            pointed = designed(hovered) and 0 <= hovered < len(state.rows)
            ringed = self.ring.show(objectives.points_of(self.function, [state.rows[hovered]])[0] if pointed else None)
        if self.layer is not None:
            self.layer.hold([*(self.caption.drawn if self.caption is not None else ()), *crossed, *ringed])

    def draw_check(self, ax, state: ParetoMetamodelState) -> None:
        """The parent's check of the response on screen; a constraint's with its limit on both axes, a thin red line at
        the simulated value 120 and one at the prediction 120 (a design in the upper left or lower right quadrant is
        one the metamodel puts on the wrong side of it)."""
        super().draw_check(ax, state)
        limit = outputs.limit(self.function, state.shown)
        if limit is None or state.check is None:
            return
        low, high = ax.get_xlim()
        if low < limit < high:
            line = {"color": LIMIT_INK, "linewidth": LIMIT_WIDTH, "alpha": LIMIT_ALPHA, "zorder": 3}
            ax.axvline(limit, **line)
            ax.axhline(limit, **line)

    def draw_query(self, ax, state, hovered) -> None:
        """No 3D view on this bench: the query point's prediction is drawn in the objective space (draw_objectives)."""

    # ------------------------------------------------------------------ the blocks of the column (Lab.columned)
    def blocks(self, state, width: float) -> tuple:
        """Where the window sets columned, the step's own block alone (the card of the cross-beams is step 1's), the
        parent's "prognosis" block under a line of the four responses' CoPs and the scale of the lit one (SCALE_ALONE):
        at least those lines and a check of BLOCK_CHECK under them (metamodel.block_height), taking the column's room left
        up to its natural height as the parent's does (the owner's 1C); () otherwise."""
        if not self.columned:
            return ()
        return (Block(PROGNOSIS, get_text("lab.mm.check_title"), least=block_height(width, BLOCK_CHECK, COPS_TALL, SCALE_ALONE),
                      most=block_height(width, width, COPS_TALL, SCALE_ALONE), tip=get_text("lab.mm.m.cop_tip")),)

    def block_composition(self, plan):
        """The parent's composition (metamodel.block_composed) under the line of the four CoPs at the block's top, which
        stands for the parent's line of the number (the CoP of the response on screen is the lit one of the four, no
        number repeated over the check): its row the scale's alone (SCALE_ALONE)."""
        _, _, wide, tall = plan.cards["check"]
        return block_composed(wide, tall, top=COPS_TALL, row=SCALE_ALONE)

    def draw_block(self, key: str, figure, state, hovered) -> bool:
        """The parent's block "prognosis" (metamodel.MetamodelLab.draw_block), drawn again also when the line of the four
        CoPs changes (the response on screen, any response's CoP)."""
        if key != PROGNOSIS or not self.columned or state is None:
            return super().draw_block(key, figure, state, hovered)
        cops = (state.shown, tuple(None if check is None else check.cop for check in state.checks), state.language)
        made = self.block_made.get(key)
        if made is not None and made.get("cops") != cops:
            made["scene"] = None
        changed = super().draw_block(key, figure, state, hovered)
        self.block_made[key]["cops"] = cops
        return changed

    def draw_block_scene(self, figure, axes: dict, made: dict, state) -> None:
        """The parent's block (the CoP and the check of the response on screen, or its competition, under the line of
        the four CoPs: the competition's axes lowered by COPS_TALL), and the line of the four CoPs over them (draw_cops),
        in every case."""
        width, height = size(figure)
        if "cops" not in axes:
            axes["cops"] = figure.add_axes((0.0, 1.0 - COPS_TALL / height, 1.0, COPS_TALL / height))
        ranking = (RANK_SIDE, RANK_BELOW, width - 2 * RANK_SIDE, max(height - RANK_BELOW - BLOCK_FOOT - COPS_TALL, 1.0))
        axes["ranking"].set_position((ranking[0] / width, ranking[1] / height, ranking[2] / width, ranking[3] / height))
        super().draw_block_scene(figure, axes, made, state)
        axes["cops"].set_visible(True)
        self.draw_cops(axes["cops"], state)

    def draw_block_hero(self, ax, state, third) -> None:
        """No number over the check: the line of the four CoPs over it says the CoP of the response on screen, lit; under
        that line the parent's slim scale from 0 to 1 filled to it (metamodel.scale: the owner's 1C)."""
        wide, tall = pixel_axes(ax)
        scale(ax, wide, tall - SCALE_ALONE + (SCALE_ALONE - SCALE_HIGH) / 2, None if state.check is None else state.check.cop)

    def draw_cops(self, ax, state) -> None:
        """The line of the four CoPs at the block's top, the strip's measures in one line (metrics): each response's
        symbol and its CoP in its share of the width, the one on screen LIT (on the chosen option's pill, in white and
        heavier, as Metric.lit), a CoP at or below 0 in the warning's colour with its mark, a dash where it cannot be
        computed."""
        ax.set_axis_off()
        width, tall = size(ax.figure)[0], COPS_TALL
        ax.set_xlim(0.0, width)
        ax.set_ylim(0.0, tall)
        count = len(state.checks)
        share = width / max(count, 1)
        for k, check in enumerate(state.checks):
            lit = k == state.shown
            value = DASH if check is None else (f"{MARK} {quality(check.cop)}" if poor(check.cop) else quality(check.cop))
            said = f"{outputs.symbol(self.function, k)} {value}"
            middle = (k + 0.5) * share
            if lit:
                ax.add_patch(FancyBboxPatch((k * share + 1.5, 2.0), share - 3.0, tall - 4.0, boxstyle="round,pad=0,rounding_size=5",
                                            facecolor=palette.PILL, edgecolor="none", zorder=1))
            ink = WARNING if check is None or poor(check.cop) else palette.WHITE if lit else palette.PROSE
            ax.text(middle, tall / 2, said, ha="center", va="center", color=ink, zorder=2,
                    **(TAG | ({"fontweight": panels.STRONG["fontweight"]} if lit else {})))

# ------------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------------
def first_shown(function: str) -> int:
    """The response the lab opens on: the second objective (beam_pareto's RMS deflection, the response the study is
    about: the mass is exactly linear, its metamodel needs no calibration), or the first for a bench of one."""
    found = outputs.objectives(function)
    return found[1] if len(found) > 1 else found[0]

def shown_of(settings: dict, function: str) -> int:
    """The response on screen the settings choose (the first shown where they name none, or one out of range)."""
    k = settings.get(outputs.RESPONSE)
    return k if isinstance(k, int) and 0 <= k < len(outputs.of(function)) else first_shown(function)

def choices_of(settings: dict, function: str) -> tuple[tuple, ...]:
    """Each response's choice of the controls CHOICE as the settings keep it (METAMODELS); the controls' own values for
    every response where they keep none of the right length (a lab made alone with other settings, an older snapshot)."""
    count = len(outputs.of(function))
    made = settings.get(METAMODELS)
    if isinstance(made, tuple) and len(made) == count and all(isinstance(one, tuple) and len(one) == len(CHOICE) for one in made):
        return made
    return (tuple(settings.get(key) for key in CHOICE),) * count

def kept(settings: dict, function: str) -> dict:
    """The settings with the controls' values kept as the choice of the response on screen."""
    made = list(choices_of(settings, function))
    made[shown_of(settings, function)] = tuple(settings.get(key) for key in CHOICE)
    return settings | {METAMODELS: tuple(made)}

def showing_choice(settings: dict, function: str) -> dict:
    """The settings with the choice of the response on screen in the controls."""
    made = choices_of(settings, function)
    return settings | {METAMODELS: made} | dict(zip(CHOICE, made[shown_of(settings, function)]))

def held_whole(figure, heads: dict, axes: dict, handles: list, most: int) -> bool:
    """Whether the plane's head holds every one of `handles` in its legend's rows (panels.head's rule: the rows its plan
    gives it, the last entries left out where they do not hold): the designs' kinds join the plane's legend only where
    they take nothing out of it (the level lines, the limit)."""
    rows = max(panels.head_rows(size(figure)[0])[1], most)
    drawn, _ = panels.legend_rows(handles, panels.head_room(figure, heads, axes, "plane"), rows)
    return sum(len(row) for row in drawn if row) == len(handles)

def floored(value: float) -> float:
    """A coefficient rounded DOWN to the decimals metamodel.quality writes it with (three near 1, one far below 0;
    beyond a thousand it is left as it is): a least value written so that "at least" stays true."""
    if abs(value) < 10:
        return math.floor(round(value * 1000, 6)) / 1000
    if abs(value) < 1000:
        return math.floor(round(value * 10, 6)) / 10
    return value

def plane_title(function: str, k: int) -> str:
    """The plane's title for response k on screen: "Weight of each design in σ̂₁(x)", the prediction typeset as the
    objective space's symbols are (objectives.math_symbol: mathematics in STIX)."""
    symbol = objectives.math_symbol(function, k, hat=True)
    return get_text("lab.pareto.mm.plane_title", prediction=f"{symbol[:-1]}(x)$")

def legend_rows(plan) -> int:
    """The rows the check's legend may take: three (its entries for a constraint: a design, the diagonal, the limit,
    each on its row where the card is narrow), four on a phone's narrow card (whose heads hold four)."""
    return 4 if plan.head > HEAD else 3

def limit_handle(function: str, k: int) -> Patch:
    """The plane's legend entry of a constraint's predicted limit: the red cross-hatch, "σ̂₁ > 120 MPa", with its unit
    (objectives.limits' look)."""
    label = f"{objectives.math_symbol(function, k, hat=True)} > {outputs.limit(function, k):g} {outputs.unit(function, k)}"
    made = Patch(facecolor="none", edgecolor=palette.RED, hatch=objectives.HATCH_LEGEND, label=label.strip())
    made.short = None
    return made

def check_handles(function: str, k: int | None = None) -> list:
    """The check's legend: a design predicted without it, the diagonal of a perfect prediction, and for a constraint k
    its limit with its unit ("limit 120 MPa", a thin red line). The first entry's short label is the check's own short
    name of its axis ("predicted") for every response, one wording whatever is on screen, so that the three rows hold
    wherever the card has a check: a legend that left an entry out where its rows do not hold would take fewer rows than
    the check's composition kept (composed)."""
    handles = [panels.dot(POINT, get_text("lab.mm.legend.design"), short=get_text("lab.mm.check.y_short")),
               Line2D([], [], color=TRUE, linewidth=1.1, label=get_text("lab.mm.legend.diagonal"))]
    if k is not None:
        handles.append(Line2D([], [], color=LIMIT_INK, linewidth=LIMIT_WIDTH,
                              label=get_text("lab.pareto.mm.legend.limit", limit=f"{outputs.limit(function, k):g}",
                                             unit=outputs.unit(function, k))))
    return handles
