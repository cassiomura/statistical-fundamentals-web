# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                     Title: pareto_optimization.py
# ==============================================================================
"""
Step 3 of a bench of SEVERAL responses (functions.many: beam_pareto, the beam whose two cross-beams are placed and sized;
its mass m and RMS deflection δ the two objectives, the stresses σ₁ and σ₂ the constraints, σ <= 120 MPa), the
multi-objective optimization: ParetoLab(function, mode), reached by explorers.lab_for("optimization", "beam_pareto",
mode). With two objectives in conflict there is no single best design: the answer is a FRONT of compromises, which
NSGA-II (pareto.py, the core: the evolutionary algorithm of the other benches with Deb's constrained dominance, the
non-dominated sort, the crowding distance) finds ON THE METAMODELS that step 2 handed; its promise is worth what the
metamodels are worth, and the validation, K real simulations of designs of the predicted front, says what it is worth.

    Optimize on                |  the beam's band: the design in focus, its places and sizes, both objectives, the check
    [MOP Solver | Real Run]    |------------------------------------------------------------------------------------------
                               | NSGA-II on the metamodels:      | objective space m across, | Pareto front: predicted
    Population [10 | 20 | 40] | the slice through the           | δ up: the population, the | and validated
    K [ 20 ] 5 10 15 20        | compromise; the predicted       | predicted front (dashed), | (legend) ------------
    (play)(step)(restart)(seed)| limits σ̂ = 120 hatched; the     | the validated designs     | generation | front
      generation 12 of 30 ·    | experiment faint; the           | joined to their           | HV/HV* of  | Bench
      survival                 | population (crosses, rank 1     | predictions, the true     | designs    |
    [Validate 20 designs]      | teal); the stage's construction | front, r, the HV's area   |------------
    Restore                    | (yellow now, slate × dropped); |-------------------------------------------------------
                               | validated designs ringed        | In real simulations: cost and front found (the board)

THE STUDY. The step receives step 2's pareto_metamodel.Surrogates (the experiment, its output 0, and one metamodel
per response: settings["surrogates"]); alone it opens on a first one of its own (first_surrogates: the bench's first
experiment, a teacher's metamodels the winners of the four competitions, a student's the linear polynomials), and given
one as it opens (opening) it never makes that first one. It hands nothing (output None): it is the last step, and it
completes the bench. The card "Received from step 2" (received), in the order of every bench: the sampling and N
(metamodel.sampled); the CoP of each response, two to a row ("CoP of m, δ 1.000 · 0.998"), a warning's kind by step
2's rule (at or below 0, or a metamodel that cannot be computed); the feasible designs of the experiment, last.

TWO SOLVERS (settings["solver"], the parent's names, icons and locking: optimization.SOLVERS, SOLVER_NAMES): the MOP
Solver runs NSGA-II on the metamodels: f(u) is the metamodels' row at u, the objectives (m^, δ^) and the constraints
σ^ / 120 - 1 (outputs.violation's normalization: each a share of its limit); an evaluation of y^ is not a simulation.
A point where a metamodel refuses (REFUSED) makes the run "cannot be computed" (REFUSALS; optimization.Refused, the
exception the lab of one objective raises there too), said on the plane. Real Run runs the same algorithm, with the
same mu and seed, on the simulation itself (outputs.simulate): every evaluation is a simulation, drawn as a simulated
design, mu (1 + 30) of them; there is nothing to validate there.
Real Run is a student's reward: locked while the bench is not won (locked); a snapshot or a surrogate received that
would leave a student on it is taken back to the MOP Solver (allowed). ONE METHOD: no method control (its name is the
plane's title's, "NSGA-II on the metamodels"; no muted line under the solver: the owner's 2026-11-21). Its
controls: mu, the population (the EA's own values and icons, 10 | 20 | 40, first 40 on this bench in both modes), and
K, the designs to validate, a TYPED number (Control.typed, symbol "K"): 1 to K_MOST; a teacher's first 20 with quick
picks 5, 10, 15, 20, a student's first 5 without (as N in step 1); typed past the predicted front's size it is held to
it (adjust), and the validation takes at most that many (ParetoOptState.k). The seed is the EA's (first 27; "New
seed" in the transport).

THE RUN (outcome, cached by what it depends on: the surrogates or the bench's key, mu, the seed) is the core's whole
history: every evaluation in call order (Run.evaluations: the unit point and its row of four outputs, predicted or
simulated) and the violation the core saw there (Run.violations), the members of each generation's population
(Run.members: indices of evaluations), the PREDICTED FRONT (the feasible designs of rank 1 of the final population,
pareto.ranked on it, sorted by the mass: Run.front). Iteration 0 is the start population; each generation has three
STAGES, each read from the core's record alone:

    (1) selection        the parents (the population of that generation), the rank-1 ones told apart, and each pair the
                         tournaments chose joined by a yellow line (the reason: rank first, crowding second)
    (2) crossover and    the mu children, yellow (what is computed now), where y^ (or f) is evaluated
        mutation
    (3) survival         parents and children sorted into fronts: the mu kept drawn as the population, the others a
                         faint slate cross under them (dropped: red is what is infeasible, only)

"Next" plays the three stages of one generation, "Run" one frame per generation at its last stage, "Restart" shows the
start and stops; a complete run begins again BEFORE its start (optimization.BEFORE). The transport's name is the
parent's ("generation 12 of 30 · survival"; at the end "complete · 1240 evaluations", simulations in Real Run). Any
control changed, a new seed or a surrogate received shows the complete run (ended); the lab opens on it. The complete run
draws no stage: the final population, the predicted front and, validated, the designs simulated.

THE VALIDATION, the lab's one primary command ("Validate 20 designs": K in its name, naming), a toggle as the parent's
(turned on it shows the validation and offers to hide it; any change takes it back): the K designs evenly spaced along the
predicted front by arc length (pareto.spaced on its objectives, its own ends included), each simulated once (validated:
outputs.simulate, cached). Enabled once the MOP Solver's run on screen is complete, can be computed and predicts a
feasible design (else missing says why, its tooltip).

WHAT A STUDY IS WORTH: the SHARE of the true front's hypervolume (game.share) held by EVERY design simulated on the
experiment: its N designs and every distinct design ever validated on it, the ones on screen and those the bench paid
for before (Lab.paid, by the experiment of output 0, given back by the window: charges names each validated design as
(experiment, (u, row)), hashable and equal for the same design, so that the bench counts it once). A validated design
the simulation finds infeasible counts in nothing (an exact fact: outputs.feasible). The COST is N plus the distinct
designs validated on that experiment, written as it is counted ("70 + 20 = 90"); validating 5, then 10, pays for their
union. COMPLETE (finished): the MOP Solver's run complete and validated, the share of all those designs at least
0.94 AND above the experiment's own (game.front_completed: the validation added to the front, the form "x* below the best
design" takes here): then the bench is passed (passed, True; False when not: the owner's 2026-11-21, no stars). A
validation that does not complete says what it misses, with its numbers, in the tooltip of the verdict's line at the
column's foot (hint: the share held but the validation added nothing, improve the metamodels; validate more designs;
or, every design of the predicted front validated, improve the metamodels).
THE VERDICT, an exact fact as the parent's: the study's share against the experiment's own (better: "HV > experiment",
teal; the same: "HV = experiment", red: the validation added nothing). summary (the cover's track): "HV/HV* 0.957" with
the verdict's kind once validated, a dash before. cue: "complete" when a played run reaches its end, "better" or "worse"
for the validation, "apply" for a new seed. "View code" reads NSGA-II (link: "nsga2").

THE FIGURE is the bench's shared picture (panels.arrangement with fill, the caption's block, pareto_doe.heading's notes,
the hero: the same boxes as steps 1 and 2 of the bench), the objective space in the first card (objectives.box):
- THE PLANE (the design space through the slice, explorers/section.py: a mark is a projection, a surface a slice): the
  predicted LIMITS on the slice, σ^₁ = 120 and σ^₂ = 120, their union's infeasible side lightly cross-hatched (objectives.limits
  on the two stress metamodels' slices, metamodel.predicted; in Real Run the true limits from the simulation's slice);
  the experiment's designs by their kind, faint; the population on screen (crosses: no simulation; the rank-1 ones teal;
  in Real Run simulated designs, discs, the rank-1 ones ringed); the stage's construction; the validated designs (a
  disc in a ring; hollow red where the simulation finds them infeasible) and those paid for before (discs).
- THE OBJECTIVE SPACE (titled "Pareto front: predicted and validated"; Real Run its own): the experiment faint, the TRUE
  front (game.front: the reference a real study never has, "true front" in its legend) only where the true response
  is shown (Lab.truth_shown, the owner's 2B: a simulation's once the reader asked to see it, Lab.revealed, a teacher's
  "Show f", a student's once the bench is won), its legend's entry with it, the reference point r,
  the population on screen at its predictions, the predicted front (dashed) once the run is complete, the validated
  designs each joined to its prediction, the designs paid for before, and the HYPERVOLUME of the study's simulated
  designs as a quiet area (before a validation the experiment's and those paid for: it grows on the validation). In Real
  Run, the run's front so far (its feasible non-dominated simulations, its rings smaller where it holds more than
  FRONT_RINGS designs) and their area. A design beyond the window is drawn at its edge, and each edge writes ONE count of
  every set beyond it (objectives.at_edges for each set, objectives.counts once: the experiment's, faint, are kept from
  the scene).
- THE SCOREBOARD in real simulations (scoreboard, draw_board; the parent's is the model): one row per route, its mark and
  its name, its cost as a bar on ONE linear scale shared by the rows (the N of step 1 translucent in it), written as it
  is counted, then how many designs its front holds and its share of HV*: (1) the experiment (step 1); (2) through the
  metamodels, K validated (before the validation the K simulations not spent yet outlined and its count without a total,
  "70 + 20"; validated, "70 + 20 = 90", the verdict's words and colour, the row outlined); (3) NSGA-II directly on the
  simulation at the SAME COST as the study, the BEST of its three populations at that cost (same_cost: mu = 10, 20
  and 40, the seed on screen, each its own start population charged from its first simulation; its front the feasible
  non-dominated designs among the simulations up to that cost, a generation cut where the cost falls in it), its mu
  named on the row ("NSGA-II directly, at the same cost · mu = 10": the comparison cannot flatter the study); (4) the
  reader's mu to its end, mu (1 + 30). In Real Run the direct rows are the run on screen up to the stage on screen (the
  fourth outlined), the route through the metamodels the muted reference. Its foot: HV*, known only because this
  simulation is cheap, written only where the true front is drawn (Lab.truth_shown). The SHARE HV/HV* of each row is
  measured against the true front all the same: it is the game's SCORE (game.front_completed, passed), so it stays
  shown to everyone, while the true front's LINE, its value HV* and the foot that names it are the truth 2B hides. In
  Real Run the constraints' limits on the plane are the simulation's (the reader runs real simulations: as the parent's
  level lines of f there), whatever is revealed.
- IN THE WINDOW'S COLUMN (Lab.columned, the owner's design of 2026-11-21; the web never sets it): the plan without its
  third panel (planned's third=False, readout=False: the objective space the right column's ONE card, larger, its head
  one row of legend; the design space filling its height; no scoreboard in the figure) and the column's one block
  (blocks), the step's own, the scoreboard (the card of the cross-beams is step 1's alone, explorers/crossbeams.py).
- THE MEASURES (metrics; beside the objective space under the band, else the strip), four: the generation on screen
  with the evaluations of y^ made; the predicted front (the rank-1 designs predicted feasible); the share of the study's
  simulated designs with the verdict; the bench (passed or not, the cost or what it needs). Real Run its own four.
- THE FOCUS on the beam's band (never a prediction: caption.simulated only for a simulated row): the simulated design
  under the pointer in either space (an experiment's design, "validated 3 of 20", a design a Real Run simulated); over a
  PREDICTED design (a cross) the place it stands at (caption.under, its four coordinates: the cross-beams dashed, no
  outputs); over the plane elsewhere the place under the pointer; with nothing pointed at, the COMPROMISE
  (outputs.compromise) of the validated feasible designs once validated, else the experiment's (in Real Run, the run's
  front so far); the pointed design ringed in both spaces (the plane's white ring, objectives.Ring in the live layer).
  The automatic slice (no slider pinned) passes through that compromise (in Real Run, the whole run's).

What is drawn when: the scene (the plane's frame, limits and experiment, the objective space's frame, true front,
reference point and experiment) once per (surrogates, solver, slice, language, the truth shown); the rest at every draw (moving), the
scoreboard only when what it shows changes, the caption's design in focus only when it changes. A slice of a stress
metamodel costs what step 2's does (seconds for a quadratic moving least squares; cached by Section.key): the sliders of
this bench are read on release. Nothing is recomputed on a pointer move or on a frame of the transport: the runs, the
validations, the direct run's fronts and the shares are cached. Nothing here reads the bench's single-response helpers
(game.spread, game.distance, doe.extent, doe.window, doe.through).
"""
import dataclasses
import math
from dataclasses import dataclass
from functools import cached_property, lru_cache
from random import Random
from textwrap import fill

import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Rectangle

from statistical_fundamentals import palette, pareto
from statistical_fundamentals.explorers import caption, game, live, objectives, outputs, panels, pareto_doe, prognoses, section
from statistical_fundamentals.explorers.base import Control, nearest, style_axes
from statistical_fundamentals.explorers.doe import FIRST_SEED, HEIGHT, first_experiment, marker_size, simulated
from statistical_fundamentals.explorers.game import STUDENT, TEACHER
from statistical_fundamentals.explorers.lab import LINK, TRANSPORT, Action, Block, Lab, Metric, page_link, size
from statistical_fundamentals.explorers.metamodel import (AXIS, FIRST_MODEL, FIRST_ORDER, Candidate, poor, predicted, quality,
                                                          sampled)
from statistical_fundamentals.explorers.optimization import (BEFORE, BOARD_APART, BOARD_BAR, BOARD_BAR_LEAST, BOARD_GAP,
                                                             BOARD_HEADING, BOARD_LINE, BOARD_LINE_PITCH, BOARD_MARK, BOARD_PAD,
                                                             BOARD_PITCH, BOARD_SIDE, BRIEF_APART, BRIEF_BAR_LEAST, BRIEF_GAP,
                                                             BRIEF_MARK, BRIEF_NAMED, BRIEF_PAD, DASH, OTHER_TONE,
                                                             POPULATIONS, SHARED_TONE, SOLVER_NAMES, SOLVERS, Refused, broken_at,
                                                             apart, cost_bar, tally)
from statistical_fundamentals.explorers.panels import (CAPTION, CARD_TONE, HEADING, LEGEND_LEAST, LEGEND_SIZE, MUTED_INK, NOTE,
                                                       READING, SMALL, STACK_WIDTH, STRONG, arrangement, draw_cards, gauge, head,
                                                       legend_most, name_plane, number_width, places, plane_ticks, text_width,
                                                       tint, under_title)
from statistical_fundamentals.explorers.pareto_metamodel import Surrogates
from statistical_fundamentals.functions import RESPONSES, many
from statistical_fundamentals.i18n import current_language, get_text

FUNCTION = "beam_pareto"              # the bench this laboratory is made for (any bench of several responses would do)
METHOD = "nsga2"                      # the bench's one method: the key of its reading in the code panel (gui/lab_code.py)
FIRST_MU = 40                         # mu on this bench, both modes (the 2026-11-20 sweep, of the section heights: 20
                                      # lost 0.003 to 0.006 of the share; not swept again on the areas)
K_MOST = max(POPULATIONS)             # K, the designs to validate: at most a population (the predicted front holds no more)
FIRST_K = {TEACHER: 20, STUDENT: 5}   # a teacher's K completes the bench with mu = 40 (the sweep); a student's is a start
K_PICKS = (5, 10, 15, 20)             # a teacher's quick picks of K (a student's K has none: they would suggest the answer)
REFUSALS = ("fit", "point")           # why a run cannot be computed: a metamodel received, a metamodel at a point asked for
EXPERIMENT_FAINT = 0.45               # the experiment's designs under the run, in both spaces: a reference, faint
POPULATION_AREA = 34.0                # points²: a member of the population on screen (a cross; a disc in Real Run, 0.6 of it)
DISC_SHARE = 0.6                      # a disc is drawn smaller than a cross of the same area, which is mostly empty
POINTED_RING = pareto_doe.POINTED_RING  # the white ring of the design pointed at on the plane, in areas of its mark
PAIR_WIDTH, PAIR_ALPHA = 0.9, 0.8     # the line joining a pair of parents (stage 1) on the plane, and in the objective
PAIRED_WIDTH, PAIRED_ALPHA = 0.7, 0.5     # space, where twenty pairs lie along the front: quieter
DESIGN = palette.BLUE                 # a simulated design
NOW = palette.YELLOW                  # what the stage computes now
REFERENCE = palette.SLATE             # what a study never has: the true front, and the routes not on screen
VERDICT_INK = {"ok": palette.TEAL, "error": palette.RED, "plain": palette.PROSE}
WARNING = palette.GOLD
BOXED = {"boxstyle": "round,pad=0.3", "facecolor": palette.CARD, "edgecolor": "none", "alpha": 0.85}
NOW_CROSS = objectives.Look(NOW, marker="+", area=46.0, width=1.6, zorder=8.0)       # a child, evaluated on y^ now
NOW_DISC = objectives.Look(NOW, area=26.0, width=0.6, zorder=8.0)                     # a child, simulated now (Real Run)
DROPPED = objectives.Look(palette.MUTED, marker="x", area=26.0, width=1.1, zorder=5.5)  # a design the survival dropped:
DROPPED_ALPHA = 0.6                   # a muted cross, faint, under the survivors (red is what is infeasible, only)
RINGED = objectives.Look(palette.TEAL, hollow=True, area=44.0, width=1.2, zorder=6.5)  # rank 1 of a simulated population
ROUTES = ("experiment", "metamodels", "same", "whole")     # the scoreboard's rows
BOARD = "board"                       # the scoreboard's block in the window's column (Lab.columned): the parent's key
# The scoreboard's block, in layout pixels: this bench's own heights (the parent's columns and gaps across), so that its
# verdict and, where the truth is shown, the foot on HV* keep their lines under the four routes
BRIEF_TOP = 16.0                      # the top line: what the numbers are
BRIEF_PITCH = 30.0                    # a route's two lines (its name; its cost, bar, front and share), its outline inside
BRIEF_PITCH_LEAST = 27.0              # the least pitch, where the column's room is short (the lines under go first)
BRIEF_NAME, BRIEF_NUMBERS = 9.0, 22.0     # those two lines' middles, under the top of the route
BRIEF_LINE = 13.0                     # a line under the routes: the verdict that did not fit beside its name, HV*'s foot
BRIEF_LINES = 2                       # the lines kept for them, whatever the state, so that the block never moves
BRIEF_HEIGHT = math.ceil(panels.BLOCK_TOP + BRIEF_TOP + len(ROUTES) * BRIEF_PITCH + BRIEF_LINES * BRIEF_LINE)
BRIEF_LEAST = math.ceil(panels.BLOCK_TOP + BRIEF_TOP + len(ROUTES) * BRIEF_PITCH_LEAST)    # the block's least: no line under
WIDEST_SHARE = "0.000"                # a share of HV*, three decimals
PLAIN = section.Section(2)            # the slice of a bench of two inputs: the whole design space
FRONT_RINGS, FRONT_RING_LEAST = 40, 12.0      # a front of more designs than this has smaller rings, down to this area

# ------------------------------------------------------------------------------
# The runs, by the core, recorded and kept by what they depend on
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Run:
    """NSGA-II's whole run on the metamodels (y^) or on the simulation (f): the core's records, every evaluation in the
    order the core asked for it ((u, row): the unit point and its four outputs, predicted or simulated), the members of
    each generation's population (indices of evaluations: members[0] the start, members[g] the survivors of generation
    g), the violation the core saw at each evaluation (pareto.violation of its constraints) and the predicted front
    (indices of evaluations: the feasible designs of rank 1 of the final population, sorted by the first objective, the
    mass)."""
    history: tuple                              # the core's records, one per generation and the start (never mutated)
    evaluations: tuple                          # ((u1, ..., ud), (m, δ, σ₁, σ₂)), in call order
    violations: tuple                           # the violation of each evaluation as the core saw it (0: feasible)
    members: tuple                              # tuple of tuples of indices of evaluations
    front: tuple                                # indices of evaluations, sorted by the mass
    mu: int
    simulated: bool = False                     # the run on f: every evaluation is a simulation (else on y^: none is)

    @property
    def last(self) -> int:
        """The last generation (generation 0 is the start)."""
        return len(self.history) - 1

    @property
    def stages(self) -> tuple:
        """The stages of each generation on screen: none for the start, three for each generation."""
        return (0,) + (3,) * self.last

    def count(self, shown: int, stage: int) -> int:
        """The evaluations made by the end of a stage: mu at the start, then mu more with the children (stage 2)."""
        if shown == 0:
            return self.mu
        return self.mu * (shown + 1) if stage >= 2 else self.mu * shown

def objective(function: str, row) -> tuple[list, list]:
    """What NSGA-II reads of one row of outputs: the objectives, and each constraint as a share of its limit, g / limit -
    1 <= 0 (outputs.violation's normalization)."""
    return ([float(row[k]) for k in outputs.objectives(function)],
            [float(row[k]) / outputs.limit(function, k) - 1 for k in outputs.constraints(function)])

@lru_cache(maxsize=64)
def outcome(target, mu: int, seed: int) -> Run | str:
    """NSGA-II's run (pareto.nsga2, mu, Random(seed), d inputs) on the target: a Surrogates (the metamodels: y^, no
    simulation) or the key of a bench (its simulation, outputs.simulate: every call one simulation), its calls recorded;
    or why it cannot be computed (REFUSALS)."""
    evaluations = []
    function = target.experiment.function if isinstance(target, Surrogates) else target
    response = RESPONSES[function]
    if isinstance(target, Surrogates):
        if any(target.fit(k) is None for k in range(len(target.candidates))):
            return "fit"

        def f(u):
            point = tuple(float(v) for v in u)
            row = target.predict(point)                               # None: refused at u, or not finite there
            if row is None:
                raise Refused(point)
            evaluations.append((point, row))
            return objective(function, row)
    else:
        def f(u):
            point = tuple(float(v) for v in u)
            row = tuple(outputs.simulate(function, [section.mapped(response.bounds, point)])[0])
            evaluations.append((point, row))
            return objective(function, row)
    try:
        history = pareto.nsga2(f, mu, Random(seed), response.d)
    except Refused:
        return "point"
    members = [tuple(range(mu))]
    for g in range(1, len(history)):
        pool = members[g - 1] + tuple(range(mu * g, mu * (g + 1)))
        members.append(tuple(pool[i] for i in history[g]["kept"]))
    violations = tuple(pareto.violation(objective(function, row)[1]) for _, row in evaluations)
    return Run(tuple(history), tuple(evaluations), violations, tuple(members),
               final_front(function, evaluations, violations, members[-1]), mu, not isinstance(target, Surrogates))

def final_front(function: str, evaluations, violations, final) -> tuple[int, ...]:
    """The predicted front of a run: of its final population, the feasible designs of rank 1 (pareto.ranked under Deb's
    rules: a feasible design always outranks an infeasible one), sorted by the first objective (the mass), a tie by the
    order of the evaluations."""
    read = [objective(function, evaluations[i][1])[0] for i in final]
    _, ranks, _ = pareto.ranked(read, [violations[i] for i in final])
    front = [final[j] for j in range(len(final)) if ranks[j] == 1 and violations[final[j]] == 0]
    first = outputs.objectives(function)[0]
    return tuple(sorted(front, key=lambda i: (evaluations[i][1][first], i)))

def run(target, mu: int, seed: int) -> Run | None:
    """The run on the target, or None when it cannot be computed (refusal says why)."""
    found = outcome(target, mu, seed)
    return found if isinstance(found, Run) else None

def refusal(target, mu: int, seed: int) -> str:
    """Why the run cannot be computed (REFUSALS), or "" when it can."""
    found = outcome(target, mu, seed)
    return "" if isinstance(found, Run) else found

@lru_cache(maxsize=256)
def validated(function: str, points: tuple) -> tuple[tuple[float, ...], ...]:
    """One simulation of each design (unit points, d coordinates each): the rows of their outputs (outputs.simulate)."""
    bounds = RESPONSES[function].bounds
    return tuple(tuple(row) for row in outputs.simulate(function, [section.mapped(bounds, u) for u in points]))

@lru_cache(maxsize=32)
def fronts_of(function: str, mu: int, seed: int) -> tuple[tuple[int, ...], ...]:
    """The front of the direct run (on the simulation) after each generation's simulations: fronts[g] the archive of its
    first mu (g + 1) simulations (indices of evaluations)."""
    found = run(function, mu, seed)
    rows = [row for _, row in found.evaluations]
    made, fronts = (), []
    for g in range(found.last + 1):
        made = grown(function, rows, made, mu * g, mu * (g + 1))
        fronts.append(made)
    return tuple(fronts)

def grown(function: str, rows, kept: tuple, start: int, end: int) -> tuple[int, ...]:
    """The feasible rows that no other one dominates among rows[:end], from those of rows[:start] (kept, indices of
    rows) and the rows after, added one at a time: a row joins when no member dominates it and drops the members it
    dominates (equal rows all kept). The set outputs.front_of gives for the same rows, in another order (a row dominated
    by one that left is dominated by the one that made it leave)."""
    front = list(kept)
    for i in range(start, end):
        row = rows[i]
        if not outputs.feasible(function, row):
            continue
        point = outputs.objective_values(function, row)
        if any(pareto.dominates(outputs.objective_values(function, rows[j]), point) for j in front):
            continue
        front = [j for j in front if not pareto.dominates(point, outputs.objective_values(function, rows[j]))] + [i]
    return tuple(front)

@lru_cache(maxsize=512)
def direct_front(function: str, mu: int, seed: int, count: int) -> tuple[int, ...]:
    """The direct run's front after its first `count` simulations (count >= 1; at most the run's whole): the archive of
    the last whole generation before it, grown with the simulations after it (a generation cut where the cost falls in
    it)."""
    found = run(function, mu, seed)
    count = min(max(int(count), 1), len(found.evaluations))
    whole = count // mu - 1                                           # the last generation wholly made by then
    rows = [row for _, row in found.evaluations]
    if whole < 0:
        return grown(function, rows, (), 0, count)
    return grown(function, rows, fronts_of(function, mu, seed)[whole], mu * (whole + 1), count)

def share_of(function: str, rows) -> float:
    """The share of the true front's hypervolume held by a set of simulated rows (game.share: their feasible
    non-dominated designs)."""
    return game.share(function, list(rows))

@lru_cache(maxsize=2048)
def front_share(function: str, rows: tuple) -> float:
    """The share of HV* of rows that are already a front (direct_front's): pareto.hypervolume of their normalized
    objectives, as game.share computes it."""
    points = [game.normalized(function, outputs.objective_values(function, row)) for row in rows]
    return pareto.hypervolume(points, (game.REFERENCE, game.REFERENCE)) / game.front(function).hypervolume

@lru_cache(maxsize=64)
def true_limits(function: str, cut_key: tuple) -> tuple[np.ndarray, ...]:
    """The true constraints on the GRID x GRID grid of a slice (the simulation of every point of it, outputs.simulate:
    Real Run's limits), one array per constraint, rows by the input up (metamodel.predicted's order). Never mutate."""
    cut = section.Section.from_key(cut_key)
    bounds = RESPONSES[function].bounds
    grid = cut.grid(AXIS)
    rows = outputs.simulate(function, [section.mapped(bounds, u) for line in grid for u in line])
    shape = (len(grid), len(grid[0]))
    made = tuple(np.array([row[k] for row in rows], dtype=float).reshape(shape) for k in outputs.constraints(function))
    for array in made:
        array.flags.writeable = False
    return made

def first_surrogates(function: str, mode: str = TEACHER) -> Surrogates:
    """The metamodels a stand-alone lab opens on: the bench's first experiment (doe.first_experiment), a teacher's the
    winner of each response's competition (prognoses, the simplest one should none be computed), a student's the
    simplest one for each (no competition is run)."""
    experiment = first_experiment(function)
    simplest = Candidate(FIRST_MODEL, FIRST_ORDER, None)
    if mode == STUDENT:
        return Surrogates(experiment, (simplest,) * len(outputs.of(function)))
    found = []
    for k in range(len(outputs.of(function))):
        best = prognoses.champion(prognoses.of(experiment, k))
        found.append(simplest if best is None else best.candidate)
    return Surrogates(experiment, tuple(found))

# ------------------------------------------------------------------------------
# The settings
# ------------------------------------------------------------------------------
def solver_of(settings: dict) -> str:
    return settings.get("solver", SOLVERS[0])

def searched(settings: dict) -> Run | None:
    """The run on the metamodels received."""
    return run(settings["surrogates"], settings["population"], settings["seed"])

def direct_of(settings: dict) -> Run | None:
    """The same run on the simulation: the direct route (and Real Run)."""
    return run(settings["surrogates"].experiment.function, settings["population"], settings["seed"])

def on_screen(settings: dict) -> Run | None:
    return searched(settings) if solver_of(settings) == "mop" else direct_of(settings)

def framed(current: Run | None, settings: dict) -> tuple[int, int]:
    """The frame of the settings brought into the run: a generation that exists and one of its stages (BEFORE, where a
    rewound run waits for its first frame, is shown as the start)."""
    if current is None:
        return 0, 0
    shown = min(max(int(settings["shown"]), 0), current.last)
    if shown == 0:
        return 0, 0
    return shown, min(max(int(settings["stage"]), 1), current.stages[shown])

def ended(settings: dict) -> dict:
    """The settings with the complete run on screen shown (its last generation, at its last stage), the validation off."""
    current = on_screen(settings)
    settings = settings | {"validate": False}
    if current is None:
        return settings | {"shown": 0, "stage": 0}
    return settings | {"shown": current.last, "stage": current.stages[current.last]}

def chosen_of(function: str, current: Run | None, k: int) -> tuple[int, ...]:
    """The designs to validate: K of the predicted front, evenly spaced along it by arc length (pareto.spaced on its
    objectives, normalized by its own ends, both ends included), as indices of the run's evaluations, in the front's
    order."""
    if current is None or not current.front:
        return ()
    points = [outputs.objective_values(function, current.evaluations[i][1]) for i in current.front]
    return tuple(current.front[j] for j in pareto.spaced(points, max(min(k, len(points)), 1)))

def k_of(settings: dict, current: Run | None, mode: str) -> int:
    """K the validation takes: the typed K, at most the predicted front's size."""
    k = int(settings.get("k") or FIRST_K[mode])
    return min(k, len(current.front)) if current is not None and current.front else k

def validation_of(function: str, settings: dict, current: Run | None, mode: str) -> tuple[int, tuple, tuple]:
    """K, the designs chosen (indices of the run on the metamodels) and, when the validation is on for the MOP Solver's
    complete run, the designs validated ((u, row): each simulated once); else ()."""
    k = k_of(settings, current, mode)
    chosen = chosen_of(function, current, k)
    if not settings.get("validate") or solver_of(settings) != "mop" or not chosen:
        return k, chosen, ()
    if framed(current, settings) != (current.last, current.stages[current.last]):
        return k, chosen, ()
    points = tuple(current.evaluations[i][0] for i in chosen)
    return k, chosen, tuple(zip(points, validated(function, points)))

def passing(function: str, settings: dict, on_metamodels: Run | None, direct: Run | None, made: tuple):
    """The unit point the automatic slice passes through, the design the band draws with nothing pointed at: the
    compromise (outputs.compromise: of a set's feasible non-dominated designs, the one nearest the ideal point) of the
    validated designs once validated, else of the experiment's (default_focus's rule: never a design paid for before);
    in Real Run, of the whole run's front (the run is computed whole: the slice stands still while it plays). None: the
    middle (nothing feasible)."""
    if solver_of(settings) == "real" and direct is not None:
        front = direct_front(function, direct.mu, settings["seed"], len(direct.evaluations))
        best = outputs.compromise(function, [direct.evaluations[i][1] for i in front])
        if best is not None:
            return direct.evaluations[front[best]][0]
    if made:
        best = outputs.compromise(function, [row for _, row in made])
        if best is not None:
            return made[best][0]
    experiment = settings["surrogates"].experiment
    best = pareto_doe.outcomes(experiment).compromise
    return None if best is None else tuple(simulated(experiment).unit[best])

# ------------------------------------------------------------------------------
# The state
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Shown:
    """A simulated design on screen (the designs the pointer may point at, the band may draw): who it is (caption.KINDS:
    "design" for the experiment's and a Real Run's, "validated"), its unit point, its place in the bounds, its row of
    outputs (simulated), its number among n, its tag (caption.TAGS) and its role here ("experiment", "validated",
    "paid", "run")."""
    kind: str
    unit: tuple
    point: tuple
    row: tuple
    index: int
    n: int
    tag: str
    role: str

@dataclass(frozen=True)
class ParetoOptState:
    response: object                            # functions.Response: the bench
    surrogates: Surrogates                      # what step 2 handed
    designs: object                             # doe.Simulated of the experiment (output 0)
    rows: tuple                                 # the experiment's rows of outputs
    mu: int
    seed: int
    solver: str
    run: Run | None                             # the run on screen (on y^, or on f in Real Run)
    refused: str                                # "" | "fit" | "point": why the MOP Solver's run cannot be computed
    searched: Run | None                        # the run on the metamodels (the route through them, in both solvers)
    direct: Run | None                          # the run on the simulation (the direct route; Real Run's run)
    shown: int                                  # the generation on screen, 0 the start
    stage: int                                  # its stage
    k: int                                      # the designs the validation takes: K, at most the predicted front's size
    chosen: tuple                               # those designs, indices of the searched run's evaluations
    validated: tuple                            # ((u, row), ...) the designs validated on screen; () while not validated
    paid: tuple                                 # ((u, row), ...) the designs validated on this experiment before
    language: str
    section: object = PLAIN                     # the slice the figure shows (a view, never a part of the study)

    @cached_property
    def population(self) -> tuple:
        """The population on screen and its stage (population_on_screen), read once per state."""
        return population_on_screen(self)

    @cached_property
    def simulations_shown(self) -> tuple:
        """The simulated designs on screen (shown_designs), the ones the pointer may point at, read once per state."""
        return shown_designs(self)

    @cached_property
    def resting(self):
        """The band's focus with nothing pointed at (default_focus), read once per state: a pointer's move computes nothing."""
        return default_focus(self, self.simulations_shown)

    @property
    def experiment(self):
        return self.surrogates.experiment

    @property
    def method(self) -> str:
        """The method on screen, the bench's one (NSGA-II, on the metamodels or in Real Run): the code panel's reading
        (gui/lab_code.reading_for), as the method of an OptimizationState."""
        return METHOD

    @property
    def function(self) -> str:
        return self.response.key

    @property
    def n(self) -> int:
        return self.experiment.n

    @property
    def simulating(self) -> bool:
        return self.solver == "real"

    @property
    def count(self) -> int:
        """The evaluations made by the end of the stage on screen (of y^; in Real Run, simulations)."""
        return self.run.count(self.shown, self.stage) if self.run is not None else 0

    @property
    def complete(self) -> bool:
        return self.run is None or (self.shown == self.run.last and self.stage == self.run.stages[self.run.last])

    @property
    def record(self) -> dict | None:
        """The core's record of the generation on screen (the start population's is record 0)."""
        return None if self.run is None else self.run.history[self.shown]

    @property
    def why(self) -> str:
        return self.refused if self.refused in REFUSALS else "point"

    @property
    def is_validated(self) -> bool:
        return bool(self.validated)

    @property
    def validations(self) -> tuple:
        """Every distinct design validated on this experiment, (u, row), in order: those paid for before, then those on
        screen not among them (a design is the same when its unit point is)."""
        known = {u for u, _ in self.paid}
        fresh = []
        for u, row in self.validated:
            if u not in known:
                known.add(u)
                fresh.append((u, row))
        return self.paid + tuple(fresh)

    @property
    def simulations(self) -> int:
        """The study's cost: step 1's N and every distinct design validated on its experiment."""
        return self.n + len(self.validations)

    @property
    def price(self) -> int:
        """What the study will have cost once the designs chosen are validated (N, those paid, and those that are new)."""
        known = {u for u, _ in self.paid}
        fresh = {self.searched.evaluations[i][0] for i in self.chosen} - known if self.searched is not None else set()
        return self.n + len(self.paid) + len(fresh)

    @property
    def study_rows(self) -> tuple:
        """Every design simulated by the study: the experiment's and every distinct design validated."""
        return self.rows + tuple(row for _, row in self.validations)

    @property
    def scene(self) -> tuple:
        return (self.surrogates, self.language, self.solver, self.section.key)

def predicted_point(state: ParetoOptState, run_: Run, i: int) -> tuple[float, float]:
    """Evaluation i of a run at its objectives (predicted on y^, simulated on f)."""
    return tuple(float(v) for v in outputs.objective_values(state.function, run_.evaluations[i][1]))

# ------------------------------------------------------------------------------
# The laboratory
# ------------------------------------------------------------------------------
class ParetoLab(live.Pointing, section.Viewing, Lab):
    """NSGA-II on the metamodels of step 2, generation by generation: the population moving onto the front and spreading
    along it, the predicted front, the K designs of it the validation simulates, and what the study is worth in real
    simulations against the same algorithm run on the simulation itself."""
    keys_text = "lab.pareto.opt.keys"                           # no key acts on the figure (NSGA-II has no start to move):
                                                                # said so, for assistive technology (Lab.keyboard)

    def __init__(self, function: str = FUNCTION, mode: str = TEACHER):
        self.function = RESPONSES[function].key
        self.mode = mode
        self.d = RESPONSES[function].d
        teacher = mode == TEACHER
        self.controls = section.controls(self.function) + (
            Control("solver", get_text("lab.opt.solver"), SOLVERS, 0, names=SOLVER_NAMES, tip=get_text("lab.pareto.opt.solver_tip"),
                    alone=True, icons={"mop": "mop", "real": "real"}),
            Control("population", get_text("lab.opt.population"), POPULATIONS, POPULATIONS.index(FIRST_MU),
                    names=tuple(f"μ = {mu}" for mu in POPULATIONS), tip=get_text("lab.opt.population_tip"),
                    icons={10: "population_10", 20: "population_20", 40: "population_40"}),
            Control("k", get_text("lab.pareto.opt.k"), tuple(range(1, K_MOST + 1)), FIRST_K[mode] - 1, typed=True, symbol="K",
                    shortcuts=K_PICKS if teacher else (), tip=get_text("lab.pareto.opt.k_tip")),
        )
        chip = section.chip("compromise")
        self.actions = (
            page_link(),
            Action("run", get_text("lab.opt.run"), get_text("lab.pareto.opt.run_tip"), motion="run",
                   playing_label=get_text("lab.opt.pause"), icon="play", playing_icon="pause"),
            Action("next", get_text("lab.pareto.opt.next"), get_text("lab.pareto.opt.next_tip"), motion="step", icon="step"),
            Action("restart", get_text("lab.opt.restart"), get_text("lab.pareto.opt.restart_tip"), icon="restart"),
            Action("new", get_text("lab.opt.new"), get_text("lab.pareto.opt.new_tip"), icon="seed"),
            *((chip,) if self.d > 2 else ()),
            Action("validate", get_text("lab.pareto.opt.validate", k="K"), get_text("lab.pareto.opt.validate_tip"), toggle=True,
                   primary=True),
        )
        self.data = {"seed": FIRST_SEED, "shown": 0, "stage": 0, "playing": "step", "validate": False}
        self.restore = True
        self.height = HEIGHT
        self.frame_ms = 900
        self.layout_key = None
        self.cards = {}
        self.scene = None
        self.plan = None
        self.axes: dict = {}
        self.heads: dict = {}
        self.moving: list = []
        self.board = None
        self.ring = None                       # the objective space's ring of the design pointed at, once per scene
        self.beyond = {}                       # the experiment's designs beyond the objective window, by edge (counted at a draw)
        self.drawing = caption.drawing(self.function)
        self.caption = None
        self.written = None

    # ------------------------------------------------------------------ the settings
    def settings(self) -> dict:
        """The first metamodels of the mode (so that the lab works alone), the controls and the data, the complete run
        shown (the lab opens on its finished construction), the view's sliders on its slice."""
        first = {"surrogates": first_surrogates(self.function, self.mode)} | Lab.settings(self) | section.first(self.function)
        return self.viewed(ended(first))

    def opening(self, handed: Surrogates | None = None) -> dict:
        """The first settings given the metamodels handed: no first metamodels made for nothing."""
        if handed is None:
            return self.settings()
        return self.receive({"surrogates": None} | Lab.settings(self) | section.first(self.function), handed)

    def receive(self, settings: dict, handed: Surrogates) -> dict:
        """Other metamodels from step 2: the complete run on them shown, the validation off, a solver locked now back to
        the MOP Solver."""
        return self.viewed(ended(self.allowed(settings | {"surrogates": handed})))

    def locked(self, key: str, value, settings: dict) -> str:
        """Real Run is a student's reward: locked until the bench is complete (won)."""
        if key == "solver" and value == "real" and self.mode == STUDENT and not self.won:
            return get_text("lab.opt.locked.real")
        return ""

    def allowed(self, settings: dict) -> dict:
        """The settings, or, on a solver locked now (a snapshot of another time), the same on the MOP Solver."""
        if self.locked("solver", solver_of(settings), settings):
            return settings | {"solver": SOLVERS[0]}
        return settings

    def adjust(self, settings: dict, key: str, old) -> dict:
        """A control of the view: section's rule, nothing of the study changes. K typed past the predicted front's size
        is held to it. Any control of the study: the complete run of the new settings, the validation off; a solver
        locked now is not taken. Then the sliders stand at the slice on screen."""
        viewed = self.adjust_view(settings, key, old)
        if viewed is not None:
            return viewed
        settings = self.allowed(settings)
        if key == "k" and settings.get("k") is not None:
            made = searched(settings)
            most = len(made.front) if made is not None and made.front else K_MOST
            settings = settings | {"k": min(max(int(settings["k"]), 1), most)}
        return self.viewed(ended(settings))

    # ------------------------------------------------------------------ a step of the study
    def missing(self, state: ParetoOptState) -> str:
        """Why the validation cannot be pressed: Real Run has nothing to validate, a run that cannot be computed has no
        front, one on its way has not found it yet, and a front with no feasible design predicted has nothing to offer."""
        if state.simulating:
            return get_text("lab.opt.missing.real")
        if state.run is None:
            return get_text("lab.opt.missing.refused")
        if not state.complete:
            return get_text("lab.opt.missing.running")
        return "" if state.run.front else get_text("lab.pareto.opt.missing.front")

    def finished(self, state: ParetoOptState) -> bool | None:
        """The verdict of the bench (passed): None while nothing is judged (Real Run, a run that cannot be computed or
        is on its way, nothing validated); True when every design simulated on the experiment holds at least
        game.SHARE_FRONT of HV*, more than the experiment alone (game.front_completed), False when not."""
        return passed(state)

    def charges(self, state: ParetoOptState) -> tuple:
        """The validation on screen, K simulations: (the experiment of output 0, (u, row)) for each design validated,
        which the window keeps in paid (each design once)."""
        if not state.is_validated:
            return ()
        return tuple((state.experiment, item) for item in state.validated)

    def hint(self, state: ParetoOptState) -> str:
        """A validation that does not complete the bench: one sentence of at most 100 characters, the verdict line's
        tooltip, stating what it misses WITH its numbers (apart: never two equal numbers said to differ): the share held
        but by the experiment alone ("HV/HV* = 0.951 comes from the experiment alone: ..."); else the share under
        game.SHARE_FRONT, and the shortest way on (more designs where K is under the predicted front's size, else
        better metamodels)."""
        if passed(state) is not False:
            return ""
        share = study_share(state)
        if share >= game.SHARE_FRONT:
            return get_text("lab.pareto.opt.hint.same", share=f"{share:.3f}")
        held, needed = apart(share, game.SHARE_FRONT)
        if state.searched is not None and state.k < len(state.searched.front):
            return get_text("lab.pareto.opt.hint.more", share=held, needed=needed)
        return get_text("lab.pareto.opt.hint.better", share=held, needed=needed)

    def cue(self, key: str, state: ParetoOptState) -> str:
        """A played run at its end, "complete"; the validation turned on, "better" when it added to the experiment's
        hypervolume, else "worse"; a new seed, "apply"."""
        if key in ("run", "next"):
            return "complete" if state.run is not None and state.complete else ""
        if key == "validate":
            return ("better" if verdict(state) == "better" else "worse") if state.is_validated else ""
        return "apply" if key == "new" else ""

    def received(self, state: ParetoOptState) -> tuple[str, tuple[tuple[str, str, str], ...]]:
        """What came from step 2, in the order of every bench (the owner's 2026-11-21: the sampling first, then the
        metamodels): the sampling and N (metamodel.sampled), the CoP of each response, two to a row (a warning at or below
        0, or where a metamodel cannot be computed), then the feasible designs of the experiment, last."""
        function, rows = self.function, list(sampled(state.experiment))
        cops = []
        for k, candidate in enumerate(state.surrogates.candidates):
            checked = prognoses.validation(candidate, state.surrogates.experiment_of(k))
            cops.append(None if checked is None else checked.cop)
        found = outputs.objectives(function), outputs.constraints(function)
        for group in found:
            if not group:
                continue
            values = [cops[k] for k in group]
            said = " · ".join(DASH if v is None else quality(v) for v in values)
            kind = "warning" if any(v is None or poor(v) for v in values) else "plain"
            rows.append((get_text("lab.pareto.opt.received.cop", symbols=", ".join(outputs.symbol(function, k) for k in group)),
                         said, kind))
        feasible = sum(outputs.feasible(function, row) for row in state.rows)
        rows.append((get_text("lab.pareto.opt.received.feasible"),
                     get_text("lab.pareto.opt.received.feasible_value", feasible=feasible, n=state.n), "plain"))
        return get_text("lab.opt.received"), tuple(rows[:5])

    def summary(self, state: ParetoOptState) -> tuple[str, str]:
        """Once validated, the share of HV* the study holds ("HV/HV* 0.957") with the verdict's kind; a dash before."""
        if not state.is_validated:
            return DASH, "plain"
        return get_text("lab.pareto.opt.summary", share=f"{study_share(state):.3f}"), verdict_kind(state)

    # ------------------------------------------------------------------ the state
    def state(self, settings: dict) -> ParetoOptState:
        """The state of the settings; never raises: what cannot be computed is None, and `refused` says why. A solver
        locked now is shown as the MOP Solver."""
        settings = self.allowed(settings)
        surrogates, solver = settings["surrogates"], solver_of(settings)
        mu, seed = settings["population"], settings["seed"]
        response = RESPONSES[surrogates.experiment.function]
        on_metamodels = run(surrogates, mu, seed)
        direct = run(response.key, mu, seed)
        current = on_metamodels if solver == "mop" else direct
        shown, stage = framed(current, settings)
        k, chosen, made = validation_of(self.function, settings, on_metamodels, self.mode)
        experiment = surrogates.experiment
        paid = tuple(self.paid.get(experiment, ()))
        auto = passing(self.function, settings, on_metamodels, direct, made) if self.d > 2 else None
        return ParetoOptState(response, surrogates, simulated(experiment), pareto_doe.outcomes(experiment).rows, mu, seed, solver,
                              current, refusal(surrogates, mu, seed), on_metamodels, direct, shown, stage, k, chosen, made, paid,
                              current_language(), section.of(self.function, settings, auto) if self.d > 2 else PLAIN)

    def automatic(self, settings: dict) -> tuple[float, ...] | None:
        """Where the slice of a bench of more than two inputs stands while no slider pinned it: through the compromise
        design (passing: of the validated designs once validated, else of the experiment's; in Real Run of the whole
        run's front); None for two inputs, or with nothing feasible (the middle)."""
        if self.d == 2 or settings.get("surrogates") is None:
            return None
        settings = self.allowed(settings)
        on_metamodels = searched(settings)
        _, _, made = validation_of(self.function, settings, on_metamodels, self.mode)
        return passing(self.function, settings, on_metamodels, direct_of(settings), made)

    # ------------------------------------------------------------------ the commands
    def act(self, key: str, state: ParetoOptState, settings: dict) -> dict:
        """The chip puts the slice back through the compromise; a new seed shows the complete run of the new one;
        restart shows the start population and stops; the validation turns on where it can, and off."""
        if key == section.CHIP:
            return self.viewed(section.released(settings))
        if key == "new":
            return self.viewed(ended(settings | {"seed": settings["seed"] + 1}))
        if key == "restart":
            return self.viewed(settings | {"shown": 0, "stage": 0, "playing": "step", "validate": False})
        if key == "validate":
            on = not settings.get("validate") and self.enabled("validate", state)
            return self.viewed(settings | {"validate": on})
        return super().act(key, state, settings)

    def enabled(self, key: str, state: ParetoOptState) -> bool:
        """The validation once the MOP Solver's run on screen is complete and predicts a feasible design; restart when
        the run on screen is not at its start."""
        if key == "validate":
            return not state.simulating and state.run is not None and state.complete and bool(state.run.front)
        if key == "restart":
            return state.run is not None and (state.shown, state.stage) != (0, 0)
        return True

    def offered(self, key: str, settings: dict) -> bool:
        """The chip of the slice while a slider pinned it; every other command always."""
        if key == section.CHIP:
            return section.pinned(settings)
        return True

    def rewind(self, key: str, state: ParetoOptState, settings: dict) -> dict:
        """The motion kept in the settings, the validation off; a complete run begins again BEFORE its start."""
        if key not in ("next", "run"):
            return settings
        settings = self.allowed(settings) | {"playing": "step" if key == "next" else "run", "validate": False}
        current = on_screen(settings)
        if current is None:
            return settings | {"shown": 0, "stage": 0}
        if framed(current, settings) == (current.last, current.stages[current.last]):
            settings = settings | {"shown": BEFORE, "stage": 0}
        return self.viewed(settings)

    def advance(self, state: ParetoOptState, settings: dict) -> dict | None:
        """Stepping, the next stage; running, the last stage of the next generation; from BEFORE, the start; None at
        the end."""
        settings = self.allowed(settings)
        current = on_screen(settings)
        if current is None:
            return None
        if settings["shown"] < 0:
            return settings | {"shown": 0, "stage": 0}
        shown, stage = framed(current, settings)
        if stage < current.stages[shown]:
            return settings | {"shown": shown, "stage": current.stages[shown] if settings["playing"] == "run" else stage + 1}
        if shown >= current.last:
            return None
        following = shown + 1
        return settings | {"shown": following, "stage": current.stages[following] if settings["playing"] == "run" else 1}

    def at_rest(self, settings: dict) -> bool:
        current = on_screen(self.allowed(settings))
        if current is None:
            return True
        shown, stage = framed(current, settings)
        return stage == current.stages[shown]

    def frame_time(self, settings: dict) -> int:
        """A stage is read; a whole run plays in about ten seconds, one generation per frame."""
        if settings["playing"] != "run":
            return self.frame_ms
        current = on_screen(self.allowed(settings))
        return max(80, min(350, 9000 // max(current.last if current is not None else 1, 1)))

    def link(self, key: str, state: ParetoOptState) -> str:
        """"View code" asks for NSGA-II's reading."""
        return METHOD if key == LINK else ""

    def naming(self, key: str, state: ParetoOptState) -> str:
        """The transport's name of the stage on screen; the validation's name with K in it, or, on, how to take it back;
        the chip, where it returns the slice (the middle, with no feasible design)."""
        if key == TRANSPORT:
            return transport_name(state)
        if key == "validate":
            if state.is_validated:
                return get_text("lab.opt.unvalidate")
            return get_text("lab.pareto.opt.validate_one") if state.k == 1 else get_text("lab.pareto.opt.validate", k=state.k)
        if key == section.CHIP and self.middle(state):
            return get_text("lab.view.slice.middle")
        return ""

    def tip_of(self, key: str, state: ParetoOptState) -> str:
        """The chip named "Slice at the middle" says so; the validation, named "Hide the validation" while it is on,
        says what that does."""
        if key == section.CHIP and self.middle(state):
            return get_text("lab.view.slice.middle_tip")
        if key == "validate" and state.is_validated:
            return get_text("lab.pareto.opt.unvalidate_tip")
        return ""

    def middle(self, state: ParetoOptState) -> bool:
        """The automatic slice stands at the middle of the ranges: no feasible design to pass through."""
        settings = {"surrogates": state.surrogates, "solver": state.solver, "seed": state.seed}
        return passing(self.function, settings, state.searched, state.direct, state.validated) is None

    # ------------------------------------------------------------------ what to read
    def lead(self, state: ParetoOptState) -> str:
        if state.run is None:
            return get_text(f"lab.pareto.opt.cannot.{state.why}")
        calls = get_text(f"lab.pareto.opt.calls.{state.solver}")
        if state.is_validated:
            feasible = sum(outputs.feasible(self.function, row) for _, row in state.validated)
            return get_text("lab.pareto.opt.lead.validated", k=len(state.validated), feasible=feasible,
                            share=f"{study_share(state):.3f}", experiment=f"{experiment_share(state):.3f}")
        if state.complete:
            if state.simulating:
                size_ = len(direct_front(self.function, state.mu, state.seed, len(state.run.evaluations)))
                return get_text("lab.pareto.opt.lead.complete_real", generations=state.run.last, count=len(state.run.evaluations),
                                size=size_)
            return get_text("lab.pareto.opt.lead.complete", generations=state.run.last, size=len(state.run.front))
        record = state.record
        if state.shown == 0:
            return get_text("lab.pareto.opt.lead.start", mu=state.mu, calls=calls)
        if state.stage == 1:
            return get_text("lab.pareto.opt.lead.selection", k=state.shown, pairs=len(record["pairs"]))
        if state.stage == 2:
            return get_text("lab.pareto.opt.lead.children", k=state.shown, mu=state.mu, sigma=f"{record['sigma']:.3g}", calls=calls)
        return get_text("lab.pareto.opt.lead.survival", k=state.shown, mu=state.mu)

    def metrics(self, state: ParetoOptState) -> list[Metric]:
        """MOP Solver: the generation on screen, the predicted front, the share of the study's simulated designs (with
        the verdict once validated) and the bench. Real Run: the generation, the simulations spent of the run's whole
        cost, the run's front so far and its share."""
        generation = generation_metric(state)
        if state.simulating:
            return [generation, *real_run_metrics(state)]
        return [generation, front_metric(state), share_metric(state), bench_metric(state)]

    # ------------------------------------------------------------------ the mouse
    def hit(self, figure, state: ParetoOptState, event):
        """The design under the pointer in either space: a simulated one (an index of `shown_designs`), else a predicted
        one of the population on screen (("predicted", its evaluation's index)); None elsewhere."""
        if event is None or state is None:
            return None
        found = state.simulations_shown
        crosses = state.population[0] if not state.simulating and state.run is not None else ()
        space, plane = self.axes.get("space"), self.axes.get("plane")
        if space is not None and event.inaxes is space:
            k = objectives.hit(space, self.function, [outputs.objective_values(self.function, d.row) for d in found], event)
            if k is not None:
                return k
            j = objectives.hit(space, self.function, [predicted_point(state, state.run, i) for i in crosses], event)
            return None if j is None else ("predicted", crosses[j])
        if plane is not None and event.inaxes is plane:
            k = nearest(plane, section.projected(state.section, [d.point for d in found]), event)
            if k is not None:
                return k
            bounds = state.response.bounds
            places_ = [section.mapped(bounds, state.run.evaluations[i][0]) for i in crosses]
            j = nearest(plane, section.projected(state.section, places_), event)
            return None if j is None else ("predicted", crosses[j])
        return None

    def focused(self, state: ParetoOptState, hovered):
        """The drawing's focus: a simulated design pointed at (whole, with its outputs); a predicted design pointed at,
        the place it stands at (not simulated); the place under the pointer; else the compromise of the validated
        designs once validated (in Real Run, of the run's front so far), else the experiment's; never a prediction."""
        found = state.simulations_shown
        if live.designed(hovered) and 0 <= hovered < len(found):
            design = found[hovered]
            return caption.simulated(design.kind, design.point, design.row, design.index, design.n, design.tag)
        if isinstance(hovered, tuple) and len(hovered) == 2 and hovered[0] == "predicted" and state.run is not None \
                and 0 <= hovered[1] < len(state.run.evaluations):
            return caption.under(section.mapped(state.response.bounds, state.run.evaluations[hovered[1]][0]))
        if self.pointer is not None:
            return caption.under(self.pointer)
        return state.resting

    def takes(self, state: ParetoOptState) -> bool:
        """A press on the design space takes nothing: NSGA-II starts from its own population."""
        return False

    # ------------------------------------------------------------------ the figure: layout
    def planned(self, width: float, height: float | None):
        """The plan the bench's three steps share (the beam's band where it has its room, the plane's note reserved alike:
        pareto_doe.heading), the third panel filling its rectangle (the scoreboard)."""
        return arrangement(width, height, pair="space", fill=True, drawing=self.drawing, notes=pareto_doe.heading(self.function),
                           hero=self.hero, third=not self.columned, readout=False)

    def height_for(self, width: int) -> int:
        if width >= STACK_WIDTH:
            return self.height
        return round(self.planned(width, None).room)

    def indicators(self, width: float, height: float) -> tuple | None:
        return self.planned(width, height).indicators

    def boxes(self, figure) -> dict:
        """The plane and the objective space (objectives.box: the same box in the three steps), the scoreboard under its
        card's title (panels.under_title, BOARD_SIDE in), and the places of the heads."""
        width, height = size(figure)
        plan = self.planned(width, height)

        def frac(x, y, w, h):
            return (x / width, y / height, max(w, 1.0) / width, max(h, 1.0) / height)
        framed_ = objectives.box(plan, self.function)
        boxes = {"plane": frac(*plan.plane), "space": frac(*(framed_ or (0.0, 0.0, 1.0, 1.0)))}
        if plan.check is not None and "check" in plan.cards:
            boxes["check"] = frac(*under_title(plan, "check", BOARD_SIDE))
        boxes["heads"] = places(plan, width, height)
        return boxes

    def prepare(self, figure, state: ParetoOptState) -> dict:
        """The axes of the figure: made again when its size or the language changes (with the cards and the band's
        caption, once per layout), reused otherwise."""
        width, height = size(figure)
        key = (id(figure), round(width), round(height), current_language(), self.columned)
        if key != self.layout_key or any(ax.figure is not figure for ax in self.axes.values()):
            figure.clear()
            figure.set_facecolor(palette.CARD)
            self.plan = self.planned(width, height)
            self.cards = draw_cards(figure, self.plan)
            boxes = self.boxes(figure)
            self.axes = {name: figure.add_axes(boxes[name]) for name in ("plane", "space", "check") if name in boxes}
            self.axes["plane"].set_zorder(1)
            self.heads = boxes["heads"]
            self.caption = caption.Caption(figure, self.plan, self.heads, self.function, state.section.pair, geometric=self.columned)
            self.written = self.caption.written
            self.layout_key = key
            self.scene = None
            self.board = None
            self.moving = []
            self.ring = None
        return self.axes

    def draw(self, figure, state: ParetoOptState, hovered) -> None:
        axes = self.prepare(figure, state)
        scene = (state.scene, self.truth_shown())                     # the true front comes and goes with "Show f" (2B)
        if self.scene != scene:
            self.draw_scene(axes, state)
            self.scene = scene
        for artist in self.moving:
            artist.remove()
        self.moving = []
        for text in list(figure.texts):
            if text is not self.written:
                text.remove()
        for legend in list(figure.legends):
            legend.remove()
        self.draw_plane(axes["plane"], state, hovered)
        self.draw_objectives(axes["space"], state)
        if "check" in axes:
            self.draw_board(axes["check"], state)
        self.draw_heads(figure, state)
        self.live(state, hovered)

    def live(self, state: ParetoOptState, hovered) -> None:
        """The live layer: the band's design in focus, the crosshair of the place under the pointer and the objective
        space's ring on the design pointed at."""
        if self.caption is not None:
            self.caption.show(self.focused(state, hovered), state.section.pair)
        crossed = self.crossing(state)
        ringed = []
        if self.ring is not None:
            ringed = self.ring.show(pointed_point(state, hovered))
        if self.layer is not None:
            self.layer.hold([*(self.caption.drawn if self.caption is not None else ()), *crossed, *ringed])

    # ------------------------------------------------------------------ the blocks of the column (Lab.columned)
    def blocks(self, state, width: float) -> tuple:
        """Where the window sets columned, the step's own block alone, the scoreboard (BOARD; the card of the
        cross-beams is step 1's), taking the column's room left (most None) from BRIEF_LEAST, the four routes at their
        least pitch with no line under them, so that the column never scrolls at 1536 x 864; () otherwise."""
        if not self.columned:
            return ()
        return (Block(BOARD, get_text("lab.pareto.opt.block.board"), least=BRIEF_LEAST, most=None,
                      tip=get_text("lab.pareto.opt.block.board_tip")),)

    def draw_block(self, key: str, figure, state, hovered) -> bool:
        """The scoreboard (draw_brief) on its own figure, its axes kept in block_axes (never among the figure's); False
        for any other key, and when what it shows has not changed (a frame of a run on y^ changes nothing there until its
        end, a frame of Real Run only once the run spent more)."""
        if not self.columned or state is None:
            return False
        if key != BOARD:
            return False
        width, height = size(figure)
        ax = self.block_axes.get(key)
        if ax is None or ax.figure is not figure or ax not in figure.axes:
            figure.clear()
            figure.set_facecolor(panels.BLOCK_TONE)
            ax = self.block_axes[key] = figure.add_axes((0.0, 0.0, 1.0, 1.0))
            self.briefed = None
        truth = self.truth_shown()
        shown = (round(width), round(height), figure.dpi, scoreboard(state), brief_widest(state), state.simulating, truth,
                 state.language)
        if shown == getattr(self, "briefed", None):
            return False
        self.briefed = shown
        self.draw_brief(ax, state, width, height, truth)
        return True

    def draw_brief(self, ax, state: ParetoOptState, width: float, height: float, truth: bool) -> None:
        """The scoreboard as the column's block, `width` x `height` layout pixels (248 x BRIEF_LEAST or more, the
        form of the figure's scoreboard, compact), from its top down (the room under it left empty); its
        routes BRIEF_PITCH apart, closer down to BRIEF_PITCH_LEAST where the height is short, once the lines under them
        are dropped: on its top line what the numbers are (the cost in simulations,
        the front's designs and the share HV/HV*), and no verdict there (the column's foot says it, with its mark: the
        block never repeats it); then each route
        (scoreboard) on two lines: its mark and its short name (Entry.brief), its verdict at the right where it fits;
        under them its cost as it is counted, a short bar on the one scale the four share (the N simulations of step 1
        translucent, what was not spent yet outlined), its front's size and its share (in the verdict's colour); the
        route that matters outlined. Under the routes, in the lines left, a verdict that did not fit beside its route's
        name ("HV > experiment", in its colour: only the study's route has one), then the foot on HV* only where the
        truth is shown (Lab.truth_shown), each dropped where its lines do not hold it; the SHARES are the game's score
        and stay shown. The numbers step down a size where the bars would be shorter than BRIEF_BAR_LEAST."""
        entries = scoreboard(state)
        widest = brief_widest(state)
        ax.clear()
        ax.set_facecolor(panels.BLOCK_TONE)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.set_xlim(0.0, width)
        ax.set_ylim(0.0, height)
        right = width - BRIEF_PAD
        for points in (LEGEND_LEAST, NOTE["fontsize"], SMALL["fontsize"]):     # the numbers' size: the bars keep their least
            columns = board_columns(entries, widest, points)
            costs = BRIEF_PAD + columns[0]                            # the right edges: the costs, the fronts, the shares
            fronts = right - columns[2] - BRIEF_APART
            bars = fronts - columns[1] - BRIEF_GAP - costs - BRIEF_GAP
            if bars >= BRIEF_BAR_LEAST:
                break
        bars = max(bars, 1.0)
        top = height - panels.BLOCK_TOP
        line = top - BRIEF_TOP / 2
        key = get_text("lab.pareto.opt.board.key")
        ax.text(BRIEF_PAD, line, key, ha="left", va="center", color=MUTED_INK, **SMALL)
        scale = max(max(entry.cost or 0 for entry in entries), 1)
        rows = top - BRIEF_TOP
        pitch = min(BRIEF_PITCH, max(BRIEF_PITCH_LEAST, rows / max(len(entries), 1)))
        left_out = [entry for k, entry in enumerate(entries)
                    if not self.draw_brief_entry(ax, entry, rows - k * pitch, width, (costs, fronts, right), bars, scale, points,
                                                 pitch)]
        under = rows - len(entries) * pitch                           # the lines left under the routes
        lines = max(int(under / BRIEF_LINE + 1e-6), 0)
        room = width - 2 * BRIEF_PAD
        said = []                                                     # a verdict that did not fit beside its name, in words
        for entry in left_out:                                        # (its share's colour is never alone), then HV*'s foot
            said += [(text, NOTE, VERDICT_INK[entry.kind]) for text in broken_at(entry.note, NOTE["fontsize"], room, lines - len(said))]
        if truth and lines > len(said):
            foot = get_text("lab.pareto.opt.board.foot", hv=f"{game.front(self.function).hypervolume:.3f}")
            said += [(text, SMALL, MUTED_INK) for text in broken_at(foot, SMALL["fontsize"], room, lines - len(said))]
        for k, (text, role, ink) in enumerate(said):
            ax.text(BRIEF_PAD, under - (k + 0.5) * BRIEF_LINE, text, ha="left", va="center", color=ink, **role)

    def draw_brief_entry(self, ax, entry: "Entry", top: float, width: float, columns: tuple, bars: float, scale: int,
                         points: float, pitch: float = BRIEF_PITCH) -> bool:
        """A route of the block's scoreboard from `top` down `pitch` (its lines' middles BRIEF_NAME and BRIEF_NUMBERS
        under the top at BRIEF_PITCH, nearer in proportion): its mark and its short name on its first
        line, its verdict at the right (NOTE's size, SMALL's where it does not fit); on the second its cost written, its
        bar, its front's size and its share; outlined when it is the route that matters. False where its verdict fits
        neither size beside its name (draw_brief then writes it under the routes, in words: never its colour alone)."""
        costs, fronts, right = columns
        name_line, numbers_line = top - BRIEF_NAME * pitch / BRIEF_PITCH, top - BRIEF_NUMBERS * pitch / BRIEF_PITCH
        featured, muted = entry.look == "featured", entry.look == "muted"
        ink = palette.WHITE if featured else palette.GREY if muted else palette.PROSE
        if featured:
            ax.add_patch(FancyBboxPatch((0.5, top - pitch + 2.0), width - 1.0, pitch - 3.0,
                                        boxstyle="round,pad=0,rounding_size=6", facecolor=tint(DESIGN, 0.08), edgecolor=DESIGN,
                                        linewidth=1.1, zorder=1))
        weight = {"fontweight": STRONG["fontweight"]} if featured else {}
        name = entry.brief or entry.name
        board_mark(ax, entry, BRIEF_MARK, name_line, panels.BLOCK_TONE)
        ax.text(BRIEF_NAMED, name_line, name, ha="left", va="center", color=ink, zorder=3,
                **(CAPTION | {"fontsize": LEGEND_LEAST} | weight))
        if entry.note:
            room = right - BRIEF_NAMED - text_width(name, LEGEND_LEAST, weight.get("fontweight", "normal")) - BRIEF_GAP
            role = next((role for role in (NOTE, SMALL) if text_width(entry.note, role["fontsize"]) <= room), None)
            if role is not None:
                ax.text(right, name_line, entry.note, ha="right", va="center", color=VERDICT_INK[entry.kind], zorder=3, **role)
        placed = not entry.note or role is not None
        if entry.cost is not None:
            cost_bar(ax, entry, costs + BRIEF_GAP, numbers_line - BOARD_BAR / 2, bars, scale, panels.BLOCK_TONE)
        number = READING | {"fontsize": points} | weight
        size_ = DASH if entry.size is None else str(entry.size)
        share = DASH if entry.share is None else f"{entry.share:.3f}"
        inks = (ink, ink, VERDICT_INK[entry.kind] if entry.kind != "plain" else ink)
        for x, text, colour in zip((costs, fronts, right), (entry.count, size_, share), inks, strict=True):
            ax.text(x, numbers_line, text, ha="right", va="center", color=colour, zorder=3, **number)
        return placed

    def draw_heads(self, figure, state: ParetoOptState) -> None:
        """Each panel's title and legend: the plane's names what the stage on screen draws and writes the slice; the
        objective space's what it shows; the scoreboard none (its rows name themselves)."""
        note = section.note(self.function, state.section)
        title = get_text("lab.pareto.opt.plane_title_real" if state.simulating else "lab.pareto.opt.plane_title")
        head(figure, self.heads, self.axes, "plane", title, plane_handles(state), note, "plane" in self.plan.noted,
             legend_most(self.plan, "plane"))
        title = get_text("lab.pareto.opt.space_title_real" if state.simulating else "lab.pareto.opt.space_title")
        head(figure, self.heads, self.axes, "space", title, space_handles(state, self.truth_shown()), most=legend_most(self.plan, "space"))
        if "check" in self.axes:
            head(figure, self.heads, self.axes, "check", get_text("lab.pareto.opt.check_title"), [])

    # ------------------------------------------------------------------ the figure: the scene
    def draw_scene(self, axes: dict, state: ParetoOptState) -> None:
        """What depends only on the metamodels, the solver, the slice and the language: the plane's frame, the
        constraints' limits on the slice (predicted; true in Real Run) and the experiment's designs, faint; the objective
        space's frame, the true front, the reference point r and the experiment, faint."""
        cut, function = state.section, self.function
        self.moving = []                                              # what moved stood on the axes cleared here
        plane = axes["plane"]
        plane.clear()
        style_axes(plane)
        plane.set_facecolor(palette.CARD)
        (a1, b1), (a2, b2) = section.pair_bounds(state.response.bounds, cut)
        plane.set_xlim(a1, b1)
        plane.set_ylim(a2, b2)
        plane_ticks(plane, self.plan is not None and self.plan.band is not None)
        for spine in plane.spines.values():
            spine.set_visible(True)
            spine.set_color(palette.DARK_GREY)
        name_plane(plane, state.response.units, cut.pair, many(self.function))     # x1, x2 and their units, as in the other steps
        grids = limits_of(state)
        if grids is not None:
            x1, x2 = np.meshgrid(a1 + (b1 - a1) * np.array(AXIS), a2 + (b2 - a2) * np.array(AXIS))
            found = outputs.constraints(function)
            objectives.limits(plane, x1, x2, grids, tuple(outputs.limit(function, k) for k in found))
        area = min(marker_size(state.n), 16.0)
        looks = objectives.kinds(function, state.rows)
        for look in (objectives.FEASIBLE, objectives.INFEASIBLE):
            picked = [j for j, kind in enumerate(looks) if kind is look]
            objectives.projections(plane, look, cut, [state.designs.points[j] for j in picked], [state.designs.unit[j] for j in picked],
                                   area, zorder=4, alpha=EXPERIMENT_FAINT)
        space = axes["space"]
        space.clear()
        objectives.frame(space, function)
        if self.truth_shown():                                        # the true front, a simulation's once revealed (2B)
            objectives.truth(space, function)
        objectives.reference(space, function)
        self.beyond = marked(space, function, state.rows, EXPERIMENT_FAINT)[1]      # counted with what moves (draw_objectives)
        self.ring = objectives.Ring(space, function)

    # ------------------------------------------------------------------ the figure: the plane
    def draw_plane(self, ax, state: ParetoOptState, hovered) -> None:
        """The population on screen at its projections (crosses on y^, the rank-1 ones teal; discs in Real Run, the
        rank-1 ones ringed), the stage's construction (the pairs of parents, the children yellow, the dropped a faint
        slate cross), the designs validated (and paid for before), the white ring of the design pointed at; a run that cannot
        be computed says why."""
        moving, cut, function = self.moving, state.section, self.function
        if state.run is None:
            columns = max(int(ax.get_position().width * size(ax.figure)[0] / 6.6), 12)
            moving.append(ax.text(0.5, 0.5, fill(get_text(f"lab.pareto.opt.cannot.{state.why}"), columns), transform=ax.transAxes,
                                  ha="center", va="center", color=WARNING, **NOTE, zorder=12, bbox=BOXED))
            return
        bounds = state.response.bounds
        current = state.run
        shown, ranked, now, dropped, pairs = state.population

        def placed(indices):
            units = [current.evaluations[i][0] for i in indices]
            return [section.mapped(bounds, u) for u in units], units
        if pairs:
            segments, alphas = [], []
            for i, j in pairs:
                u, w = current.evaluations[i][0], current.evaluations[j][0]
                segments.append((cut.project(section.mapped(bounds, u)), cut.project(section.mapped(bounds, w))))
                alphas.append(PAIR_ALPHA * (cut.nearness(u) + cut.nearness(w)) / 2)
            moving.append(ax.add_collection(LineCollection(segments, colors=[tint(NOW, a) for a in alphas], linewidths=PAIR_WIDTH,
                                                           zorder=5)))
        area = POPULATION_AREA * (DISC_SHARE if state.simulating else 1.0)
        for look, members in population_looks(state, shown, ranked):
            points, units = placed(members)
            moving += objectives.projections(ax, look, cut, points, units, area, grow=False, zorder=look.zorder)
        if state.simulating:
            points, units = placed([i for i in shown if i in ranked])
            moving += objectives.projections(ax, RINGED, cut, points, units, area * 2.6, grow=False, zorder=RINGED.zorder)
        if dropped:
            points, units = placed(dropped)
            moving += objectives.projections(ax, DROPPED, cut, points, units, DROPPED.area, grow=False, alpha=DROPPED_ALPHA)
        if now:
            points, units = placed(now)
            look = NOW_DISC if state.simulating else NOW_CROSS
            moving += objectives.projections(ax, look, cut, points, units, look.area, grow=False, zorder=look.zorder)
        for design in state.simulations_shown:
            if design.role == "experiment" or design.role == "run":
                continue
            look = validated_look(function, design.row) if design.role == "validated" else objectives.kinds(function, [design.row])[0]
            moving += objectives.projections(ax, look, cut, [design.point], [design.unit], 16.0, grow=False, zorder=look.zorder + 1)
        ringed = pointed_place(state, hovered)
        if ringed is not None:
            point, unit = ringed
            x, y = cut.project(point)
            grown_ = POPULATION_AREA if cut.plain else section.shrunk(POPULATION_AREA, cut.closeness(unit))
            moving.append(ax.scatter([x], [y], s=POINTED_RING * grown_, facecolors="none", edgecolors=palette.WHITE, linewidths=1.4,
                                     zorder=9, clip_on=False))

    # ------------------------------------------------------------------ the figure: the objective space
    def draw_objectives(self, ax, state: ParetoOptState) -> None:
        """The hypervolume of the study's simulated designs (Real Run: of the run's front so far), the designs paid for
        before, the population on screen at its predictions (or simulations) with the stage's construction, the
        predicted front once the run is complete, and the validated designs joined to their predictions."""
        function, moving = self.function, self.moving
        beyond = {side: list(placed) for side, placed in getattr(self, "beyond", {}).items()}     # the experiment's, faint

        def count(found: dict) -> None:
            for side, placed in found.items():
                beyond.setdefault(side, []).extend(placed)
        if state.simulating:
            front = run_front_rows(state)
            moving += objectives.hypervolume(ax, function, objectives.points_of(function, front))
            moving += front_drawn(ax, function, front)
        else:
            rows = state.study_rows
            kept = outputs.front_of(function, rows)
            moving += objectives.hypervolume(ax, function, objectives.points_of(function, [rows[i] for i in kept]))
            fresh = {u for u, _ in state.validated}
            drawn, found = marked(ax, function, [row for u, row in state.paid if u not in fresh])
            moving += drawn
            count(found)
        if state.run is not None:
            current = state.run
            shown, ranked, now, dropped, pairs = state.population
            window = objectives.window(function)
            if pairs:
                segments = [(window.placed(predicted_point(state, current, i))[:2], window.placed(predicted_point(state, current, j))[:2])
                            for i, j in pairs]
                moving.append(ax.add_collection(LineCollection(segments, colors=tint(NOW, PAIRED_ALPHA), linewidths=PAIRED_WIDTH,
                                                               zorder=5)))
            complete = state.complete and not state.simulating
            front = set(current.front) if complete else set()
            for look, members in population_looks(state, shown, ranked):
                members = [i for i in members if i not in front]
                if state.simulating:
                    drawn, found = marked(ax, function, [current.evaluations[i][1] for i in members])
                else:
                    drawn, found = objectives.at_edges(ax, function, look, [predicted_point(state, current, i) for i in members])
                moving += drawn
                count(found)
            if complete and current.front:
                ordered = sorted(window.placed(predicted_point(state, current, i))[:2] for i in current.front)
                moving += ax.plot([p[0] for p in ordered], [p[1] for p in ordered], color=palette.TEAL, linewidth=objectives.FRONT_WIDTH,
                                  linestyle=objectives.FRONT_DASH, zorder=objectives.RANKED.zorder, clip_on=False)
                points = [predicted_point(state, current, i) for i in current.front]
                drawn, found = objectives.at_edges(ax, function, objectives.RANKED, points)
                moving += drawn
                count(found)
            for look, members, alpha in ((DROPPED, dropped, DROPPED_ALPHA), (NOW_DISC if state.simulating else NOW_CROSS, now, 1.0)):
                if members:
                    drawn, found = objectives.at_edges(ax, function, look, [predicted_point(state, current, i) for i in members],
                                                       alpha)
                    moving += drawn
                    count(found)
        if state.is_validated:
            rows = [row for _, row in state.validated]
            predictions = [predicted_point(state, state.searched, i) for i in state.chosen]
            moving += objectives.validated(ax, function, rows, predictions)
        moving += objectives.counts(ax, beyond)

    # ------------------------------------------------------------------ the figure: the scoreboard
    def draw_board(self, ax, state: ParetoOptState) -> None:
        """The scoreboard in real simulations: one row per route (scoreboard), each on two lines, its mark and its name
        (its note at the right), then its cost as a bar on ONE linear scale shared by the rows (the N of step 1
        translucent, what the route spent after it solid, what it has not spent yet outlined) with the cost written as it
        is counted, its front's size and its share of HV*, in columns right-aligned on the digit; the row that matters
        outlined; at the foot HV*. Too narrow for the bars between the columns (a phone's card), each row on three
        lines: its name, its cost and its bar across, its front and its share. Drawn again only when what it shows
        changes."""
        entries = scoreboard(state)
        foot = get_text("lab.pareto.opt.board.foot", hv=f"{game.front(self.function).hypervolume:.3f}") if self.truth_shown() else ""
        widest = (str(state.run.mu * (state.run.last + 1)) if state.run is not None else "", tally(state.n, K_MOST))
        shown = (entries, foot, widest, state.language)
        if shown == self.board:
            return
        self.board = shown
        ax.clear()
        ax.set_facecolor(CARD_TONE)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
        figure_width, figure_height = size(ax.figure)
        box = ax.get_position(original=True)
        width, height = box.width * figure_width, box.height * figure_height
        ax.set_xlim(0.0, width)
        ax.set_ylim(0.0, height)
        right = width - BOARD_PAD
        for points in (LEGEND_SIZE, LEGEND_LEAST):
            columns = board_columns(entries, widest, points)
            costs = BOARD_MARK + columns[0]
            fronts = right - columns[2] - BOARD_APART
            bars = fronts - columns[1] - BOARD_GAP - costs - BOARD_GAP
            if bars >= BOARD_BAR_LEAST:
                break
        narrow = bars < BOARD_BAR_LEAST
        if narrow:
            bars = right - costs - BOARD_GAP
        bars = max(bars, 1.0)
        heading = HEADING | {"fontsize": points}
        line = height - BOARD_HEADING / 2
        if not narrow:
            ax.text(costs, line, get_text("lab.opt.board.cost"), ha="right", va="center", **heading)
        ax.text(fronts, line, get_text("lab.pareto.opt.board.front"), ha="right", va="center", **heading)
        ax.text(right, line, get_text("lab.pareto.opt.board.share"), ha="right", va="center", **heading)
        ax.plot([BOARD_PAD, right], [height - BOARD_HEADING] * 2, color=palette.DARK_GREY, linewidth=0.8)
        top = height - BOARD_HEADING - 2.0
        room = width - 2 * BOARD_PAD
        feet = (broken_at(foot, SMALL["fontsize"], room, 1) or broken_at(foot, SMALL["fontsize"], room, 2)) if foot else []
        most = BOARD_LINE_PITCH[1] * 3 if narrow else BOARD_PITCH[1]
        pitch = min(max((top - BOARD_LINE * len(feet)) / len(entries), 1.0), most)
        scale = max(max(entry.cost or 0 for entry in entries), 1)
        for k, entry in enumerate(entries):
            self.draw_entry(ax, entry, top - k * pitch, pitch, width, (costs, fronts, right), bars, scale, points, narrow)
        for k, foot_line in enumerate(feet):
            ax.text(BOARD_PAD, (len(feet) - k - 0.5) * BOARD_LINE, foot_line, ha="left", va="center", color=MUTED_INK, **SMALL)

    def draw_entry(self, ax, entry: "Entry", top: float, pitch: float, width: float, columns: tuple, bars: float, scale: int,
                   points: float, narrow: bool) -> None:
        """A row of the scoreboard from `top` down `pitch`: its mark and its name (its note at the right), its cost's bar
        on the shared scale and the cost written, its front's size and its share; outlined when it is the row that
        matters. Narrow: the cost and the bar on a line of their own, the numbers under them."""
        costs, fronts, right = columns
        if narrow:
            first, second, numbers = (top - 3.0 - (pitch - 6.0) * (k + 0.5) / 3 for k in range(3))
        else:
            first, second = top - 0.33 * pitch, top - 0.73 * pitch
            numbers = second
        featured, muted = entry.look == "featured", entry.look == "muted"
        ink = palette.WHITE if featured else palette.GREY if muted else palette.PROSE
        if featured:
            ax.add_patch(FancyBboxPatch((0.5, top - pitch + 2.0), width - 1.0, pitch - 3.0, boxstyle="round,pad=0,rounding_size=6",
                                        facecolor=tint(DESIGN, 0.08), edgecolor=DESIGN, linewidth=1.1, zorder=1))
        weight = {"fontweight": STRONG["fontweight"]} if featured else {}
        board_mark(ax, entry, BOARD_PAD + 6.0, first)
        ax.text(BOARD_MARK, first, entry.name, ha="left", va="center", color=ink, zorder=3, **(CAPTION | {"fontsize": points} | weight))
        if entry.note:
            room = right - BOARD_MARK - text_width(entry.name, points, weight.get("fontweight", "normal")) - BOARD_GAP
            for role in (NOTE, SMALL):
                if text_width(entry.note, role["fontsize"]) <= room or role is SMALL:
                    ax.text(right, first, entry.note, ha="right", va="center", color=VERDICT_INK[entry.kind], zorder=3, **role)
                    break
        if entry.cost is not None:
            colour = DESIGN if entry.shown else tint(REFERENCE, OTHER_TONE)
            low, origin = second - BOARD_BAR / 2, costs + BOARD_GAP
            spent = entry.cost - entry.pending
            gauge(ax, origin, low, bars, BOARD_BAR, entry.shared or spent, tint(DESIGN, SHARED_TONE) if entry.shared else colour,
                  low=0.0, high=scale, zorder=2)
            if spent > entry.shared > 0:
                ax.add_patch(Rectangle((origin + bars * entry.shared / scale, low), bars * (spent - entry.shared) / scale, BOARD_BAR,
                                       facecolor=colour, edgecolor="none", zorder=2.2))
            if entry.pending:
                ax.add_patch(Rectangle((origin + bars * spent / scale, low), bars * entry.pending / scale, BOARD_BAR,
                                       facecolor=CARD_TONE, edgecolor=colour, linewidth=1.0, zorder=2.3))
        number = READING | {"fontsize": points} | weight
        size_ = DASH if entry.size is None else str(entry.size)
        share = DASH if entry.share is None else f"{entry.share:.3f}"
        inks = (ink, ink, VERDICT_INK[entry.kind] if entry.kind != "plain" else ink)
        for x, y, text, colour in zip((costs, fronts, right), (second, numbers, numbers), (entry.count, size_, share), inks, strict=True):
            ax.text(x, y, text, ha="right", va="center", color=colour, zorder=3, **number)

# ------------------------------------------------------------------------------
# What is on screen
# ------------------------------------------------------------------------------
def population_on_screen(state: ParetoOptState) -> tuple:
    """The population on screen and its stage, as indices of the run's evaluations: (the population drawn, its rank-1
    members, what the stage computes now, what it dropped, the pairs of parents). The start: the start population,
    evaluated now. Selection: the parents and the pairs the tournaments chose. Crossover and mutation: the parents and
    the children, now. Survival: the survivors, and the others of parents and children, dropped. The complete run: the
    final population, no stage. Read from the core's records alone (their ranks and fronts)."""
    current = state.run
    if current is None:
        return (), set(), (), (), ()
    k, stage, history, mu = state.shown, state.stage, current.history, current.mu
    if state.complete or stage == 3:
        g = k if not state.complete else current.last
        if g == 0:
            return current.members[0], ranked_start(current), (), (), ()
        pool = current.members[g - 1] + tuple(range(mu * g, mu * (g + 1)))
        first = {pool[i] for i in history[g]["fronts"][0]}
        kept = set(current.members[g])
        dropped = () if state.complete else tuple(i for i in pool if i not in kept)
        return current.members[g], first & kept, (), dropped, ()
    if k == 0:
        return current.members[0], ranked_start(current), current.members[0], (), ()
    parents = current.members[k - 1]
    ranks = history[k]["ranks"]
    first = {parents[j] for j in range(len(parents)) if ranks[j] == 1}
    if stage == 1:
        return parents, first, (), (), tuple((parents[i], parents[j]) for i, j in history[k]["pairs"])
    return parents, first, tuple(range(mu * k, mu * (k + 1))), (), ()

def ranked_start(current: Run) -> set:
    """The rank-1 members of the start population (the ranks generation 1 computed of its parents)."""
    if current.last < 1:
        return set()
    ranks = current.history[1]["ranks"]
    return {current.members[0][j] for j in range(len(ranks)) if ranks[j] == 1}

def population_looks(state: ParetoOptState, shown, ranked) -> list:
    """The looks of the population on screen: on y^ a cross, teal for rank 1, white for the others; in Real Run the
    simulated designs' discs by their kind (the rank-1 ones ringed apart). The members the stage computes now are drawn
    by their own look (yellow), not here."""
    current = state.run
    now = set(state.population[2])
    members = [i for i in shown if i not in now]
    if state.simulating:
        looks = objectives.kinds(state.function, [current.evaluations[i][1] for i in members])
        return [(look, [i for i, kind in zip(members, looks) if kind is look]) for look in (objectives.FEASIBLE, objectives.INFEASIBLE)]
    return [(objectives.PREDICTION, [i for i in members if i not in ranked]), (objectives.RANKED, [i for i in members if i in ranked])]

def shown_designs(state: ParetoOptState) -> tuple[Shown, ...]:
    """The simulated designs on screen, the ones the pointer may point at (hovered: an index of them): the validated
    ones on screen ("validated i of K"), those paid for before ("validated i of n", among every design validated on the
    experiment), the experiment's, and in Real Run the population on screen (each a simulation). A design of the study's
    front is tagged non-dominated, a validated one predicted feasible."""
    function, bounds = state.function, state.response.bounds
    study = state.study_rows
    front_rows = {tuple(study[i]) for i in outputs.front_of(function, study)}
    made = []
    for j, (u, row) in enumerate(state.validated):
        made.append(Shown("validated", u, section.mapped(bounds, u), row, j + 1, len(state.validated), "feasible", "validated"))
    fresh = {u for u, _ in state.validated}
    everything = state.validations
    for j, (u, row) in enumerate(everything):
        if u in fresh:
            continue
        made.append(Shown("validated", u, section.mapped(bounds, u), row, j + 1, len(everything),
                          "nondominated" if tuple(row) in front_rows else "", "paid"))
    for i, row in enumerate(state.rows):
        made.append(Shown("design", tuple(state.designs.unit[i]), tuple(state.designs.points[i]), row, i + 1, state.n,
                          "nondominated" if tuple(row) in front_rows else "", "experiment"))
    if state.simulating and state.run is not None:
        current = state.run
        for i in state.population[0]:
            u, row = current.evaluations[i]
            made.append(Shown("run", u, section.mapped(bounds, u), row, i + 1, state.count, "", "run"))
    return tuple(made)

def default_focus(state: ParetoOptState, found) -> caption.Focus | None:
    """With nothing pointed at: the compromise of the validated designs once validated; in Real Run, of the run's front
    so far; else of the experiment's (never one paid for before: with the validation hidden its marks are not drawn as
    validated, so the band does not say "validated i of n" at rest); None with no feasible design."""
    function = state.function
    if state.simulating and state.run is not None:
        front = run_front_rows(state)
        best = outputs.compromise(function, list(front))
        if best is not None:
            index = run_front(state)[best]
            u, row = state.run.evaluations[index]
            return caption.simulated("run", section.mapped(state.response.bounds, u), row, index + 1, state.count)
    if state.is_validated:
        best = outputs.compromise(function, [row for _, row in state.validated])
        if best is not None:
            design = next(d for d in found if d.role == "validated" and d.index == best + 1)
            return caption.simulated(design.kind, design.point, design.row, design.index, design.n, design.tag)
    pool = [d for d in found if d.role == "experiment"]        # the validation hidden: never a design it validated, which
    best = outputs.compromise(function, [d.row for d in pool])  # is drawn as a plain disc now (no "validated i of n")
    if best is None:
        return None
    design = pool[best]
    return caption.simulated(design.kind, design.point, design.row, design.index, design.n, design.tag)

def pointed_point(state: ParetoOptState, hovered) -> tuple[float, float] | None:
    """The point of the objective space of what is pointed at (a simulated design, or a predicted one), or None."""
    found = state.simulations_shown
    if live.designed(hovered) and 0 <= hovered < len(found):
        return tuple(float(v) for v in outputs.objective_values(state.function, found[hovered].row))
    if isinstance(hovered, tuple) and len(hovered) == 2 and hovered[0] == "predicted" and state.run is not None \
            and 0 <= hovered[1] < len(state.run.evaluations):
        return predicted_point(state, state.run, hovered[1])
    return None

def pointed_place(state: ParetoOptState, hovered) -> tuple | None:
    """The place on the plane of what is pointed at: (its point in the bounds, its unit point), or None."""
    found = state.simulations_shown
    if live.designed(hovered) and 0 <= hovered < len(found):
        return found[hovered].point, found[hovered].unit
    if isinstance(hovered, tuple) and len(hovered) == 2 and hovered[0] == "predicted" and state.run is not None \
            and 0 <= hovered[1] < len(state.run.evaluations):
        u = state.run.evaluations[hovered[1]][0]
        return section.mapped(state.response.bounds, u), u
    return None

def marked(ax, function: str, rows, alpha: float = 1.0) -> tuple[list, dict]:
    """Simulated designs in the objective space by their kind (objectives.at_edges: feasible blue discs, infeasible
    hollow red rings, those beyond the window at its edge), `alpha` the set faded; their counts are left to the caller,
    which writes one count per edge for every set drawn (objectives.counts): returns the artists and the edge points."""
    rows = list(rows)
    feasible = [outputs.feasible(function, row) for row in rows]
    points = objectives.points_of(function, rows)
    drawn, beyond = objectives.at_edges(ax, function, objectives.FEASIBLE, [p for p, ok in zip(points, feasible) if ok], alpha)
    more, failed = objectives.at_edges(ax, function, objectives.INFEASIBLE, [p for p, ok in zip(points, feasible) if not ok], alpha)
    for side, placed in failed.items():
        beyond.setdefault(side, []).extend(placed)
    return drawn + more, beyond

def front_drawn(ax, function: str, rows) -> list:
    """A front of simulated designs (rows no other one dominates: Real Run's so far) as objectives.nondominated draws
    one, its staircase and a teal ring around each design, the rings smaller where the front holds many designs (a run's
    front reaches 250: rings of the experiment's size would make a band of them)."""
    if not rows:
        return []
    window = objectives.window(function)
    points = [window.placed(p)[:2] for p in objectives.points_of(function, rows)]
    path = objectives.staircase(points)
    drawn = ax.plot([p[0] for p in path], [p[1] for p in path], color=tint(palette.TEAL, 0.9), linewidth=objectives.FRONT_WIDTH,
                    zorder=objectives.NONDOMINATED.zorder - 1, clip_on=False)
    area = objectives.NONDOMINATED.area * min(1.0, FRONT_RINGS / len(points))
    return drawn + objectives.mark(ax, objectives.NONDOMINATED, [p[0] for p in points], [p[1] for p in points],
                                   sizes=[max(area, FRONT_RING_LEAST)] * len(points))

def validated_look(function: str, row) -> objectives.Look:
    """A validated design's mark: a disc in a ring, or hollow red in a ring where the simulation finds it infeasible."""
    return objectives.VALIDATED if outputs.feasible(function, row) else objectives.REFUSED

def limits_of(state: ParetoOptState) -> tuple | None:
    """The constraints on the slice's grid: the stress metamodels' slices (metamodel.predicted, cached by the slice);
    in Real Run the simulation's (true_limits). None where a metamodel cannot be computed on this slice."""
    function = state.function
    if state.simulating:
        return true_limits(function, state.section.key)
    grids = []
    for k in outputs.constraints(function):
        grid = predicted(state.surrogates.candidates[k], state.surrogates.experiment_of(k), state.section)
        if grid is None:
            return None
        grids.append(grid)
    return tuple(grids)

def run_front(state: ParetoOptState) -> tuple[int, ...]:
    """The direct run's (Real Run's) front by the stage on screen: indices of its evaluations."""
    if state.run is None or state.count < 1:
        return ()
    return direct_front(state.function, state.mu, state.seed, state.count)

def run_front_rows(state: ParetoOptState) -> tuple:
    return tuple(state.run.evaluations[i][1] for i in run_front(state)) if state.run is not None else ()

# ------------------------------------------------------------------------------
# The legends
# ------------------------------------------------------------------------------
def designs_handle() -> Line2D:
    """The experiment's designs under the run, faint, of both kinds as they are drawn: a disc and a hollow red ring
    (objectives.kinds_handle)."""
    return objectives.kinds_handle(get_text("lab.pareto.opt.legend.designs"), get_text("lab.pareto.opt.legend.designs_short"),
                                   EXPERIMENT_FAINT)

def dropped_handle() -> Line2D:
    """A design the survival dropped: the muted cross, faint (DROPPED)."""
    made = Line2D([], [], linestyle="none", marker=DROPPED.marker, markersize=7, markeredgewidth=DROPPED.width + 0.2,
                  color=tint(DROPPED.color, DROPPED_ALPHA), label=get_text("lab.pareto.opt.legend.dropped"))
    made.short = None
    return made

def now_handle(simulating: bool) -> Line2D:
    if simulating:
        made = panels.dot(NOW, get_text("lab.opt.legend.now"), size=6)
    else:
        made = Line2D([], [], linestyle="none", marker="+", markersize=8, markeredgewidth=1.8, color=NOW,
                      label=get_text("lab.opt.legend.now"))
        made.short = None
    return made

def plane_handles(state: ParetoOptState) -> list:
    """The plane's legend, in the ONE ORDER every bench's step 3 shares: the experiment's designs (step 1's), the
    population (the predicted front first: rank 1 on the metamodels), what the stage draws, the validated designs, then
    the limits, a reference (the last entries go first in a narrow head)."""
    function = state.function
    if state.run is None:
        return [designs_handle(), objectives.limit_handle(function, hat=not state.simulating)]
    shown, ranked, now, dropped, pairs = state.population
    drawn = [i for i in shown if i not in set(now)]                    # what the stage computes now has its own look
    handles = [designs_handle()]
    if state.simulating:
        if drawn:
            handles.append(panels.dot(DESIGN, get_text("lab.pareto.opt.legend.simulated"), size=6,
                                      short=get_text("lab.pareto.opt.legend.simulated_short")))
        if any(i in ranked for i in drawn):
            handles.append(objectives.handle("nondominated"))
    else:
        if any(i in ranked for i in drawn):
            handles.append(objectives.handle("ranked"))
        if any(i not in ranked for i in drawn):
            handles.append(objectives.handle("predicted"))
    if pairs:
        made = Line2D([], [], color=NOW, linewidth=1.2, label=get_text("lab.pareto.opt.legend.pairs"))
        made.short = get_text("lab.pareto.opt.legend.pairs_short")
        handles.append(made)
    if now:
        handles.append(now_handle(state.simulating))
    if dropped:
        handles.append(dropped_handle())
    if state.is_validated:
        handles.append(objectives.handle("validated"))
        if any(not outputs.feasible(function, row) for _, row in state.validated):
            handles.append(objectives.handle("infeasible"))
    return handles + [objectives.limit_handle(function, hat=not state.simulating)]

def space_handles(state: ParetoOptState, truth: bool = True) -> list:
    """The objective space's legend, in the plane's order: the experiment's designs, what the run shows (the predicted
    front, or the population and the stage; in Real Run the run's simulations and its front), the validated designs,
    then the references: the true front where it is drawn (`truth`: Lab.truth_shown) and the hypervolume (the last
    entries go first in a narrow head)."""
    function = state.function
    handles = [designs_handle()]
    if state.run is not None:
        shown, ranked, now, dropped, _ = state.population
        drawn = [i for i in shown if i not in set(now)]
        if state.simulating:
            if drawn:
                handles.append(panels.dot(DESIGN, get_text("lab.pareto.opt.legend.simulated"), size=6,
                                          short=get_text("lab.pareto.opt.legend.simulated_short")))
            if run_front(state):
                handles.append(objectives.handle("nondominated"))
        elif state.complete and state.run.front:
            handles.append(objectives.handle("front"))
        elif any(i in ranked for i in drawn):
            handles.append(objectives.handle("ranked"))
        if now:
            handles.append(now_handle(state.simulating))
        if dropped:
            handles.append(dropped_handle())
    if state.is_validated:
        handles.append(objectives.handle("validated"))
        if any(not outputs.feasible(function, row) for _, row in state.validated):
            handles.append(objectives.handle("infeasible"))
    return handles + [*((objectives.handle("truth"),) if truth else ()), objectives.handle("hypervolume")]

# ------------------------------------------------------------------------------
# The scoreboard: what each route cost and found, in real simulations
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Entry:
    """A row of the scoreboard: a route of the study (ROUTES), what it was charged in real simulations, how many
    designs its front holds and its share of HV*; None where it is not known (yet, or at all), written as a dash."""
    route: str
    name: str
    mark: str                                   # "design" (a blue disc), "validated" (a disc in a ring), "front" (a disc
                                                # in the front's teal ring: the direct run's simulations)
    cost: int | None
    shared: int                                 # of the cost, the N simulations of step 1 (translucent in the bar)
    count: str                                  # the cost as it is written: "70", "70 + 20 = 90", "70 + 20"; a dash
    size: int | None                            # the designs of its front
    share: float | None                         # its share of HV*
    look: str = "plain"                         # "plain" | "featured" | "muted"
    shown: bool = True                          # of the study on screen (blue), or of the other one (slate)
    note: str = ""                              # at the right of its name: the verdict in words
    kind: str = "plain"                         # the colour of its share and note: "ok", "error" (the verdict), "plain"
    pending: int = 0                            # of its cost, the simulations not spent yet (outlined in its bar)
    brief: str = ""                             # its short name in the column's block (lab.pareto.opt.board.brief.*)

def scoreboard(state: ParetoOptState) -> tuple[Entry, ...]:
    """The four routes, each charged what it used: (1) the experiment, N simulations; (2) through the metamodels, K
    validated (before the validation its count without a total and the new designs outlined; validated, its front, its
    share with the verdict, the row featured; a run on y^ still on its way: dashes); (3) NSGA-II directly on the
    simulation at the same cost as the study (price), the best of its three populations (same_cost), its mu in its
    name; (4) the reader's mu to its end. In Real Run the direct rows are the run on
    screen up to the stage on screen (the fourth featured, the third known once the run has spent that much) and the
    route through the metamodels the muted reference."""
    function, n, real = state.function, state.n, state.simulating
    alone = outputs.front_of(function, state.rows)
    entries = [Entry("experiment", get_text("lab.pareto.opt.board.experiment"), "design", n, n, str(n), len(alone),
                     share_of(function, state.rows), brief=get_text("lab.pareto.opt.board.brief.experiment"))]
    route = Entry("metamodels", get_text("lab.pareto.opt.board.metamodels", k=state.k), "validated", None, n, DASH, None, None,
                  look="muted", shown=not real, brief=get_text("lab.pareto.opt.board.brief.metamodels", k=state.k))
    made = state.searched
    if made is not None and made.front and (real or state.complete):
        price = state.price
        pending = price - n - len(state.paid) if not state.is_validated else 0
        count = f"{n} + {price - n}" if pending else tally(n, price - n)
        route = dataclasses.replace(route, cost=price, count=count, pending=pending,         # named by the distinct designs
                                    name=get_text("lab.pareto.opt.board.metamodels", k=price - n),     # paid, as the sum
                                    brief=get_text("lab.pareto.opt.board.brief.metamodels", k=price - n))
        if state.is_validated:
            rows = state.study_rows
            route = dataclasses.replace(route, size=len(outputs.front_of(function, rows)), share=share_of(function, rows),
                                        look="featured", kind=verdict_kind(state),
                                        note=get_text(f"lab.pareto.opt.board.verdict.{verdict(state)}"))
        elif real and not pending:                                     # every design of the K paid for before: known
            rows = state.rows + tuple(row for _, row in state.paid)
            route = dataclasses.replace(route, size=len(outputs.front_of(function, rows)), share=share_of(function, rows))
    entries.append(route)
    direct = state.direct
    priced = min(state.price, len(direct.evaluations)) if direct is not None else 0
    rival = same_cost(function, state.seed, priced) if direct is not None and not real and priced else None
    mu = rival[0] if rival is not None else state.mu
    same = Entry("same", get_text("lab.pareto.opt.board.same", mu=mu), "front", None, 0, DASH, None, None, shown=real,
                 brief=get_text("lab.pareto.opt.board.brief.same", mu=mu))
    name = "whole" if not real or state.complete else "so_far"
    whole = Entry("whole", get_text(f"lab.pareto.opt.board.{name}"), "front", None, 0, DASH, None, None,
                  look="featured" if real else "plain", shown=real, brief=get_text(f"lab.pareto.opt.board.brief.{name}"))
    if direct is not None:
        count = state.count if real else len(direct.evaluations)
        front = direct_front(function, state.mu, state.seed, count)
        whole = dataclasses.replace(whole, cost=count, count=str(count), size=len(front),
                                    share=front_share(function, tuple(direct.evaluations[i][1] for i in front)))
        if made is not None and made.front and (not real or count >= priced):
            if real:                                                  # the run on screen, up to the study's cost
                front = direct_front(function, state.mu, state.seed, priced)
                said = (len(front), front_share(function, tuple(direct.evaluations[i][1] for i in front)))
            else:                                                     # the best of the three populations at that cost
                said = (len(rival[1]), rival[2])
            same = dataclasses.replace(same, cost=priced, count=str(priced), size=said[0], share=said[1])
    return tuple(entries + [same, whole])

@lru_cache(maxsize=256)
def same_cost(function: str, seed: int, count: int) -> tuple[int, tuple[int, ...], float]:
    """NSGA-II directly on the simulation at the study's cost, so that the comparison cannot flatter the study: each
    population of POPULATIONS (10, 20, 40; the seed on screen) charged from its first simulation and stopped after
    `count` of them (direct_front: a generation cut where the cost falls in it), the best by its share of HV* (the
    smallest mu among equal shares; mu = 40 has barely left its start at 90 simulations): (its mu, its front, indices of
    that run's evaluations, its share). Cached, as the direct fronts are (real simulations are cheap here)."""
    best = None
    for mu in POPULATIONS:
        found = run(function, mu, seed)
        front = direct_front(function, mu, seed, min(count, len(found.evaluations)))
        share = front_share(function, tuple(found.evaluations[i][1] for i in front))
        if best is None or share > best[2]:
            best = (mu, front, share)
    return best

def brief_widest(state: ParetoOptState) -> tuple[str, str]:
    """The widest costs the scoreboard keeps room for: the whole direct run's (mu (1 + G)) and the study's at K_MOST
    (draw_board's and draw_brief's)."""
    return (str(state.run.mu * (state.run.last + 1)) if state.run is not None else "", tally(state.n, K_MOST))

def board_columns(entries, widest: tuple, points: float) -> tuple[float, float, float]:
    """The widths of the scoreboard's three columns of numbers (the costs, the fronts' sizes, the shares) at `points`,
    as many characters of the monospace (in the featured row's weight) as their longest text may be (each row's, the
    whole direct run's cost, the study's widest), and their headings: a column keeps its width from a frame to the next."""
    weight = STRONG["fontweight"]

    def measured(texts) -> float:
        return max(number_width("0" * len(text), points, weight) for text in texts)
    costs = [entry.count for entry in entries] + [text for text in widest if text] + [DASH]
    sizes = [str(entry.size) for entry in entries if entry.size is not None] + ["888"]
    return (max(measured(costs), text_width(get_text("lab.opt.board.cost"), points)),
            max(measured(sizes), text_width(get_text("lab.pareto.opt.board.front"), points)),
            max(measured([WIDEST_SHARE]), text_width(get_text("lab.pareto.opt.board.share"), points)))

def board_mark(ax, entry: Entry, x: float, y: float, tone: str = CARD_TONE) -> None:
    """The mark of a route before its name: the designs' blue disc (the experiment); a disc in a ring (the validated
    designs); a disc in the front's teal ring (the direct run's simulations and their front); a route not on screen in
    slate, a row not known yet translucent; edged in the tone it stands on (the card's, or the block's)."""
    alpha = 0.55 if entry.look == "muted" else 1.0
    colour = DESIGN if entry.shown or entry.mark == "design" else REFERENCE
    ax.scatter([x], [y], s=26, c=colour, edgecolors=tone, linewidths=0.6, zorder=4, alpha=alpha)
    if entry.mark == "validated":
        ax.scatter([x], [y], s=70, facecolors="none", edgecolors=colour, linewidths=1.1, zorder=4, alpha=alpha)
    elif entry.mark == "front":
        ax.scatter([x], [y], s=70, facecolors="none", edgecolors=palette.TEAL if entry.shown else REFERENCE, linewidths=1.1,
                   zorder=4, alpha=alpha)

# ------------------------------------------------------------------------------
# The verdict and the game
# ------------------------------------------------------------------------------
def experiment_share(state: ParetoOptState) -> float:
    """The experiment's own share of HV*: its N designs alone."""
    return share_of(state.function, state.rows)

def study_share(state: ParetoOptState) -> float:
    """The study's share of HV*: every design simulated on the experiment (its N, every distinct design validated)."""
    return share_of(state.function, state.study_rows)

def verdict(state: ParetoOptState) -> str:
    """The study against the experiment alone, an exact fact: "better" when its share of HV* is larger, "same" when
    equal (the validated designs added nothing: dominated, or infeasible); "" before the validation. Adding designs never
    lowers a hypervolume, so there is no "worse"."""
    if not state.is_validated:
        return ""
    return "better" if study_share(state) > experiment_share(state) else "same"

def verdict_kind(state: ParetoOptState) -> str:
    return "ok" if verdict(state) == "better" else "error"

def passed(state: ParetoOptState) -> bool | None:
    """The bench's verdict (the owner's 2026-11-21: passed or not, no stars): None while nothing is judged (Real Run, a
    run that cannot be computed or is on its way, nothing validated); True when every design simulated on the experiment
    holds at least game.SHARE_FRONT of HV* and more than the experiment alone (game.front_completed: the validation added
    to the front), False when not."""
    if state.simulating or state.run is None or not state.complete or not state.is_validated:
        return None
    return game.front_completed(study_share(state), experiment_share(state))

# ------------------------------------------------------------------------------
# The measures
# ------------------------------------------------------------------------------
def generation_metric(state: ParetoOptState) -> Metric:
    """The generation on screen ("30 of 30") and what it has evaluated (y^; simulations in Real Run), or, while
    stepped, the stage."""
    total = state.run.last if state.run is not None else pareto.GENERATIONS
    tip = get_text("lab.pareto.opt.m.generation_tip", total=total)
    if state.run is None:
        return Metric(get_text("lab.pareto.opt.m.generation"), DASH, tip=tip)
    value = get_text("lab.opt.m.generation_value", k=state.shown, total=state.run.last)
    if state.complete:
        detail = get_text(f"lab.pareto.opt.m.{'simulations' if state.simulating else 'evaluations'}", count=state.count)
    else:
        detail = get_text("lab.opt.stage.start") if state.shown == 0 else get_text(f"lab.opt.stage.ea.{state.stage}")
    return Metric(get_text("lab.pareto.opt.m.generation"), value, tip=tip, detail=detail)

def front_metric(state: ParetoOptState) -> Metric:
    """The rank-1 designs predicted feasible in the population on screen: at the end, the predicted front."""
    tip = get_text("lab.pareto.opt.m.front_tip")
    if state.run is None:
        return Metric(get_text("lab.pareto.opt.m.front"), DASH, tip=tip)
    shown, ranked, *_ = state.population
    feasible = [i for i in shown if i in ranked and state.run.violations[i] == 0]
    detail = get_text("lab.pareto.opt.m.front_detail") if feasible else get_text("lab.pareto.opt.m.front_none")
    return Metric(get_text("lab.pareto.opt.m.front"), str(len(feasible)), tip=tip, detail=detail)

def share_metric(state: ParetoOptState) -> Metric:
    """The share of HV* of the study's simulated designs: the experiment alone (and the designs paid for before) before
    the validation, said as such; validated, with the verdict and the experiment's own share beside it."""
    tip = get_text("lab.pareto.opt.m.share_tip")
    if state.is_validated:
        sign = ">" if verdict(state) == "better" else "="
        return Metric(get_text("lab.pareto.opt.m.share"), f"{study_share(state):.3f}", kind=verdict_kind(state), tip=tip,
                      detail=get_text("lab.pareto.opt.m.share_against", sign=sign, share=f"{experiment_share(state):.3f}"))
    detail = get_text("lab.pareto.opt.m.share_paid", count=len(state.paid)) if state.paid else get_text("lab.pareto.opt.m.share_alone")
    return Metric(get_text("lab.pareto.opt.m.share"), f"{study_share(state):.3f}", tip=tip, detail=detail)

def bench_metric(state: ParetoOptState) -> Metric:
    """The bench (the web's strip): "✓ complete" and the cost ("70 + 20 = 90") when complete
    (passed); "✗ not complete" and what it needs otherwise (the mark and the word, never colour alone); a dash before
    the validation."""
    needed = f"{game.SHARE_FRONT:g}"
    tip = get_text("lab.pareto.opt.m.bench_tip", needed=needed)
    verdict_ = passed(state)
    if verdict_ is None:
        return Metric(get_text("lab.opt.m.bench"), DASH, tip=tip)
    if verdict_:
        return Metric(get_text("lab.opt.m.bench"), get_text("lab.opt.m.bench_passed"), kind="ok", tip=tip,
                      detail=get_text("lab.opt.m.bench_cost", cost=tally(state.n, len(state.validations))))
    return Metric(get_text("lab.opt.m.bench"), get_text("lab.opt.m.bench_failed"), kind="error", tip=tip,
                  detail=get_text("lab.pareto.opt.m.bench_needs", needed=needed))

def real_run_metrics(state: ParetoOptState) -> list[Metric]:
    """Real Run's own three after the generation: the simulations spent of the run's whole cost, its front so far and
    its share of HV*."""
    simulations = Metric(get_text("lab.pareto.opt.m.simulations_title"), DASH, tip=get_text("lab.pareto.opt.m.simulations_tip"))
    front = Metric(get_text("lab.pareto.opt.m.run_front"), DASH, tip=get_text("lab.pareto.opt.m.run_front_tip"),
                   detail=get_text("lab.pareto.opt.m.run_front_detail"))
    share = Metric(get_text("lab.pareto.opt.m.run_share"), DASH, tip=get_text("lab.pareto.opt.m.run_share_tip"),
                   detail=get_text("lab.pareto.opt.m.run_share_detail"))
    if state.run is not None:
        rows = run_front_rows(state)
        simulations = dataclasses.replace(simulations, value=str(state.count),
                                          detail=get_text("lab.pareto.opt.m.simulations_of", total=len(state.run.evaluations)))
        front = dataclasses.replace(front, value=str(len(rows)))
        share = dataclasses.replace(share, value=f"{front_share(state.function, rows):.3f}")
    return [simulations, front, share]

def transport_name(state: ParetoOptState) -> str:
    """The name of the stage on screen beside the transport icons: "generation 12 of 30 · survival", at the end
    "complete · 1240 evaluations" (simulations in Real Run); "" for a run that cannot be computed."""
    current = state.run
    if current is None:
        return ""
    if state.complete:
        return get_text(f"lab.opt.transport.complete.{state.solver}", count=len(current.evaluations))
    stage = get_text("lab.opt.stage.start") if state.shown == 0 else get_text(f"lab.opt.stage.ea.{state.stage}")
    return get_text("lab.opt.transport.generation", k=state.shown, total=current.last, stage=stage)
