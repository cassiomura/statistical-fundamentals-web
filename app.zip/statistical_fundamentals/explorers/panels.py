# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: panels.py
# ==============================================================================
"""
The layout that the three steps of a bench share (the design of experiments, the metamodel, the optimization): a figure
of three panels (a square design space, a 3D view and a third panel) and where each panel and its title go, by the
figure's size. Every step lays its figure out with `arrangement(width, height, pair="space", fill=...)`, so that for the
same figure size the design space and the 3D view stand in the same boxes, to the pixel, in the three steps: changing
step updates one picture in place. What each panel draws belongs to its laboratory; here is only the geometry, the look
of the titles (TITLE, TITLE_LEAST) and the small helpers of the drawing that do not depend on a step.

The figure has four arrangements (`arrangement`). With room, the corner: the design space at the left, as large as the
height allows, and at its right a column with the 3D view on top and the third panel under it (the step's own: step 1's
table of the designs and step 3's convergence fill its rectangle, step 2's check is a square). Otherwise, by the width:
the three panels in a row; the design space and the 3D view side by side, the third panel left out, when there is no room
for three (the code panel open beside the lab); and the three stacked in a narrow figure. A laboratory with no use for
the 3D view when only two panels fit may ask `arrangement(width, height, pair="check")`: the design space and the third
panel side by side, two equal squares, and the 3D view a box of one pixel that the caller hides.

The corner is chosen, for any width of the side-by-side range, when it is feasible (the third panel keeps THIRD_LEAST of
height, the 3D view above it SPACE_TALL_LEAST, SPACE_FOOT clear of the third panel's head for its tick labels, and the
column COLUMN_LEAST of width) and its design space is larger than the row's (or the pair's): a figure about as wide as
tall, or taller, has no use for a row. The leasts are those that keep the corner, its three panels on show, in the
figure a window of 1280 x 720 gives a step (928 x 609). Where the width binds the
design space, the corner's column takes the figure's whole height and the design space centres on its own. Every arrangement is ONE
picture centred in the figure: what the panels leave of the width or of the height is shared as equal margins on both
sides, never a panel against one edge and a void against the other (a figure too short for its panels hangs them from the
top). In a row or a pair the 3D view takes the width the squares leave, up to SPACE_WIDE times their side.

All lengths are layout pixels (explorers/lab.size), from the figure's lower left corner. Over every panel its head: its
title and, under it, its legend in the light ink (`head`, at the places `places` gives in figure fractions), which
shrink to the room the panel has before what stands at their right; a legend too wide for one row breaks into two
(LEGEND_ROW keeps the room of two in every arrangement, so nothing moves when it does). text_width and legend_width
measure them in the figure's face, the same at any screen density (a text's outline once, at one size: its width is
linear in the size, so the sizes a title steps through cost nothing more).

The formula of the bench's response has its own block in the plan (Plan.formula): over the 3D view's title, at the top
of the corner's column, over the 3D view in the row, the pair and the stack (over the third panel in the pair of two
squares). It is as high as the WIDEST formula of the benches needs at its width (formula_room: one line, FORMULA_ONE,
or two, FORMULA_ROOM), the same for every bench and every step at a figure's size, so that nothing under it moves
between benches or steps, and no empty band waits over the 3D view where one line is enough: the room it leaves goes
to the 3D view. `typeset` sets it there in matplotlib's mathtext with the STIX face, as a paper does, on one line or
broken in two at a top-level "+" (fitted, the rule formula_room asks too), hung from the top of its block: its first
line on the row of the panels' titles, the second under it.

matplotlib draws a 3D view in the largest square its box holds, centred, and that drawing leaves the top of its square
empty (the panes) while its tick labels and axis names hang under it: a 3D box wider than tall reaches higher into its
head (`reach`, by a share of its height), where the drawing grows without meeting the legend over it.

level_values, facets, cut_at, dot, beside, tint and subscript are the drawing's helpers: the levels of a metamodel's
faint lines on the plane (LINES their look), the cells of a surface cut at a window, a legend's mark, where a mark's
label goes so that it stays in its panel, a colour with transparency, and a number in subscript. space_ticks gives the
3D view its ticks for the room it has, the same rule in the three steps (each calls it after styling its 3D axes): a
view drawn smaller than SPACE_FEW has at most SPACE_FEW_BINS intervals per axis, so that its labels never crowd.
"""
from dataclasses import dataclass
from functools import cache

import numpy as np
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
from matplotlib.mathtext import MathTextParser
from matplotlib.path import Path
from matplotlib.textpath import TextPath
from matplotlib.ticker import AutoLocator, MaxNLocator

from statistical_fundamentals import palette
from statistical_fundamentals.explorers.lab import LAYOUT_DPI, size
from statistical_fundamentals.explorers.responses import FORMULAS

TITLE = {"color": palette.WHITE, "fontsize": 12, "fontweight": "semibold"}      # the title of a panel
TITLE_LEAST = 9.5                     # points: a title shrinks to this, to fit the room its panel has
SPACE_WIDE = 1.3                      # in a row or a pair: the 3D view is at most this wide, in sides of the squares
# The figure's layout, in layout pixels (explorers/lab.size)
ROW_LEAST = 1020                      # a narrower figure has no room for the three panels in a row
STACK_WIDTH = 620                     # a narrower figure stacks them (the code panel open beside the lab leaves more)
LEGEND_SIZE, LEGEND_LEAST = 10.5, 10.0        # points: a legend shrinks to fit its panel, then breaks into two rows
LEGEND_INK = palette.WHITE            # the labels of a legend: the light ink, read at a glance
HANDLE_LENGTH, HANDLE_HEIGHT, HANDLE_PAD = 1.5, 0.9, 0.5    # a legend's handle and the gap to its label, in font sizes
COLUMN_SPACING, LEGEND_PITCH = 1.1, 1.45                    # between the entries of a row; from a row to the next (font sizes)
HEAD_GAP = 14.0                       # layout pixels between a title or a legend and the next panel's
EDGE, TITLE_ROW, LEGEND_ROW = 6.0, 30.0, 40.0     # above a panel: the figure's edge, the line of its title, two rows of legend
HEAD = EDGE + TITLE_ROW + LEGEND_ROW
TITLE_DROP = 25.0                     # the baseline of a title, from the top of its block
LEGEND_DROP = 7.0                     # the top of a legend, under its title's baseline
FORMULA_PX, FORMULA_LEAST = 16.0, 12.0        # layout pixels: the size of the formula's type, and the least it shrinks to
FORMULA_ROOM, FORMULA_ONE = 76.0, 42.0     # the formula's block over the 3D view's title, for two lines of the tallest
                                           # formula (Branin's fractions) or one, with air under them (formula_room)
FORMULA_SPACING = 1.05                # between its two lines, in heights of a line
FORMULA_SLACK = 4.0                   # layout pixels: what a line drawn may take beyond its width measured (rounding)
FORMULA_INK = palette.WHITE
FORMULA_REACH = 8.0                   # the corner: the formula's block reaches this far into the figure's right margin
LEFT, CHECK_LEFT, RIGHT, BELOW = 62.0, 66.0, 14.0, 46.0       # the margins of the square panels (the check's ticks are wider)
SIDE_LEAST = 60.0                     # a square panel is never smaller, whatever the figure
SPACE_LEAST = 400.0                   # in a row: the least width of the 3D view
SPACE_GAP, SPACE_OVER, SPACE_RIGHT = 2.0, 16.0, 44.0          # the 3D box: beside a square panel, into its legend's line, at the edge
SPACE_REACH, SPACE_CLEAR = 0.11, 12.0 # a 3D box wider than tall reaches higher into its head by this share of its height
                                      # less this (layout pixels): its drawing's top, about 0.9 of its square, stays under
                                      # the legend's second row; its tick labels, under it, rise with it
SPACE_FOOT = 10.0                     # the corner: from the third panel's head up to the 3D box (its tick labels hang under it)
SPACE_ROOM = 44.0                     # in a row: from the 3D box to the check's block (its vertical axis and the name of it)
SPACE_INSET = 34.0                    # the title of the 3D view, from the left of its box
PAIR_SHARE, PAIR_MOST, PAIR_GAP = 0.46, 480.0, 12.0           # side by side: the block of the design space
STACK_SIDE = 380.0                    # stacked: the largest side of the square panels
SPACE_SHARE = 0.72                    # stacked: the height of the 3D view, of the figure's width
COLUMN_LEAST, COLUMN_MOST, COLUMN_GAP = 400.0, 1.25, 8.0      # the corner's column: least width; most width, in heights of the
                                                              # picture; from the design space's edge to the column
THIRD_SHARE, THIRD_LEAST = 0.36, 160.0       # the corner: the third panel's share of the column's height, and its least height
TALL_SIDE_LEAST = 400.0               # the tall corner (column taller than the design space) needs the space this large at least
SPACE_TALL_LEAST = 170.0              # the corner: the least height of the 3D view's box (the two leasts let the corner, with
                                      # its third panel, hold the figure a window of 1280 x 720 gives: 928 x 609)
RANK_INSET, RANK_LEFT = 14.0, 16.0    # the competition: from the left of the check's block; from the figure's edge
SUBSCRIPTS = "₀₁₂₃₄₅₆₇₈₉"
LEVELS = 14                           # the level lines of a metamodel's surface on the plane (level_values)
LINES = {"colors": palette.GREY, "linewidths": 0.7, "alpha": 0.55, "zorder": 1, "linestyles": "solid"}    # their look: faint, under
                                                                  # everything, solid below 0 too (a dashed line is a method's model)
LABEL_OFFSET, LABEL_EDGE = (7.0, 6.0), 0.9      # a mark's label (beside): its offset in points; flipped past this share
MEASURE_POINTS = 10.0                # the size a text is measured at once (text_width scales it: extents are linear in the size)
SPACE_FEW, SPACE_FEW_BINS = 280.0, 4  # a 3D view drawn smaller than this (layout pixels: the square its box holds) has at
                                      # most this many intervals per axis: at 1280 x 720 (about 196 px) the default eight
                                      # labels of x1 crowd into each other

# ------------------------------------------------------------------------------
# The layout
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Plan:
    """The figure's panels, in layout pixels from the figure's lower left corner, each a box (left, bottom, width,
    height): the design space (a square of side `side`), the third panel (the check, a square; in the corner the
    convergence may fill a rectangle), the 3D view and the competition; where each panel's title begins (its left and
    the top of its block); and the formula's block, over the 3D view's title (its left, its bottom, the width it may
    take, its height: formula_room for that width less the figure's edge above it)."""
    kind: str                                   # "corner", "row", "pair" (the third panel left out, or two squares), "stack"
    side: float
    plane: tuple[float, float, float, float]
    check: tuple[float, float, float, float] | None     # None when it is left out
    space: tuple[float, float, float, float]
    ranking: tuple[float, float, float, float]
    heads: dict
    formula: tuple[float, float, float, float]
    room: float                                 # the height the figure needs (a figure as tall as that has no margin)

def arrangement(width: float, height: float | None, pair: str = "space", fill: bool = False) -> Plan:
    """The panels as large as the figure allows; height None: a figure as tall as it needs (height_for), which has no
    corner. From STACK_WIDTH on the corner is taken when it is feasible and its design space is larger than that of the
    row (width from ROW_LEAST) or of the pair (below it); `fill` lets the third panel fill its rectangle in the corner
    (a convergence curve) instead of being a square (the check, a measure of the diagonal).
    Row: the squares take the height left under their titles, while the 3D view between them keeps SPACE_LEAST (more
    when the squares are small: up to SPACE_WIDE sides). Pair: the design space and the 3D view side by side, the 3D view
    as wide as the width allows, up to SPACE_WIDE sides but at least SPACE_LEAST. pair="check" (width below ROW_LEAST, the
    3D view left out): the design space and the third panel, two squares of the same side, as large as the height and the
    width allow; its Plan has kind "pair" and a check, its box of the 3D view is one pixel (to hide) and its box of the
    competition is the check's; only the titles of the two squares are placed (a figure as tall as it needs, height
    None, has squares of at most STACK_SIDE). Stacked, the squares are as wide as the figure allows, STACK_SIDE at most,
    and smaller in a figure too short for the three."""
    if width < STACK_WIDTH:
        return stack(width, height)
    flat = row(width, height) if width >= ROW_LEAST else pair_squares(width, height) if pair == "check" else pair_space(width, height)
    if height is None:
        return flat
    raised = corner(width, height, fill)
    return raised if raised is not None and raised.side > flat.side else flat

def hung(height: float, group: float) -> float:
    """The bottom of a group of panels `group` high in a figure `height` high: centred, or hung from the top when it
    is taller than the figure."""
    return (height - group) / 2 if height >= group else height - group

def row(width: float, height: float | None) -> Plan:
    """The three panels in a row, the 3D view between the squares."""
    height = height or 0.0
    room = width - LEFT - CHECK_LEFT - RIGHT - SPACE_GAP - SPACE_ROOM             # for the two squares and the 3D view
    side = max(min(height - HEAD - BELOW, (room - SPACE_LEAST) / 2), SIDE_LEAST)
    wide = max(min(room - 2 * side, max(SPACE_LEAST, SPACE_WIDE * side)), 1.0)
    left = max(width - (LEFT + 2 * side + SPACE_GAP + wide + SPACE_ROOM + CHECK_LEFT + RIGHT), 0.0) / 2
    group = HEAD + side + BELOW
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    space = plane + side + SPACE_GAP
    block = space + wide + SPACE_ROOM                                            # of the check: its tick labels and their name
    check = block + CHECK_LEFT
    high = formula_room(block - plane - side - SPACE_INSET)
    heads = {"plane": (plane, top), "space": (plane + side + SPACE_INSET, top - high), "check": (block + RANK_INSET, top),
             "ranking": (block + RANK_INSET, top)}
    return Plan("row", side, (plane, base, side, side), (check, base, side, side),
                reach((space, bottom, wide, group - HEAD + SPACE_OVER - high)),
                (block + RANK_INSET, base, check + side - block - RANK_INSET, side), heads,
                writing(plane + side + SPACE_INSET, top, block, high), group)

def reach(box: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    """The 3D view's box (left, bottom, width, height) reaching higher into its head: matplotlib draws a 3D view in
    the largest square its box holds, centred, and the drawing leaves the top tenth of that square empty (the panes)
    while its tick labels and axis names hang under it. A box wider than tall grows by SPACE_REACH of its height less
    SPACE_CLEAR, up to its width (its square grows with it, and its drawing's top stays under the legend over it); a box
    already as tall as wide keeps its height, since its drawing would only rise towards its legend."""
    left, bottom, wide, tall = box
    return left, bottom, wide, min(tall + max(SPACE_REACH * tall - SPACE_CLEAR, 0.0), max(tall, wide))

def writing(left: float, top: float, right: float, high: float) -> tuple[float, float, float, float]:
    """The formula's block from `left` to `right`, under the top `top` of the 3D view's head: `high` (formula_room),
    the figure's edge left above the type; the 3D view's title begins under it."""
    return left, top - high, max(right - left, 1.0), high - EDGE

def formula_room(wide: float) -> float:
    """The height of the formula's block `wide` layout pixels wide: FORMULA_ONE when the widest formula of the benches
    keeps to one line there (typeset's rule: fitted), FORMULA_ROOM when one of them breaks into two. The same for every
    bench, so that nothing under the block moves from a bench to another; measured a hair narrower than the block, so
    that typeset, which measures the same block in figure fractions, never finds a line more than was kept."""
    return FORMULA_ONE if formula_lines(round(wide - FORMULA_SLACK - 1e-3, 3)) == 1 else FORMULA_ROOM

@cache
def formula_lines(room: float) -> int:
    """The most lines a formula of the benches (explorers/responses.FORMULAS) takes `room` layout pixels wide."""
    return max(len(fitted(terms, room)[0]) for terms in FORMULAS.values())

def pair_space(width: float, height: float | None) -> Plan:
    """The design space and the 3D view side by side, the third panel left out; the competition takes the plane's place."""
    height = height or 0.0
    block = max(PAIR_SHARE * width, min(width - SPACE_LEAST, PAIR_MOST))
    side = max(min(height - HEAD - BELOW, block - LEFT - PAIR_GAP), SIDE_LEAST)
    wide = max(min(width - LEFT - side - SPACE_GAP - SPACE_RIGHT, max(SPACE_LEAST, SPACE_WIDE * side)), 1.0)
    left = max(width - (LEFT + side + SPACE_GAP + wide + SPACE_RIGHT), 0.0) / 2
    group = HEAD + side + BELOW
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    space = plane + side + SPACE_GAP
    high = formula_room(space + wide + SPACE_RIGHT - RIGHT - plane - side - SPACE_INSET)
    heads = {"plane": (plane, top), "space": (plane + side + SPACE_INSET, top - high), "ranking": (left + RANK_LEFT, top)}
    return Plan("pair", side, (plane, base, side, side), None, reach((space, bottom, wide, group - HEAD + SPACE_OVER - high)),
                (left + RANK_LEFT, base, LEFT + side - RANK_LEFT, side), heads,
                writing(plane + side + SPACE_INSET, top, space + wide + SPACE_RIGHT - RIGHT, high), group)

def pair_squares(width: float, height: float | None) -> Plan:
    """The design space and the third panel, two equal squares; the 3D view a box of one pixel, to hide."""
    widest = (width - LEFT - CHECK_LEFT - RIGHT) / 2
    asked = height

    def squares(high: float) -> tuple[float, float]:
        """The side of the squares and the figure's height under a formula's block `high`."""
        tall = high + HEAD + max(min(widest, STACK_SIDE), SIDE_LEAST) + BELOW if asked is None else asked
        return max(min(tall - high - HEAD - BELOW, widest), SIDE_LEAST), tall
    high = FORMULA_ROOM
    side, height = squares(high)
    if formula_room(side) < high:                                     # one line over a square this large: larger squares,
        high = FORMULA_ONE                                            # whose width keeps it to one line
        side, height = squares(high)
    left = max(width - (LEFT + 2 * side + CHECK_LEFT + RIGHT), 0.0) / 2
    group = high + HEAD + side + BELOW                              # the formula over the third panel, both titles under it
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    check = plane + side + CHECK_LEFT
    heads = {"plane": (plane, top - high), "check": (check, top - high)}
    return Plan("pair", side, (plane, base, side, side), (check, base, side, side), (0.0, 0.0, 1.0, 1.0), (check, base, side, side), heads,
                writing(check, top, check + side, high), group)

def stack(width: float, height: float | None) -> Plan:
    """The three panels one under the other: the squares as wide as the figure allows, the 3D view between them."""
    asked = height

    def sized(high: float) -> tuple[float, float, float, float, float]:
        """The side of the squares, the height of the 3D view, the height the figure needs and has, and the lift of
        the picture, under a formula's block `high`."""
        side = max(min(width - CHECK_LEFT - RIGHT, STACK_SIDE), SIDE_LEAST)
        tall = SPACE_SHARE * width
        fixed = 3 * HEAD + 2 * BELOW - SPACE_OVER + EDGE + high
        room = fixed + 2 * side + tall
        lift, height = 0.0, asked
        if height is None:
            height = room
        elif height < room:                                           # a figure too short: everything smaller, in proportion
            share = max(height - fixed, 0.0) / (2 * side + tall)
            side, tall = max(side * share, SIDE_LEAST), max(tall * share, SIDE_LEAST)
        else:
            lift = (height - room) / 2
        return side, tall, room, height, lift

    def plane_of(side: float) -> float:
        return max(width - (CHECK_LEFT + side + RIGHT), 0.0) / 2 + CHECK_LEFT
    high = FORMULA_ONE                                                # one line, if the block it leaves still holds it
    side, tall, room, height, lift = sized(high)
    if formula_room(width - RIGHT - plane_of(side)) > high:
        high = FORMULA_ROOM
        side, tall, room, height, lift = sized(high)
    plane = plane_of(side)
    left = plane - CHECK_LEFT
    top = height - lift                                               # the design space
    base = top - HEAD - side
    middle = base - BELOW - high                                      # the 3D view, under the formula
    floor = middle - HEAD + SPACE_OVER - tall
    under = floor                                                     # the check
    low = under - HEAD - side
    heads = {"plane": (plane, top), "space": (plane, middle), "check": (plane, under), "ranking": (left + RANK_LEFT, under)}
    return Plan("stack", side, (plane, base, side, side), (plane, low, side, side), reach((0.0, floor, width, tall)),
                (left + RANK_LEFT, low, CHECK_LEFT + side - RANK_LEFT, side), heads, writing(plane, base - BELOW, width - RIGHT, high),
                room)

def corner(width: float, height: float, fill: bool) -> Plan | None:
    """The design space at the left, as large as the height allows (the column keeps COLUMN_LEAST); at its right the 3D
    view over the third panel, which takes THIRD_SHARE of the height the column has under its two titles (THIRD_LEAST at
    least). None when the figure has no room: the design space under SIDE_LEAST, or the 3D view under SPACE_TALL_LEAST.
    The third panel is a square, centred with its tick labels in the column, or, with `fill`, the whole rectangle.
    When the width binds the design space (side under the height) and it is at least TALL_SIDE_LEAST, the column is a
    picture of its own as tall as the figure, the design space centred vertically on its own: the plane's title then
    stands on another line than the 3D view's, and `head` keeps it before the column."""
    side = min(height - HEAD - BELOW, width - LEFT - COLUMN_GAP - COLUMN_LEAST - RIGHT)
    group = HEAD + side + BELOW                                       # the design space's picture
    tall = TALL_SIDE_LEAST <= side < height - HEAD - BELOW - 1e-9     # bound by the width, with height to spare: the column
    whole = height if tall else group                                 # takes the figure's height and the plane centres on its own
    column = min(width - LEFT - side - COLUMN_GAP - RIGHT, COLUMN_MOST * whole)
    high = formula_room(column + FORMULA_REACH - RANK_INSET)          # the formula's block, at the top of the column
    held = whole - 2 * HEAD - BELOW - high                            # the column's height under the formula and its two titles
    third = max(THIRD_SHARE * held, THIRD_LEAST)
    if side < SIDE_LEAST or held - third - SPACE_FOOT < SPACE_TALL_LEAST:
        return None
    left = max(width - (LEFT + side + COLUMN_GAP + column + RIGHT), 0.0) / 2
    low = hung(height, whole)                                         # the bottom of the column
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    start = plane + side + COLUMN_GAP                                 # the left of the column
    if fill:
        shape = (start + CHECK_LEFT, low + BELOW, column - CHECK_LEFT, third)
    else:
        square = min(third, column - CHECK_LEFT)
        shape = (start + (column - CHECK_LEFT - square) / 2 + CHECK_LEFT, low + BELOW, square, square)
    block = low + BELOW + third + HEAD                                # the top of the third panel's block
    over = low + whole                                                # the top of the column: the formula, then the 3D view
    space = reach((start, block + SPACE_FOOT, column + RIGHT - SPACE_RIGHT, over - high - HEAD + SPACE_OVER - block - SPACE_FOOT))
    heads = {"plane": (plane, top), "space": (start + RANK_INSET, over - high),
             "check": (shape[0] - CHECK_LEFT + RANK_INSET, block), "ranking": (start + RANK_INSET, block)}
    return Plan("corner", side, (plane, base, side, side), shape, space,
                (start + RANK_INSET, low + BELOW, column - RANK_INSET, third), heads,
                writing(start + RANK_INSET, over, start + column + FORMULA_REACH, high), whole)

def places(plan: Plan, width: float, height: float, names=None) -> dict:
    """The places of the panels' heads in figure fractions, for head: (left, baseline of the title, top of the legend)
    for each panel (those of `names` only, when given), and under the key "formula" the formula's block (x0, y0, x1, y1),
    which no title or legend at its left runs into."""
    heads = {name: (x / width, (top - TITLE_DROP) / height, (top - TITLE_DROP - LEGEND_DROP) / height)
             for name, (x, top) in plan.heads.items() if names is None or name in names}
    left, bottom, wide, tall = plan.formula
    heads["formula"] = (left / width, bottom / height, (left + wide) / width, (bottom + tall) / height)
    return heads

def head(figure, heads: dict, axes: dict, name: str, title: str, handles: list) -> None:
    """Above a panel: its title and, under it, its legend, each in the room the panel has before what stands at its
    right at the height of its head: the next panel's title on the same line, a panel on show whose box reaches that
    height (its own title elsewhere: the tall corner; the third panel of a row beside the 3D view's title), the
    formula's block. The title shrinks to fit (to TITLE_LEAST); the legend, in the light ink, to LEGEND_LEAST, then
    breaks into two rows at LEGEND_SIZE (the plan keeps the room of two rows, LEGEND_ROW, in every step), and only then
    loses its last entries (the first say what the panel is). No entry, no legend: its room stays reserved (nothing
    under it moves). `heads` is the places of the titles (figure fractions: left, baseline, legend's top; places) and
    `axes` the panels, of which only those on show count."""
    x, baseline, legend = heads[name]
    width, height = size(figure)
    room = head_room(figure, heads, axes, name)
    points = TITLE["fontsize"]
    while points > TITLE_LEAST and text_width(title, points, TITLE["fontweight"]) > room:
        points -= 0.5
    figure.text(x, baseline, title, ha="left", va="baseline", **(TITLE | {"fontsize": points}))
    rows, small = legend_rows(handles, room)
    for k, row in enumerate(row for row in rows if row):              # each row a legend of its own: no columns to align
        top = legend - k * LEGEND_PITCH * small / 72 * LAYOUT_DPI / height
        figure.legend(handles=row, loc="upper left", bbox_to_anchor=(x, top), ncol=len(row), frameon=False, fontsize=small,
                      labelcolor=LEGEND_INK, handlelength=HANDLE_LENGTH, handleheight=HANDLE_HEIGHT, columnspacing=COLUMN_SPACING,
                      handletextpad=HANDLE_PAD, borderaxespad=0.0, borderpad=0.0)

def head_room(figure, heads: dict, axes: dict, name: str) -> float:
    """The width a panel's head may take, in layout pixels: to what stands at its right in the band of its title and
    its two rows of legend (the next title on the same line, a panel on show whose box reaches that band, the formula's
    block), less HEAD_GAP; to the figure's edge when nothing does."""
    x, baseline, legend = heads[name]
    width, height = size(figure)
    low, high = legend - LEGEND_ROW / height, baseline + (TITLE_DROP - EDGE) / height      # the band of the head
    others = [other for key, (other, line, *_) in heads.items() if key != name and line == baseline and other > x
              and key in axes and axes[key].get_visible()]                     # the panels on show only
    for key, ax in axes.items():                                              # a panel at the right whose box stands at
        box = ax.get_position(original=True)                                  # the height of the head, its own title on
        if key != name and ax.get_visible() and box.x0 > x and box.y0 < high and box.y1 > low:     # another line
            beside = heads.get(key)
            others.append(min(box.x0, beside[0]) if beside is not None and beside[0] > x else box.x0)
    if "formula" in heads:
        x0, y0, _, y1 = heads["formula"]
        if x0 > x and y0 < high and y1 > low:
            others.append(x0)
    return (min(others, default=1.0) - x) * width - HEAD_GAP

def legend_rows(handles: list, room: float) -> tuple[list[list], float]:
    """The rows of a legend `room` layout pixels wide and its size in points: one row at LEGEND_SIZE, or smaller down
    to LEGEND_LEAST; else two rows, the entries in their order, broken where the longer row is the shortest, at
    LEGEND_SIZE or smaller down to LEGEND_LEAST; else, at LEGEND_LEAST, the last entries left out (the first say what the
    panel is) until two rows hold the rest."""
    labels = [handle.get_label() for handle in handles]
    for small in sizes():
        if legend_width(labels, small) <= room:
            return [list(handles)], small

    def widest(cut, small):
        return max(legend_width(labels[:cut], small), legend_width(labels[cut:], small))
    while len(handles) > 1:
        for small in sizes():
            cut = min(range(1, len(handles)), key=lambda k: widest(k, small))
            if widest(cut, small) <= room or len(handles) == 2 and small == LEGEND_LEAST:
                return [list(handles[:cut]), list(handles[cut:])], small
        handles, labels = handles[:-1], labels[:-1]
    return [list(handles)], LEGEND_LEAST

def sizes() -> list[float]:
    """The sizes a legend steps down through, in points: LEGEND_SIZE to LEGEND_LEAST by half a point."""
    return [LEGEND_SIZE - 0.5 * k for k in range(int(round((LEGEND_SIZE - LEGEND_LEAST) / 0.5)) + 1)]

# ------------------------------------------------------------------------------
# The formula of the response, typeset in the figure
# ------------------------------------------------------------------------------
def typeset(figure, heads: dict, terms: tuple[str, ...]):
    """The formula of the bench's response in its block (heads["formula"], places), as a paper sets it: mathtext in
    the STIX face, FORMULA_PX layout pixels high, white, hung from the top of its block: its first line stands on the
    row of the panels' titles (its baseline TITLE_DROP under the top of a head, as a title's), the second line under it
    when there is one. On one line when it fits the block's width; otherwise broken in two at a top-level "+" (the
    break that leaves the shorter longest line), the second line aligned after the "=" and opened by its "+"; still too
    wide, the type steps down half a pixel at a time to FORMULA_LEAST, never below (fitted). The block keeps the room
    of the lines the widest formula of the benches takes at its width (formula_room), so nothing under it moves from a
    bench to another. Returns the Text drawn (one artist, both lines)."""
    width, height = size(figure)
    x0, _, x1, y1 = heads["formula"]
    lines, px = fitted(terms, (x1 - x0) * width - FORMULA_SLACK)
    top = y1 * height + EDGE - TITLE_DROP + mathtext_ascent(lines[0], px)     # the first line's baseline on the titles' row
    return figure.text(x0, top / height, "\n".join(lines), ha="left", va="top", fontsize=px * 72 / LAYOUT_DPI, color=FORMULA_INK,
                       math_fontfamily="stix", linespacing=FORMULA_SPACING)

def fitted(terms: tuple[str, ...], room: float) -> tuple[tuple[str, ...], float]:
    """The lines of a formula `room` layout pixels wide and their size in layout pixels: the first size from FORMULA_PX
    down by half a pixel at which it fits, on one line or broken in two (layout); at FORMULA_LEAST, broken at its best
    when nothing fits."""
    px = FORMULA_PX
    lines = layout(terms, px, room)
    while lines is None and px > FORMULA_LEAST:
        px -= 0.5
        lines = layout(terms, px, room)
    if lines is None:                                                 # nothing fits: the least size, broken at its best
        lines = min(breaks(terms, px), key=lambda pair: max(mathtext_width(line, px) for line in pair))
    return tuple(lines), px

def layout(terms: tuple[str, ...], px: float, room: float) -> tuple[str, ...] | None:
    """The lines of the formula at `px` within `room` layout pixels: one line, or the break into two whose longest line
    is the shortest; None when neither fits."""
    whole = ("$" + " + ".join(terms) + "$",)
    if mathtext_width(whole[0], px) <= room:
        return whole
    fitting = [pair for pair in breaks(terms, px) if max(mathtext_width(line, px) for line in pair) <= room]
    return min(fitting, key=lambda pair: max(mathtext_width(line, px) for line in pair)) if fitting else None

def breaks(terms: tuple[str, ...], px: float) -> list[tuple[str, str]]:
    """Every break of the formula into two lines at a top-level "+": the first line, and the second set in from the
    left by the width of the formula's left side ("f(x1, x2) ="), opened by its "+"."""
    left = terms[0].split("=")[0] + "="
    indent = mathtext_width(f"${left}$", px) / px                    # in ems of the type: mathtext's \hspace
    return [("$" + " + ".join(terms[:k]) + "$", rf"$\hspace{{{indent:.3f}}}+\ " + " + ".join(terms[k:]) + "$")
            for k in range(1, len(terms))]

@cache
def mathtext_box(text: str, px: float) -> tuple[float, float, float]:
    """The width, the height and the depth (under the baseline) of a line of mathtext set in the STIX face at `px`
    layout pixels, in layout pixels."""
    parsed = MathTextParser("path").parse(text, dpi=72, prop=FontProperties(size=px * 72 / LAYOUT_DPI, math_fontfamily="stix"))
    return parsed.width * LAYOUT_DPI / 72, parsed.height * LAYOUT_DPI / 72, parsed.depth * LAYOUT_DPI / 72

def mathtext_width(text: str, px: float) -> float:
    """The width of a line of mathtext set in the STIX face at `px` layout pixels, in layout pixels."""
    return mathtext_box(text, px)[0]

def mathtext_ascent(text: str, px: float) -> float:
    """How far a line of mathtext set at `px` layout pixels rises over its baseline, in layout pixels."""
    _, high, deep = mathtext_box(text, px)
    return high - deep

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def text_width(text: str, points: float, weight: str = "normal") -> float:
    """The width of a text drawn in the figure's face at `points`, in layout pixels (the same at any screen density):
    the width of one point (width_per_point) times the size. A TextPath is the outline of the glyphs at one size scaled
    by points / FONT_SCALE, so its extents are linear in the size: a title stepped down half a point at a time, or a
    legend whose labels carry numbers, is measured once per text and weight, not once per size."""
    return points * width_per_point(text, weight)

@cache
def width_per_point(text: str, weight: str = "normal") -> float:
    """The width of a text in layout pixels per point of its size, measured once at MEASURE_POINTS: the horizontal
    extent of its outline (outline_width)."""
    path = TextPath((0, 0), text, size=MEASURE_POINTS, prop=FontProperties(weight=weight))
    return outline_width(path) * LAYOUT_DPI / 72 / MEASURE_POINTS

def outline_width(path: Path) -> float:
    """The horizontal extent of a glyph outline, exactly what path.get_extents().width gives, in one pass over its
    arrays: the points on the outline, and for every quadratic curve (on, control, on) its extreme in x where the
    derivative vanishes inside the curve, t = (p0 - p1) / (p0 - 2 p1 + p2). get_extents finds the same extremes curve by
    curve, with a polynomial root finder each: about 50 ms for a title. An outline with cubic curves (not a TrueType
    face) is measured by get_extents."""
    vertices, codes = path.vertices, path.codes
    if codes is None or not len(codes) or (codes == Path.CURVE4).any():
        return path.get_extents().width
    curve = codes == Path.CURVE3
    control = np.zeros(len(codes), dtype=bool)                        # straight outlines only ("i", "W"): no control point
    if curve.any():
        begins = curve & ~np.r_[False, curve[:-1]]                    # the runs of CURVE3 codes: control, end, control, end...
        run = np.flatnonzero(begins)[np.maximum(np.cumsum(begins) - 1, 0)]
        control = curve & ((np.arange(len(codes)) - run) % 2 == 0)
    x = vertices[:, 0]
    on = x[~control & (codes != Path.CLOSEPOLY)]
    k = np.flatnonzero(control)
    p0, p1, p2 = x[k - 1], x[k], x[k + 1]
    bend = p0 - 2 * p1 + p2
    t = np.divide(p0 - p1, bend, out=np.full(len(k), -1.0), where=bend != 0)
    inside = (t > 0) & (t < 1)
    t, p0, p1, p2 = t[inside], p0[inside], p1[inside], p2[inside]
    extremes = (1 - t) ** 2 * p0 + 2 * t * (1 - t) * p1 + t ** 2 * p2
    both = np.concatenate([on, extremes])
    return float(both.max() - both.min()) if both.size else path.get_extents().width

def legend_width(labels: list[str], points: float) -> float:
    """The width of a row of a legend: each handle, its pad, its label, and the spacing between the entries (the
    lengths head gives the legend, in multiples of the font size)."""
    em = points * LAYOUT_DPI / 72
    return (sum(text_width(label, points) for label in labels) + len(labels) * (HANDLE_LENGTH + HANDLE_PAD) * em
            + (len(labels) - 1) * COLUMN_SPACING * em)

def level_values(surface) -> list:
    """The levels of the faint lines of a metamodel's surface on a plane (step 2 under the weights, step 3 under the
    search): LEVELS of them, geometric above its least value on the grid, as the eye reads a valley; none for a flat
    surface."""
    low, high = float(np.min(surface)), float(np.max(surface))
    rise = high - low
    if not rise > 1e-12 * max(abs(low), abs(high), 1.0):
        return []
    return list(low + rise * np.geomspace(3e-4, 0.7, LEVELS))

def facets(x1: np.ndarray, x2: np.ndarray, y: np.ndarray, low: float, high: float) -> tuple[list, list, bool]:
    """The cells of a surface as polygons (x1, x2, y), each cut where it leaves the window [low, high], with the mean
    height of each polygon; and whether anything was cut. A cut follows the edges of its cell: nothing is drawn that
    the grid does not hold."""
    rows, columns = y.shape
    if ((y >= low) & (y <= high)).all():
        corners = [np.stack([x1[r:r + rows - 1, c:c + columns - 1], x2[r:r + rows - 1, c:c + columns - 1],
                             y[r:r + rows - 1, c:c + columns - 1]], axis=-1) for r, c in ((0, 0), (0, 1), (1, 1), (1, 0))]
        polygons = np.stack(corners, axis=2).reshape(-1, 4, 3)
        return list(polygons), list(polygons[:, :, 2].mean(axis=1)), False
    polygons, heights = [], []
    for r in range(rows - 1):
        for c in range(columns - 1):
            polygon = [(float(x1[i, j]), float(x2[i, j]), float(y[i, j])) for i, j in ((r, c), (r, c + 1), (r + 1, c + 1), (r + 1, c))]
            polygon = cut_at(cut_at(polygon, high, below=True), low, below=False)
            if len(polygon) >= 3:
                polygons.append(np.array(polygon))
                heights.append(sum(vertex[2] for vertex in polygon) / len(polygon))
    return polygons, heights, True

def cut_at(polygon: list, level: float, below: bool) -> list:
    """The part of a polygon below (or above) a level: where an edge crosses it, the crossing point (Sutherland-Hodgman)."""
    kept = []
    for k in range(len(polygon)):
        p, q = polygon[k - 1], polygon[k]
        p_in = p[2] <= level if below else p[2] >= level
        q_in = q[2] <= level if below else q[2] >= level
        if p_in != q_in:
            t = (level - p[2]) / (q[2] - p[2])
            kept.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]), level))
        if q_in:
            kept.append(q)
    return kept

def dot(color: str, label: str, hollow: bool = False, soft: bool = False, marker: str = "o", size: float = 8.5) -> Line2D:
    """A legend's mark: a point (hollow: a ring; soft: a translucent disc with its rim)."""
    face = "none" if hollow else tint(color, 0.42) if soft else color
    return Line2D([], [], linestyle="none", marker=marker, markersize=size, markerfacecolor=face,
                  markeredgecolor=color if hollow or soft else palette.CARD, markeredgewidth=1.5 if hollow else 0.9, label=label)

def beside(point: tuple[float, float], offset: tuple[float, float] = LABEL_OFFSET) -> dict:
    """Where the label of a mark at `point` (in the unit square of its panel) goes, as annotate's keywords: `offset`
    points up and to the right of it, or, near the top or the right edge (beyond LABEL_EDGE), under it or to its left,
    so that the label never leaves its panel into the head over it (the legend's second row stands a few pixels above)."""
    high, right = point[1] > LABEL_EDGE, point[0] > LABEL_EDGE
    return {"xytext": (-offset[0] if right else offset[0], -offset[1] if high else offset[1]), "textcoords": "offset points",
            "ha": "right" if right else "left", "va": "top" if high else "baseline"}

def tint(color: str, alpha: float) -> tuple[float, float, float, float]:
    return tuple(int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)) + (alpha,)

def subscript(number: int) -> str:
    return "".join(SUBSCRIPTS[int(digit)] for digit in str(number))

def space_ticks(ax) -> None:
    """The 3D view's ticks for the room it has (called after its axes are styled, at every draw of its scene): drawn
    smaller than SPACE_FEW (the square its box holds, in layout pixels), at most SPACE_FEW_BINS intervals on each axis,
    at round values; larger, matplotlib's own choice."""
    position = ax.get_position()
    width, height = size(ax.figure)
    small = min(position.width * width, position.height * height) < SPACE_FEW
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_major_locator(MaxNLocator(SPACE_FEW_BINS) if small else AutoLocator())
