# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: panels.py
# ==============================================================================
"""
The layout that the three steps of a bench share (the design of experiments, the metamodel, the optimization): a figure
of three panels (a square design space, a 3D view and a third panel) and where each panel and its title go, by the
figure's size. Every step lays its figure out with `arrangement(width, height, pair="space", fill=...)`, so that for the
same figure size the design space and the 3D view stand in the same boxes, to the pixel, in the three steps: changing
step updates one picture in place. What each panel draws belongs to its laboratory; here is only the geometry, the look
of the titles (TITLE, TITLE_LEAST) and the small helpers of the drawing that do not depend on a step.

The figure has four arrangements (`arrangement`). The corner: the design space at the left, as large as the height
allows, and at its right a column with the 3D view on top and the third panel under it (the step's own: step 1's table of
the designs and step 3's scoreboard fill its rectangle, step 2's check is a square). The others: the three panels in a
row; the design space and the 3D view side by side, the third panel left out (the pair); and the three stacked in a
narrow figure. A laboratory with no use for the 3D view when only two panels fit may ask `arrangement(width, height,
pair="check")`: the design space and the third panel side by side, two equal squares, and the 3D view a box of one pixel
that the caller hides.

From STACK_WIDTH up, a figure of a given height is the corner: the right column always (the owner's rule: the squares
never stand side by side), the code panel open beside the lab included. Its leasts (the third panel THIRD_LEAST of
height, the 3D view above it SPACE_TALL_LEAST once its tick labels are clear of the caption's rule (hang) and the cards
have their gaps, the column COLUMN_LEAST of width) keep the corner, its three panels on show, in the figure a window of
1280 x 720 gives a step (928 x 609). A shorter figure gives way, in this order: the third panel down to THIRD_FLOOR, the
3D view down to SPACE_FLOOR, then the caption's own height trimmed to one line at FORMULA_LEAST; the caption always stands
under the 3D view. Under that floor (532 layout pixels of height), or where the design space would be under
CORNER_SIDE_LEAST (a figure narrower than about 730), the figure falls back to the row or the pair, as a figure with no
height given does. Where the width binds the design space, the corner's column takes the figure's whole height and the
design space centres on its own. Every arrangement is ONE picture centred in the figure: what the panels leave of the
width or of the height is shared as equal margins on both sides, never a panel against one edge and a void against the
other (a figure too short for its panels hangs them from the top). In a row or a pair the 3D view takes the width the
squares leave, up to SPACE_WIDE times their side.

A bench drawn (the beams: arrangement's `drawing`) takes, from HERO_WIDTH x HERO_HEIGHT on (the window's figure at
1280 x 720 and above, the strip at its foot given to the figure), the HERO arrangement (banded: the owner's 1A and 5E):
the beam's band, a card over the whole picture (Plan.band, its block Plan.formula: explorers/caption.py draws the beam
as the hero there, explorers/sketch.hero), and under it the corner's two parts, the design space at the left and the
right column of two cards. The 3D view's card holds its view at the LEFT over the card's height and, beside it, the side:
the head (title, legend, the slice's note), a hairline (Plan.rule) and the block of the step's indicators
(Plan.indicators), which the figure leaves empty: the window lays the step's measures there (Lab.indicators) and hides
the strip. No caption stands under the 3D view then; the same boxes in the three steps. Under that size, or with `hero`
False (the web's page), the bench drawn keeps the arrangements below with its compact caption under the 3D view.

Where the window puts the step's own third panel in its column (Lab.columned: the step's blocks, the owner's design
of 2026-11-21), the three steps ask `arrangement(..., third=False)`: a plan with no third panel (Plan.alone; check
None, no card "check", the competition's box a pixel, no indicators). The corner's right column is then ONE card, the
3D view's, over the column's whole height (corner_alone), the column ALONE_SHARE of the width it shares with the design
space (alone_column, COLUMN_LEAST at least), the design space FILLING the picture's height beside it (its head on the
3D view's head's line, its axes down to the card's foot: taller than wide where the width binds, the owner's
2026-11-21 "always fit the figures to their room"); under the band the same card under the band and the design space
filling the height under it (banded_alone: no side, no indicators). That card is laid out as the owner's 2A of
2026-11-21 (alone_card): its head, the title and ONE row of legend (SPACE_HEAD, Plan.space_head; Plan.legends gives it
one row, and legend_rows keeps one: one_row), the formula of the response right under it as the figure's subtitle
(FORMULA_PX, SUBTITLE_GAP under the legend; a bench drawn keeps its compact caption at the card's foot, under the
band none), the READOUT at the card's foot under its rule (Plan.readout, READOUT high: readout writes the values the
view reads there, off its surface; arrangement's `readout` False, a bench of several responses, has none), and the 3D
box FILLING the room between (filled: the square matplotlib draws it in, Plan.space, and its vertical aspect,
Plan.aspect, from ASPECT up to ASPECT_MOST, so that the drawn box, BOX_DRAWN, is as tall for its width as its room;
the square may pass the card's edges, its drawing and labels never do: FILL_*); the note of a surface cut at the
window at the top of that room (Plan.cut, places' "cut space"). The stack keeps its cards without the third; and where
the corner has no room, the pair of the design space and the 3D view. There a bench drawn (whose true f the window's
chip "Show f" may reveal) keeps that chip's room at the right end of its 3D card's head (Plan.reveal, revealed:
REVEAL_ROOM, the widest language's; places' "chip space"), before which the head's title, the slice's note beside it
and the first row of its legend end (head, chip_room, legend_rows' `first`), and gives its design space the left
margin that the widest vertical name of its inputs needs whole and clear of the tick labels (alone_left, plane_left;
name_plane's pad, apart). A block's own figure has its plan too (block_plan: its one card "check" the whole figure,
under a head BLOCK_TOP high), painted in BLOCK_TONE, the tone of the column's raised card. With third True (the
default, and the web's page) every plan is as it always was, to the pixel.

All lengths are layout pixels (explorers/lab.size), from the figure's lower left corner. Over every panel its head: its
title and, under it, its legend in the light ink (`head`, at the places `places` gives in figure fractions), which
shrink to the room the panel has before what stands at their right; a legend too wide for one row breaks into two
(LEGEND_ROW keeps the room of two in every arrangement, so nothing moves when it does). text_width and legend_width
measure them in the figure's face, the same at any screen density (a text's outline once, at one size: its width is
linear in the size, so the sizes a title steps through cost nothing more).

The formula of the bench's response is the caption of the 3D view's card, as a paper sets one under its figure, in every
arrangement that has that card (the corner, the row, the pair, the stack): its block (Plan.formula) stands CAPTION_FOOT
over the card's foot, across the card's inner width (RANK_INSET from its sides, left-aligned with its title), under a
hairline (Plan.rule: RULE high, CAPTION_GAP over the block, in RULE_INK) that the 3D view's lowest tick label or axis
name keeps RULE_PAD over; caption_room is the whole (captioned places it). The block is as high as the WIDEST formula of
the benches needs at its width (formula_room: one line, FORMULA_ONE, or two, FORMULA_ROOM), the same for every bench
and every step at a figure's size, so that nothing over it moves between benches or steps. A bench whose caption is a
drawing, not a formula (the beam: explorers/caption.py draws it, explorers/sketch.py), asks for a block of its own height
instead (arrangement's `drawing`, passed down to row, pair_space, stack, corner and caption_room), never trimmed, the
same in its three steps; with no drawing asked, the plan is the formula's, to the pixel. A drawn bench keeps the corner
wherever a formula's bench keeps it (the same arrangement at every size): its 3D box pays what the drawing takes over the
trimmed formula, down to about 90 layout pixels at the corner's least height. `typeset` sets the formula in
matplotlib's mathtext with the STIX face, in the light ink of a legend's labels (FORMULA_INK: reference; the titles keep
the white), on one line or broken in two at a top-level "+" (fitted, the rule formula_room asks too), hung from the top
of its block. A short corner trims its block to one line at FORMULA_LEAST (FORMULA_TRIM: caption_room with trim, the
least its type allows) before it gives up the corner: every corner has its formula, always under the 3D view (the
owner's choice: never beside it). The corner of ONE card (corner_alone, the window's figure) sets it at FORMULA_PX
as the card's subtitle, under its one legend row (the owner's 2026-11-21, 2A; alone_card). Nothing floats over the
first card: the 3D view's card tops the column, on the line of the plane's title wherever the arrangement puts that title
at the top of the picture. Only the pair of two squares, which has no 3D view's card, keeps the formula over the third
panel's title, with no rule.

matplotlib draws a 3D view in the largest square its box holds, centred, and that drawing leaves the top of its square
empty (the panes) while its tick labels and axis names hang under it: a 3D box wider than tall reaches higher into its
head (`reach`, by a share of its height), where the drawing grows without meeting the legend over it, and stands over
its caption's rule by what its labels need there (`hang`: more for a small drawing, none for a large one).

The right column is two cards (Plan.cards, drawn by draw_cards): the 3D view and the third panel each on a rounded
rectangle (CARD_RADIUS, the web page's cards' 12 px) of a raised tone (CARD_TONE, palette.PANEL), told apart from the
figure by tone alone, a light of one pixel along its upper edge inside the rounding (CARD_LIGHT), each holding its
panel's head (title and legend, RANK_INSET from its left and HEAD_GAP from its right: head_room), its axes, tick labels
and axis names (CARD_FOOT under the third panel's, the caption under the 3D view's), with CARD_GAP of the page between
the two; the design space stays on the page (it is the scene). In the stack the cards span the figure (CARD_EDGE from
its sides), each inside the row a phone shows (web/bridge.crops). A laboratory draws the cards once per layout, under
every axes, and keeps them; `inner` is the room a card leaves under its head (`under_title`: under its title alone, for
a card whose content needs no legend).
In the stack the heads and the caption stand on the cards' inset (CARD_EDGE + RANK_INSET), the widest room a phone has.
A stack narrower than NARROW (a phone's panel, shown one at a time) ends its 3D box SPACE_RIGHT and STACK_LABEL before
the card's edge (the name of y inside it) and gives each head two lines of title and four rows of legend (head_rows,
Plan.head, Plan.titled: titled breaks a title in two rather than cut it; legend_rows takes more rows, then the entries'
short labels, rather than leave one out) and its third panel NARROW_THIRD more than its square; plane_ticks gives a
small design space fewer, rounder ticks.
A bench of two objectives (explorers/objectives.py) draws its OBJECTIVE SPACE, a 2D panel, in the 3D view's card in
its place: objective_box is its frame's box, the same in the three steps (under the band the card's left part, beside
the side; else under the card's head and over the caption's rule), measured on its vertical axis' name and widest tick
label so that every tick label, axis name and mark at the frame stays in the card.
The true response over a metamodel in the 3D view of steps 2 and 3 is one look, true_wire (and its legend's handle,
wire_handle): the reference's slate, bright, over a dark casing, every WIRE_STRIDE-th line of its grid; in the window's
figure (a plan alone: the owner's 3A of 2026-11-21) a fine wire over a lit surface, y^'s facets given a light by
lit_facets (brightness only, the height's colours and values as computed) so that y^ leads and f is the reference.

The figure's writing is ONE type system, the window's, named here and used by the three labs (no size, weight or face
is typed in a lab): the faces are the interface font of the column (SANS: Segoe UI) and its monospace (MONO: Consolas),
each a list resolved once among the fonts matplotlib finds (installed) and ending in matplotlib's own DejaVu (the web's
Pyodide has no Segoe UI: it registers Selawik, of the same widths, web/faces.py, and draws in DejaVu the Greek, the
subscripts and the minus sign Selawik lacks), so that a missing font is never looked for at a draw and a glyph the
first face lacks is drawn by the next; mathematics between dollars in STIX (MATH), as the formula. The roles: TITLE (a
panel's title, semibold (600: Segoe UI Semibold, Selawik's on the web) and white, at the window's heading size, 13.5
points: the owner's 2026-11-21, a card's title stands out; his 4A, semibold, so that the numbers read first), CAPTION
(a legend's labels, at LEGEND_SIZE in LEGEND_INK, the softer white: caption(points)), LABEL (an axis named in words,
muted) and NAME (an axis named by a symbol, X1, X2, Y, in STIX), the tick labels (ticks: TICK,
TICK_SMALL for the 3D view, muted), NOTE (a sentence on a panel), TAG (the name or value beside a mark), SMALL (a muted
line at a panel's foot), STRONG (the one value read first), COUNT (a count in a band), HEADING and NUMBER (a table: its
headings as muted captions, its numbers in the monospace, right-aligned on the digit), HERO (the one number a card is
about, large and bold in the interface font, the face of the strip's value: a number alone, in no column; down to
HERO_LEAST where its room asks), READING (a number read beside its name on a
card, never under 10 points; READOUT_NAME its name in the readout) and DEFINITION (a formula set small under the
number it defines). The roles carry no ink
where the ink is a meaning (NOTE, TAG, STRONG, NUMBER, HERO, READING: the lab gives its colour). What is muted and must
be read (LABEL, NAME, HEADING, a foot line) takes MUTED_INK, the column's secondary ink (4.5 : 1 at least on a card); the
tick labels keep the quieter TICK_INK. subtitle sets a caption in a legend's place (what a table's numbers are);
legend_at a legend anywhere, as head does under a title; cut_note the note of a surface cut at the 3D view's window, at
the top of its card under the legend. text_width measures the
face drawn, number_width the monospace; gauge draws a value on a scale (its track, GAUGE_TRACK, and its bar, clamped:
never longer than the scale, empty below it).

level_values, facets, cut_at, dot, beside, tint and subscript are the drawing's helpers: the levels of a metamodel's
faint lines on the plane (LINES their look), the cells of a surface cut at a window, a legend's mark, where a mark's
label goes so that it stays in its panel, a colour with transparency, and a number in subscript. space_ticks gives the
3D view its ticks for the room it has, the same rule in the three steps (each calls it after styling its 3D axes): a
view drawn smaller than SPACE_FEW has at most SPACE_FEW_BINS intervals per axis, so that its labels never crowd.
axis_name, name_plane and name_space name the axes of the design space and of the 3D view alike in the three steps:
the symbol, and the unit of the response in brackets where it has one (functions.Response.units: "$x_1$ [m]"; on the
design space x2's unit under its symbol, the name set across); a test function's symbols alone, as always. On a bench of
more than two inputs they name the pair on the axes (their `pair`, explorers/section.py; input_name: "$x_3$" and on),
and head writes the slice's note on the title's line (its `note`: the inputs held and their values, in a legend's light
ink, at the right end of the head; noted, NOTE_GAP); under the title where the title would not hold its line beside it
at TITLE_LEAST: a narrow head's second line, or, wider, a line the plan reserves that head (arrangement's `notes`,
Plan.noted, decided with the widest title of the three steps so that they keep one plan; the legend a TITLE_LINE lower:
dropped).
"""
import itertools
from dataclasses import dataclass, field, replace
from functools import cache

import numpy as np
from matplotlib.cbook import is_math_text
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
from matplotlib.mathtext import MathTextParser
from matplotlib.patheffects import withStroke
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.path import Path
from matplotlib.textpath import TextPath
from matplotlib.transforms import Affine2D
from matplotlib.ticker import AutoLocator, MaxNLocator

from statistical_fundamentals import palette
from statistical_fundamentals.explorers.lab import LAYOUT_DPI, size
from statistical_fundamentals.explorers.responses import FORMULAS

@cache
def installed(families: tuple[str, ...]) -> tuple[str, ...]:
    """The families of a list that matplotlib finds on this machine, in their order, the last one always kept (it is
    matplotlib's own: DejaVu): resolved once, so that no draw looks a font up and no missing one is ever warned about.
    A list draws each glyph in the first family that has it (Agg's fallback), and TextPath measures it the same way."""
    from matplotlib import font_manager
    found = {entry.name for entry in font_manager.fontManager.ttflist}
    return tuple(family for family in families[:-1] if family in found) + families[-1:]

# The writing of the figure: ONE type system, the window's (gui/style.py), every text of the three labs set by a role
SANS = list(installed(palette.SANS_FACES))       # the column's interface font (Segoe UI; Selawik on the web), then DejaVu Sans
MONO = list(installed(palette.MONO_FACES))       # tabulated numbers, right-aligned on the digit (Consolas), then DejaVu Mono
MATH = "stix"                                    # the mathematics of a text between dollars, as the formula's block sets it
TITLE = {"color": palette.WHITE, "fontsize": 13.5, "fontweight": "semibold", "fontfamily": SANS, "math_fontfamily": MATH}
CAPTION = {"fontfamily": SANS, "math_fontfamily": MATH}                          # a legend's labels (LEGEND_SIZE, LEGEND_INK)
MUTED_INK = palette.MUTED            # the muted ink of what must be read (a name, a heading, a foot line): 4.5 : 1 on a card
LABEL = {"color": MUTED_INK, "fontsize": 10, "fontfamily": SANS, "math_fontfamily": MATH}   # the name of an axis, muted
NAME = LABEL | {"fontsize": 12.5}       # an axis named by a symbol (X1, X2, Y: mathematics, whose italic sits small)
TICK, TICK_SMALL = 9, 8                  # points: a 2D panel's tick labels, the 3D view's (muted: TICK_INK), in SANS (ticks)
PLANE_NAME_PAD = 9                      # points: the design space's vertical name from its tick labels (name_plane)
TABLE_SIZE, TABLE_LEAST = 9.0, 8.5      # points: a table of values' numbers (bench 4's designs, nine columns), and the
                                        # least it is set in (step 1's table of intervals has its own: doe.TABLE_FONT)
NAME_TOUCH = 3.0                        # layout pixels: that name nearer a tick label than this, across and up, touches it
LINE_HEIGHT = 1.2                       # a line of text, in its size (matplotlib's): the height touches measures a name by
TICK_INK = palette.GREY               # tick labels may stay quiet
NOTE = {"fontsize": 9.5, "fontfamily": SANS, "math_fontfamily": MATH}            # a sentence on a panel; its ink is its meaning
TAG = {"fontsize": 9, "fontfamily": SANS, "math_fontfamily": MATH}               # the name or value beside a mark
SMALL = {"fontsize": 8.5, "fontfamily": SANS, "math_fontfamily": MATH}           # a muted line at a panel's foot
STRONG = {"fontsize": 11, "fontweight": "semibold", "fontfamily": SANS, "math_fontfamily": MATH}    # the one value read first
COUNT = {"fontsize": 7, "fontweight": "bold", "fontfamily": SANS}               # a count written in a band
HEADING = {"color": MUTED_INK, "fontfamily": SANS, "math_fontfamily": MATH}     # a table's headings: captions, muted (+ size)
NUMBER = {"fontfamily": MONO}                                                   # a table's numbers (+ size), right-aligned
HERO = {"fontsize": 24, "fontweight": "bold", "fontfamily": SANS, "math_fontfamily": MATH}     # the one number a card is about,
                                                                                # in the face of the strip's value (alone: no column)
HERO_LEAST = 16                       # points: a hero number too wide for its room steps down to this, never below
READING = {"fontsize": 10.5, "fontfamily": MONO}                                # a number read beside its name on a card (10 pt
                                                                                # at least: never a tick label's size)
DEFINITION = {"fontsize": 11.5, "fontfamily": SANS, "math_fontfamily": MATH}     # a formula set small under the number it defines
GAUGE_TRACK = palette.tone(55, 58, 61)     # a gauge's track: its whole scale, lighter than the card it stands on (2 : 1)
SCALE_END_ROLE = {"fontsize": TICK, "fontfamily": SANS}    # the ends of a slim scale ("0", "1": step 2's block), in TICK_INK
GAUGE_TICK = palette.GREY             # the ticks at a gauge's ends (gauge, ends): its scale seen even when the bar fills it
X1, X2, Y = "$x_1$", "$x_2$", "$y$"   # the names of the axes, set as mathematics (STIX italic), as a paper sets them
SPACE_UNIT_PAD = 0                    # points: a 3D view's name with its unit, from its tick labels (a symbol alone: 2, y's 4)
TITLE_LEAST = 9.5                     # points: a title shrinks to this, to fit the room its panel has
SPACE_WIDE = 1.3                      # in a row or a pair: the 3D view is at most this wide, in sides of the squares
# The figure's layout, in layout pixels (explorers/lab.size)
ROW_LEAST = 1020                      # a narrower figure has no room for the three panels in a row
STACK_WIDTH = 620                     # a narrower figure stacks them (the code panel open beside the lab leaves more)
LEGEND_SIZE, LEGEND_LEAST = 10.5, 10.0        # points: a legend shrinks to fit its panel, then breaks into two rows
LEGEND_INK = palette.PROSE            # the labels of a legend: the light ink, a step softer than the titles' white
HANDLE_LENGTH, HANDLE_HEIGHT, HANDLE_PAD = 1.5, 0.9, 0.5    # a legend's handle and the gap to its label, in font sizes
COLUMN_SPACING, LEGEND_PITCH = 1.1, 1.45                    # between the entries of a row; from a row to the next (font sizes)
HEAD_GAP = 14.0                       # layout pixels between a title or a legend and the next panel's
NOTE_GAP = 12.0                       # layout pixels between a panel's title and the note of its slice on the same line (head)
EDGE, TITLE_ROW, LEGEND_ROW = 6.0, 30.0, 40.0     # above a panel: the figure's edge, the line of its title, two rows of legend
HEAD = EDGE + TITLE_ROW + LEGEND_ROW
NARROW = 420.0                        # a figure narrower than this (a phone's panel, stacked) gives each head two lines of title
TITLE_LINE = 21.0                     # and four rows of legend (head_rows): a title is never cut, a legend never loses an entry;
                                      # TITLE_LINE, from a title's first line to its second
NARROW_THIRD = 140.0                  # a narrow figure's third panel is this much taller than its square: the CoP over its
                                      # check, the scoreboard's rows on their lines (layout pixels)
NARROW_ROW = 22.0                     # a row of legend in a narrow figure's head (LEGEND_PITCH at LEGEND_SIZE, rounded up)
PLANE_FEW, PLANE_FEW_BINS = 330.0, 4  # a design space smaller than this (layout pixels) has at most this many intervals per axis,
                                      # at round values (plane_ticks): its tick labels never crowd nor leave the figure
TITLE_DROP = 25.0                     # the baseline of a title, from the top of its block
LEGEND_DROP = 7.0                     # the top of a legend, under its title's baseline
FORMULA_PX, FORMULA_LEAST = 15.0, 12.0        # layout pixels: the size of the formula's type, and the least it shrinks to
FORMULA_TRIM = 30.0                   # a short corner's caption: one line at FORMULA_LEAST, as drawn at any density
FORMULA_ROOM, FORMULA_ONE = 65.0, 34.0     # the formula's lines: two lines of the tallest formula (Branin's fractions) or
                                           # one, as drawn at FORMULA_PX at any density (the box of mathtext at 100 dpi, a
                                           # pixel or three taller than its ink), rounded up (formula_room)
FORMULA_SPACING = 1.05                # between its two lines, in heights of a line
FORMULA_SLACK = 4.0                   # layout pixels: what a line drawn may take beyond its width measured (rounding)
FORMULA_INK = LEGEND_INK              # the caption is reference: the light ink of a legend's labels, a step under the titles' white
CAPTION_GAP = 6.0                     # layout pixels: from the caption's rule down to the formula's box (its ink a pixel lower)
CAPTION_FOOT = 9.0                    # from the formula's box down to its card's foot: with the box's own air under the ink,
                                      # about the room a title has over its capitals (TITLE_DROP less their height, 13): the
                                      # card reads as one frame
RULE = 1.0                            # layout pixels: the hairline over the caption, across its card's inner width
RULE_INK = (*(int(LEGEND_INK[i:i + 2], 16) / 255 for i in (1, 3, 5)), 0.08)    # the light ink, at 8 % on the card
LEFT, CHECK_LEFT, RIGHT, BELOW = 62.0, 66.0, 14.0, 46.0       # the margins of the square panels (the check's ticks are wider)
SIDE_LEAST = 60.0                     # a square panel is never smaller, whatever the figure
SPACE_LEAST = 400.0                   # in a row: the least width of the 3D view
SPACE_GAP, SPACE_OVER, SPACE_RIGHT = 2.0, 16.0, 44.0          # the 3D box: beside a square panel, into its legend's line, at the edge
SPACE_REACH, SPACE_CLEAR = 0.11, 12.0 # a 3D box wider than tall reaches higher into its head by this share of its height
                                      # less this (layout pixels): its drawing's top, about 0.9 of its square, stays under
                                      # the legend's second row; its tick labels, under it, rise with it
SPACE_HANG, SPACE_HANG_SHARE = 46.0, 0.139  # the 3D view's tick labels and axis names fall under its box by about this less this
                                      # share of the side of the square it is drawn in (layout pixels; measured at its first
                                      # angle, from 185 px, 18 under, to 330 px, inside it): hang keeps its card's foot under them
SPACE_ROOM = 60.0                     # in a row: from the 3D box to the check's block (the name of y, then the gap of the cards)
SPACE_INSET = 34.0                    # the title of the 3D view, from the left of its box
PAIR_SHARE, PAIR_MOST, PAIR_GAP = 0.46, 480.0, 12.0           # side by side: the block of the design space
STACK_SIDE = 380.0                    # stacked: the largest side of the square panels
STACK_LABEL = 20.0                    # stacked: the 3D box ends this far before SPACE_RIGHT from its card's edge (the name of y)
SPACE_SHARE = 0.72                    # stacked: the height of the 3D view, of the figure's width
COLUMN_LEAST, COLUMN_MOST, COLUMN_GAP = 400.0, 1.25, 14.0     # the corner's column: least width; most width, in heights of the
                                                              # picture; from the design space's edge to the column's cards
                                                              # (the plane's last tick label overhangs its edge by about 8)
THIRD_SHARE, THIRD_LEAST = 0.36, 145.0       # the corner: the third panel's share of the column's height, and its least height
SPACE_TALL_LEAST = 150.0              # the corner: the least height of the 3D view's box (the two leasts let the corner, with
                                      # its third panel and the cards, hold the figure a window of 1280 x 720 gives: 928 x 609)
THIRD_FLOOR = 120.0                   # a short corner: the third panel gives way down to this (its table pages, its scoreboard and
                                      # its CoP's check still read) before the caption does, then the 3D view down to SPACE_FLOOR
SPACE_FLOOR = 120.0                   # the least 3D box of a short corner: under it the figure falls back to the row or the pair
CORNER_SIDE_LEAST = 240.0             # the corner's least design space (a phone's is about as large): a figure narrower than
                                      # about 730 layout pixels, its column at COLUMN_LEAST, falls back to the pair
# The figure whose step's own panel stands in the window's column (arrangement's third=False, Plan.alone)
ALONE_SHARE = 0.5                     # the right column of ONE card (the 3D view): this share of the width the design space
                                      # and the column share, COLUMN_LEAST at least (alone_column): its 3D box 381 layout pixels
                                      # at the figures of a 1280 x 720 window (928 x 609 to 650), 515 at 1196 x 820 (the
                                      # corner's with its third panel: 202 to 256, and 370)
BLOCK_TOP = 4.0                       # a block's figure (block_plan): its content this far under its top (the window draws
                                      # the block's heading over the figure, on the card)
BLOCK_TONE = palette.theme.RAISED     # the tone of a block's card, the column's raised card ("The problem": gui/style's
                                      # QFrame#LabReceived): a block's figure is painted in it, so that it reads as the card
REVEAL_FRAME = 60.0                   # layout pixels: what the chip "Show f" takes beside its name (gui/style's ToolChip:
                                      # its two borders, CHIP_PADDING's 18 at each side, its eye MARK_SIZE and MARK_GAP)
REVEAL_ROOM = 124.0                   # the room of the chip "Show f" at the right end of the 3D view's card's head (Plan.reveal,
                                      # gui/lab_views' reveal_chip): REVEAL_FRAME and its widest name, "Mostrar f" (about 60 px
                                      # semibold, as when checked; "Show f" 45), a few pixels to spare; kept shown or not
REVEAL_HEIGHT = 28.0                  # its height (the window's chip)
REVEAL_INSET = (10.0, 8.0)            # from the 3D view's card's right edge and from its top to the chip
PLANE_EDGE = 4.0                      # the design space's vertical name keeps this off the figure's left edge (plane_left)
INK_SLACK = 2.0                       # layout pixels a text's box takes beyond its outline measured, at each side (its glyphs'
                                      # side bearings: about 1.7 for a stacked name, 0.7 for a tick label)
# The 3D view's card alone in the right column (Plan.alone: the owner's 2A of 2026-11-21, "formula as subtitle, readout at
# the foot"): its head a title and ONE row of legend, the formula under it, the drawing filling the card, the readout
SPACE_HEAD = EDGE + TITLE_ROW + NARROW_ROW    # its head: the title's line and one row of legend (alone_box)
SUBTITLE_GAP = 4.0                    # layout pixels: from that row of legend down to the formula's block (the subtitle)
READOUT_TOP, READOUT_PITCH = 22.0, 20.0       # the readout at the card's foot: its first baseline under its rule, its rows'
READOUT_ROWS, READOUT_FOOT = 2, 12.0          # pitch, its rows (the point in focus; the design under the pointer), and the
READOUT = READOUT_TOP + (READOUT_ROWS - 1) * READOUT_PITCH + READOUT_FOOT     # room under the last: the readout's height
READOUT_GAP, READOUT_NAMED = 22.0, 6.0        # between two readings of a row; from a reading's name to its number
READOUT_NAME = {"fontsize": 10.5, "fontfamily": SANS, "math_fontfamily": MATH}  # a reading's name (in its mark's ink): its
                                              # number is READING's, the monospace (tabular)
FILL_LEFT, FILL_RIGHT = 8.0, 52.0             # layout pixels: the drawing's room in its card, from the card's inner sides
FILL_BELOW, FILL_TOP = 40.0, 2.0              # (RANK_INSET in): the tick labels and names of x1 and x2 under the drawn box,
                                              # those of y at its right; the box's back edge under the head
FILL_LEAST = 150.0                    # a drawn box (the square it is drawn in) smaller than this: the corner trims its formula
ASPECT, ASPECT_MOST = 0.72, 1.1       # the vertical axis of the 3D box, in sides of its floor: today's, and the most a tall card
                                      # stretches it to (the prototype's 1.1) so that the drawing fills its card (filled)
BOX_DRAWN = ((0.60, 0.055, 0.956, 0.123, 0.861), (0.72, 0.069, 0.944, 0.102, 0.884),    # the 3D box drawn in its square (x0,
             (0.85, 0.085, 0.928, 0.083, 0.905), (1.00, 0.104, 0.910, 0.066, 0.925),    # x1, y0, y1, in sides of the square)
             (1.10, 0.118, 0.898, 0.056, 0.937), (1.25, 0.137, 0.879, 0.045, 0.951))    # by its vertical aspect, at the first
                                      # angle (VIEW, 26 and -58 degrees) and SPACE_ZOOM 1: measured, its corners projected
# The light on a metamodel's surface (the owner's 3A): a facet's colour, the height's, darker the more it turns from the light
LIGHT = (-0.45, -0.55, 0.70)          # towards the light, in the box's drawn proportions (lit_facets)
LIT_FLOOR, LIT_GAIN = 0.72, 0.38      # a facet's brightness: LIT_FLOOR turned away from it, up to LIT_FLOOR + LIT_GAIN facing it
FINE_WIRE = {"color": palette.SLATE, "linewidth": 0.8, "alpha": 0.75}      # f's wire over a lit surface (true_wire's `fine`):
FINE_CASING = (withStroke(linewidth=2.2, foreground=palette.BACKGROUND, alpha=0.45),)     # the reference, a step behind y^
# The hero arrangement of a bench drawn (banded): the beam's band over the figure, the plane and the right column under it
HERO_WIDTH, HERO_HEIGHT = 880.0, 590.0        # the least figure that takes the band (the window's figure at 1280 x 720 is
                                              # 928 x 626 on bench 3 with its view band, 1170 x 598 at 1522 x 692)
BAND_LEAST, BAND_MOST = 136.0, 198.0          # the band's height: BAND_LEAST from HERO_HEIGHT to BAND_BASE, then growing by
BAND_BASE, BAND_GROWTH = 640.0, 0.35          # BAND_GROWTH of the figure's height over BAND_BASE, up to BAND_MOST (the mock's)
BAND_SIDE = 8.0                       # the band's card from the picture's left: under it the plane's tick labels have their room
SIDED_COLUMN = 540.0                  # the least width of the right column under the band (the 3D view and its side): the
                                      # design space gives way to it where the width binds (1280 x 720)
SIDED_TOP = 4.0                       # the 3D box under the top of its card (its drawing's top tenth is empty panes)
SIDED_FOOT = 4.0                      # its lowest tick label or axis name over its card's foot (as RULE_PAD over a rule)
SIDED_ASPECT = 1.15                   # the 3D box's width, in heights: the drawing in its square and its labels at its sides
SIDED_GAP = 54.0                      # from the 3D box to the side's head (title, legend, the slice's note): the vertical
                                      # axis's tick labels and the name of y stand in it
SIDED_LEAST = 300.0                   # the side's least width, the 3D box narrower when the card would leave it less: step
                                      # 3's legend, the widest head of the three steps, holds its five entries in two rows
INDICATOR_ROW, INDICATOR_SHORT = 68.0, 46.0     # a row of the step's indicators beside the 3D view (the window's own
                                      # measures): a measure's name, its value and its qualifier folded under it in a narrow
                                      # column; its name over its value and qualifier on one line where the column is wide
SIDE_WIDE = 440.0                     # a side at least this wide has the indicators' short rows (two measures across)
INDICATOR_ROWS = 2                    # the block holds two rows at least: four measures in a grid of two columns
RULE_ABOVE, RULE_BELOW = 4.0, 7.0     # the side's hairline under the head's legend, and over the indicators' block
CUT_TOP = 8.0                         # under the band, the note of a surface cut at the window: under its 3D card's top
THIRD_SPLIT = 0.5                     # under the band, the third panel's card takes this share of the column's height ...
BAND_THIRD_FLOOR = 95.0               # ... at least THIRD_LEAST, giving way down to this before the 3D card's side is short
LEGEND_THIRD, LEGEND_ROWS_MOST = 22.0, 3      # under the band, a plane bound by the width (1280 x 720) has the height over
                                      # it: its head takes a third row of legend (LEGEND_PITCH at LEGEND_SIZE, rounded up),
                                      # so that no entry is left out of a narrow plane's legend
# The cards of the right column: the 3D view and the third panel each on a rounded card of a raised tone (cards)
CARD_TONE = palette.PANEL             # the card's tone, told apart from the figure's (palette.CARD) without a border
CARD_RADIUS = 12.0                    # layout pixels: the rounding of a card's corners (the web page's cards: 12 px)
CARD_LIGHT = 0.06                     # a card's upper edge: a light of 1 layout pixel inside its rounding, white at this share
                                      # over the card's tone (the page's cards: an inset light on their top edge)
CARD_GAP = 10.0                       # the page between the two cards (the corner and the stack), and over the stack's first
CARD_PAD = 8.0                        # inside the 3D view's card, at its right: the 3D box ends this far before SPACE_RIGHT
RULE_PAD = 5.0                        # under the 3D view's lowest tick label or axis name, over its caption's rule (hang)
CARD_FOOT = 6.0                       # the corner and the stack: under the third panel's axis name, inside its card
CARD_EDGE = 6.0                       # the stack: from the figure's sides to the cards
RANK_INSET, RANK_LEFT = 14.0, 16.0    # the competition: from the left of the check's block; from the figure's edge
SUBSCRIPTS = "₀₁₂₃₄₅₆₇₈₉"
LEVELS = 14                           # the level lines of a metamodel's surface on the plane (level_values)
LINES = {"colors": palette.GREY, "linewidths": 0.7, "alpha": 0.55, "zorder": 1, "linestyles": "solid"}    # their look: faint, under
                                                                  # everything, solid below 0 too (a dashed line is a method's model)
LABEL_OFFSET, LABEL_EDGE = (7.0, 6.0), 0.9      # a mark's label (beside): its offset in points; flipped past this share
MEASURE_POINTS = 10.0                # the size a text is measured at once (text_width scales it: extents are linear in the size)
WIRE_STRIDE = 5                       # f's wire over y^ in the 3D view (steps 2 and 3): every fifth line of the grid of 31, 7 a side
WIRE = {"color": palette.SLATE, "linewidth": 1.2, "alpha": 0.95}      # the reference's slate, bright and whole (true_wire)
WIRE_CASING = (withStroke(linewidth=3.0, foreground=palette.BACKGROUND, alpha=0.7),)    # a dark casing under the light line: it
                                                                  # reads on the dark and on the light parts of the surface alike
SPACE_FEW, SPACE_FEW_BINS = 280.0, 4  # a 3D view drawn smaller than this (layout pixels: the square its box holds) has at
                                      # most this many intervals per axis: at 1280 x 720 (about 196 px) the default eight
                                      # labels of x1 crowd into each other
SPACE_AXES = (0.559, 0.410, 0.409)    # the 3D view's x, y and vertical axes, drawn, in sides of its square (measured at its
                                      # first angle, 26 and -58 degrees, and its box aspect: the same at every size)
SPACE_NAME_OVER = 5.0                 # layout pixels: y's turned name may pass its axis by this at each end (name_space; at 900 x
                                      # 532, 9 px past it, its top touched the legend's second row)
SPACE_TICK_GAP = 8.0                  # layout pixels: the least gap between two tick labels of the 3D view's floor (space_ticks)
LABELS_APART = 1.6 * 9 / 72 * 96      # layout pixels: two TAG labels (9 points, boxed) on one vertical closer than this print
                                      # over each other (screen_gap): they are written on one line
# The objective space of a bench of two objectives (objective_box): a 2D panel in the 3D view's card, in its place
OBJECTIVE_INSET = 6.0                 # layout pixels: from the card's left to the vertical axis' name (set across, stacked)
OBJECTIVE_LABELPAD = 6.0              # points: from that name to the axis' tick labels (matplotlib's labelpad)
OBJECTIVE_TICKS = (3.0 + 3.5) * LAYOUT_DPI / 72     # layout pixels: a tick (style_axes: 3 points) and its pad (3.5 points)
OBJECTIVE_BELOW = 48.0                # from the card's foot (or the caption's rule) up to the frame: CARD_FOOT, the axis' name
                                      # across (NAME), its labelpad (2 points), the tick labels and the ticks under the frame
OBJECTIVE_TOP = 12.0                  # from the card's top (under the band) or from under the head (else) down to the frame:
                                      # the highest tick label's upper half and a mark at the frame stay in the card
OBJECTIVE_GAP = 20.0                  # under the band: from the frame's right to the side's head (the last tick label's half)
OBJECTIVE_RIGHT = 30.0                # else: from the frame's right to the card's right edge (RANK_INSET and that half)
OBJECTIVE_NAME = ("[mm]",)            # objective_box's defaults: the lines of the vertical axis' name and its widest tick label
OBJECTIVE_LABEL = "88"

# ------------------------------------------------------------------------------
# The layout
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Plan:
    """The figure's panels, in layout pixels from the figure's lower left corner, each a box (left, bottom, width,
    height): the design space (a square of side `side`), the third panel (the check, a square; in the corner the
    scoreboard may fill a rectangle), the 3D view and the competition; where each panel's title begins (its left and
    the top of its block); the formula's block (its left, its bottom, the width it may take, its height: formula_room
    for that width), the caption at the foot of the 3D view's card, under its rule (rule: its left, its bottom, its
    width; None where there is no 3D view's card and the formula stands over the third panel's title); and the cards
    under the 3D view and the third panel (cards: by the panel's name, "space" and "check", each a box of the same kind
    that holds the panel's head, its axes, its tick labels and the names of its axes, the 3D view's its caption too,
    with CARD_GAP of the page between the two; a panel left out has no card). alone: the step's own third panel stands
    in the window's column (arrangement's third=False): no third panel, no card of it, the 3D view's card alone."""
    kind: str                                   # "corner", "row", "pair" (the third panel left out, or two squares), "stack";
                                                # "block": a block's own figure in the column (block_plan)
    side: float
    plane: tuple[float, float, float, float]
    check: tuple[float, float, float, float] | None     # None when it is left out
    space: tuple[float, float, float, float]
    ranking: tuple[float, float, float, float]
    heads: dict
    formula: tuple[float, float, float, float]
    room: float                                 # the height the figure needs (a figure as tall as that has no margin)
    cards: dict = field(default_factory=dict)   # "space", "check": the cards of the 3D view and of the third panel
    head: float = HEAD                          # the height of a panel's head: its title's lines and its legend's rows
    titled: float = EDGE + TITLE_ROW            # the height of its title's lines alone (under_title)
    rule: tuple[float, float, float] | None = None      # the caption's rule in the 3D view's card (left, bottom, width);
                                                # under the band, the side's hairline over the indicators' block
    noted: tuple[str, ...] = ()                 # the panels whose slice's note stands under the title, a TITLE_LINE more
    band: tuple[float, float, float, float] | None = None      # the beam's band (banded): its card, over the whole picture
    indicators: tuple[float, float, float, float] | None = None    # under the band, the block of the step's indicators
                                                # in the 3D card's side, beside the view (the window lays its measures there)
    legends: dict = field(default_factory=dict) # the rows of legend a head holds where the plan gives it more than two
                                                # (under the band, a plane bound by the width: three; legend_most)
    alone: bool = False                         # the third panel in the window's column (arrangement's third=False)
    reveal: tuple[float, float, float, float] | None = None    # alone, a bench drawn: the box of the chip "Show f" at the
                                                # right end of the 3D view's card's head (revealed), which no head runs into
    aspect: float = ASPECT                      # the 3D box's vertical axis, in sides of its floor (set_box_aspect): alone,
                                                # what fills its card (filled), between ASPECT and ASPECT_MOST
    readout: tuple[float, float, float, float] | None = None   # alone, a bench of one response: the readout's room at the
                                                # 3D card's foot, under its rule (left, bottom, width, height: readout)
    cut: float | None = None                    # alone: the top of the 3D view's drawing room, where the note of a surface
                                                # cut at the window stands (places' "cut space")
    space_head: float = HEAD                    # the height of the 3D view's head (alone: SPACE_HEAD, one row of legend)

def arrangement(width: float, height: float | None, pair: str = "space", fill: bool = False, drawing: float | None = None,
                notes: dict | None = None, hero: bool = True, third: bool = True, readout: bool = True) -> Plan:
    """The panels as large as the figure allows; height None: a figure as tall as it needs (height_for), which has no
    corner. From STACK_WIDTH on, a figure of a given height is the corner, the right column always (the owner's rule: the
    squares never stand side by side), giving way on a short figure as `corner` says; only where even that has no room
    (a figure under 532 layout pixels tall, or narrower than about 730) does it fall back to the row (width from
    ROW_LEAST) or the pair (below it). `fill` lets the third panel fill its rectangle in the corner (step 1's table,
    step 3's scoreboard) instead of being a square (the check, a measure of the diagonal). `drawing`: the height of the
    caption's block of a bench whose caption is a drawing, not a formula (explorers/caption.py: the beam's,
    sketch.HEIGHT), in layout pixels, never trimmed; None, the formula's (formula_room, trimmed in a short corner). The
    three steps of a bench pass the same, so that they share one plan. `notes`, a bench of more than two inputs: by
    the panel's name ("plane", "space"), the titles of the three steps and the notes of the slice that head may write
    beside them (explorers/section.heading), of which the widest are measured; where the title would not hold its line
    beside the note at TITLE_LEAST in the head's room, the note goes under it (Plan.noted) and the plan reserves that
    head a TITLE_LINE more (taken from its panel's height), the same in the three steps: they keep one rect. None, the
    plan as it was. `hero`: a bench drawn takes the band (banded) where the figure has its room, from HERO_WIDTH x
    HERO_HEIGHT; False keeps it in the arrangements of a formula's bench with the compact caption (the web's page).
    Row: the squares take the height left under their titles, while the 3D view between them keeps SPACE_LEAST (more
    when the squares are small: up to SPACE_WIDE sides). Pair: the design space and the 3D view side by side, the 3D view
    as wide as the width allows, up to SPACE_WIDE sides but at least SPACE_LEAST. pair="check" (width below ROW_LEAST, the
    3D view left out): the design space and the third panel, two squares of the same side, as large as the height and the
    width allow; its Plan has kind "pair" and a check, its box of the 3D view is one pixel (to hide) and its box of the
    competition is the check's; only the titles of the two squares are placed (a figure as tall as it needs, height
    None, has squares of at most STACK_SIDE). Stacked, the squares are as wide as the figure allows, STACK_SIDE at most,
    and smaller in a figure too short for the three. `third` False: the step's own third panel stands in the window's
    column (Lab.columned, its blocks), not in the figure (Plan.alone): the corner's right column is ONE card, the 3D
    view over the column's whole height with its caption at its foot (alone_column's width), the band's likewise under
    the band (no side, no indicators), the stack without its third card, and where the corner has no room the pair of
    the design space and the 3D view (never the row, nor two squares); no plan has a third panel then (check None, the
    competition's box a pixel). True, the plans as they always were, to the pixel. The three steps pass the same.
    `readout` (third False only): the 3D view's card keeps the room of the readout at its foot (Plan.readout: a bench of
    one response; False, bench 4, whose card is its objective space)."""
    plan = laid(width, height, pair, fill, drawing, (), hero, third, readout)
    def bold(title: str) -> float:
        return text_width(title, TITLE_LEAST, TITLE["fontweight"])

    def light(note: str) -> float:
        return text_width(note, LEGEND_SIZE)
    under = tuple(name for name, (titles, said) in (notes or {}).items()
                  if name in plan.heads and not holds_beside(plan, name, max(titles, key=bold), max(said, key=light), width))
    return laid(width, height, pair, fill, drawing, under, hero, third, readout) if under else plan

def laid(width: float, height: float | None, pair: str, fill: bool, drawing: float | None, noted: tuple = (),
         hero: bool = True, third: bool = True, readout: bool = True) -> Plan:
    """arrangement's plan, the heads of `noted` a TITLE_LINE taller (the note of their slice under the title); a bench
    drawn under the band where it has its room (`hero`, banded); `third` False, without the third panel (Plan.alone),
    with the readout's room or not (`readout`)."""
    if not third:
        plan = replace(laid_alone(width, height, drawing, noted, hero, readout), alone=True)
        return replace(plan, reveal=revealed(plan)) if drawing is not None else plan
    if width < STACK_WIDTH:
        return stack(width, height, drawing, noted)
    flat = (row(width, height, drawing, noted) if width >= ROW_LEAST else pair_squares(width, height) if pair == "check"
            else pair_space(width, height, drawing, noted))
    if height is None:
        return flat
    if drawing is not None and hero:
        sided = banded(width, height, fill, noted)
        if sided is not None:
            return sided
    raised = corner(width, height, fill, drawing, noted)
    return raised if raised is not None else flat

def laid_alone(width: float, height: float | None, drawing: float | None, noted: tuple, hero: bool,
               readout: bool = True) -> Plan:
    """laid's plan without the third panel: the stack without its third card, else the band's or the corner's right
    column of one card where they have their room (`readout`: with the readout's room at its foot), else the pair of
    the design space and the 3D view. A bench drawn gives its design space the left margin its inputs' names need
    (alone_left)."""
    if width < STACK_WIDTH:
        return stack(width, height, drawing, noted, third=False)
    paired = pair_space(width, height, drawing, noted)                # the competition, in the plane's place there, is
    flat = replace(paired, ranking=(0.0, 0.0, 1.0, 1.0),              # the column's too
                   heads={name: at for name, at in paired.heads.items() if name != "ranking"})
    if height is None:
        return flat
    margin = alone_left(drawing)
    if drawing is not None and hero:
        sided = banded(width, height, False, noted, third=False, margin=margin, readout=readout)
        if sided is not None:
            return sided
    raised = corner(width, height, False, drawing, noted, third=False, margin=margin, readout=readout)
    return raised if raised is not None else flat

def alone_column(width: float, margin: float = LEFT) -> float:
    """The least width of the right column of one card (Plan.alone) in a figure `width` layout pixels wide: ALONE_SHARE
    of the width the design space and the column share (the design space's left margin `margin`: alone_left),
    COLUMN_LEAST at least."""
    return max(COLUMN_LEAST, ALONE_SHARE * (width - margin - COLUMN_GAP - RIGHT))

def alone_left(drawing: float | None) -> float:
    """The design space's left margin in a plan without the third panel: LEFT for a bench with a formula (its names are
    symbols alone, as they always were), plane_left for a bench drawn (a simulation: its inputs carry units)."""
    return LEFT if drawing is None else plane_left()

@cache
def plane_left() -> float:
    """The design space's left margin, in layout pixels, that the widest vertical name of the benches drawn needs
    (every input of a bench whose inputs have units, any of which may stand on the vertical axis: its symbol over its
    unit, as name_plane sets it), measured in the face drawn: PLANE_EDGE from the figure's edge, the name's widest
    line, NAME_TOUCH, that input's widest tick label (plane_labels) and the ticks (OBJECTIVE_TICKS), each text with its
    box's INK_SLACK; LEFT at least.
    One margin for those benches, so that the three steps keep one plan whatever bench calls (bench 4's areas, "[cm²]"
    over three digits, ask about 14 more than LEFT)."""
    from statistical_fundamentals.functions import RESPONSES
    need = LEFT
    for response in RESPONSES.values():
        if not any(response.units[:response.d]):
            continue
        for k, (low, high) in enumerate(response.bounds):
            lines = axis_name(input_name(k), response.units[k], stacked=True).split("\n")
            named = max(text_width(line, NAME["fontsize"]) for line in lines) + 2 * INK_SLACK
            label = max(text_width(text, TICK) for text in plane_labels(low, high)) + 2 * INK_SLACK
            need = max(need, PLANE_EDGE + named + NAME_TOUCH + label + OBJECTIVE_TICKS)
    return need

def plane_labels(low: float, high: float) -> list[str]:
    """The tick labels an axis of the design space over [low, high] may write (matplotlib's automatic steps, at most
    nine intervals, every label with the decimals of the finest), for measuring their width."""
    values = [float(v) for v in MaxNLocator(9, steps=[1, 2, 2.5, 5, 10]).tick_values(low, high) if low - 1e-9 <= v <= high + 1e-9]
    decimals = max((len(f"{abs(v):.6g}".partition(".")[2]) for v in values), default=0)
    return [f"{v:.{decimals}f}" for v in values]

def revealed(plan: Plan) -> tuple[float, float, float, float] | None:
    """The box of the chip "Show f" in a plan (layout pixels, left, bottom, width, height): at the right end of the 3D
    view's card's head, REVEAL_INSET from the card's right edge and top, REVEAL_ROOM x REVEAL_HEIGHT; None without that
    card. The window places the chip at its right end and top (gui/lab_views.place_reveal); head keeps the title's line,
    the note beside it and a row of legend it stands on clear of it (places' "chip space")."""
    card = plan.cards.get("space")
    if card is None:
        return None
    left, bottom, wide, tall = card
    right, inset = REVEAL_INSET
    return left + wide - right - REVEAL_ROOM, bottom + tall - inset - REVEAL_HEIGHT, REVEAL_ROOM, REVEAL_HEIGHT

def holds_beside(plan: Plan, name: str, title: str, note: str, width: float) -> bool:
    """Whether a panel's title holds its line beside the slice's note at TITLE_LEAST in the room its head has in the
    plan (plan_room: never more than head_room finds in the figure), NOTE_GAP apart (noted's rule); always in a narrow
    figure, whose heads put the note on the title's second line anyway (head_rows)."""
    if head_rows(width)[0] > 1:
        return True
    beside = plan_room(plan, name, width) - text_width(note, LEGEND_SIZE) - NOTE_GAP
    return text_width(title, TITLE_LEAST, TITLE["fontweight"]) <= beside

def plan_room(plan: Plan, name: str, width: float) -> float:
    """The room a panel's head has in a plan, in layout pixels: to the nearest thing at its right that stands at the
    height of its head (another head on its line, a panel's box, a card, the caption's block; its own card's edge),
    less HEAD_GAP; the figure's edge when nothing does. It takes in all that head_room may find, and more (the band of
    the whole head), so that a title found to hold here holds on the figure."""
    x, top = plan.heads[name]
    low = top - HEAD
    own = plan.cards.get("check" if name == "ranking" else name)
    found = [width]
    for other, (left, line) in plan.heads.items():
        if other != name and line == top and left > x:
            found.append(left)
    boxes = [plan.plane, plan.space, plan.check, plan.formula, plan.reveal, *(card for card in plan.cards.values() if card != own)]
    for box in boxes:
        if box is not None and box[0] > x and box[1] < top and box[1] + box[3] > low:
            found.append(box[0])
    if own is not None:
        found.append(own[0] + own[2])
    return min(found) - x - HEAD_GAP

def dropped(plan: Plan | None, name: str) -> float:
    """How far under its usual place a panel's legend stands, in layout pixels: a TITLE_LINE where the slice's note
    stands under the title (Plan.noted), else nothing."""
    return TITLE_LINE if plan is not None and name in plan.noted else 0.0

def hung(height: float, group: float) -> float:
    """The bottom of a group of panels `group` high in a figure `height` high: centred, or hung from the top when it
    is taller than the figure."""
    return (height - group) / 2 if height >= group else height - group

def row(width: float, height: float | None, drawing: float | None = None, noted: tuple = ()) -> Plan:
    """The three panels in a row, the 3D view between the squares (`drawing`: arrangement's; `noted`: laid's, the
    heads on one line, all a TITLE_LINE taller when one is)."""
    height = height or 0.0
    over = TITLE_LINE if noted else 0.0                                          # a note under a title: one line more
    room = width - LEFT - CHECK_LEFT - RIGHT - SPACE_GAP - SPACE_ROOM             # for the two squares and the 3D view
    side = max(min(height - HEAD - over - BELOW, (room - SPACE_LEAST) / 2), SIDE_LEAST)
    wide = max(min(room - 2 * side, max(SPACE_LEAST, SPACE_WIDE * side)), 1.0)
    left = max(width - (LEFT + 2 * side + SPACE_GAP + wide + SPACE_ROOM + CHECK_LEFT + RIGHT), 0.0) / 2
    group = HEAD + over + side + BELOW
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    space = plane + side + SPACE_GAP
    block = space + wide + SPACE_ROOM                                            # of the check: its tick labels and their name
    check = block + CHECK_LEFT
    title = plane + side + SPACE_INSET - RANK_INSET                              # the 3D card: its title RANK_INSET in
    card = block - CARD_GAP - title
    high = caption_room(card - 2 * RANK_INSET, drawing=drawing)                  # its caption, at its foot
    heads = {"plane": (plane, top), "space": (title + RANK_INSET, top), "check": (block + RANK_INSET, top),
             "ranking": (block + RANK_INSET, top)}
    cards = {"space": (title, bottom, card, top - bottom), "check": (block, bottom, check + side + RIGHT - block, top - bottom)}
    formula, rule = captioned(title + RANK_INSET, bottom, card - 2 * RANK_INSET, high)
    return Plan("row", side, (plane, base, side, side), (check, base, side, side),
                lifted(space, bottom + high, wide, group - HEAD - over + SPACE_OVER - high),
                (block + RANK_INSET, base, check + side - block - RANK_INSET, side), heads, formula, group, cards, rule=rule,
                noted=noted)

def reach(box: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    """The 3D view's box (left, bottom, width, height) reaching higher into its head: matplotlib draws a 3D view in
    the largest square its box holds, centred, and the drawing leaves the top tenth of that square empty (the panes)
    while its tick labels and axis names hang under it. A box wider than tall grows by SPACE_REACH of its height less
    SPACE_CLEAR, up to its width (its square grows with it, and its drawing's top stays under the legend over it); a box
    already as tall as wide keeps its height, since its drawing would only rise towards its legend."""
    left, bottom, wide, tall = box
    return left, bottom, wide, min(tall + max(SPACE_REACH * tall - SPACE_CLEAR, 0.0), max(tall, wide))

def hang(room: float, wide: float) -> float:
    """From the caption's rule up to the 3D box, for a box `wide` layout pixels wide that may take `room` of height
    over that rule: its tick labels and axis names fall under its drawing by about SPACE_HANG less SPACE_HANG_SHARE of
    the side of the square it is drawn in (reach), the more the smaller it is, and RULE_PAD stays under them; 0 for a
    drawing large enough to hold them in its box. A few rounds of the fixed point: the side depends on the hang."""
    under = 0.0
    for _ in range(4):
        _, _, wide_, tall = reach((0.0, 0.0, wide, max(room - under, 1.0)))
        under = max(SPACE_HANG - SPACE_HANG_SHARE * min(wide_, tall) + RULE_PAD, 0.0)
    return under

def lifted(left: float, bottom: float, wide: float, room: float) -> tuple[float, float, float, float]:
    """The 3D box of the row and the pair: from the top of its card's caption `bottom`, raised by hang, up to `room`
    over it."""
    under = hang(room, wide)
    return reach((left, bottom + under, wide, room - under))

def caption_room(wide: float, trim: bool = False, drawing: float | None = None) -> float:
    """The height of the caption at the foot of the 3D view's card, `wide` layout pixels wide: CAPTION_FOOT, the
    formula's lines (formula_room, at FORMULA_PX; with `trim`, a short corner's, one line at FORMULA_LEAST, FORMULA_TRIM,
    where every formula of the benches holds on one line at that size) or, for a bench whose caption is a drawing, its
    height `drawing` (never trimmed), CAPTION_GAP and the rule over them."""
    if drawing is not None:
        lines = drawing
    else:
        lines = FORMULA_TRIM if trim and one_line_least(round(wide - FORMULA_SLACK, 3)) else formula_room(wide)
    return CAPTION_FOOT + lines + CAPTION_GAP + RULE

@cache
def one_line_least(room: float) -> bool:
    """Whether every formula of the benches holds on one line at FORMULA_LEAST `room` layout pixels wide."""
    return all(mathtext_width("$" + " + ".join(terms) + "$", FORMULA_LEAST) <= room for terms in FORMULAS.values())

def captioned(left: float, foot: float, wide: float, high: float) -> tuple[tuple, tuple]:
    """The formula's block and the rule over it in the caption of a card whose foot is at `foot`, `wide` layout pixels
    from `left` (the card's inner width, its title's left), `high` (caption_room) in all: the block CAPTION_FOOT over the
    foot, the rule CAPTION_GAP over the block."""
    lines = high - CAPTION_FOOT - CAPTION_GAP - RULE
    return (left, foot + CAPTION_FOOT, max(wide, 1.0), lines), (left, foot + CAPTION_FOOT + lines + CAPTION_GAP, max(wide, 1.0))

def formula_room(wide: float) -> float:
    """The height of the formula's lines `wide` layout pixels wide at FORMULA_PX: one line's (FORMULA_ONE) when the
    widest formula of the benches keeps to one line there (typeset's rule: fitted), two lines' (FORMULA_ROOM) when one of
    them breaks into two. The same for every bench, so that nothing over the caption moves from a bench to another;
    measured a hair narrower than the block, so that typeset, which measures the same block in figure fractions, never
    finds a line more than was kept."""
    return FORMULA_ONE if formula_lines(round(wide - FORMULA_SLACK - 1e-3, 3)) == 1 else FORMULA_ROOM

@cache
def formula_lines(room: float) -> int:
    """The most lines a formula of the benches (explorers/responses.FORMULAS) takes `room` layout pixels wide, its type
    FORMULA_PX at most."""
    return max(len(fitted(terms, room)[0]) for terms in FORMULAS.values())

def pair_space(width: float, height: float | None, drawing: float | None = None, noted: tuple = ()) -> Plan:
    """The design space and the 3D view side by side, the third panel left out; the competition takes the plane's place
    (`drawing`: arrangement's; `noted`: laid's, the two heads on one line, both a TITLE_LINE taller when one is)."""
    height = height or 0.0
    over = TITLE_LINE if noted else 0.0                                          # a note under a title: one line more
    block = max(PAIR_SHARE * width, min(width - SPACE_LEAST, PAIR_MOST))
    side = max(min(height - HEAD - over - BELOW, block - LEFT - PAIR_GAP), SIDE_LEAST)
    wide = max(min(width - LEFT - side - SPACE_GAP - SPACE_RIGHT, max(SPACE_LEAST, SPACE_WIDE * side)), 1.0)
    left = max(width - (LEFT + side + SPACE_GAP + wide + SPACE_RIGHT), 0.0) / 2
    group = HEAD + over + side + BELOW
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    space = plane + side + SPACE_GAP
    title = plane + side + SPACE_INSET - RANK_INSET                              # the 3D card: its title RANK_INSET in
    card = space + wide + SPACE_RIGHT - title
    high = caption_room(card - 2 * RANK_INSET, drawing=drawing)                  # its caption, at its foot
    heads = {"plane": (plane, top), "space": (title + RANK_INSET, top), "ranking": (left + RANK_LEFT, top)}
    cards = {"space": (title, bottom, card, top - bottom)}
    formula, rule = captioned(title + RANK_INSET, bottom, card - 2 * RANK_INSET, high)
    return Plan("pair", side, (plane, base, side, side), None,
                lifted(space, bottom + high, wide, group - HEAD - over + SPACE_OVER - high),
                (left + RANK_LEFT, base, LEFT + side - RANK_LEFT, side), heads, formula, group, cards, rule=rule, noted=noted)

def pair_squares(width: float, height: float | None) -> Plan:
    """The design space and the third panel, two equal squares; the 3D view a box of one pixel, to hide. It has no 3D
    view's card, so no caption under it: the formula's block over the third panel (no caller asks for it now, a bench
    drawn included)."""
    widest = (width - LEFT - CHECK_LEFT - RIGHT) / 2
    asked = height

    def squares(high: float) -> tuple[float, float]:
        """The side of the squares and the figure's height under a formula's block `high`."""
        tall = high + HEAD + max(min(widest, STACK_SIDE), SIDE_LEAST) + BELOW if asked is None else asked
        return max(min(tall - high - HEAD - BELOW, widest), SIDE_LEAST), tall
    high = EDGE + FORMULA_ROOM + CAPTION_GAP                          # no 3D view's card: the formula over the third
    side, height = squares(high)                                      # panel's title, the figure's edge over it
    if EDGE + formula_room(side) + CAPTION_GAP < high:                # one line over a square this large: larger squares,
        high = EDGE + FORMULA_ONE + CAPTION_GAP                       # whose width keeps it to one line
        side, height = squares(high)
    left = max(width - (LEFT + 2 * side + CHECK_LEFT + RIGHT), 0.0) / 2
    group = high + HEAD + side + BELOW                              # the formula over the third panel, both titles under it
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    check = plane + side + CHECK_LEFT
    heads = {"plane": (plane, top - high), "check": (check, top - high)}
    cards = {"check": (check - CHECK_LEFT, bottom, CHECK_LEFT + side + RIGHT, top - high - bottom)}     # no step asks for it now
    return Plan("pair", side, (plane, base, side, side), (check, base, side, side), (0.0, 0.0, 1.0, 1.0), (check, base, side, side), heads,
                (check, top - high + CAPTION_GAP, side, high - EDGE - CAPTION_GAP), group, cards)     # the formula's lines

def stack(width: float, height: float | None, drawing: float | None = None, noted: tuple = (), third: bool = True) -> Plan:
    """The three panels one under the other: the squares as wide as the figure allows, the 3D view between them
    (`drawing`: arrangement's; `noted`: laid's, each of those heads a TITLE_LINE taller); `third` False, the design
    space over the 3D view's card alone (the third panel in the window's column)."""
    plane_over = TITLE_LINE if "plane" in noted else 0.0             # a note under a title: one line more
    space_over = TITLE_LINE if "space" in noted else 0.0
    lines, rows = head_rows(width)
    longer = NARROW_THIRD if lines > 1 and third else 0.0            # a phone's third panel: taller than its square
    headed = EDGE + TITLE_ROW + (lines - 1) * TITLE_LINE + rows * (LEGEND_ROW / 2 if rows <= 2 else NARROW_ROW)   # a phone's: more
    inset = CARD_EDGE + RANK_INSET                                    # the titles and the caption: on the cards' inset, the
    wide = max(width - 2 * CARD_EDGE, 1.0)                            # widest room a narrow figure has; the cards: the
    high = caption_room(wide - 2 * RANK_INSET, drawing=drawing)       # figure's width, CARD_EDGE in from its sides
    side = max(min(width - CHECK_LEFT - RIGHT, STACK_SIDE), SIDE_LEAST)
    tall = SPACE_SHARE * width
    fixed = 3 * headed + plane_over + space_over + 2 * BELOW - SPACE_OVER + EDGE + CARD_GAP + high + CARD_GAP + CARD_FOOT + longer
    squares = 2                                                       # the design space and the third panel
    if not third:                                                     # the third card left out: its head, its square, its gaps
        fixed -= headed + BELOW + CARD_GAP + CARD_FOOT
        squares = 1
    room = fixed + squares * side + tall + hang(tall, width)
    lift = 0.0
    if height is None:
        height = room
    elif height < room:                                               # a figure too short: everything smaller, in proportion
        share = max(height - fixed - hang(tall, width), 0.0) / (squares * side + tall)
        side, tall = max(side * share, SIDE_LEAST), max(tall * share, SIDE_LEAST)
    else:
        lift = (height - room) / 2
    plane = max(width - (CHECK_LEFT + side + RIGHT), 0.0) / 2 + CHECK_LEFT
    left = plane - CHECK_LEFT
    top = height - lift                                               # the design space
    base = top - headed - plane_over - side
    middle = base - BELOW - CARD_GAP                                  # the 3D view's card: its top, under the plane's labels
    floor = middle - headed - space_over + SPACE_OVER - tall
    foot = floor - hang(tall, width) - high                           # its foot: the caption under the 3D view's labels
    under = foot - CARD_GAP                                           # the check: its card's top
    low = under - headed - side - longer
    heads = {"plane": (inset, top), "space": (inset, middle), "check": (inset, under), "ranking": (inset, under)}
    cards = {"space": (CARD_EDGE, foot, wide, middle - foot),
             "check": (CARD_EDGE, low - BELOW - CARD_FOOT, wide, under - low + BELOW + CARD_FOOT)}
    formula, rule = captioned(inset, foot, wide - 2 * RANK_INSET, high)
    narrow = (CARD_EDGE, floor, width - CARD_EDGE - SPACE_RIGHT - STACK_LABEL, tall) if lines > 1 else (0.0, floor, width, tall)
    if not third:                                                     # no third panel: the 3D view's card the last
        return Plan("stack", side, (plane, base, side, side), None, reach(narrow), (0.0, 0.0, 1.0, 1.0),
                    {"plane": heads["plane"], "space": heads["space"]}, formula, room, {"space": cards["space"]}, headed,
                    EDGE + TITLE_ROW + (lines - 1) * TITLE_LINE, rule, noted)
    return Plan("stack", side, (plane, base, side, side), (plane, low, side, side + longer),
                reach((CARD_EDGE, floor, width - CARD_EDGE - SPACE_RIGHT - STACK_LABEL, tall) if longer else (0.0, floor, width, tall)),
                (left + RANK_LEFT, low, CHECK_LEFT + side - RANK_LEFT, side + longer), heads, formula,
                room, cards, headed, EDGE + TITLE_ROW + (lines - 1) * TITLE_LINE, rule, noted)

def head_rows(width: float) -> tuple[int, int]:
    """The lines of title and the rows of legend a panel's head holds in a figure `width` layout pixels wide: two and
    four in a narrow one (NARROW: a phone shows its panels one at a time), one and two otherwise (LEGEND_ROW)."""
    return (2, 4) if width < NARROW else (1, 2)

def corner(width: float, height: float, fill: bool, drawing: float | None = None, noted: tuple = (),
           third: bool = True, margin: float = LEFT, readout: bool = True) -> Plan | None:
    """The design space at the left, as large as the height allows (the column keeps COLUMN_LEAST); at its right the 3D
    view over the third panel, which takes THIRD_SHARE of the height the column has under its two titles (THIRD_LEAST at
    least). The caption always stands under the 3D box, at its card's foot. A short figure gives way in this order: the
    third panel down to THIRD_FLOOR while the 3D box is under SPACE_TALL_LEAST, the 3D box down to SPACE_FLOOR, then the
    caption's own height trimmed (caption_room with trim: one line at FORMULA_LEAST, the least its type allows). None
    when even that leaves no room: the design space under CORNER_SIDE_LEAST, or the 3D box under SPACE_FLOOR. A
    drawing, `drawing` high, is never trimmed: its corner stands wherever the formula's does (the same arrangement in
    every bench), its 3D box shorter by what the drawing takes over the formula (under SPACE_FLOOR in a short corner).
    The third panel is a square, centred with its tick labels in the column, or, with `fill`, the whole rectangle.
    When the width binds the design space (side under the height), the column is a picture of its own as tall as the
    figure, the design space centred vertically on its own: the plane's title then stands on another line than the 3D
    view's, and `head` keeps it before the column. `noted` (laid's): the heads of those panels a TITLE_LINE taller,
    the plane's taken from the design space, the 3D view's from its box. `third` False: corner_alone's (`margin`: the
    design space's left margin there, alone_left; `readout`, its readout's room)."""
    if not third:
        return corner_alone(width, height, drawing, noted, margin, readout)
    lower = TITLE_LINE if "plane" in noted else 0.0                   # a note under a title: one line more
    deeper = TITLE_LINE if "space" in noted else 0.0
    side = min(height - HEAD - lower - BELOW, width - LEFT - COLUMN_GAP - COLUMN_LEAST - RIGHT)
    group = HEAD + lower + side + BELOW                               # the design space's picture
    tall = side < height - HEAD - lower - BELOW - 1e-9                # bound by the width, with height to spare: the column
    whole = height if tall else group                                 # takes the figure's height and the plane centres on its own
    column = min(width - LEFT - side - COLUMN_GAP - RIGHT, COLUMN_MOST * whole)
    wide = column + RIGHT - SPACE_RIGHT - CARD_PAD                    # the 3D box: its name of y inside its card

    def shared(high: float) -> tuple[float, float, float]:
        """The third panel's height, the 3D box's hang and its height before it reaches into its head, under a caption
        `high`: the third panel at its share (THIRD_LEAST at least), less, down to THIRD_FLOOR, what the 3D box lacks of
        SPACE_TALL_LEAST."""
        held = whole - 2 * HEAD - deeper - BELOW - high               # the column's height under its two titles and the caption
        third = max(THIRD_SHARE * held, THIRD_LEAST)
        for _ in range(4):
            under = hang(held + SPACE_OVER - third - CARD_FOOT - CARD_GAP, wide)    # from the caption's rule up to the 3D box
            lifted = held - third - CARD_FOOT - CARD_GAP - under
            if lifted >= SPACE_TALL_LEAST - 1e-6 or third <= THIRD_FLOOR:
                break
            third = max(third - (SPACE_TALL_LEAST - lifted), THIRD_FLOOR)
        return third, under, lifted
    inside = column + RIGHT - 2 * RANK_INSET                          # the card's inner width: the caption's
    high = caption_room(inside, drawing=drawing)                      # the caption, at the foot of the 3D view's card
    third, under, lifted = shared(high)
    if drawing is not None:                                           # a drawing, never trimmed: the corner where the
        if corner(width, height, fill, None, noted) is None:          # formula's corner stands, its 3D box paying the
            return None                                               # drawing's height over the trimmed formula's
    else:
        if lifted < SPACE_FLOOR:                                      # a short corner: the formula trimmed to its least
            high = caption_room(inside, trim=True)
            third, under, lifted = shared(high)
        if side < CORNER_SIDE_LEAST or lifted < SPACE_FLOOR:
            return None
    left = max(width - (LEFT + side + COLUMN_GAP + column + RIGHT), 0.0) / 2
    low = hung(height, whole)                                         # the bottom of the column: the third panel's card
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    start = plane + side + COLUMN_GAP                                 # the left of the column, and of its cards
    right = start + column + RIGHT                                    # the right of the cards (the picture's edge)
    floor = low + BELOW + CARD_FOOT                                   # the third panel's axes, its name under them in its card
    if fill:
        shape = (start + CHECK_LEFT, floor, column - CHECK_LEFT, third)
    else:
        square = min(third, column - CHECK_LEFT)
        shape = (start + (column - CHECK_LEFT - square) / 2 + CHECK_LEFT, floor, square, square)
    block = floor + third + HEAD                                      # the top of the third panel's block: its card's top
    over = low + whole                                                # the top of the column: the 3D view's card
    foot = block + CARD_GAP                                           # its foot, under its caption
    space = reach((start, foot + high + under, wide, over - HEAD - deeper + SPACE_OVER - foot - high - under))
    heads = {"plane": (plane, top), "space": (start + RANK_INSET, over), "check": (start + RANK_INSET, block),
             "ranking": (start + RANK_INSET, block)}
    cards = {"space": (start, foot, right - start, over - foot), "check": (start, low, right - start, block - low)}
    formula, rule = captioned(start + RANK_INSET, foot, inside, high)
    return Plan("corner", side, (plane, base, side, side), shape, space,
                (start + RANK_INSET, floor, column - RANK_INSET, third), heads, formula, whole, cards, rule=rule, noted=noted)

def corner_alone(width: float, height: float, drawing: float | None = None, noted: tuple = (),
                 margin: float = LEFT, readout: bool = True) -> Plan | None:
    """The corner without its third panel (it stands in the window's column: Plan.alone): the design space at the left,
    as large as the height allows while the right column keeps alone_column's width (ALONE_SHARE of the width they
    share), and the column ONE card, the 3D view's, over the column's whole height, laid out as the owner's 2A of
    2026-11-21 (alone_card): its head (the title and one row of legend), the formula of the response right under it as
    the figure's subtitle (FORMULA_PX, Plan.formula), the readout at its foot under its rule (`readout`), and the 3D
    drawing filling the room between (filled: Plan.space and Plan.aspect). A bench drawn keeps its drawing (the compact
    caption) at the card's foot under its rule, the readout over that rule. A short figure trims the formula to one line
    at FORMULA_LEAST before it gives up the corner; None where the design space is under CORNER_SIDE_LEAST or the 3D box
    under SPACE_FLOOR (a drawing, never trimmed, stands where the formula's corner stands). Where the width binds the
    design space, the column takes the figure's height and the design space FILLS it (the owner's 2026-11-21: "always
    fit the figures to their room"): its head on the 3D view's head's line, its axes down to the card's foot, taller
    than wide (Plan.side is its width). `margin`: the design space's left margin (alone_left: LEFT, or what a bench
    drawn's names need)."""
    lower = TITLE_LINE if "plane" in noted else 0.0                   # a note under a title: one line more
    deeper = TITLE_LINE if "space" in noted else 0.0
    shared = width - margin - COLUMN_GAP - RIGHT                      # the width of the design space and the column
    side = min(height - HEAD - lower - BELOW, shared - alone_column(width, margin))
    group = HEAD + lower + side + BELOW                               # the design space's picture
    tall = side < height - HEAD - lower - BELOW - 1e-9                # bound by the width: the column takes the figure's height
    whole = height if tall else group
    column = min(shared - side, COLUMN_MOST * whole)
    inside = column + RIGHT - 2 * RANK_INSET                          # the card's inner width: the caption's
    left = max(width - (margin + side + COLUMN_GAP + column + RIGHT), 0.0) / 2
    low = hung(height, whole)                                         # the bottom of the column: the 3D view's card
    plane = left + margin
    start = plane + side + COLUMN_GAP                                 # the left of the column, and of its card
    right = start + column + RIGHT
    over = low + whole                                                # the top of the column
    card = (start, low, right - start, whole)
    headed = SPACE_HEAD + deeper
    if drawing is not None:                                           # a drawing, never trimmed: where the formula's stands
        if corner_alone(width, height, None, noted, margin, readout) is None:
            return None
        made = alone_card(card, headed, 0.0, caption_room(inside, drawing=drawing), readout)
    else:
        made = alone_card(card, headed, formula_room(inside), 0.0, readout)
        if made["space"][2] < FILL_LEAST:                             # a short corner: the formula on one line at its least
            made = alone_card(card, headed, FORMULA_TRIM, 0.0, readout)
        if side < CORNER_SIDE_LEAST or made["space"][2] < SPACE_FLOOR:
            return None
    base = low + BELOW                                                # the design space down to the card's foot, its head on
    heads = {"plane": (plane, over), "space": (start + RANK_INSET, over)}     # the 3D view's head's line
    return Plan("corner", side, (plane, base, side, whole - HEAD - lower - BELOW), None, made["space"], (0.0, 0.0, 1.0, 1.0),
                heads, made["formula"], whole, {"space": card}, rule=made["rule"], noted=noted,
                aspect=made["aspect"], readout=made["readout"], cut=made["cut"], space_head=SPACE_HEAD,
                legends={"space": 1})

def alone_card(card: tuple[float, float, float, float], headed: float, formula: float, caption: float,
               readout: bool) -> dict:
    """The 3D view's card alone in the right column (Plan.alone), laid out as the owner's 2A of 2026-11-21, in layout
    pixels: under its head (`headed` high: its title and one row of legend), the formula's block (`formula` high, the
    figure's subtitle, SUBTITLE_GAP under the legend; 0 for none); at its foot the caption of a drawing (`caption`:
    caption_room, its rule over it; 0 for none), and the readout (`readout`: READOUT high, at the foot under its own
    rule, or over the caption's rule); between them the drawing's room, which the 3D box fills (filled). Returns the
    pieces by name: "space" (the 3D box), "aspect", "formula" (the subtitle's block, or the caption's, or a pixel),
    "rule", "readout" (or None) and "cut" (the top of the drawing's room)."""
    left, bottom, wide, tall = card
    inner, across = left + RANK_INSET, max(wide - 2 * RANK_INSET, 1.0)
    top = bottom + tall - headed                                      # under the head
    block, rule = (inner, top - SUBTITLE_GAP - formula, across, formula), None
    if formula:
        top -= SUBTITLE_GAP + formula
    foot = bottom
    if caption:
        block, rule = captioned(inner, bottom, across, caption)
        foot += caption
    read = None
    if readout:
        read = (inner, foot, across, READOUT)
        if rule is None:
            rule = (inner, foot + READOUT, across)
            foot += RULE
        foot += READOUT
    if not formula and not caption:
        block = (inner, bottom, 1.0, 1.0)
    room = (inner + FILL_LEFT, foot + FILL_BELOW, across - FILL_LEFT - FILL_RIGHT, top - FILL_TOP - foot - FILL_BELOW)
    box, aspect = filled(room)
    return {"space": box, "aspect": aspect, "formula": block, "rule": rule, "readout": read, "cut": top}

def drawn_box(aspect: float) -> tuple[float, ...]:
    """Where the 3D box is drawn in its square at the vertical aspect `aspect` (x0, x1, y0, y1, in sides of the square):
    BOX_DRAWN, interpolated."""
    rows = BOX_DRAWN
    aspect = min(max(aspect, rows[0][0]), rows[-1][0])
    for (a, *low), (b, *high) in itertools.pairwise(rows):
        if a <= aspect <= b:
            share = (aspect - a) / (b - a)
            return tuple(p + share * (q - p) for p, q in zip(low, high))
    return tuple(rows[-1][1:])

def filled(room: tuple[float, float, float, float]) -> tuple[tuple[float, float, float, float], float]:
    """The 3D box (left, bottom, width, height: the square matplotlib draws it in) and its vertical aspect that fill
    the drawing's room `room` (layout pixels, the tick labels and the names around the drawn box left out: FILL_*):
    the aspect, from ASPECT up to ASPECT_MOST, whose drawn box is as tall for its width as the room (a tall card
    stretches its vertical axis, as the prototype's 1.1), the square as large as the room holds the drawn box, the drawn
    box centred in the room. The square may pass the card's edges: only its drawn box and labels stand in the room."""
    left, bottom, wide, tall = room
    wide, tall = max(wide, 1.0), max(tall, 1.0)

    def ratio(aspect: float) -> float:
        x0, x1, y0, y1 = drawn_box(aspect)
        return (y1 - y0) / (x1 - x0)
    low, high = ASPECT, ASPECT_MOST
    if ratio(low) >= tall / wide:
        aspect = low
    elif ratio(high) <= tall / wide:
        aspect = high
    else:
        for _ in range(30):
            middle = (low + high) / 2
            low, high = (middle, high) if ratio(middle) < tall / wide else (low, middle)
        aspect = (low + high) / 2
    x0, x1, y0, y1 = drawn_box(aspect)
    side = max(min(wide / (x1 - x0), tall / (y1 - y0)), 1.0)
    return (left + (wide - side * (x1 - x0)) / 2 - side * x0, bottom + (tall - side * (y1 - y0)) / 2 - side * y0, side, side), aspect

def band_height(height: float) -> float:
    """The beam's band of a figure `height` layout pixels tall: BAND_LEAST up to BAND_BASE, then BAND_GROWTH of the
    height over it, never more than BAND_MOST."""
    return min(max(BAND_LEAST + BAND_GROWTH * (height - BAND_BASE), BAND_LEAST), BAND_MOST)

def banded(width: float, height: float, fill: bool, noted: tuple = (), third: bool = True, margin: float = LEFT,
           readout: bool = True) -> Plan | None:
    """The hero arrangement of a bench drawn (the owner's 1A, 5E): the beam's band (band_height) over the whole picture
    on a card of its own ("beam" among the cards; Plan.band, and Plan.formula, the block its drawing takes: the card
    whole), and under it the corner's two parts: the design space at the left, as large as the height leaves, and the
    right column of two cards; a design space bound by the width has the height over its head, and that head takes a
    third row of legend there (LEGEND_THIRD, Plan.legends). The third panel's card takes THIRD_SPLIT of the column
    (THIRD_LEAST at least), the 3D
    view's the rest; the 3D card has its view at the LEFT over the card's height (SIDED_TOP under its top, its labels
    SIDED_FOOT over its foot: the same hang as the corner's) and, beside it, the side: the head (Plan.heads["space"]:
    title, legend in two rows, the slice's note under the title where `noted` says so), the hairline (Plan.rule) and
    under it the block of the step's indicators (Plan.indicators, INDICATOR_ROWS rows at least), which the figure leaves
    empty: the window lays the step's measures there. Where the side would be short, the third panel gives way down to
    BAND_THIRD_FLOOR; None where the figure is under HERO_WIDTH x HERO_HEIGHT, or where even that leaves no room (the
    design space under CORNER_SIDE_LEAST, the 3D card short of its side, the column under SIDED_COLUMN): the
    arrangements of a formula's bench, the compact caption under the 3D view, take it. The same boxes for the three
    steps of a bench (only `fill` differs, the third panel's shape). `third` False: banded_alone's (`margin`: the design
    space's left margin there, alone_left; `readout`, its readout's room)."""
    if width < HERO_WIDTH or height < HERO_HEIGHT:
        return None
    band = band_height(height)
    under = height - band - CARD_GAP                                  # the picture under the band
    lower = TITLE_LINE if "plane" in noted else 0.0                   # a note under a title: one line more
    deeper = TITLE_LINE if "space" in noted else 0.0
    if not third:
        return banded_alone(width, height, band, under, lower, deeper, noted, margin, readout)
    tall_side = under - HEAD - lower - BELOW                          # the plane as the height allows, and as the width
    wide_side = width - LEFT - COLUMN_GAP - SIDED_COLUMN - RIGHT      # leaves beside the column
    third_row = LEGEND_THIRD if wide_side < tall_side else 0.0        # a plane bound by the width: a third row of legend
    side = min(tall_side - third_row, wide_side)                      # in the height it leaves over it
    column = width - LEFT - side - COLUMN_GAP - RIGHT                 # the rest of the width: the band spans the figure
    headed = HEAD + deeper + RULE_ABOVE + RULE + RULE_BELOW          # the side's head and hairline, over the block
    least_third = BELOW + CARD_FOOT + HEAD                            # the third card without its panel
    wide = column + RIGHT                                             # the cards' width

    def viewed(card: float) -> tuple[float, float, float]:
        """The 3D box's height, width and hang in a 3D card `card` tall: its labels hang under the drawing (hang's
        rule), the box SIDED_ASPECT of its height wide, narrower where the side would be under SIDED_LEAST."""
        hanging = 0.0
        for _ in range(5):
            tall = max(card - SIDED_TOP - hanging, 1.0)
            across = max(min(SIDED_ASPECT * tall, wide - SIDED_LEAST - SIDED_GAP - RANK_INSET), 1.0)
            hanging = max(SPACE_HANG - SPACE_HANG_SHARE * min(across, tall) + SIDED_FOOT, 0.0)
        tall = max(card - SIDED_TOP - hanging, 1.0)
        return tall, max(min(SIDED_ASPECT * tall, wide - SIDED_LEAST - SIDED_GAP - RANK_INSET), 1.0), hanging

    def split(row: float, extra: float) -> tuple[float, float, float]:
        """The third card, the 3D card and what the 3D card needs, for indicators' rows `row` high and a head `extra`
        taller."""
        need = headed + extra + INDICATOR_ROWS * row + CARD_FOOT
        third_card = max(least_third + THIRD_LEAST, THIRD_SPLIT * (under - CARD_GAP))
        space_card = under - CARD_GAP - third_card
        if space_card < need:                                         # the third panel gives way to the side
            third_card = max(third_card - (need - space_card), least_third + BAND_THIRD_FLOOR)
            space_card = under - CARD_GAP - third_card
        return third_card, space_card, need

    def fitted(extra: float) -> tuple[float, float, float]:
        """split's, with short rows where the side is wide enough for two measures across, else the folded ones."""
        found = split(INDICATOR_SHORT, extra)
        return found if wide - viewed(found[1])[1] - SIDED_GAP - RANK_INSET >= SIDE_WIDE else split(INDICATOR_ROW, extra)
    third_card, space_card, need = fitted(0.0)
    if side < CORNER_SIDE_LEAST or space_card < need - 1e-6 or column < SIDED_COLUMN - 1e-6:
        return None
    third = third_card - least_third
    left = max(width - (LEFT + side + COLUMN_GAP + column + RIGHT), 0.0) / 2
    group = HEAD + third_row + lower + side + BELOW
    bottom = hung(under, group)                                       # the design space, centred under the band
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    start = plane + side + COLUMN_GAP
    right = start + column + RIGHT
    floor = BELOW + CARD_FOOT
    if fill:
        shape = (start + CHECK_LEFT, floor, column - CHECK_LEFT, third)
    else:
        square = min(third, column - CHECK_LEFT)
        shape = (start + (column - CHECK_LEFT - square) / 2 + CHECK_LEFT, floor, square, square)
    foot = third_card + CARD_GAP                                      # the 3D card: its foot and its height
    tall, across, hanging = viewed(space_card)
    space = (start, foot + hanging, across, tall)
    aside = start + across + SIDED_GAP                                # the side: its head, its rule, its block
    rule = under - headed + RULE_BELOW                                # the hairline's bottom
    heads = {"plane": (plane, top), "space": (aside, under), "check": (start + RANK_INSET, third_card),
             "ranking": (start + RANK_INSET, third_card)}
    strip = (left + BAND_SIDE, height - band, right - left - BAND_SIDE, band)
    cards = {"beam": strip, "space": (start, foot, wide, space_card), "check": (start, 0.0, wide, third_card)}
    block = (aside, foot + CARD_FOOT, right - RANK_INSET - aside, rule - RULE_BELOW - foot - CARD_FOOT)
    return Plan("corner", side, (plane, base, side, side), shape, space, (start + RANK_INSET, floor, column - RANK_INSET, third),
                heads, strip, height, cards, rule=(aside, rule, right - RANK_INSET - aside), noted=noted, band=strip,
                indicators=block, legends={"plane": LEGEND_ROWS_MOST} if third_row else {})

def banded_alone(width: float, height: float, band: float, under: float, lower: float, deeper: float,
                 noted: tuple, margin: float = LEFT, readout: bool = True) -> Plan | None:
    """The hero arrangement without its third panel (it stands in the window's column: Plan.alone): the beam's band
    `band` high over the whole picture, as banded's, and under it (`under` high) the design space, FILLING that height
    (taller than wide where the width binds it: the owner's 2026-11-21) while the right column keeps alone_column's
    width, and the column ONE card, the 3D view's, over that height, laid out as corner_alone's (alone_card: its head,
    the title and one row of legend, at its top left; the readout at its foot, `readout`; the 3D box filling the room
    between; no caption: the band is the drawing; no side, no indicators). A design space bound by the width takes a
    third row of legend in its head, as banded's; the column is at most COLUMN_MOST of the height under the band, the
    picture centred. `lower`, `deeper`: the heads of the plane and of the 3D view a TITLE_LINE taller (noted); `margin`,
    the design space's left margin (alone_left). None where the design space is under CORNER_SIDE_LEAST or the 3D box
    under SPACE_FLOOR."""
    shared = width - margin - COLUMN_GAP - RIGHT                      # the width of the design space and the column
    tall_side = under - HEAD - lower - BELOW                          # the plane as the height allows, and as the width
    wide_side = shared - alone_column(width, margin)                  # leaves beside the column
    third_row = LEGEND_THIRD if wide_side < tall_side else 0.0        # a plane bound by the width: a third row of legend
    side = min(tall_side - third_row, wide_side)                      # in the height it leaves over it
    column = min(shared - side, COLUMN_MOST * under)
    left = max(width - (margin + side + COLUMN_GAP + column + RIGHT), 0.0) / 2
    plane = left + margin
    start = plane + side + COLUMN_GAP
    right = start + column + RIGHT
    card = (start, 0.0, right - start, under)
    made = alone_card(card, SPACE_HEAD + deeper, 0.0, 0.0, readout)
    if side < CORNER_SIDE_LEAST or made["space"][2] < SPACE_FLOOR:
        return None
    heads = {"plane": (plane, under), "space": (start + RANK_INSET, under)}
    strip = (left + BAND_SIDE, height - band, right - left - BAND_SIDE, band)
    cards = {"beam": strip, "space": card}
    legends = {"space": 1} | ({"plane": LEGEND_ROWS_MOST} if third_row else {})
    return Plan("corner", side, (plane, BELOW, side, tall_side - third_row), None, made["space"], (0.0, 0.0, 1.0, 1.0), heads,
                strip, height, cards, rule=made["rule"], noted=noted, band=strip, legends=legends, aspect=made["aspect"],
                readout=made["readout"], cut=made["cut"], space_head=SPACE_HEAD)

def places(plan: Plan, width: float, height: float, names=None) -> dict:
    """The places of the panels' heads in figure fractions, for head: (left, baseline of the title, top of the legend)
    for each panel (those of `names` only, when given), under the key "formula" the formula's block (x0, y0, x1, y1),
    which no title or legend at its left runs into, and under "card <name>" the card of a panel that has one (x0, y0,
    x1, y1), whose head ends HEAD_GAP before the card's right edge; under "chip space" the box of the chip "Show f"
    (Plan.reveal: x0, y0, x1, y1), whose lines of the 3D view's head end HEAD_GAP before it."""
    heads = {name: (x / width, (top - TITLE_DROP) / height, (top - TITLE_DROP - LEGEND_DROP) / height)
             for name, (x, top) in plan.heads.items() if names is None or name in names}
    left, bottom, wide, tall = plan.formula
    heads["formula"] = (left / width, bottom / height, (left + wide) / width, (bottom + tall) / height)
    for name, (left, bottom, wide, tall) in plan.cards.items():
        card = (left / width, bottom / height, (left + wide) / width, (bottom + tall) / height)
        for panel in (name, "ranking") if name == "check" else (name,):     # the competition stands on the third panel's card
            if names is None or panel in names:
                heads[f"card {panel}"] = card
    if plan.reveal is not None and (names is None or "space" in names):        # the chip "Show f" over the 3D card's head:
        left, bottom, wide, tall = plan.reveal                              # head keeps what it stands beside clear of it
        heads["chip space"] = (left / width, bottom / height, (left + wide) / width, (bottom + tall) / height)
    if plan.indicators is not None and (names is None or "space" in names):    # a 3D card with its side (under the band):
        left, bottom, wide, tall = plan.cards["space"]                      # the note of a surface cut at the window over
        heads["cut space"] = ((left + RANK_INSET) / width, (bottom + tall - CUT_TOP) / height,     # the 3D view, at its
                              (plan.space[0] + plan.space[2]) / width)      # card's top left (the side holds the indicators)
    if plan.cut is not None and "space" in plan.cards and (names is None or "space" in names):    # alone: at the top of
        left, _, wide, _ = plan.cards["space"]                              # the drawing's room, under the head and the
        heads["cut space"] = ((left + RANK_INSET) / width, plan.cut / height, (left + wide - RANK_INSET) / width)   # formula
    return heads

def legend_most(plan: Plan | None, name: str) -> int:
    """The rows of legend the plan gives a panel's head beyond the usual (Plan.legends), or 0: the head's own rule."""
    return plan.legends.get(name, 0) if plan is not None else 0

def head(figure, heads: dict, axes: dict, name: str, title: str, handles: list, note: str = "", below: bool = False,
         most: int = 0) -> int:
    """Above a panel: its title and, under it, its legend, each in the room the panel has before what stands at its
    right at the height of its head: the next panel's title on the same line, a panel on show whose box reaches that
    height (its own title elsewhere: the tall corner; the third panel of a row beside the 3D view's title), the
    formula's block. The title shrinks to fit (to TITLE_LEAST); the legend, in the light ink, to LEGEND_LEAST, then
    breaks into two rows at LEGEND_SIZE (the plan keeps the room of two rows, LEGEND_ROW, in every step), and only then
    loses its last entries (the first say what the panel is). No entry, no legend: its room stays reserved (nothing
    under it moves). `heads` is the places of the titles (figure fractions: left, baseline, legend's top; places) and
    `axes` the panels, of which only those on show count. `note`, the slice a bench of more than two inputs shows
    ("x₃ = 5.68 m · x₄ = 6.94 m", explorers/section.note; "" for none, and the head is as it always was): set on the
    title's line at the right end of the head's room, in a legend's light ink and size (names and numbers, no
    sentence), the title shrinking to the room it leaves (noted); where even that is too narrow and the head holds two
    lines of title (a narrow figure), or where the plan reserved the head a line more for it (`below`: Plan.noted, the
    same in the three steps), on the line under the title instead, the legend a line lower. `most`: the rows of legend
    the plan reserved this head where it gave it others (legend_most: more, or one in the 3D view's card alone; 0,
    head_rows'). Where the chip "Show f" stands at
    the right end of the head (places' "chip <name>", Plan.reveal), the title's line (the title and the note beside it)
    and the row of legend at its height end HEAD_GAP before it (chip_room); the rows under it keep the head's room.
    Returns the rows of legend drawn."""
    x, baseline, legend = heads[name]
    width, height = size(figure)
    room = head_room(figure, heads, axes, name)
    lines, rows = head_rows(width)
    rows = most or rows
    chip = heads.get(f"chip {name}")
    beside = chip_room(chip, x, room, width)
    line_room = beside if chip is not None and chip[1] < baseline + (TITLE_DROP - EDGE) / height and chip[3] > baseline else room
    said, under = noted(title, note, line_room, lines, below)
    points = said[1]
    for k, line in enumerate(said[0]):
        figure.text(x, baseline - k * TITLE_LINE / height, line, ha="left", va="baseline", **(TITLE | {"fontsize": points}))
    if note:
        drop = len(said[0]) * TITLE_LINE / height if under else 0.0
        figure.text(x if under else x + line_room / width, baseline - drop, note, ha="left" if under else "right", va="baseline",
                    color=LEGEND_INK, **(CAPTION | {"fontsize": LEGEND_SIZE}))
    shown = len(said[0]) + (1 if under else 0)
    top = legend - (shown - 1) * TITLE_LINE / height
    first = beside if chip is not None and chip[1] < top else None   # the first row stands beside the chip
    return legend_at(figure, x, top, room, handles, rows, first)

def chip_room(chip: tuple | None, x: float, room: float, width: float) -> float:
    """The room of a head's line beside the chip "Show f" (`chip`: its box in figure fractions, places' "chip <name>"),
    in layout pixels: from the head's left `x` (a fraction) to HEAD_GAP before the chip, never more than `room`; `room`
    itself without a chip."""
    return room if chip is None else min(room, (chip[0] - x) * width - HEAD_GAP)

def noted(title: str, note: str, room: float, lines: int = 1, below: bool = False) -> tuple[tuple[tuple[str, ...], float], bool]:
    """A title's lines and size (titled) beside a note on its line, `room` layout pixels wide for the two, NOTE_GAP
    apart; and whether the note goes under the title instead, the title on one line: where the plan reserved the line
    (`below`), or where the title would not hold its line beside it at TITLE_LEAST and the head holds two lines
    (lines)."""
    if not note:
        return titled(title, room, lines), False
    if below:
        return titled(title, room, 1), True
    beside = room - text_width(note, LEGEND_SIZE) - NOTE_GAP
    if text_width(title, TITLE_LEAST, TITLE["fontweight"]) <= beside or lines < 2:
        return titled(title, beside, 1), False
    return titled(title, room, 1), True

def title_drop(figure, heads: dict, axes: dict, name: str, title: str) -> float:
    """How far under its usual place a panel's legend (or caption) stands, in figure fractions: a title on two lines
    (titled) pushes it down by TITLE_LINE."""
    lines, _ = head_rows(size(figure)[0])
    return (len(titled(title, head_room(figure, heads, axes, name), lines)[0]) - 1) * TITLE_LINE / size(figure)[1]

def titled(title: str, room: float, lines: int = 1) -> tuple[tuple[str, ...], float]:
    """A title's lines and its size in points, `room` layout pixels wide: one line from TITLE's size down to
    TITLE_LEAST; where the head holds two lines (head_rows), broken at the word that leaves the shorter longest line,
    at the largest size both fit; else one line at TITLE_LEAST (a figure wide enough never needs it)."""
    weight = TITLE["fontweight"]
    points = TITLE["fontsize"]
    while points > TITLE_LEAST and text_width(title, points, weight) > room:
        points -= 0.5
    words = title.split()
    if text_width(title, points, weight) <= room or lines < 2 or len(words) < 2:
        return (title,), points
    pairs = [(" ".join(words[:k]), " ".join(words[k:])) for k in range(1, len(words))]
    pair = min(pairs, key=lambda two: max(text_width(line, TITLE["fontsize"], weight) for line in two))
    points = TITLE["fontsize"]
    while points > TITLE_LEAST and max(text_width(line, points, weight) for line in pair) > room:
        points -= 0.5
    return pair, points

def legend_at(figure, x: float, top: float, room: float, handles: list, most: int = 2, first: float | None = None) -> int:
    """A legend at (x, top) in figure fractions, `room` layout pixels wide: one row, or two (legend_rows), each a legend
    of its own (no columns to align); head's, and that of a panel whose legend stands over its own content rather than
    under its card's title (step 2's check, beside the CoP); `most` rows (four in a narrow figure); `first`, the room of
    its first row where it is narrower (beside the chip "Show f": head). A row under the first whose labels are set in
    mathtext (a hat over a subscripted letter, "σ̂₁ > 120 MPa") draws taller than a row of words: it is raised by that
    excess (row_excess), so that its foot stays where the head's room for its rows ends. Returns the rows drawn."""
    height = size(figure)[1]
    rows, small = legend_rows(handles, room, most, first) if handles else ([], LEGEND_SIZE)
    rows = [row for row in rows if row]
    for k, row in enumerate(rows):
        maths = tuple(entry.get_label() for entry in row if is_math_text(entry.get_label()))
        at = top - k * LEGEND_PITCH * small / 72 * LAYOUT_DPI / height + (row_excess(maths, small) if k else 0.0) / height
        figure.legend(handles=row, loc="upper left", bbox_to_anchor=(x, at), ncol=len(row), frameon=False, prop=caption(small),
                      labelcolor=LEGEND_INK, handlelength=HANDLE_LENGTH, handleheight=HANDLE_HEIGHT, columnspacing=COLUMN_SPACING,
                      handletextpad=HANDLE_PAD, borderaxespad=0.0, borderpad=0.0)
    return len(rows)

@cache
def row_excess(labels: tuple[str, ...], points: float) -> float:
    """How much taller, in layout pixels, a legend row holding these mathtext labels draws than a row of words at
    `points` (the face's own line, "lp", as matplotlib measures a text): 0 for none. Measured as Agg lays them out."""
    if not labels:
        return 0.0
    prop = FontProperties(**caption(points))
    plain = measurer().get_text_width_height_descent("lp", prop, ismath=False)[1]
    return max(max(measurer().get_text_width_height_descent(label, prop, ismath=True)[1] for label in labels) - plain, 0.0)

@cache
def measurer():
    """A renderer of one pixel at LAYOUT_DPI, to measure texts as the figure lays them out (row_excess): Agg's, imported
    here at its first use, never when this module is imported (the web registers its faces before it: web/faces.py)."""
    from matplotlib.backends.backend_agg import RendererAgg
    return RendererAgg(1, 1, LAYOUT_DPI)

def cut_note(ax, heads: dict, name: str, text: str, color: str, drop: float = 0.0):
    """A note on a 3D view whose surface is cut at the vertical window, at the top of its card under the two rows its
    legend may take (the same place in steps 2 and 3, whatever their legends hold; `drop` layout pixels lower where the
    legend stands lower: dropped), where no tick label or axis name stands: on one line where the card holds it, else
    broken at the words; in the TAG role. In a 3D card with its side (under the band: places' "cut <name>", the side of
    the card holds the step's indicators) it stands over the 3D view instead, at its card's top left, as wide as the
    view. Returns the Text."""
    width, height = size(ax.figure)
    if f"cut {name}" in heads:
        x, top, end = heads[f"cut {name}"]
        room = (end - x) * width
    else:
        x, _, legend = heads[name]
        room = (heads[f"card {name}"][2] - x) * width - RANK_INSET
        top = legend - (LEGEND_ROW + drop) / height
    lines: list[str] = []
    for word in text.split():
        if lines and text_width(f"{lines[-1]} {word}", TAG["fontsize"]) <= room:
            lines[-1] = f"{lines[-1]} {word}"
        else:
            lines.append(word)
    box = ax.get_position()
    return ax.text2D((x - box.x0) / box.width, (top - box.y0) / box.height, "\n".join(lines), transform=ax.transAxes, ha="left",
                     va="top", color=color, zorder=10, **TAG)

def subtitle(figure, heads: dict, name: str, text: str, room: float | None = None, drop: float = 0.0):
    """A caption in the place of a panel's legend, under its title: what its content's numbers are (step 1's table),
    in the muted ink at the legend's size, one row, `room` layout pixels wide at most (down to LEGEND_LEAST, then broken
    in two at a word in a narrow figure, whose head keeps four rows), `drop` under the legend's place (title_drop);
    returns the Text."""
    x, _, legend = heads[name]
    legend -= drop
    points = LEGEND_SIZE
    while room is not None and points > LEGEND_LEAST and text_width(text, points) > room:
        points -= 0.5
    if room is not None and text_width(text, points) > room and len(text.split()) > 1:
        words = text.split()
        pair = min(((" ".join(words[:k]), " ".join(words[k:])) for k in range(1, len(words))),
                   key=lambda two: max(text_width(line, points) for line in two))
        text = "\n".join(pair)
    return figure.text(x, legend, text, ha="left", va="top", color=MUTED_INK, linespacing=LEGEND_PITCH,
                       **(CAPTION | {"fontsize": points}))

def plane_ticks(ax, banded: bool = False) -> None:
    """The design space's ticks for the room it has, the same rule in the three steps (each calls it once its limits are
    set): drawn smaller than PLANE_FEW, at most PLANE_FEW_BINS intervals on each axis at round values (1, 2, 5, 10 and
    their powers of ten: no "12.5", no "10.0" at the edge); larger, matplotlib's own choice. Under the beam's band
    (`banded`: Plan.band) always matplotlib's own: that plane is never under CORNER_SIDE_LEAST, where matplotlib's
    spacing of the labels still reads steps of 1 or 0.5 m ("2, 4" on [0.5, 5] m is too few to read a place by)."""
    position = ax.get_position()
    width, height = size(ax.figure)
    if not banded and min(position.width * width, position.height * height) < PLANE_FEW:
        for axis in (ax.xaxis, ax.yaxis):
            axis.set_major_locator(MaxNLocator(PLANE_FEW_BINS, steps=[1, 2, 5, 10]))

def head_room(figure, heads: dict, axes: dict, name: str) -> float:
    """The width a panel's head may take, in layout pixels: to what stands at its right in the band of its title and
    its two rows of legend (the next title on the same line, a panel on show whose box reaches that band, the formula's
    block, another panel's card), less HEAD_GAP; to the figure's edge when nothing does."""
    x, baseline, legend = heads[name]
    width, height = size(figure)
    low, high = legend - LEGEND_ROW / height, baseline + (TITLE_DROP - EDGE) / height      # the band of the head
    others = [other for key, (other, line, *_) in heads.items() if key != name and line == baseline and other > x
              and key in axes and axes[key].get_visible()]                     # the panels on show only
    for key, ax in axes.items():                                              # a panel at the right whose box stands at
        box = ax.get_position(original=True)                                  # the height of the head, its own title on
        if key != name and ax.get_visible() and box.x0 > x and box.y0 < high and box.y1 > low:     # another line
            beside = heads.get(key)
            others.append(min(box.x0, beside[0]) if beside is not None and beside[0] > x else box.x0)
    if "formula" in heads:
        x0, y0, _, y1 = heads["formula"]
        if x0 > x and y0 < high and y1 > low:
            others.append(x0)
    if f"card {name}" in heads:                                               # a panel on a card: to the card's edge
        others.append(heads[f"card {name}"][2])
    own = heads.get(f"card {name}")
    for key, card in heads.items():                                           # another panel's card at the right, at the
        if key.startswith("card ") and card != own and card[0] > x and card[1] < high and card[3] > low:     # height of
            others.append(card[0])                                            # the head (the 3D view's, by the plane's legend)
    return (min(others, default=1.0) - x) * width - HEAD_GAP

def legend_rows(handles: list, room: float, most: int = 2, first: float | None = None) -> tuple[list[list], float]:
    """The rows of a legend `room` layout pixels wide and its size in points: one row at LEGEND_SIZE, or smaller down
    to LEGEND_LEAST; else two rows (up to `most`: four in a narrow figure), the entries in their order, broken where
    the longest row is the shortest, at LEGEND_SIZE or smaller down to LEGEND_LEAST; else the same with the short labels
    of the entries that have one (dot's `short`: "f's minima" for "f's minima (unknown in a real study)"), set on them;
    else, at LEGEND_LEAST, the last entries left out (the first say what the panel is) until two rows hold the rest.
    `first`: the room of the first row where it is narrower than the others' (beside the chip "Show f"); the rows are
    then broken where the row that passes its room the most passes it the least."""
    labels = [handle.get_label() for handle in handles]
    limit = room if first is None else 0.0                            # what measure is held to: a width, or a row's excess
    if most == 1:                                                     # one row (the 3D view's card alone): smaller, then
        return one_row(handles, room if first is None else min(first, room))    # the short labels, then fewer entries

    def measure(edges, small):
        """The longest row of these cuts (each row within its own room: how far the row that passes it most passes it)."""
        if first is None:
            return max(legend_width(labels[a:b], small) for a, b in zip(edges, edges[1:]))
        return max(legend_width(labels[a:b], small) - (min(first, room) if a == 0 else room) for a, b in zip(edges, edges[1:]))
    for small in sizes():
        if measure((0, len(handles)), small) <= limit:
            return [list(handles)], small

    def broken(count, small):
        """The cuts into `count` rows whose longest row is the shortest (measure), and that measure."""
        best = None
        for cuts in itertools.combinations(range(1, len(handles)), count - 1):
            edges = (0, *cuts, len(handles))
            wide = measure(edges, small)
            if best is None or wide < best[1]:
                best = (edges, wide)
        return best

    def widest(cut, small):
        return measure((0, cut, len(handles)), small)
    shorter = [getattr(handle, "short", None) or handle.get_label() for handle in handles]
    for words in ((labels, shorter) if shorter != labels else (labels,)):
        labels = words
        for count in range(2, min(most, len(handles)) + 1):
            for small in sizes():
                edges, wide = broken(count, small)
                if wide <= limit:
                    for handle, label in zip(handles, labels):
                        handle.set_label(label)
                    return [list(handles[a:b]) for a, b in zip(edges, edges[1:])], small
    for handle, label in zip(handles, labels):
        handle.set_label(label)
    while len(handles) > 1:
        for small in sizes():
            cut = min(range(1, len(handles)), key=lambda k: widest(k, small))
            if widest(cut, small) <= limit or len(handles) == 2 and small == LEGEND_LEAST:
                return [list(handles[:cut]), list(handles[cut:])], small
        handles, labels = handles[:-1], labels[:-1]
    return [list(handles)], LEGEND_LEAST

def one_row(handles: list, room: float) -> tuple[list[list], float]:
    """legend_rows' one row `room` layout pixels wide: at LEGEND_SIZE or smaller down to LEGEND_LEAST; else with the
    short labels of the entries that have one, set on them; else, at LEGEND_LEAST, the last entries left out until the
    row holds the rest (the first entry always kept)."""
    labels = [handle.get_label() for handle in handles]
    shorter = [getattr(handle, "short", None) or label for handle, label in zip(handles, labels)]
    for words in ((labels, shorter) if shorter != labels else (labels,)):
        for small in sizes():
            if legend_width(words, small) <= room:
                for handle, label in zip(handles, words):
                    handle.set_label(label)
                return [list(handles)], small
    for handle, label in zip(handles, shorter):
        handle.set_label(label)
    kept = list(handles)
    while len(kept) > 1 and legend_width([handle.get_label() for handle in kept], LEGEND_LEAST) > room:
        kept.pop()
    return [kept], LEGEND_LEAST

def sizes() -> list[float]:
    """The sizes a legend steps down through, in points: LEGEND_SIZE to LEGEND_LEAST by half a point."""
    return [LEGEND_SIZE - 0.5 * k for k in range(int(round((LEGEND_SIZE - LEGEND_LEAST) / 0.5)) + 1)]

# ------------------------------------------------------------------------------
# The cards of the right column
# ------------------------------------------------------------------------------
def draw_cards(figure, plan: Plan, names=None) -> dict:
    """The cards of the plan (Plan.cards; those of `names` only, when given) drawn on the figure under every panel: a
    rounded rectangle of CARD_TONE, CARD_RADIUS layout pixels at its corners, with no border, laid out in layout pixels
    (the rounding stays round and the same at any density of the screen); along its upper edge, inside the rounding, a
    light of one layout pixel (the same card a pixel taller in CARD_LIGHT under it: the light thins into the corners, as
    the page's cards' inset light does); on the 3D view's card the caption's rule (Plan.rule, RULE_INK). Returns the
    cards by the panel's name, each with what goes with it (furniture: the light, the rule): a laboratory draws them
    once per layout, when it makes its axes, and keeps them (a redraw clears axes, texts and legends, never them)."""
    pixels = Affine2D().scale(1 / LAYOUT_DPI) + figure.dpi_scale_trans          # layout pixels to the screen's
    style = f"round,pad=0,rounding_size={CARD_RADIUS}"
    drawn = {}
    for name, (left, bottom, wide, tall) in plan.cards.items():
        if names is not None and name not in names:
            continue
        wide, tall = max(wide, 1.0), max(tall, 2.0)
        light = FancyBboxPatch((left, bottom), wide, tall, boxstyle=style, transform=pixels, facecolor=lit(CARD_TONE, CARD_LIGHT),
                               edgecolor="none", linewidth=0, zorder=-1.1)
        card = FancyBboxPatch((left, bottom), wide, tall - 1.0, boxstyle=style, transform=pixels, facecolor=CARD_TONE,
                              edgecolor="none", linewidth=0, zorder=-1)
        furniture = [figure.add_artist(light)]
        if name == "space" and plan.rule is not None:
            x, y, across = plan.rule
            furniture.append(figure.add_artist(Rectangle((x, y), across, RULE, transform=pixels, facecolor=RULE_INK, edgecolor="none",
                                                         linewidth=0, zorder=-0.9)))
        card.furniture = tuple(furniture)
        drawn[name] = figure.add_artist(card)
    return drawn

def lit(color: str, share: float) -> tuple[float, float, float]:
    """A colour with `share` of white laid over it (opaque): a card's upper light, CARD_LIGHT over its tone."""
    return tuple((1 - share) * int(color[i:i + 2], 16) / 255 + share for i in (1, 3, 5))

def inner(plan: Plan, name: str) -> tuple[float, float, float, float]:
    """The room inside a panel's card under its head, in layout pixels (left, bottom, width, height): RANK_INSET in from
    the card's sides, CARD_FOOT up from its foot, HEAD down from its top (the title and two rows of legend). What a
    laboratory draws in a card stays in it."""
    left, bottom, wide, tall = plan.cards[name]
    return left + RANK_INSET, bottom + CARD_FOOT, max(wide - 2 * RANK_INSET, 1.0), max(tall - CARD_FOOT - plan.head, 1.0)

def under_title(plan: Plan, name: str, side: float = RANK_INSET) -> tuple[float, float, float, float]:
    """The room inside a panel's card under its title alone, for a card whose head has no legend (its own content
    names what it shows, as a table's headings do), in layout pixels (left, bottom, width, height): `side` in from the
    card's sides, CARD_FOOT up from its foot, EDGE and TITLE_ROW down from its top."""
    left, bottom, wide, tall = plan.cards[name]
    return left + side, bottom + CARD_FOOT, max(wide - 2 * side, 1.0), max(tall - CARD_FOOT - plan.titled, 1.0)

def objective_box(plan: Plan, name: tuple[str, ...] = OBJECTIVE_NAME, label: str = OBJECTIVE_LABEL) \
        -> tuple[float, float, float, float] | None:
    """The frame of the OBJECTIVE SPACE of a bench of two objectives (explorers/objectives.py), in layout pixels (left,
    bottom, width, height): a 2D panel in the 3D view's card, where the benches of one response have their 3D view
    (Plan.space is the 3D box, which leaves no room for a 2D panel's tick labels and axis names). The same box in the
    three steps, since their plans share the card. Across, from the card's left: OBJECTIVE_INSET, the vertical axis'
    name set across at its left (`name`: its lines, stacked, measured in the NAME role's face; the symbol and its unit),
    OBJECTIVE_LABELPAD, its widest tick label (`label`, measured in the TICK size) and the ticks; up, the frame
    OBJECTIVE_BELOW over the card's foot, room for the ticks, their labels and the name across under it. In a 3D card
    with its side (under the band with the third panel in the figure: Plan.indicators) the frame takes the card's
    height (OBJECTIVE_TOP under its top) and ends OBJECTIVE_GAP before the side's head; in the other arrangements (the
    corner, the row, the pair and the stack: the code panel open; the band's card alone, Plan.alone) it stands under
    the card's head (title, legend and, where Plan.noted holds it, the slice's line) and over the caption's rule (the
    card's foot where it has none), OBJECTIVE_RIGHT in from the card's right. None where the plan has no 3D view's card
    (the pair of two squares)."""
    if "space" not in plan.cards:
        return None
    left, bottom, wide, tall = plan.cards["space"]
    named = max(text_width(line, NAME["fontsize"]) for line in name) if name else 0.0
    x0 = left + OBJECTIVE_INSET + named + OBJECTIVE_LABELPAD * LAYOUT_DPI / 72 + text_width(label, TICK) + OBJECTIVE_TICKS
    if plan.indicators is not None:
        x1, y1 = plan.heads["space"][0] - OBJECTIVE_GAP, bottom + tall - OBJECTIVE_TOP
        y0 = bottom + OBJECTIVE_BELOW
    else:
        x1, y1 = left + wide - OBJECTIVE_RIGHT, bottom + tall - plan.space_head - dropped(plan, "space") - OBJECTIVE_TOP
        y0 = (plan.rule[1] + RULE + RULE_PAD - CARD_FOOT if plan.rule is not None else bottom) + OBJECTIVE_BELOW
    return x0, y0, max(x1 - x0, 1.0), max(y1 - y0, 1.0)

def block_plan(width: float, height: float) -> Plan:
    """The plan of a block's own figure in the window's column (Lab.draw_block), `width` x `height` layout pixels: its
    one card, "check", the whole figure (also Plan.check and the competition's box), with its head and its title BLOCK_TOP
    high (the window draws the block's heading over the figure), so that under_title, inner and what a lab composes in a
    third card draw inside it as in the figure's third card; no other panel (the design space and the 3D view boxes of a
    pixel), no caption, no rule. The figure is painted in BLOCK_TONE, never given cards (draw_cards)."""
    whole = (0.0, 0.0, max(width, 1.0), max(height, 1.0))
    heads = {"check": (0.0, height), "ranking": (0.0, height)}
    return Plan("block", min(width, height), (0.0, 0.0, 1.0, 1.0), whole, (0.0, 0.0, 1.0, 1.0), whole, heads,
                (0.0, 0.0, 1.0, 1.0), height, {"check": whole}, head=BLOCK_TOP, titled=BLOCK_TOP)

# ------------------------------------------------------------------------------
# The formula of the response, typeset in the figure
# ------------------------------------------------------------------------------
def typeset(figure, heads: dict, terms: tuple[str, ...]):
    """The formula of the bench's response in its block (heads["formula"], places), as a paper sets the caption of a
    figure: mathtext in the STIX face, FORMULA_PX layout pixels high, in the light ink of a legend's labels (FORMULA_INK:
    reference, a step under the titles' white), left-aligned with the card's title and hung from the top of its block
    (CAPTION_GAP under the rule), the second line under the first when there is one. On one line when it fits the
    block's width; otherwise broken in two at a top-level "+" (the break that leaves the shorter longest line), the
    second line aligned after the "=" and opened by its "+"; still too wide, the type steps down half a pixel at a time
    to FORMULA_LEAST, never below (fitted). The block keeps the room of the lines the widest formula of the benches takes
    at its width (formula_room), so nothing over it moves from a bench to another (a shorter formula leaves the room under
    it); a block kept for one trimmed line (FORMULA_TRIM, a short corner's) sets it on one line at FORMULA_LEAST. No
    terms leave the block empty (explorers/caption.py never asks it so: a response without a formula is drawn).
    Returns the Text drawn (one artist, both lines; an empty one without a formula)."""
    width, height = size(figure)
    x0, y0, x1, y1 = heads["formula"]
    if not terms:                                                     # no formula: the caption empty, its block kept
        return figure.text(x0, y1, "", ha="left", va="top", color=FORMULA_INK)
    if (y1 - y0) * height < FORMULA_ONE - 0.5:                        # trimmed: one line at the least size
        lines, px = ("$" + " + ".join(terms) + "$",), FORMULA_LEAST
    else:
        lines, px = fitted(terms, (x1 - x0) * width - FORMULA_SLACK)
    return figure.text(x0, y1, "\n".join(lines), ha="left", va="top", fontsize=px * 72 / LAYOUT_DPI, color=FORMULA_INK,
                       math_fontfamily="stix", linespacing=FORMULA_SPACING)

def fitted(terms: tuple[str, ...], room: float) -> tuple[tuple[str, ...], float]:
    """The lines of a formula `room` layout pixels wide and their size in layout pixels: the first size from
    FORMULA_PX down by half a pixel at which it fits, on one line or broken in two (layout); at FORMULA_LEAST, broken at
    its best when nothing fits."""
    px = FORMULA_PX
    lines = layout(terms, px, room)
    while lines is None and px > FORMULA_LEAST:
        px -= 0.5
        lines = layout(terms, px, room)
    if lines is None:                                                 # nothing fits: the least size, broken at its best
        lines = min(breaks(terms, px), key=lambda pair: max(mathtext_width(line, px) for line in pair))
    return tuple(lines), px

def layout(terms: tuple[str, ...], px: float, room: float) -> tuple[str, ...] | None:
    """The lines of the formula at `px` within `room` layout pixels: one line, or the break into two whose longest line
    is the shortest; None when neither fits."""
    whole = ("$" + " + ".join(terms) + "$",)
    if mathtext_width(whole[0], px) <= room:
        return whole
    fitting = [pair for pair in breaks(terms, px) if max(mathtext_width(line, px) for line in pair) <= room]
    return min(fitting, key=lambda pair: max(mathtext_width(line, px) for line in pair)) if fitting else None

def breaks(terms: tuple[str, ...], px: float) -> list[tuple[str, str]]:
    """Every break of the formula into two lines at a top-level "+": the first line, and the second set in from the
    left by the width of the formula's left side ("f(x1, x2) ="), opened by its "+"."""
    left = terms[0].split("=")[0] + "="
    indent = mathtext_width(f"${left}$", px) / px                    # in ems of the type: mathtext's \hspace
    return [("$" + " + ".join(terms[:k]) + "$", rf"$\hspace{{{indent:.3f}}}+\ " + " + ".join(terms[k:]) + "$")
            for k in range(1, len(terms))]

@cache
def mathtext_box(text: str, px: float) -> tuple[float, float, float]:
    """The width, the height and the depth (under the baseline) of a line of mathtext set in the STIX face at `px`
    layout pixels, in layout pixels."""
    parsed = MathTextParser("path").parse(text, dpi=72, prop=FontProperties(size=px * 72 / LAYOUT_DPI, math_fontfamily="stix"))
    return parsed.width * LAYOUT_DPI / 72, parsed.height * LAYOUT_DPI / 72, parsed.depth * LAYOUT_DPI / 72

def mathtext_width(text: str, px: float) -> float:
    """The width of a line of mathtext set in the STIX face at `px` layout pixels, in layout pixels."""
    return mathtext_box(text, px)[0]

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def text_width(text: str, points: float, weight: str = "normal") -> float:
    """The width of a text drawn in the figure's face (SANS, as titles and legends are drawn: each glyph in the first
    family that has it) at `points`, in layout pixels (the same at any screen density):
    the width of one point (width_per_point) times the size. A TextPath is the outline of the glyphs at one size scaled
    by points / FONT_SCALE, so its extents are linear in the size: a title stepped down half a point at a time, or a
    legend whose labels carry numbers, is measured once per text and weight, not once per size."""
    return points * width_per_point(text, weight)

@cache
def width_per_point(text: str, weight: str = "normal") -> float:
    """The width of a text in layout pixels per point of its size, measured once at MEASURE_POINTS: the horizontal
    extent of its outline (outline_width)."""
    path = TextPath((0, 0), text, size=MEASURE_POINTS, prop=FontProperties(family=SANS, weight=weight, math_fontfamily=MATH))
    return outline_width(path) * LAYOUT_DPI / 72 / MEASURE_POINTS

def outline_width(path: Path) -> float:
    """The horizontal extent of a glyph outline, exactly what path.get_extents().width gives, in one pass over its
    arrays: the points on the outline, and for every quadratic curve (on, control, on) its extreme in x where the
    derivative vanishes inside the curve, t = (p0 - p1) / (p0 - 2 p1 + p2). get_extents finds the same extremes curve by
    curve, with a polynomial root finder each: about 50 ms for a title. An outline with cubic curves (not a TrueType
    face) is measured by get_extents."""
    vertices, codes = path.vertices, path.codes
    if codes is None or not len(codes) or (codes == Path.CURVE4).any():
        return path.get_extents().width
    curve = codes == Path.CURVE3
    control = np.zeros(len(codes), dtype=bool)                        # straight outlines only ("i", "W"): no control point
    if curve.any():
        begins = curve & ~np.r_[False, curve[:-1]]                    # the runs of CURVE3 codes: control, end, control, end...
        run = np.flatnonzero(begins)[np.maximum(np.cumsum(begins) - 1, 0)]
        control = curve & ((np.arange(len(codes)) - run) % 2 == 0)
    x = vertices[:, 0]
    on = x[~control & (codes != Path.CLOSEPOLY)]
    k = np.flatnonzero(control)
    p0, p1, p2 = x[k - 1], x[k], x[k + 1]
    bend = p0 - 2 * p1 + p2
    t = np.divide(p0 - p1, bend, out=np.full(len(k), -1.0), where=bend != 0)
    inside = (t > 0) & (t < 1)
    t, p0, p1, p2 = t[inside], p0[inside], p1[inside], p2[inside]
    extremes = (1 - t) ** 2 * p0 + 2 * t * (1 - t) * p1 + t ** 2 * p2
    both = np.concatenate([on, extremes])
    return float(both.max() - both.min()) if both.size else path.get_extents().width

def legend_width(labels: list[str], points: float) -> float:
    """The width of a row of a legend: each handle, its pad, its label, and the spacing between the entries (the
    lengths head gives the legend, in multiples of the font size)."""
    em = points * LAYOUT_DPI / 72
    return (sum(text_width(label, points) for label in labels) + len(labels) * (HANDLE_LENGTH + HANDLE_PAD) * em
            + (len(labels) - 1) * COLUMN_SPACING * em)

def number_width(text: str, points: float, weight: str = "normal") -> float:
    """The width of a text drawn in the figure's monospace (MONO, as the numbers of a table, a hero number and READING
    are drawn) at `points`, in layout pixels: text_width's measure, in the face drawn."""
    return points * mono_per_point(text, weight)

@cache
def mono_per_point(text: str, weight: str = "normal") -> float:
    """The width of a text in MONO in layout pixels per point of its size, measured once at MEASURE_POINTS."""
    path = TextPath((0, 0), text, size=MEASURE_POINTS, prop=FontProperties(family=MONO, weight=weight, math_fontfamily=MATH))
    return outline_width(path) * LAYOUT_DPI / 72 / MEASURE_POINTS

def gauge(ax, left: float, bottom: float, width: float, height: float, value: float | None, color: str, low: float = 0.0,
          high: float = 1.0, zorder: float = 3, ends: bool = False) -> tuple:
    """A horizontal gauge in the data coordinates of `ax`: its track (GAUGE_TRACK, the whole scale from `low` to `high`,
    `width` long) and over it a bar of `color` filled from `low` to `value`, clamped to the scale: a value under `low`
    (or None: not computed) leaves the track empty, never a bar that reaches beyond it; with `ends`, a tick at each end
    of the scale (GAUGE_TICK, 3 units over and under it: layout pixels where the axes are laid out in them). Returns the
    track, the bar (None when empty) and the share filled, in [0, 1]."""
    share = 0.0 if value is None else min(max((value - low) / (high - low), 0.0), 1.0)
    track = ax.add_patch(Rectangle((left, bottom), width, height, facecolor=GAUGE_TRACK, edgecolor="none", zorder=zorder))
    bar = None
    if share > 0.0:
        bar = ax.add_patch(Rectangle((left, bottom), share * width, height, facecolor=color, edgecolor="none", zorder=zorder + 0.1))
    if ends:
        for x in (left, left + width):
            ax.plot([x, x], [bottom - 3.0, bottom + height + 3.0], color=GAUGE_TICK, linewidth=1.0, solid_capstyle="butt",
                    zorder=zorder + 0.2)
    return track, bar, share

def level_values(surface) -> list:
    """The levels of the faint lines of a metamodel's surface on a plane (step 2 under the weights, step 3 under the
    search): LEVELS of them, geometric above its least value on the grid, as the eye reads a valley; none for a flat
    surface."""
    low, high = float(np.min(surface)), float(np.max(surface))
    rise = high - low
    if not rise > 1e-12 * max(abs(low), abs(high), 1.0):
        return []
    return list(low + rise * np.geomspace(3e-4, 0.7, LEVELS))

def facets(x1: np.ndarray, x2: np.ndarray, y: np.ndarray, low: float, high: float) -> tuple[list, list, bool]:
    """The cells of a surface as polygons (x1, x2, y), each cut where it leaves the window [low, high], with the mean
    height of each polygon; and whether anything was cut. A cut follows the edges of its cell: nothing is drawn that
    the grid does not hold."""
    rows, columns = y.shape
    if ((y >= low) & (y <= high)).all():
        corners = [np.stack([x1[r:r + rows - 1, c:c + columns - 1], x2[r:r + rows - 1, c:c + columns - 1],
                             y[r:r + rows - 1, c:c + columns - 1]], axis=-1) for r, c in ((0, 0), (0, 1), (1, 1), (1, 0))]
        polygons = np.stack(corners, axis=2).reshape(-1, 4, 3)
        return list(polygons), list(polygons[:, :, 2].mean(axis=1)), False
    polygons, heights = [], []
    for r in range(rows - 1):
        for c in range(columns - 1):
            polygon = [(float(x1[i, j]), float(x2[i, j]), float(y[i, j])) for i, j in ((r, c), (r, c + 1), (r + 1, c + 1), (r + 1, c))]
            polygon = cut_at(cut_at(polygon, high, below=True), low, below=False)
            if len(polygon) >= 3:
                polygons.append(np.array(polygon))
                heights.append(sum(vertex[2] for vertex in polygon) / len(polygon))
    return polygons, heights, True

def cut_at(polygon: list, level: float, below: bool) -> list:
    """The part of a polygon below (or above) a level: where an edge crosses it, the crossing point (Sutherland-Hodgman)."""
    kept = []
    for k in range(len(polygon)):
        p, q = polygon[k - 1], polygon[k]
        p_in = p[2] <= level if below else p[2] >= level
        q_in = q[2] <= level if below else q[2] >= level
        if p_in != q_in:
            t = (level - p[2]) / (q[2] - p[2])
            kept.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]), level))
        if q_in:
            kept.append(q)
    return kept

def dot(color: str, label: str, hollow: bool = False, soft: bool = False, marker: str = "o", size: float = 8.5,
        short: str | None = None) -> Line2D:
    """A legend's mark: a point (hollow: a ring; soft: a translucent disc with its rim); `short`, the label a crowded
    legend gives it rather than leave it out (legend_rows)."""
    face = "none" if hollow else tint(color, 0.42) if soft else color
    handle = Line2D([], [], linestyle="none", marker=marker, markersize=size, markerfacecolor=face,
                    markeredgecolor=color if hollow or soft else palette.CARD, markeredgewidth=1.5 if hollow else 0.9, label=label)
    handle.short = short
    return handle

def beside(point: tuple[float, float], offset: tuple[float, float] = LABEL_OFFSET) -> dict:
    """Where the label of a mark at `point` (in the unit square of its panel) goes, as annotate's keywords: `offset`
    points up and to the right of it, or, near the top or the right edge (beyond LABEL_EDGE), under it or to its left,
    so that the label never leaves its panel into the head over it (the legend's second row stands a few pixels above)."""
    high, right = point[1] > LABEL_EDGE, point[0] > LABEL_EDGE
    return {"xytext": (-offset[0] if right else offset[0], -offset[1] if high else offset[1]), "textcoords": "offset points",
            "ha": "right" if right else "left", "va": "top" if high else "baseline"}

def tint(color: str, alpha: float) -> tuple[float, float, float, float]:
    return tuple(int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)) + (alpha,)

def subscript(number: int) -> str:
    return "".join(SUBSCRIPTS[int(digit)] for digit in str(number))

def true_wire(ax, x1: np.ndarray, x2: np.ndarray, y: np.ndarray, zorder: float = 2, fine: bool = False):
    """The true response f as a wire over the metamodel's surface in the 3D view (steps 2 and 3, the same look): every
    WIRE_STRIDE-th line of its grid, in the slate of a reference, bright and over a dark casing (WIRE, WIRE_CASING), so
    that it reads at 1280 x 720 on every colour of the surface under it; `fine` (the window's figure, its surface lit:
    the owner's 3A), a thin wire at 0.8 px and 75 % over a thin casing (FINE_WIRE, FINE_CASING), so that y^ leads and f
    is the reference. Returns the wire."""
    look, casing = (FINE_WIRE, FINE_CASING) if fine else (WIRE, WIRE_CASING)
    wire = ax.plot_wireframe(x1, x2, y, rstride=WIRE_STRIDE, cstride=WIRE_STRIDE, zorder=zorder, **look)
    wire.set_path_effects(list(casing))
    return wire

def wire_handle(label: str, fine: bool = False) -> Line2D:
    """The legend's handle of f's wire: its line, its casing (true_wire's `fine` too)."""
    look, casing = (FINE_WIRE, FINE_CASING) if fine else (WIRE, WIRE_CASING)
    return Line2D([], [], label=label, path_effects=list(casing), **look)

def lit_facets(polygons: list, colors: np.ndarray, spans: tuple[float, float, float]) -> np.ndarray:
    """The colours of a surface's facets (`colors`, RGBA rows, the height's colour of each: the same ramp) with a light
    on them (the owner's 3A): each facet's colour times LIT_FLOOR plus LIT_GAIN times the cosine between its normal
    (Newell's, up) and LIGHT, none below 0, in the box's drawn proportions (`spans`: the extents of x1, x2 and y that
    the box draws as its sides, the vertical one divided by its aspect). Brightness only: the colour's hue and the
    surface's values are as computed, and its alpha is kept."""
    light = np.asarray(LIGHT, dtype=float)
    light = light / np.linalg.norm(light)
    scale = np.asarray(spans, dtype=float)
    lit_ = np.array(colors, dtype=float, copy=True)
    for k, polygon in enumerate(polygons):
        q = np.asarray(polygon, dtype=float) / scale
        nxt = np.roll(q, -1, axis=0)
        normal = np.array([np.sum((q[:, 1] - nxt[:, 1]) * (q[:, 2] + nxt[:, 2])),
                           np.sum((q[:, 2] - nxt[:, 2]) * (q[:, 0] + nxt[:, 0])),
                           np.sum((q[:, 0] - nxt[:, 0]) * (q[:, 1] + nxt[:, 1]))])
        norm = float(np.linalg.norm(normal))
        if norm == 0.0:
            continue
        normal = normal / norm if normal[2] >= 0 else -normal / norm
        lit_[k, :3] = np.clip(lit_[k, :3] * (LIT_FLOOR + LIT_GAIN * max(float(normal @ light), 0.0)), 0.0, 1.0)
    return lit_

def readout(figure, plan: Plan, rows: list) -> list:
    """The readout at the foot of the 3D view's card alone (Plan.readout; the owner's 2A of 2026-11-21): the values read
    in the view, off its surface, on READOUT_ROWS rows under the card's rule, each reading its name (READOUT_NAME, in
    the ink of its mark in the view) and its number (READING: the monospace, tabular, in the light ink), READOUT_GAP
    apart; a reading past the card's inner width is left out (never cut). `rows`: per row, a list of (name, ink, number).
    Returns the Texts drawn (nothing without the plan's readout)."""
    if plan.readout is None:
        return []
    left, bottom, wide, tall = plan.readout
    width, height = size(figure)
    drawn = []
    for k, row in enumerate(rows[:READOUT_ROWS]):
        x = left
        baseline = bottom + tall - READOUT_TOP - k * READOUT_PITCH
        for name, ink, value in row:
            named = text_width(name, READOUT_NAME["fontsize"])
            said = number_width(value, READING["fontsize"])
            if x + named + READOUT_NAMED + said > left + wide + 1e-6:
                break
            drawn.append(figure.text(x / width, baseline / height, name, ha="left", va="baseline", color=ink, **READOUT_NAME))
            drawn.append(figure.text((x + named + READOUT_NAMED) / width, baseline / height, value, ha="left", va="baseline",
                                     color=palette.PROSE, **READING))
            x += named + READOUT_NAMED + said + READOUT_GAP
    return drawn

def read_point(point, unit: str = "", decimals: int = 2) -> str:
    """A place written for the readout: its coordinates in parentheses, `decimals` after the point, the minus sign a
    true minus, its unit after it where it has one: "(4.30, 6.30)", "(3.68, 5.66) m"."""
    said = "(" + ", ".join(f"{float(c):.{decimals}f}".replace("-", "−") for c in point) + ")"
    return f"{said} {unit}" if unit else said

def read_value(value: str, unit: str = "") -> str:
    """A value written for the readout (the lab's own writing: base.short), its unit after it where it has one."""
    return f"{value} {unit}" if unit else value

def caption(points: float) -> dict:
    """The font of a legend's labels at `points` (CAPTION), as figure.legend takes it."""
    return {"family": SANS, "size": points, "math_fontfamily": MATH}

def input_name(k: int) -> str:
    """The symbol of input k (0-based) as an axis or a heading names it, in mathematics: X1 and X2 for the first two,
    "$x_3$" and on for the others (a bench of more inputs names its pair by them)."""
    return X1 if k == 0 else X2 if k == 1 else f"$x_{{{k + 1}}}$"

def axis_name(symbol: str, unit: str = "", stacked: bool = False) -> str:
    """The name of an axis: its symbol (X1, X2, Y: mathematics) and, where the response has a unit for it
    (functions.Response.units), the unit in brackets after it, "$x_1$ [m]", or, `stacked`, on the line under it (the
    design space's x2, set across at its left); the symbol alone where there is none."""
    if not unit:
        return symbol
    return f"{symbol}\n[{unit}]" if stacked else f"{symbol} [{unit}]"

def name_plane(ax, units: tuple = ("", "", ""), pair: tuple[int, int] = (0, 1), touching: bool = True) -> None:
    """The design space's axes named, the same in the three steps: the pair's first input under it (x1), its second
    across at its left (x2; its unit, where there is one, on the line under its symbol), in the NAME role; with no
    units, the symbols as they always were. `pair`: the inputs on the axes (explorers/section.py), (0, 1) for two. A
    unit of more than one letter (bench 4's areas and heights, whose ticks have three digits) leaves the name no room
    beside the tick labels, and, `touching` (a bench of several responses: its callers say it, functions.many), a name
    with its unit that would touch a tick label at the middle (touches: measured, bench 4's places, "[m]" beside "6.5")
    has none either: it stands between the two ticks nearest the middle (the limits and ticks are set before).
    Everywhere else at the middle, matplotlib's own place: the benches of one response (touching False) keep their
    names where they always stood, in every pair of every plan (bench 3's x3, whose middle 5.8 is a tick, too). Such
    a name (wider than twice its pad from the tick labels: centred there, it would reach into them) stands NAME_TOUCH
    clear of the widest tick label where the figure's margin leaves it PLANE_EDGE from its left edge (apart), as a plan
    without the third panel gives a bench drawn (plane_left); in a narrower margin, at its pad as before."""
    across, up = pair
    ax.set_xlabel(axis_name(input_name(across), units[across]), **NAME, labelpad=2)
    stacked = {"linespacing": 1.0} if units[up] else {}
    name = axis_name(input_name(up), units[up], stacked=True)
    pad = apart(ax, name.split("\n")) if len(units[up]) > 1 else PLANE_NAME_PAD
    ax.set_ylabel(name, **NAME, labelpad=pad, rotation=0, va="center", **stacked)
    middle = 0.5                                                    # the name at the axis' middle (matplotlib's own place)
    low, high = ax.get_ylim()
    if units[up] and high > low:                                    # "[mm]" (bench 4's heights, ticks of three digits) is
        ticks = [t for t in ax.yaxis.get_major_locator().tick_values(low, high) if low <= t <= high]      # wider than the tick
        if len(ticks) >= 2 and (len(units[up]) > 1 or touching and touches(ax, ticks, name.split("\n"))):     # room left of the
            a, b = min(zip(ticks, ticks[1:]), key=lambda two: abs((two[0] + two[1]) / 2 - (low + high) / 2))     # labels:
            middle = ((a + b) / 2 - low) / (high - low)             # between the two ticks nearest the middle, beside none
    ax.yaxis.label.set_y(middle)

def apart(ax, lines: list[str]) -> float:
    """The pad, in points, of the design space's vertical name (its `lines`, set across and centred at the pad's
    distance left of the tick labels, as matplotlib places it) that keeps its right end NAME_TOUCH from the widest tick
    label, as far as its left end keeps PLANE_EDGE from the figure's left edge; never under PLANE_NAME_PAD. Measured in
    the face drawn with their boxes' INK_SLACK, the tick labels the axis' formatter writes inside its limits (their
    ticks: OBJECTIVE_TICKS)."""
    width = size(ax.figure)[0]
    low, high = ax.get_ylim()
    ticks = [t for t in ax.yaxis.get_major_locator().tick_values(low, high) if min(low, high) <= t <= max(low, high)]
    labels = ax.yaxis.get_major_formatter().format_ticks(ticks) if ticks else []
    widest = max((text_width(label, TICK) for label in labels), default=0.0) + 2 * INK_SLACK
    half = max(text_width(line, NAME["fontsize"]) for line in lines) / 2 + INK_SLACK
    labelled = ax.get_position().x0 * width - OBJECTIVE_TICKS - widest            # the tick labels' left
    least = PLANE_NAME_PAD * LAYOUT_DPI / 72
    return max(least, min(half + NAME_TOUCH, labelled - half - PLANE_EDGE)) * 72 / LAYOUT_DPI

def touches(ax, ticks: list, lines: list[str]) -> bool:
    """Whether a tick label stands against the design space's vertical name, measured: the label's centre within half
    a label's height and NAME_TOUCH layout pixels of the axis' middle (where the name's two lines meet: the label level
    with both), and the name's widest line, centred PLANE_NAME_PAD left of the widest tick label as matplotlib places
    it, nearer than NAME_TOUCH to that label across (text_width; the labels the axis' formatter writes). Bench 4's
    places ("[m]" level with "6.5" at the middle of [5, 8] m) touch; so would bench 3's x3 ("5.8", the middle of
    [5, 6.6] m), which name_plane keeps where it always stood (touching False for a bench of one response)."""
    height = size(ax.figure)[1]
    tall = ax.get_position().height * height
    low, high = ax.get_ylim()
    labels = ax.yaxis.get_major_formatter().format_ticks(ticks)
    widths = [text_width(label, TICK) for label in labels]
    half = max(text_width(line, NAME["fontsize"]) for line in lines) / 2
    pad = PLANE_NAME_PAD * LAYOUT_DPI / 72
    reach = TICK * LINE_HEIGHT * LAYOUT_DPI / 72 / 2 + NAME_TOUCH
    for tick, wide in zip(ticks, widths, strict=True):
        across = pad - half + max(widths) - wide                    # from the name's right end to this label's left
        if across < NAME_TOUCH and abs(tick - (low + high) / 2) / (high - low) * tall < reach:
            return True
    return False

def name_space(ax, units: tuple = ("", "", ""), pair: tuple[int, int] = (0, 1)) -> None:
    """The 3D view's axes named, the same in the three steps: the pair's two inputs (x1, x2) and y, each with its unit
    where the response has one (y's along its axis, as matplotlib sets it), in the NAME role. A name with its unit
    stands nearer its tick labels (SPACE_UNIT_PAD): longer, x1's and x2's would hang under the caption's rule (hang
    measured them as symbols), and y's brackets make its turned line thicker, out of a card that ends at the figure's
    edge (the pair of panels). In a view so small that y's turned name with its unit passes its axis drawn (SPACE_AXES,
    at the first angle) by more than SPACE_NAME_OVER at each end, it would rise into the legend over the view: its unit
    stands on the line under the symbol instead (stacked), a shorter turned name (a larger view keeps it on one line)."""
    across, up = pair
    ax.set_xlabel(axis_name(input_name(across), units[across]), labelpad=SPACE_UNIT_PAD if units[across] else 2, **NAME)
    ax.set_ylabel(axis_name(input_name(up), units[up]), labelpad=SPACE_UNIT_PAD if units[up] else 2, **NAME)
    position = ax.get_position()
    width, height = size(ax.figure)
    axis = space_axes(ax)[2] * min(position.width * width, position.height * height)
    stacked = bool(units[-1]) and text_width(f"y [{units[-1]}]", NAME["fontsize"]) > axis + 2 * SPACE_NAME_OVER
    ax.set_zlabel(axis_name(Y, units[-1], stacked), labelpad=SPACE_UNIT_PAD if units[-1] else 4, **NAME)     # y's unit: the last

def space_axes(ax) -> tuple[float, float, float]:
    """SPACE_AXES for the box aspect the 3D view `ax` is drawn at (Plan.aspect: set before its ticks and names): each
    axis drawn in proportion to its side of the box as matplotlib scales it (the aspect over its norm)."""
    drawn = np.asarray(ax.get_box_aspect(), dtype=float)              # matplotlib's: the aspect over its norm, scaled
    reference = np.array([1.0, 1.0, ASPECT]) / np.linalg.norm((1.0, 1.0, ASPECT)) * float(np.linalg.norm(drawn))
    return tuple(share * d / r for share, d, r in zip(SPACE_AXES, drawn, reference))

def ticks(ax, small: bool = False) -> None:
    """A panel's tick labels in the figure's face, muted: TICK points (TICK_SMALL for the 3D view's, small)."""
    ax.tick_params(colors=TICK_INK, labelsize=TICK_SMALL if small else TICK, labelfontfamily=SANS)

def screen_gap(ax, x: float, y: float, low: float, high: float) -> float:
    """How far apart two values on one vertical of a 3D view are drawn, in layout pixels (the view as it stands: its
    projection, then its axes' transform): two labels closer than LABELS_APART would print over each other."""
    from mpl_toolkits.mplot3d import proj3d
    matrix = ax.get_proj()
    first, second = (ax.transData.transform(proj3d.proj_transform(x, y, z, matrix)[:2]) for z in (low, high))
    return abs(float(second[1]) - float(first[1])) * LAYOUT_DPI / ax.figure.dpi

def space_ticks(ax, many: bool = False) -> None:
    """The 3D view's ticks for the room it has (called after its axes are styled and its limits set, at every draw of
    its scene): drawn smaller than SPACE_FEW (the square its box holds, in layout pixels), at most SPACE_FEW_BINS
    intervals on each axis, at round values; larger, matplotlib's own choice. Then, on each axis of the floor of a small
    view, or of any view of a bench of more than two inputs (`many`: its ranges' labels take two decimals), fewer
    intervals only where its labels would touch: their pitch along the axis drawn (SPACE_AXES of the square, at the
    first angle) under the widest label and SPACE_TICK_GAP, at most as many intervals as that length holds. The benches
    of two inputs keep their ticks at their windows' sizes (their small views' labels stand apart; a large view's,
    matplotlib's own, stand a few pixels apart on the steep axis and are kept as they were drawn)."""
    position = ax.get_position()
    width, height = size(ax.figure)
    side = min(position.width * width, position.height * height)
    small = side < SPACE_FEW
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_major_locator(MaxNLocator(SPACE_FEW_BINS) if small else AutoLocator())
    for axis, share in zip((ax.xaxis, ax.yaxis), space_axes(ax)[:2] if small or many else ()):
        length = share * side
        low, high = sorted(axis.get_view_interval())
        if not high > low:
            continue
        slack = 1e-9 * (high - low)
        locs = [v for v in axis.get_major_locator().tick_values(low, high) if low - slack <= v <= high + slack]
        if len(locs) < 2:
            continue
        widest = max(text_width(label, TICK_SMALL) for label in axis.get_major_formatter().format_ticks(locs))
        if length * (locs[1] - locs[0]) / (high - low) < widest + SPACE_TICK_GAP:
            axis.set_major_locator(MaxNLocator(max(int(length // (widest + SPACE_TICK_GAP)), 1)))
