# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: panels.py
# ==============================================================================
"""
The layout that the three steps of a bench share (the design of experiments, the metamodel, the optimization): a figure
of three panels (a square design space, a 3D view and a third panel) and where each panel and its title go, by the
figure's size. Every step lays its figure out with `arrangement(width, height, pair="space", fill=...)`, so that for the
same figure size the design space and the 3D view stand in the same boxes, to the pixel, in the three steps: changing
step updates one picture in place. What each panel draws belongs to its laboratory; here is only the geometry, the look
of the titles (TITLE, TITLE_LEAST) and the small helpers of the drawing that do not depend on a step.

The figure has four arrangements (`arrangement`). With room, the corner: the design space at the left, as large as the
height allows, and at its right a column with the 3D view on top and the third panel under it (the step's own: step 1's
table of the designs and step 3's scoreboard fill its rectangle, step 2's check is a square). Otherwise, by the width:
the three panels in a row; the design space and the 3D view side by side, the third panel left out, when there is no room
for three (the code panel open beside the lab); and the three stacked in a narrow figure. A laboratory with no use for
the 3D view when only two panels fit may ask `arrangement(width, height, pair="check")`: the design space and the third
panel side by side, two equal squares, and the 3D view a box of one pixel that the caller hides.

The corner is chosen, for any width of the side-by-side range, when it is feasible (the third panel keeps THIRD_LEAST of
height, the 3D view above it SPACE_TALL_LEAST once its card's foot is clear of its tick labels (hang) and the cards have
their gaps, and the column COLUMN_LEAST of width) and its design space is larger than the row's (or the pair's): a figure about as wide as
tall, or taller, has no use for a row. The leasts are those that keep the corner, its three panels on show, in the
figure a window of 1280 x 720 gives a step (928 x 609). Where the width binds the
design space, the corner's column takes the figure's whole height and the design space centres on its own. Every arrangement is ONE
picture centred in the figure: what the panels leave of the width or of the height is shared as equal margins on both
sides, never a panel against one edge and a void against the other (a figure too short for its panels hangs them from the
top). In a row or a pair the 3D view takes the width the squares leave, up to SPACE_WIDE times their side.

All lengths are layout pixels (explorers/lab.size), from the figure's lower left corner. Over every panel its head: its
title and, under it, its legend in the light ink (`head`, at the places `places` gives in figure fractions), which
shrink to the room the panel has before what stands at their right; a legend too wide for one row breaks into two
(LEGEND_ROW keeps the room of two in every arrangement, so nothing moves when it does). text_width and legend_width
measure them in the figure's face, the same at any screen density (a text's outline once, at one size: its width is
linear in the size, so the sizes a title steps through cost nothing more).

The formula of the bench's response has its own block in the plan (Plan.formula): over the 3D view's title, at the top
of the corner's column, over the 3D view in the row, the pair and the stack (over the third panel in the pair of two
squares). It is as high as the WIDEST formula of the benches needs at its width (formula_room: one line, FORMULA_ONE,
or two, FORMULA_ROOM), the same for every bench and every step at a figure's size, so that nothing under it moves
between benches or steps, and no empty band waits over the 3D view where one line is enough: the room it leaves goes
to the 3D view. `typeset` sets it there in matplotlib's mathtext with the STIX face, as a paper does, on one line or
broken in two at a top-level "+" (fitted, the rule formula_room asks too), hung from the top of its block: its first
line on the row of the panels' titles, the second under it.

matplotlib draws a 3D view in the largest square its box holds, centred, and that drawing leaves the top of its square
empty (the panes) while its tick labels and axis names hang under it: a 3D box wider than tall reaches higher into its
head (`reach`, by a share of its height), where the drawing grows without meeting the legend over it, and stands over
its card's foot by what its labels need there (`hang`: more for a small drawing, none for a large one).

The right column is two cards (Plan.cards, drawn by draw_cards): the 3D view and the third panel each on a rounded
rectangle (CARD_RADIUS) of a raised tone (CARD_TONE, palette.PANEL), told apart from the figure by tone alone, each
holding its panel's head (title and legend, RANK_INSET from its left and HEAD_GAP from its right: head_room), its axes,
tick labels and axis names (CARD_FOOT under the third panel's), with CARD_GAP of the page between the two and CARD_TOP
between the formula's block and the card under it; the design space stays on the page (it is the scene). In the stack
the cards span the figure (CARD_EDGE from its sides), each inside the row a phone shows (web/bridge.crops). A laboratory
draws the cards once per layout, under every axes, and keeps them; `inner` is the room a card leaves under its head
(`under_title`: under its title alone, for a card whose content needs no legend).
In the stack the heads and the formula stand on the cards' inset (CARD_EDGE + RANK_INSET), the widest room a phone has.
A stack narrower than NARROW (a phone's panel, shown one at a time) ends its 3D box SPACE_RIGHT and STACK_LABEL before
the card's edge (the name of y inside it) and gives each head two lines of title and four rows of legend (head_rows,
Plan.head, Plan.titled: titled breaks a title in two rather than cut it; legend_rows takes more rows, then the entries'
short labels, rather than leave one out) and its third panel NARROW_THIRD more than its square; plane_ticks gives a
small design space fewer, rounder ticks.
The true response over a metamodel in the 3D view of steps 2 and 3 is one look, true_wire (and its legend's handle,
wire_handle): the reference's slate, bright, over a dark casing, every WIRE_STRIDE-th line of its grid.

The figure's writing is ONE type system, the window's, named here and used by the three labs (no size, weight or face
is typed in a lab): the faces are the interface font of the column (SANS: Segoe UI) and its monospace (MONO: Consolas),
each a list resolved once among the fonts matplotlib finds (installed) and ending in matplotlib's own DejaVu, the only
one the web's Pyodide has, so that a missing font is never looked for at a draw and a glyph the first face lacks is
drawn by the next; mathematics between dollars in STIX (MATH), as the formula. The roles: TITLE (a panel's title, bold
and white), CAPTION (a legend's labels, at LEGEND_SIZE in LEGEND_INK, the softer white: caption(points)), LABEL (an
axis named in words, muted) and NAME (an axis named by a symbol, X1, X2, Y, in STIX), the tick labels (ticks: TICK,
TICK_SMALL for the 3D view, muted), NOTE (a sentence on a panel), TAG (the name or value beside a mark), SMALL (a muted
line at a panel's foot), STRONG (the one value read first), COUNT (a count in a band), HEADING and NUMBER (a table: its
headings as muted captions, its numbers in the monospace, right-aligned on the digit), HERO (the one number a card is
about, large and bold in the interface font, the face of the strip's value: a number alone, in no column; down to
HERO_LEAST where its room asks), READING (a number read beside its name on a
card, never under 10 points) and DEFINITION (a formula set small under the number it defines). The roles carry no ink
where the ink is a meaning (NOTE, TAG, STRONG, NUMBER, HERO, READING: the lab gives its colour). What is muted and must
be read (LABEL, NAME, HEADING, a foot line) takes MUTED_INK, the column's secondary ink (4.5 : 1 at least on a card); the
tick labels keep the quieter TICK_INK. subtitle sets a caption in a legend's place (what a table's numbers are);
legend_at a legend anywhere, as head does under a title; cut_note the note of a surface cut at the 3D view's window, at
the top of its card under the legend. text_width measures the
face drawn, number_width the monospace; gauge draws a value on a scale (its track, GAUGE_TRACK, and its bar, clamped:
never longer than the scale, empty below it).

level_values, facets, cut_at, dot, beside, tint and subscript are the drawing's helpers: the levels of a metamodel's
faint lines on the plane (LINES their look), the cells of a surface cut at a window, a legend's mark, where a mark's
label goes so that it stays in its panel, a colour with transparency, and a number in subscript. space_ticks gives the
3D view its ticks for the room it has, the same rule in the three steps (each calls it after styling its 3D axes): a
view drawn smaller than SPACE_FEW has at most SPACE_FEW_BINS intervals per axis, so that its labels never crowd.
"""
import itertools
from dataclasses import dataclass, field
from functools import cache

import numpy as np
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
from matplotlib.mathtext import MathTextParser
from matplotlib.patheffects import withStroke
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.path import Path
from matplotlib.textpath import TextPath
from matplotlib.transforms import Affine2D
from matplotlib.ticker import AutoLocator, MaxNLocator

from statistical_fundamentals import palette
from statistical_fundamentals.explorers.lab import LAYOUT_DPI, size
from statistical_fundamentals.explorers.responses import FORMULAS

@cache
def installed(families: tuple[str, ...]) -> tuple[str, ...]:
    """The families of a list that matplotlib finds on this machine, in their order, the last one always kept (it is
    matplotlib's own: DejaVu): resolved once, so that no draw looks a font up and no missing one is ever warned about.
    A list draws each glyph in the first family that has it (Agg's fallback), and TextPath measures it the same way."""
    from matplotlib import font_manager
    found = {entry.name for entry in font_manager.fontManager.ttflist}
    return tuple(family for family in families[:-1] if family in found) + families[-1:]

# The writing of the figure: ONE type system, the window's (gui/style.py), every text of the three labs set by a role
SANS = list(installed(palette.SANS_FACES))       # the interface font of the column (Segoe UI), then DejaVu Sans
MONO = list(installed(palette.MONO_FACES))       # tabulated numbers, right-aligned on the digit (Consolas), then DejaVu Mono
MATH = "stix"                                    # the mathematics of a text between dollars, as the formula's block sets it
TITLE = {"color": palette.WHITE, "fontsize": 12, "fontweight": "bold", "fontfamily": SANS, "math_fontfamily": MATH}
CAPTION = {"fontfamily": SANS, "math_fontfamily": MATH}                          # a legend's labels (LEGEND_SIZE, LEGEND_INK)
MUTED_INK = palette.MUTED            # the muted ink of what must be read (a name, a heading, a foot line): 4.5 : 1 on a card
LABEL = {"color": MUTED_INK, "fontsize": 10, "fontfamily": SANS, "math_fontfamily": MATH}   # the name of an axis, muted
NAME = LABEL | {"fontsize": 12.5}       # an axis named by a symbol (X1, X2, Y: mathematics, whose italic sits small)
TICK, TICK_SMALL = 9, 8                  # points: a 2D panel's tick labels, the 3D view's (muted: TICK_INK), in SANS (ticks)
TICK_INK = palette.GREY               # tick labels may stay quiet
NOTE = {"fontsize": 9.5, "fontfamily": SANS, "math_fontfamily": MATH}            # a sentence on a panel; its ink is its meaning
TAG = {"fontsize": 9, "fontfamily": SANS, "math_fontfamily": MATH}               # the name or value beside a mark
SMALL = {"fontsize": 8.5, "fontfamily": SANS, "math_fontfamily": MATH}           # a muted line at a panel's foot
STRONG = {"fontsize": 11, "fontweight": "semibold", "fontfamily": SANS, "math_fontfamily": MATH}    # the one value read first
COUNT = {"fontsize": 7, "fontweight": "bold", "fontfamily": SANS}               # a count written in a band
HEADING = {"color": MUTED_INK, "fontfamily": SANS, "math_fontfamily": MATH}     # a table's headings: captions, muted (+ size)
NUMBER = {"fontfamily": MONO}                                                   # a table's numbers (+ size), right-aligned
HERO = {"fontsize": 24, "fontweight": "bold", "fontfamily": SANS, "math_fontfamily": MATH}     # the one number a card is about,
                                                                                # in the face of the strip's value (alone: no column)
HERO_LEAST = 16                       # points: a hero number too wide for its room steps down to this, never below
READING = {"fontsize": 10.5, "fontfamily": MONO}                                # a number read beside its name on a card (10 pt
                                                                                # at least: never a tick label's size)
DEFINITION = {"fontsize": 11.5, "fontfamily": SANS, "math_fontfamily": MATH}     # a formula set small under the number it defines
GAUGE_TRACK = palette.tone(55, 58, 61)     # a gauge's track: its whole scale, lighter than the card it stands on (2 : 1)
GAUGE_TICK = palette.GREY             # the ticks at a gauge's ends (gauge, ends): its scale seen even when the bar fills it
X1, X2, Y = "$x_1$", "$x_2$", "$y$"   # the names of the axes, set as mathematics (STIX italic), as a paper sets them
TITLE_LEAST = 9.5                     # points: a title shrinks to this, to fit the room its panel has
SPACE_WIDE = 1.3                      # in a row or a pair: the 3D view is at most this wide, in sides of the squares
# The figure's layout, in layout pixels (explorers/lab.size)
ROW_LEAST = 1020                      # a narrower figure has no room for the three panels in a row
STACK_WIDTH = 620                     # a narrower figure stacks them (the code panel open beside the lab leaves more)
LEGEND_SIZE, LEGEND_LEAST = 10.5, 10.0        # points: a legend shrinks to fit its panel, then breaks into two rows
LEGEND_INK = palette.PROSE            # the labels of a legend: the light ink, a step softer than the titles' white
HANDLE_LENGTH, HANDLE_HEIGHT, HANDLE_PAD = 1.5, 0.9, 0.5    # a legend's handle and the gap to its label, in font sizes
COLUMN_SPACING, LEGEND_PITCH = 1.1, 1.45                    # between the entries of a row; from a row to the next (font sizes)
HEAD_GAP = 14.0                       # layout pixels between a title or a legend and the next panel's
EDGE, TITLE_ROW, LEGEND_ROW = 6.0, 30.0, 40.0     # above a panel: the figure's edge, the line of its title, two rows of legend
HEAD = EDGE + TITLE_ROW + LEGEND_ROW
NARROW = 420.0                        # a figure narrower than this (a phone's panel, stacked) gives each head two lines of title
TITLE_LINE = 21.0                     # and four rows of legend (head_rows): a title is never cut, a legend never loses an entry;
                                      # TITLE_LINE, from a title's first line to its second
NARROW_THIRD = 140.0                  # a narrow figure's third panel is this much taller than its square: the CoP over its
                                      # check, the scoreboard's rows on their lines (layout pixels)
NARROW_ROW = 22.0                     # a row of legend in a narrow figure's head (LEGEND_PITCH at LEGEND_SIZE, rounded up)
PLANE_FEW, PLANE_FEW_BINS = 330.0, 4  # a design space smaller than this (layout pixels) has at most this many intervals per axis,
                                      # at round values (plane_ticks): its tick labels never crowd nor leave the figure
TITLE_DROP = 25.0                     # the baseline of a title, from the top of its block
LEGEND_DROP = 7.0                     # the top of a legend, under its title's baseline
FORMULA_PX, FORMULA_LEAST = 16.0, 12.0        # layout pixels: the size of the formula's type, and the least it shrinks to
FORMULA_ROOM, FORMULA_ONE = 76.0, 42.0     # the formula's block over the 3D view's title, for two lines of the tallest
                                           # formula (Branin's fractions) or one, with air under them (formula_room)
FORMULA_SPACING = 1.05                # between its two lines, in heights of a line
FORMULA_SLACK = 4.0                   # layout pixels: what a line drawn may take beyond its width measured (rounding)
FORMULA_INK = palette.WHITE
FORMULA_REACH = 8.0                   # the corner: the formula's block reaches this far into the figure's right margin
LEFT, CHECK_LEFT, RIGHT, BELOW = 62.0, 66.0, 14.0, 46.0       # the margins of the square panels (the check's ticks are wider)
SIDE_LEAST = 60.0                     # a square panel is never smaller, whatever the figure
SPACE_LEAST = 400.0                   # in a row: the least width of the 3D view
SPACE_GAP, SPACE_OVER, SPACE_RIGHT = 2.0, 16.0, 44.0          # the 3D box: beside a square panel, into its legend's line, at the edge
SPACE_REACH, SPACE_CLEAR = 0.11, 12.0 # a 3D box wider than tall reaches higher into its head by this share of its height
                                      # less this (layout pixels): its drawing's top, about 0.9 of its square, stays under
                                      # the legend's second row; its tick labels, under it, rise with it
SPACE_HANG, SPACE_HANG_SHARE = 46.0, 0.139  # the 3D view's tick labels and axis names fall under its box by about this less this
                                      # share of the side of the square it is drawn in (layout pixels; measured at its first
                                      # angle, from 185 px, 18 under, to 330 px, inside it): hang keeps its card's foot under them
SPACE_ROOM = 60.0                     # in a row: from the 3D box to the check's block (the name of y, then the gap of the cards)
SPACE_INSET = 34.0                    # the title of the 3D view, from the left of its box
PAIR_SHARE, PAIR_MOST, PAIR_GAP = 0.46, 480.0, 12.0           # side by side: the block of the design space
STACK_SIDE = 380.0                    # stacked: the largest side of the square panels
STACK_LABEL = 20.0                    # stacked: the 3D box ends this far before SPACE_RIGHT from its card's edge (the name of y)
SPACE_SHARE = 0.72                    # stacked: the height of the 3D view, of the figure's width
COLUMN_LEAST, COLUMN_MOST, COLUMN_GAP = 400.0, 1.25, 14.0     # the corner's column: least width; most width, in heights of the
                                                              # picture; from the design space's edge to the column's cards
                                                              # (the plane's last tick label overhangs its edge by about 8)
THIRD_SHARE, THIRD_LEAST = 0.36, 145.0       # the corner: the third panel's share of the column's height, and its least height
TALL_SIDE_LEAST = 400.0               # the tall corner (column taller than the design space) needs the space this large at least
SPACE_TALL_LEAST = 150.0              # the corner: the least height of the 3D view's box (the two leasts let the corner, with
                                      # its third panel and the cards, hold the figure a window of 1280 x 720 gives: 928 x 609)
# The cards of the right column: the 3D view and the third panel each on a rounded card of a raised tone (cards)
CARD_TONE = palette.PANEL             # the card's tone, told apart from the figure's (palette.CARD) without a border
CARD_RADIUS = 10.0                    # layout pixels: the rounding of a card's corners
CARD_TOP = 6.0                        # the page between the formula's block and the card under it (the 3D view's head moves down)
CARD_GAP = 10.0                       # the page between the two cards (the corner and the stack)
CARD_PAD = 8.0                        # inside the 3D view's card, under its lowest tick label or axis name (hang)
CARD_FOOT = 6.0                       # the corner and the stack: under the third panel's axis name, inside its card
CARD_EDGE = 6.0                       # the stack: from the figure's sides to the cards
RANK_INSET, RANK_LEFT = 14.0, 16.0    # the competition: from the left of the check's block; from the figure's edge
SUBSCRIPTS = "₀₁₂₃₄₅₆₇₈₉"
LEVELS = 14                           # the level lines of a metamodel's surface on the plane (level_values)
LINES = {"colors": palette.GREY, "linewidths": 0.7, "alpha": 0.55, "zorder": 1, "linestyles": "solid"}    # their look: faint, under
                                                                  # everything, solid below 0 too (a dashed line is a method's model)
LABEL_OFFSET, LABEL_EDGE = (7.0, 6.0), 0.9      # a mark's label (beside): its offset in points; flipped past this share
MEASURE_POINTS = 10.0                # the size a text is measured at once (text_width scales it: extents are linear in the size)
WIRE_STRIDE = 5                       # f's wire over y^ in the 3D view (steps 2 and 3): every fifth line of the grid of 31, 7 a side
WIRE = {"color": palette.SLATE, "linewidth": 1.2, "alpha": 0.95}      # the reference's slate, bright and whole (true_wire)
WIRE_CASING = (withStroke(linewidth=3.0, foreground=palette.BACKGROUND, alpha=0.7),)    # a dark casing under the light line: it
                                                                  # reads on the dark and on the light parts of the surface alike
SPACE_FEW, SPACE_FEW_BINS = 280.0, 4  # a 3D view drawn smaller than this (layout pixels: the square its box holds) has at
                                      # most this many intervals per axis: at 1280 x 720 (about 196 px) the default eight
                                      # labels of x1 crowd into each other

# ------------------------------------------------------------------------------
# The layout
# ------------------------------------------------------------------------------
@dataclass(frozen=True)
class Plan:
    """The figure's panels, in layout pixels from the figure's lower left corner, each a box (left, bottom, width,
    height): the design space (a square of side `side`), the third panel (the check, a square; in the corner the
    scoreboard may fill a rectangle), the 3D view and the competition; where each panel's title begins (its left and
    the top of its block); and the formula's block, over the 3D view's title (its left, its bottom, the width it may
    take, its height: formula_room for that width less the figure's edge above it); and the cards under the 3D view and
    the third panel (cards: by the panel's name, "space" and "check", each a box of the same kind that holds the panel's
    head, its axes, its tick labels and the names of its axes, with CARD_GAP of the page between the two and CARD_TOP
    between the formula's block and the card under it; a panel left out has no card)."""
    kind: str                                   # "corner", "row", "pair" (the third panel left out, or two squares), "stack"
    side: float
    plane: tuple[float, float, float, float]
    check: tuple[float, float, float, float] | None     # None when it is left out
    space: tuple[float, float, float, float]
    ranking: tuple[float, float, float, float]
    heads: dict
    formula: tuple[float, float, float, float]
    room: float                                 # the height the figure needs (a figure as tall as that has no margin)
    cards: dict = field(default_factory=dict)   # "space", "check": the cards of the 3D view and of the third panel
    head: float = HEAD                          # the height of a panel's head: its title's lines and its legend's rows
    titled: float = EDGE + TITLE_ROW            # the height of its title's lines alone (under_title)

def arrangement(width: float, height: float | None, pair: str = "space", fill: bool = False) -> Plan:
    """The panels as large as the figure allows; height None: a figure as tall as it needs (height_for), which has no
    corner. From STACK_WIDTH on the corner is taken when it is feasible and its design space is larger than that of the
    row (width from ROW_LEAST) or of the pair (below it); `fill` lets the third panel fill its rectangle in the corner
    (step 1's table, step 3's scoreboard) instead of being a square (the check, a measure of the diagonal).
    Row: the squares take the height left under their titles, while the 3D view between them keeps SPACE_LEAST (more
    when the squares are small: up to SPACE_WIDE sides). Pair: the design space and the 3D view side by side, the 3D view
    as wide as the width allows, up to SPACE_WIDE sides but at least SPACE_LEAST. pair="check" (width below ROW_LEAST, the
    3D view left out): the design space and the third panel, two squares of the same side, as large as the height and the
    width allow; its Plan has kind "pair" and a check, its box of the 3D view is one pixel (to hide) and its box of the
    competition is the check's; only the titles of the two squares are placed (a figure as tall as it needs, height
    None, has squares of at most STACK_SIDE). Stacked, the squares are as wide as the figure allows, STACK_SIDE at most,
    and smaller in a figure too short for the three."""
    if width < STACK_WIDTH:
        return stack(width, height)
    flat = row(width, height) if width >= ROW_LEAST else pair_squares(width, height) if pair == "check" else pair_space(width, height)
    if height is None:
        return flat
    raised = corner(width, height, fill)
    return raised if raised is not None and raised.side > flat.side else flat

def hung(height: float, group: float) -> float:
    """The bottom of a group of panels `group` high in a figure `height` high: centred, or hung from the top when it
    is taller than the figure."""
    return (height - group) / 2 if height >= group else height - group

def row(width: float, height: float | None) -> Plan:
    """The three panels in a row, the 3D view between the squares."""
    height = height or 0.0
    room = width - LEFT - CHECK_LEFT - RIGHT - SPACE_GAP - SPACE_ROOM             # for the two squares and the 3D view
    side = max(min(height - HEAD - BELOW, (room - SPACE_LEAST) / 2), SIDE_LEAST)
    wide = max(min(room - 2 * side, max(SPACE_LEAST, SPACE_WIDE * side)), 1.0)
    left = max(width - (LEFT + 2 * side + SPACE_GAP + wide + SPACE_ROOM + CHECK_LEFT + RIGHT), 0.0) / 2
    group = HEAD + side + BELOW
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    space = plane + side + SPACE_GAP
    block = space + wide + SPACE_ROOM                                            # of the check: its tick labels and their name
    check = block + CHECK_LEFT
    high = formula_room(block - plane - side - SPACE_INSET)
    lower = top - high - CARD_TOP                                                # the 3D view's card, under the formula
    heads = {"plane": (plane, top), "space": (plane + side + SPACE_INSET, lower), "check": (block + RANK_INSET, top),
             "ranking": (block + RANK_INSET, top)}
    title = plane + side + SPACE_INSET - RANK_INSET                              # the 3D card: its title RANK_INSET in
    cards = {"space": (title, bottom, block - CARD_GAP - title, lower - bottom),
             "check": (block, bottom, check + side + RIGHT - block, top - bottom)}
    return Plan("row", side, (plane, base, side, side), (check, base, side, side),
                lifted(space, bottom, wide, group - HEAD + SPACE_OVER - high - CARD_TOP),
                (block + RANK_INSET, base, check + side - block - RANK_INSET, side), heads,
                writing(plane + side + SPACE_INSET, top, block, high), group, cards)

def reach(box: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    """The 3D view's box (left, bottom, width, height) reaching higher into its head: matplotlib draws a 3D view in
    the largest square its box holds, centred, and the drawing leaves the top tenth of that square empty (the panes)
    while its tick labels and axis names hang under it. A box wider than tall grows by SPACE_REACH of its height less
    SPACE_CLEAR, up to its width (its square grows with it, and its drawing's top stays under the legend over it); a box
    already as tall as wide keeps its height, since its drawing would only rise towards its legend."""
    left, bottom, wide, tall = box
    return left, bottom, wide, min(tall + max(SPACE_REACH * tall - SPACE_CLEAR, 0.0), max(tall, wide))

def hang(room: float, wide: float) -> float:
    """From the foot of the 3D view's card up to its box, for a box `wide` layout pixels wide that may take `room` of
    height over that foot: its tick labels and axis names fall under its drawing by about SPACE_HANG less SPACE_HANG_SHARE
    of the side of the square it is drawn in (reach), the more the smaller it is, and CARD_PAD stays under them; 0 for a
    drawing large enough to hold them in its box. A few rounds of the fixed point: the side depends on the hang."""
    under = 0.0
    for _ in range(4):
        _, _, wide_, tall = reach((0.0, 0.0, wide, max(room - under, 1.0)))
        under = max(SPACE_HANG - SPACE_HANG_SHARE * min(wide_, tall) + CARD_PAD, 0.0)
    return under

def lifted(left: float, bottom: float, wide: float, room: float) -> tuple[float, float, float, float]:
    """The 3D box of the row and the pair: from its card's foot `bottom`, raised by hang, up to `room` over that foot."""
    under = hang(room, wide)
    return reach((left, bottom + under, wide, room - under))

def writing(left: float, top: float, right: float, high: float) -> tuple[float, float, float, float]:
    """The formula's block from `left` to `right`, under the top `top` of the 3D view's head: `high` (formula_room),
    the figure's edge left above the type; the 3D view's title begins under it."""
    return left, top - high, max(right - left, 1.0), high - EDGE

def formula_room(wide: float) -> float:
    """The height of the formula's block `wide` layout pixels wide: FORMULA_ONE when the widest formula of the benches
    keeps to one line there (typeset's rule: fitted), FORMULA_ROOM when one of them breaks into two. The same for every
    bench, so that nothing under the block moves from a bench to another; measured a hair narrower than the block, so
    that typeset, which measures the same block in figure fractions, never finds a line more than was kept."""
    return FORMULA_ONE if formula_lines(round(wide - FORMULA_SLACK - 1e-3, 3)) == 1 else FORMULA_ROOM

@cache
def formula_lines(room: float) -> int:
    """The most lines a formula of the benches (explorers/responses.FORMULAS) takes `room` layout pixels wide."""
    return max(len(fitted(terms, room)[0]) for terms in FORMULAS.values())

def pair_space(width: float, height: float | None) -> Plan:
    """The design space and the 3D view side by side, the third panel left out; the competition takes the plane's place."""
    height = height or 0.0
    block = max(PAIR_SHARE * width, min(width - SPACE_LEAST, PAIR_MOST))
    side = max(min(height - HEAD - BELOW, block - LEFT - PAIR_GAP), SIDE_LEAST)
    wide = max(min(width - LEFT - side - SPACE_GAP - SPACE_RIGHT, max(SPACE_LEAST, SPACE_WIDE * side)), 1.0)
    left = max(width - (LEFT + side + SPACE_GAP + wide + SPACE_RIGHT), 0.0) / 2
    group = HEAD + side + BELOW
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    space = plane + side + SPACE_GAP
    high = formula_room(space + wide + SPACE_RIGHT - RIGHT - plane - side - SPACE_INSET)
    lower = top - high - CARD_TOP                                                # the 3D view's card, under the formula
    heads = {"plane": (plane, top), "space": (plane + side + SPACE_INSET, lower), "ranking": (left + RANK_LEFT, top)}
    title = plane + side + SPACE_INSET - RANK_INSET
    cards = {"space": (title, bottom, space + wide + SPACE_RIGHT - title, lower - bottom)}
    return Plan("pair", side, (plane, base, side, side), None,
                lifted(space, bottom, wide, group - HEAD + SPACE_OVER - high - CARD_TOP),
                (left + RANK_LEFT, base, LEFT + side - RANK_LEFT, side), heads,
                writing(plane + side + SPACE_INSET, top, space + wide + SPACE_RIGHT - RIGHT, high), group, cards)

def pair_squares(width: float, height: float | None) -> Plan:
    """The design space and the third panel, two equal squares; the 3D view a box of one pixel, to hide."""
    widest = (width - LEFT - CHECK_LEFT - RIGHT) / 2
    asked = height

    def squares(high: float) -> tuple[float, float]:
        """The side of the squares and the figure's height under a formula's block `high`."""
        tall = high + HEAD + max(min(widest, STACK_SIDE), SIDE_LEAST) + BELOW if asked is None else asked
        return max(min(tall - high - HEAD - BELOW, widest), SIDE_LEAST), tall
    high = FORMULA_ROOM
    side, height = squares(high)
    if formula_room(side) < high:                                     # one line over a square this large: larger squares,
        high = FORMULA_ONE                                            # whose width keeps it to one line
        side, height = squares(high)
    left = max(width - (LEFT + 2 * side + CHECK_LEFT + RIGHT), 0.0) / 2
    group = high + HEAD + side + BELOW                              # the formula over the third panel, both titles under it
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    check = plane + side + CHECK_LEFT
    heads = {"plane": (plane, top - high), "check": (check, top - high)}
    cards = {"check": (check - CHECK_LEFT, bottom, CHECK_LEFT + side + RIGHT, top - high - bottom)}     # no step asks for it now
    return Plan("pair", side, (plane, base, side, side), (check, base, side, side), (0.0, 0.0, 1.0, 1.0), (check, base, side, side), heads,
                writing(check, top, check + side, high), group, cards)

def stack(width: float, height: float | None) -> Plan:
    """The three panels one under the other: the squares as wide as the figure allows, the 3D view between them."""
    asked = height

    def sized(high: float) -> tuple[float, float, float, float, float]:
        """The side of the squares, the height of the 3D view, the height the figure needs and has, and the lift of
        the picture, under a formula's block `high`."""
        side = max(min(width - CHECK_LEFT - RIGHT, STACK_SIDE), SIDE_LEAST)
        tall = SPACE_SHARE * width
        fixed = 3 * headed + 2 * BELOW - SPACE_OVER + EDGE + high + CARD_TOP + CARD_GAP + CARD_FOOT + longer
        room = fixed + 2 * side + tall + hang(tall, width)
        lift, height = 0.0, asked
        if height is None:
            height = room
        elif height < room:                                           # a figure too short: everything smaller, in proportion
            share = max(height - fixed - hang(tall, width), 0.0) / (2 * side + tall)
            side, tall = max(side * share, SIDE_LEAST), max(tall * share, SIDE_LEAST)
        else:
            lift = (height - room) / 2
        return side, tall, room, height, lift

    def plane_of(side: float) -> float:
        return max(width - (CHECK_LEFT + side + RIGHT), 0.0) / 2 + CHECK_LEFT
    lines, rows = head_rows(width)
    longer = NARROW_THIRD if lines > 1 else 0.0                      # a phone's third panel: taller than its square
    headed = EDGE + TITLE_ROW + (lines - 1) * TITLE_LINE + rows * (LEGEND_ROW / 2 if rows <= 2 else NARROW_ROW)   # a phone's: more
    inset = CARD_EDGE + RANK_INSET                                    # the titles and the formula: on the cards' inset, the
    high = FORMULA_ONE                                                # widest room a narrow figure has (one line of formula,
    side, tall, room, height, lift = sized(high)                      # if the block it leaves still holds it)
    if formula_room(width - RIGHT - inset) > high:
        high = FORMULA_ROOM
        side, tall, room, height, lift = sized(high)
    plane = plane_of(side)
    left = plane - CHECK_LEFT
    top = height - lift                                               # the design space
    base = top - headed - side
    middle = base - BELOW - high - CARD_TOP                           # the 3D view, under the formula: its card's top
    floor = middle - headed + SPACE_OVER - tall
    under = floor - hang(tall, width) - CARD_GAP                      # the check: its card's top
    low = under - headed - side - longer
    heads = {"plane": (inset, top), "space": (inset, middle), "check": (inset, under), "ranking": (inset, under)}
    wide = max(width - 2 * CARD_EDGE, 1.0)                            # the cards: the figure's width, CARD_EDGE in from its sides
    cards = {"space": (CARD_EDGE, under + CARD_GAP, wide, middle - under - CARD_GAP),
             "check": (CARD_EDGE, low - BELOW - CARD_FOOT, wide, under - low + BELOW + CARD_FOOT)}
    return Plan("stack", side, (plane, base, side, side), (plane, low, side, side + longer),
                reach((CARD_EDGE, floor, width - CARD_EDGE - SPACE_RIGHT - STACK_LABEL, tall) if longer else (0.0, floor, width, tall)),
                (left + RANK_LEFT, low, CHECK_LEFT + side - RANK_LEFT, side + longer), heads,
                writing(inset, base - BELOW, width - RIGHT, high),
                room, cards, headed, EDGE + TITLE_ROW + (lines - 1) * TITLE_LINE)

def head_rows(width: float) -> tuple[int, int]:
    """The lines of title and the rows of legend a panel's head holds in a figure `width` layout pixels wide: two and
    four in a narrow one (NARROW: a phone shows its panels one at a time), one and two otherwise (LEGEND_ROW)."""
    return (2, 4) if width < NARROW else (1, 2)

def corner(width: float, height: float, fill: bool) -> Plan | None:
    """The design space at the left, as large as the height allows (the column keeps COLUMN_LEAST); at its right the 3D
    view over the third panel, which takes THIRD_SHARE of the height the column has under its two titles (THIRD_LEAST at
    least). None when the figure has no room: the design space under SIDE_LEAST, or the 3D view under SPACE_TALL_LEAST.
    The third panel is a square, centred with its tick labels in the column, or, with `fill`, the whole rectangle.
    When the width binds the design space (side under the height) and it is at least TALL_SIDE_LEAST, the column is a
    picture of its own as tall as the figure, the design space centred vertically on its own: the plane's title then
    stands on another line than the 3D view's, and `head` keeps it before the column."""
    side = min(height - HEAD - BELOW, width - LEFT - COLUMN_GAP - COLUMN_LEAST - RIGHT)
    group = HEAD + side + BELOW                                       # the design space's picture
    tall = TALL_SIDE_LEAST <= side < height - HEAD - BELOW - 1e-9     # bound by the width, with height to spare: the column
    whole = height if tall else group                                 # takes the figure's height and the plane centres on its own
    column = min(width - LEFT - side - COLUMN_GAP - RIGHT, COLUMN_MOST * whole)
    high = formula_room(column + FORMULA_REACH - RANK_INSET)          # the formula's block, at the top of the column
    held = whole - 2 * HEAD - BELOW - high                            # the column's height under the formula and its two titles
    third = max(THIRD_SHARE * held, THIRD_LEAST)
    wide = column + RIGHT - SPACE_RIGHT - CARD_PAD                    # the 3D box: its name of y inside its card
    under = hang(held + SPACE_OVER - third - CARD_FOOT - CARD_TOP - CARD_GAP, wide)    # from its card's foot up to the 3D box
    lifted = held - third - CARD_FOOT - CARD_TOP - CARD_GAP - under   # the 3D box, before it reaches into its head
    if side < SIDE_LEAST or lifted < SPACE_TALL_LEAST:
        return None
    left = max(width - (LEFT + side + COLUMN_GAP + column + RIGHT), 0.0) / 2
    low = hung(height, whole)                                         # the bottom of the column: the third panel's card
    bottom = hung(height, group)
    base, top = bottom + BELOW, bottom + group
    plane = left + LEFT
    start = plane + side + COLUMN_GAP                                 # the left of the column, and of its cards
    right = start + column + RIGHT                                    # the right of the cards (the picture's edge)
    floor = low + BELOW + CARD_FOOT                                   # the third panel's axes, its name under them in its card
    if fill:
        shape = (start + CHECK_LEFT, floor, column - CHECK_LEFT, third)
    else:
        square = min(third, column - CHECK_LEFT)
        shape = (start + (column - CHECK_LEFT - square) / 2 + CHECK_LEFT, floor, square, square)
    block = floor + third + HEAD                                      # the top of the third panel's block: its card's top
    over = low + whole                                                # the top of the column: the formula, then the 3D view
    lower = over - high - CARD_TOP                                    # the top of the 3D view's head: its card's top
    space = reach((start, block + CARD_GAP + under, wide, lower - HEAD + SPACE_OVER - block - CARD_GAP - under))
    heads = {"plane": (plane, top), "space": (start + RANK_INSET, lower), "check": (start + RANK_INSET, block),
             "ranking": (start + RANK_INSET, block)}
    cards = {"space": (start, block + CARD_GAP, right - start, lower - block - CARD_GAP), "check": (start, low, right - start, block - low)}
    return Plan("corner", side, (plane, base, side, side), shape, space,
                (start + RANK_INSET, floor, column - RANK_INSET, third), heads,
                writing(start + RANK_INSET, over, start + column + FORMULA_REACH, high), whole, cards)

def places(plan: Plan, width: float, height: float, names=None) -> dict:
    """The places of the panels' heads in figure fractions, for head: (left, baseline of the title, top of the legend)
    for each panel (those of `names` only, when given), under the key "formula" the formula's block (x0, y0, x1, y1),
    which no title or legend at its left runs into, and under "card <name>" the card of a panel that has one (x0, y0,
    x1, y1), whose head ends HEAD_GAP before the card's right edge."""
    heads = {name: (x / width, (top - TITLE_DROP) / height, (top - TITLE_DROP - LEGEND_DROP) / height)
             for name, (x, top) in plan.heads.items() if names is None or name in names}
    left, bottom, wide, tall = plan.formula
    heads["formula"] = (left / width, bottom / height, (left + wide) / width, (bottom + tall) / height)
    for name, (left, bottom, wide, tall) in plan.cards.items():
        card = (left / width, bottom / height, (left + wide) / width, (bottom + tall) / height)
        for panel in (name, "ranking") if name == "check" else (name,):     # the competition stands on the third panel's card
            if names is None or panel in names:
                heads[f"card {panel}"] = card
    return heads

def head(figure, heads: dict, axes: dict, name: str, title: str, handles: list) -> int:
    """Above a panel: its title and, under it, its legend, each in the room the panel has before what stands at its
    right at the height of its head: the next panel's title on the same line, a panel on show whose box reaches that
    height (its own title elsewhere: the tall corner; the third panel of a row beside the 3D view's title), the
    formula's block. The title shrinks to fit (to TITLE_LEAST); the legend, in the light ink, to LEGEND_LEAST, then
    breaks into two rows at LEGEND_SIZE (the plan keeps the room of two rows, LEGEND_ROW, in every step), and only then
    loses its last entries (the first say what the panel is). No entry, no legend: its room stays reserved (nothing
    under it moves). `heads` is the places of the titles (figure fractions: left, baseline, legend's top; places) and
    `axes` the panels, of which only those on show count. Returns the rows of legend drawn (0, 1 or 2)."""
    x, baseline, legend = heads[name]
    width, height = size(figure)
    room = head_room(figure, heads, axes, name)
    lines, rows = head_rows(width)
    said = titled(title, room, lines)
    points = said[1]
    for k, line in enumerate(said[0]):
        figure.text(x, baseline - k * TITLE_LINE / height, line, ha="left", va="baseline", **(TITLE | {"fontsize": points}))
    return legend_at(figure, x, legend - (len(said[0]) - 1) * TITLE_LINE / height, room, handles, rows)

def title_drop(figure, heads: dict, axes: dict, name: str, title: str) -> float:
    """How far under its usual place a panel's legend (or caption) stands, in figure fractions: a title on two lines
    (titled) pushes it down by TITLE_LINE."""
    lines, _ = head_rows(size(figure)[0])
    return (len(titled(title, head_room(figure, heads, axes, name), lines)[0]) - 1) * TITLE_LINE / size(figure)[1]

def titled(title: str, room: float, lines: int = 1) -> tuple[tuple[str, ...], float]:
    """A title's lines and its size in points, `room` layout pixels wide: one line from TITLE's size down to
    TITLE_LEAST; where the head holds two lines (head_rows), broken at the word that leaves the shorter longest line,
    at the largest size both fit; else one line at TITLE_LEAST (a figure wide enough never needs it)."""
    weight = TITLE["fontweight"]
    points = TITLE["fontsize"]
    while points > TITLE_LEAST and text_width(title, points, weight) > room:
        points -= 0.5
    words = title.split()
    if text_width(title, points, weight) <= room or lines < 2 or len(words) < 2:
        return (title,), points
    pairs = [(" ".join(words[:k]), " ".join(words[k:])) for k in range(1, len(words))]
    pair = min(pairs, key=lambda two: max(text_width(line, TITLE["fontsize"], weight) for line in two))
    points = TITLE["fontsize"]
    while points > TITLE_LEAST and max(text_width(line, points, weight) for line in pair) > room:
        points -= 0.5
    return pair, points

def legend_at(figure, x: float, top: float, room: float, handles: list, most: int = 2) -> int:
    """A legend at (x, top) in figure fractions, `room` layout pixels wide: one row, or two (legend_rows), each a legend
    of its own (no columns to align); head's, and that of a panel whose legend stands over its own content rather than
    under its card's title (step 2's check, beside the CoP); `most` rows (four in a narrow figure). Returns the rows
    drawn."""
    height = size(figure)[1]
    rows, small = legend_rows(handles, room, most) if handles else ([], LEGEND_SIZE)
    rows = [row for row in rows if row]
    for k, row in enumerate(rows):
        at = top - k * LEGEND_PITCH * small / 72 * LAYOUT_DPI / height
        figure.legend(handles=row, loc="upper left", bbox_to_anchor=(x, at), ncol=len(row), frameon=False, prop=caption(small),
                      labelcolor=LEGEND_INK, handlelength=HANDLE_LENGTH, handleheight=HANDLE_HEIGHT, columnspacing=COLUMN_SPACING,
                      handletextpad=HANDLE_PAD, borderaxespad=0.0, borderpad=0.0)
    return len(rows)

def cut_note(ax, heads: dict, name: str, text: str, color: str):
    """A note on a 3D view whose surface is cut at the vertical window, at the top of its card under the two rows its
    legend may take (the same place in steps 2 and 3, whatever their legends hold), where no tick label or axis name
    stands: on one line where the card holds it, else broken at the words; in the TAG role. Returns the Text."""
    width, height = size(ax.figure)
    x, _, legend = heads[name]
    room = (heads[f"card {name}"][2] - x) * width - RANK_INSET
    top = legend - LEGEND_ROW / height
    lines: list[str] = []
    for word in text.split():
        if lines and text_width(f"{lines[-1]} {word}", TAG["fontsize"]) <= room:
            lines[-1] = f"{lines[-1]} {word}"
        else:
            lines.append(word)
    box = ax.get_position()
    return ax.text2D((x - box.x0) / box.width, (top - box.y0) / box.height, "\n".join(lines), transform=ax.transAxes, ha="left",
                     va="top", color=color, zorder=10, **TAG)

def subtitle(figure, heads: dict, name: str, text: str, room: float | None = None, drop: float = 0.0):
    """A caption in the place of a panel's legend, under its title: what its content's numbers are (step 1's table),
    in the muted ink at the legend's size, one row, `room` layout pixels wide at most (down to LEGEND_LEAST, then broken
    in two at a word in a narrow figure, whose head keeps four rows), `drop` under the legend's place (title_drop);
    returns the Text."""
    x, _, legend = heads[name]
    legend -= drop
    points = LEGEND_SIZE
    while room is not None and points > LEGEND_LEAST and text_width(text, points) > room:
        points -= 0.5
    if room is not None and text_width(text, points) > room and len(text.split()) > 1:
        words = text.split()
        pair = min(((" ".join(words[:k]), " ".join(words[k:])) for k in range(1, len(words))),
                   key=lambda two: max(text_width(line, points) for line in two))
        text = "\n".join(pair)
    return figure.text(x, legend, text, ha="left", va="top", color=MUTED_INK, linespacing=LEGEND_PITCH,
                       **(CAPTION | {"fontsize": points}))

def plane_ticks(ax) -> None:
    """The design space's ticks for the room it has, the same rule in the three steps (each calls it once its limits are
    set): drawn smaller than PLANE_FEW, at most PLANE_FEW_BINS intervals on each axis at round values (1, 2, 5, 10 and
    their powers of ten: no "12.5", no "10.0" at the edge); larger, matplotlib's own choice."""
    position = ax.get_position()
    width, height = size(ax.figure)
    if min(position.width * width, position.height * height) < PLANE_FEW:
        for axis in (ax.xaxis, ax.yaxis):
            axis.set_major_locator(MaxNLocator(PLANE_FEW_BINS, steps=[1, 2, 5, 10]))

def head_room(figure, heads: dict, axes: dict, name: str) -> float:
    """The width a panel's head may take, in layout pixels: to what stands at its right in the band of its title and
    its two rows of legend (the next title on the same line, a panel on show whose box reaches that band, the formula's
    block, another panel's card), less HEAD_GAP; to the figure's edge when nothing does."""
    x, baseline, legend = heads[name]
    width, height = size(figure)
    low, high = legend - LEGEND_ROW / height, baseline + (TITLE_DROP - EDGE) / height      # the band of the head
    others = [other for key, (other, line, *_) in heads.items() if key != name and line == baseline and other > x
              and key in axes and axes[key].get_visible()]                     # the panels on show only
    for key, ax in axes.items():                                              # a panel at the right whose box stands at
        box = ax.get_position(original=True)                                  # the height of the head, its own title on
        if key != name and ax.get_visible() and box.x0 > x and box.y0 < high and box.y1 > low:     # another line
            beside = heads.get(key)
            others.append(min(box.x0, beside[0]) if beside is not None and beside[0] > x else box.x0)
    if "formula" in heads:
        x0, y0, _, y1 = heads["formula"]
        if x0 > x and y0 < high and y1 > low:
            others.append(x0)
    if f"card {name}" in heads:                                               # a panel on a card: to the card's edge
        others.append(heads[f"card {name}"][2])
    own = heads.get(f"card {name}")
    for key, card in heads.items():                                           # another panel's card at the right, at the
        if key.startswith("card ") and card != own and card[0] > x and card[1] < high and card[3] > low:     # height of
            others.append(card[0])                                            # the head (the 3D view's, by the plane's legend)
    return (min(others, default=1.0) - x) * width - HEAD_GAP

def legend_rows(handles: list, room: float, most: int = 2) -> tuple[list[list], float]:
    """The rows of a legend `room` layout pixels wide and its size in points: one row at LEGEND_SIZE, or smaller down
    to LEGEND_LEAST; else two rows (up to `most`: four in a narrow figure), the entries in their order, broken where
    the longest row is the shortest, at LEGEND_SIZE or smaller down to LEGEND_LEAST; else the same with the short labels
    of the entries that have one (dot's `short`: "f's minima" for "f's minima (unknown in a real study)"), set on them;
    else, at LEGEND_LEAST, the last entries left out (the first say what the panel is) until two rows hold the rest."""
    labels = [handle.get_label() for handle in handles]
    for small in sizes():
        if legend_width(labels, small) <= room:
            return [list(handles)], small

    def broken(count, small):
        """The cuts into `count` rows whose longest row is the shortest, and that row's width."""
        best = None
        for cuts in itertools.combinations(range(1, len(handles)), count - 1):
            edges = (0, *cuts, len(handles))
            wide = max(legend_width(labels[a:b], small) for a, b in zip(edges, edges[1:]))
            if best is None or wide < best[1]:
                best = (edges, wide)
        return best

    def widest(cut, small):
        return max(legend_width(labels[:cut], small), legend_width(labels[cut:], small))
    shorter = [getattr(handle, "short", None) or handle.get_label() for handle in handles]
    for words in ((labels, shorter) if shorter != labels else (labels,)):
        labels = words
        for count in range(2, min(most, len(handles)) + 1):
            for small in sizes():
                edges, wide = broken(count, small)
                if wide <= room:
                    for handle, label in zip(handles, labels):
                        handle.set_label(label)
                    return [list(handles[a:b]) for a, b in zip(edges, edges[1:])], small
    for handle, label in zip(handles, labels):
        handle.set_label(label)
    while len(handles) > 1:
        for small in sizes():
            cut = min(range(1, len(handles)), key=lambda k: widest(k, small))
            if widest(cut, small) <= room or len(handles) == 2 and small == LEGEND_LEAST:
                return [list(handles[:cut]), list(handles[cut:])], small
        handles, labels = handles[:-1], labels[:-1]
    return [list(handles)], LEGEND_LEAST

def legend_fits(handles: list, room: float) -> bool:
    """Whether a legend holds every entry in its one or two rows `room` layout pixels wide (legend_rows), none left out
    and none wider than the room."""
    rows, small = legend_rows(handles, room)
    return sum(len(row) for row in rows) == len(handles) and all(
        legend_width([handle.get_label() for handle in row], small) <= room for row in rows)

def sizes() -> list[float]:
    """The sizes a legend steps down through, in points: LEGEND_SIZE to LEGEND_LEAST by half a point."""
    return [LEGEND_SIZE - 0.5 * k for k in range(int(round((LEGEND_SIZE - LEGEND_LEAST) / 0.5)) + 1)]

# ------------------------------------------------------------------------------
# The cards of the right column
# ------------------------------------------------------------------------------
def draw_cards(figure, plan: Plan, names=None) -> dict:
    """The cards of the plan (Plan.cards; those of `names` only, when given) drawn on the figure under every panel: a
    rounded rectangle of CARD_TONE, CARD_RADIUS layout pixels at its corners, with no border, laid out in layout pixels
    (the rounding stays round and the same at any density of the screen). Returns the patches by the panel's name: a
    laboratory draws them once per layout, when it makes its axes, and keeps them (a redraw clears axes, texts and
    legends, never them)."""
    pixels = Affine2D().scale(1 / LAYOUT_DPI) + figure.dpi_scale_trans          # layout pixels to the screen's
    drawn = {}
    for name, (left, bottom, wide, tall) in plan.cards.items():
        if names is not None and name not in names:
            continue
        card = FancyBboxPatch((left, bottom), max(wide, 1.0), max(tall, 1.0), boxstyle=f"round,pad=0,rounding_size={CARD_RADIUS}",
                              transform=pixels, facecolor=CARD_TONE, edgecolor="none", linewidth=0, zorder=-1)
        drawn[name] = figure.add_artist(card)
    return drawn

def inner(plan: Plan, name: str) -> tuple[float, float, float, float]:
    """The room inside a panel's card under its head, in layout pixels (left, bottom, width, height): RANK_INSET in from
    the card's sides, CARD_FOOT up from its foot, HEAD down from its top (the title and two rows of legend). What a
    laboratory draws in a card stays in it."""
    left, bottom, wide, tall = plan.cards[name]
    return left + RANK_INSET, bottom + CARD_FOOT, max(wide - 2 * RANK_INSET, 1.0), max(tall - CARD_FOOT - plan.head, 1.0)

def under_title(plan: Plan, name: str, side: float = RANK_INSET) -> tuple[float, float, float, float]:
    """The room inside a panel's card under its title alone, for a card whose head has no legend (its own content
    names what it shows, as a table's headings do), in layout pixels (left, bottom, width, height): `side` in from the
    card's sides, CARD_FOOT up from its foot, EDGE and TITLE_ROW down from its top."""
    left, bottom, wide, tall = plan.cards[name]
    return left + side, bottom + CARD_FOOT, max(wide - 2 * side, 1.0), max(tall - CARD_FOOT - plan.titled, 1.0)

# ------------------------------------------------------------------------------
# The formula of the response, typeset in the figure
# ------------------------------------------------------------------------------
def typeset(figure, heads: dict, terms: tuple[str, ...]):
    """The formula of the bench's response in its block (heads["formula"], places), as a paper sets it: mathtext in
    the STIX face, FORMULA_PX layout pixels high, white, hung from the top of its block: its first line stands on the
    row of the panels' titles (its baseline TITLE_DROP under the top of a head, as a title's), the second line under it
    when there is one. On one line when it fits the block's width; otherwise broken in two at a top-level "+" (the
    break that leaves the shorter longest line), the second line aligned after the "=" and opened by its "+"; still too
    wide, the type steps down half a pixel at a time to FORMULA_LEAST, never below (fitted). The block keeps the room
    of the lines the widest formula of the benches takes at its width (formula_room), so nothing under it moves from a
    bench to another. Returns the Text drawn (one artist, both lines)."""
    width, height = size(figure)
    x0, _, x1, y1 = heads["formula"]
    lines, px = fitted(terms, (x1 - x0) * width - FORMULA_SLACK)
    top = y1 * height + EDGE - TITLE_DROP + mathtext_ascent(lines[0], px)     # the first line's baseline on the titles' row
    return figure.text(x0, top / height, "\n".join(lines), ha="left", va="top", fontsize=px * 72 / LAYOUT_DPI, color=FORMULA_INK,
                       math_fontfamily="stix", linespacing=FORMULA_SPACING)

def fitted(terms: tuple[str, ...], room: float) -> tuple[tuple[str, ...], float]:
    """The lines of a formula `room` layout pixels wide and their size in layout pixels: the first size from FORMULA_PX
    down by half a pixel at which it fits, on one line or broken in two (layout); at FORMULA_LEAST, broken at its best
    when nothing fits."""
    px = FORMULA_PX
    lines = layout(terms, px, room)
    while lines is None and px > FORMULA_LEAST:
        px -= 0.5
        lines = layout(terms, px, room)
    if lines is None:                                                 # nothing fits: the least size, broken at its best
        lines = min(breaks(terms, px), key=lambda pair: max(mathtext_width(line, px) for line in pair))
    return tuple(lines), px

def layout(terms: tuple[str, ...], px: float, room: float) -> tuple[str, ...] | None:
    """The lines of the formula at `px` within `room` layout pixels: one line, or the break into two whose longest line
    is the shortest; None when neither fits."""
    whole = ("$" + " + ".join(terms) + "$",)
    if mathtext_width(whole[0], px) <= room:
        return whole
    fitting = [pair for pair in breaks(terms, px) if max(mathtext_width(line, px) for line in pair) <= room]
    return min(fitting, key=lambda pair: max(mathtext_width(line, px) for line in pair)) if fitting else None

def breaks(terms: tuple[str, ...], px: float) -> list[tuple[str, str]]:
    """Every break of the formula into two lines at a top-level "+": the first line, and the second set in from the
    left by the width of the formula's left side ("f(x1, x2) ="), opened by its "+"."""
    left = terms[0].split("=")[0] + "="
    indent = mathtext_width(f"${left}$", px) / px                    # in ems of the type: mathtext's \hspace
    return [("$" + " + ".join(terms[:k]) + "$", rf"$\hspace{{{indent:.3f}}}+\ " + " + ".join(terms[k:]) + "$")
            for k in range(1, len(terms))]

@cache
def mathtext_box(text: str, px: float) -> tuple[float, float, float]:
    """The width, the height and the depth (under the baseline) of a line of mathtext set in the STIX face at `px`
    layout pixels, in layout pixels."""
    parsed = MathTextParser("path").parse(text, dpi=72, prop=FontProperties(size=px * 72 / LAYOUT_DPI, math_fontfamily="stix"))
    return parsed.width * LAYOUT_DPI / 72, parsed.height * LAYOUT_DPI / 72, parsed.depth * LAYOUT_DPI / 72

def mathtext_width(text: str, px: float) -> float:
    """The width of a line of mathtext set in the STIX face at `px` layout pixels, in layout pixels."""
    return mathtext_box(text, px)[0]

def mathtext_ascent(text: str, px: float) -> float:
    """How far a line of mathtext set at `px` layout pixels rises over its baseline, in layout pixels."""
    _, high, deep = mathtext_box(text, px)
    return high - deep

# ------------------------------------------------------------------------------
# Small helpers
# ------------------------------------------------------------------------------
def text_width(text: str, points: float, weight: str = "normal") -> float:
    """The width of a text drawn in the figure's face (SANS, as titles and legends are drawn: each glyph in the first
    family that has it) at `points`, in layout pixels (the same at any screen density):
    the width of one point (width_per_point) times the size. A TextPath is the outline of the glyphs at one size scaled
    by points / FONT_SCALE, so its extents are linear in the size: a title stepped down half a point at a time, or a
    legend whose labels carry numbers, is measured once per text and weight, not once per size."""
    return points * width_per_point(text, weight)

@cache
def width_per_point(text: str, weight: str = "normal") -> float:
    """The width of a text in layout pixels per point of its size, measured once at MEASURE_POINTS: the horizontal
    extent of its outline (outline_width)."""
    path = TextPath((0, 0), text, size=MEASURE_POINTS, prop=FontProperties(family=SANS, weight=weight, math_fontfamily=MATH))
    return outline_width(path) * LAYOUT_DPI / 72 / MEASURE_POINTS

def outline_width(path: Path) -> float:
    """The horizontal extent of a glyph outline, exactly what path.get_extents().width gives, in one pass over its
    arrays: the points on the outline, and for every quadratic curve (on, control, on) its extreme in x where the
    derivative vanishes inside the curve, t = (p0 - p1) / (p0 - 2 p1 + p2). get_extents finds the same extremes curve by
    curve, with a polynomial root finder each: about 50 ms for a title. An outline with cubic curves (not a TrueType
    face) is measured by get_extents."""
    vertices, codes = path.vertices, path.codes
    if codes is None or not len(codes) or (codes == Path.CURVE4).any():
        return path.get_extents().width
    curve = codes == Path.CURVE3
    control = np.zeros(len(codes), dtype=bool)                        # straight outlines only ("i", "W"): no control point
    if curve.any():
        begins = curve & ~np.r_[False, curve[:-1]]                    # the runs of CURVE3 codes: control, end, control, end...
        run = np.flatnonzero(begins)[np.maximum(np.cumsum(begins) - 1, 0)]
        control = curve & ((np.arange(len(codes)) - run) % 2 == 0)
    x = vertices[:, 0]
    on = x[~control & (codes != Path.CLOSEPOLY)]
    k = np.flatnonzero(control)
    p0, p1, p2 = x[k - 1], x[k], x[k + 1]
    bend = p0 - 2 * p1 + p2
    t = np.divide(p0 - p1, bend, out=np.full(len(k), -1.0), where=bend != 0)
    inside = (t > 0) & (t < 1)
    t, p0, p1, p2 = t[inside], p0[inside], p1[inside], p2[inside]
    extremes = (1 - t) ** 2 * p0 + 2 * t * (1 - t) * p1 + t ** 2 * p2
    both = np.concatenate([on, extremes])
    return float(both.max() - both.min()) if both.size else path.get_extents().width

def legend_width(labels: list[str], points: float) -> float:
    """The width of a row of a legend: each handle, its pad, its label, and the spacing between the entries (the
    lengths head gives the legend, in multiples of the font size)."""
    em = points * LAYOUT_DPI / 72
    return (sum(text_width(label, points) for label in labels) + len(labels) * (HANDLE_LENGTH + HANDLE_PAD) * em
            + (len(labels) - 1) * COLUMN_SPACING * em)

def number_width(text: str, points: float, weight: str = "normal") -> float:
    """The width of a text drawn in the figure's monospace (MONO, as the numbers of a table, a hero number and READING
    are drawn) at `points`, in layout pixels: text_width's measure, in the face drawn."""
    return points * mono_per_point(text, weight)

@cache
def mono_per_point(text: str, weight: str = "normal") -> float:
    """The width of a text in MONO in layout pixels per point of its size, measured once at MEASURE_POINTS."""
    path = TextPath((0, 0), text, size=MEASURE_POINTS, prop=FontProperties(family=MONO, weight=weight, math_fontfamily=MATH))
    return outline_width(path) * LAYOUT_DPI / 72 / MEASURE_POINTS

def gauge(ax, left: float, bottom: float, width: float, height: float, value: float | None, color: str, low: float = 0.0,
          high: float = 1.0, zorder: float = 3, ends: bool = False) -> tuple:
    """A horizontal gauge in the data coordinates of `ax`: its track (GAUGE_TRACK, the whole scale from `low` to `high`,
    `width` long) and over it a bar of `color` filled from `low` to `value`, clamped to the scale: a value under `low`
    (or None: not computed) leaves the track empty, never a bar that reaches beyond it; with `ends`, a tick at each end
    of the scale (GAUGE_TICK, 3 units over and under it: layout pixels where the axes are laid out in them). Returns the
    track, the bar (None when empty) and the share filled, in [0, 1]."""
    share = 0.0 if value is None else min(max((value - low) / (high - low), 0.0), 1.0)
    track = ax.add_patch(Rectangle((left, bottom), width, height, facecolor=GAUGE_TRACK, edgecolor="none", zorder=zorder))
    bar = None
    if share > 0.0:
        bar = ax.add_patch(Rectangle((left, bottom), share * width, height, facecolor=color, edgecolor="none", zorder=zorder + 0.1))
    if ends:
        for x in (left, left + width):
            ax.plot([x, x], [bottom - 3.0, bottom + height + 3.0], color=GAUGE_TICK, linewidth=1.0, solid_capstyle="butt",
                    zorder=zorder + 0.2)
    return track, bar, share

def level_values(surface) -> list:
    """The levels of the faint lines of a metamodel's surface on a plane (step 2 under the weights, step 3 under the
    search): LEVELS of them, geometric above its least value on the grid, as the eye reads a valley; none for a flat
    surface."""
    low, high = float(np.min(surface)), float(np.max(surface))
    rise = high - low
    if not rise > 1e-12 * max(abs(low), abs(high), 1.0):
        return []
    return list(low + rise * np.geomspace(3e-4, 0.7, LEVELS))

def facets(x1: np.ndarray, x2: np.ndarray, y: np.ndarray, low: float, high: float) -> tuple[list, list, bool]:
    """The cells of a surface as polygons (x1, x2, y), each cut where it leaves the window [low, high], with the mean
    height of each polygon; and whether anything was cut. A cut follows the edges of its cell: nothing is drawn that
    the grid does not hold."""
    rows, columns = y.shape
    if ((y >= low) & (y <= high)).all():
        corners = [np.stack([x1[r:r + rows - 1, c:c + columns - 1], x2[r:r + rows - 1, c:c + columns - 1],
                             y[r:r + rows - 1, c:c + columns - 1]], axis=-1) for r, c in ((0, 0), (0, 1), (1, 1), (1, 0))]
        polygons = np.stack(corners, axis=2).reshape(-1, 4, 3)
        return list(polygons), list(polygons[:, :, 2].mean(axis=1)), False
    polygons, heights = [], []
    for r in range(rows - 1):
        for c in range(columns - 1):
            polygon = [(float(x1[i, j]), float(x2[i, j]), float(y[i, j])) for i, j in ((r, c), (r, c + 1), (r + 1, c + 1), (r + 1, c))]
            polygon = cut_at(cut_at(polygon, high, below=True), low, below=False)
            if len(polygon) >= 3:
                polygons.append(np.array(polygon))
                heights.append(sum(vertex[2] for vertex in polygon) / len(polygon))
    return polygons, heights, True

def cut_at(polygon: list, level: float, below: bool) -> list:
    """The part of a polygon below (or above) a level: where an edge crosses it, the crossing point (Sutherland-Hodgman)."""
    kept = []
    for k in range(len(polygon)):
        p, q = polygon[k - 1], polygon[k]
        p_in = p[2] <= level if below else p[2] >= level
        q_in = q[2] <= level if below else q[2] >= level
        if p_in != q_in:
            t = (level - p[2]) / (q[2] - p[2])
            kept.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]), level))
        if q_in:
            kept.append(q)
    return kept

def dot(color: str, label: str, hollow: bool = False, soft: bool = False, marker: str = "o", size: float = 8.5,
        short: str | None = None) -> Line2D:
    """A legend's mark: a point (hollow: a ring; soft: a translucent disc with its rim); `short`, the label a crowded
    legend gives it rather than leave it out (legend_rows)."""
    face = "none" if hollow else tint(color, 0.42) if soft else color
    handle = Line2D([], [], linestyle="none", marker=marker, markersize=size, markerfacecolor=face,
                    markeredgecolor=color if hollow or soft else palette.CARD, markeredgewidth=1.5 if hollow else 0.9, label=label)
    handle.short = short
    return handle

def beside(point: tuple[float, float], offset: tuple[float, float] = LABEL_OFFSET) -> dict:
    """Where the label of a mark at `point` (in the unit square of its panel) goes, as annotate's keywords: `offset`
    points up and to the right of it, or, near the top or the right edge (beyond LABEL_EDGE), under it or to its left,
    so that the label never leaves its panel into the head over it (the legend's second row stands a few pixels above)."""
    high, right = point[1] > LABEL_EDGE, point[0] > LABEL_EDGE
    return {"xytext": (-offset[0] if right else offset[0], -offset[1] if high else offset[1]), "textcoords": "offset points",
            "ha": "right" if right else "left", "va": "top" if high else "baseline"}

def tint(color: str, alpha: float) -> tuple[float, float, float, float]:
    return tuple(int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)) + (alpha,)

def subscript(number: int) -> str:
    return "".join(SUBSCRIPTS[int(digit)] for digit in str(number))

def true_wire(ax, x1: np.ndarray, x2: np.ndarray, y: np.ndarray, zorder: float = 2):
    """The true response f as a wire over the metamodel's surface in the 3D view (steps 2 and 3, the same look): every
    WIRE_STRIDE-th line of its grid, in the slate of a reference, bright and over a dark casing (WIRE, WIRE_CASING), so
    that it reads at 1280 x 720 on every colour of the surface under it. Returns the wire."""
    wire = ax.plot_wireframe(x1, x2, y, rstride=WIRE_STRIDE, cstride=WIRE_STRIDE, zorder=zorder, **WIRE)
    wire.set_path_effects(list(WIRE_CASING))
    return wire

def wire_handle(label: str) -> Line2D:
    """The legend's handle of f's wire: its line, its casing."""
    return Line2D([], [], label=label, path_effects=list(WIRE_CASING), **WIRE)

def caption(points: float) -> dict:
    """The font of a legend's labels at `points` (CAPTION), as figure.legend takes it."""
    return {"family": SANS, "size": points, "math_fontfamily": MATH}

def ticks(ax, small: bool = False) -> None:
    """A panel's tick labels in the figure's face, muted: TICK points (TICK_SMALL for the 3D view's, small)."""
    ax.tick_params(colors=TICK_INK, labelsize=TICK_SMALL if small else TICK, labelfontfamily=SANS)

def space_ticks(ax) -> None:
    """The 3D view's ticks for the room it has (called after its axes are styled, at every draw of its scene): drawn
    smaller than SPACE_FEW (the square its box holds, in layout pixels), at most SPACE_FEW_BINS intervals on each axis,
    at round values; larger, matplotlib's own choice."""
    position = ax.get_position()
    width, height = size(ax.figure)
    small = min(position.width * width, position.height * height) < SPACE_FEW
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_major_locator(MaxNLocator(SPACE_FEW_BINS) if small else AutoLocator())
