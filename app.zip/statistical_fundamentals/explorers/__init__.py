# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: explorers
# ==============================================================================
"""
The interactive views, without Qt (the window adds the controls and the mouse): LABS, the laboratory of each step of a
study (benches.STEPS: the design of experiments, the metamodel, the optimization), by the step's key. Every laboratory
works on one bench, the key of its response, given when it is made (explorers/lab.py, gui/lab_views.py).

A bench of SEVERAL responses (functions.many: beam_pareto, two objectives and constraints) has laboratories of its own,
MANY, by the step's key (explorers/pareto_doe.py, pareto_metamodel.py, pareto_optimization.py); lab_for gives a bench
the laboratories of its kind. LABS stays the three laboratories of a bench of one response.
"""
from statistical_fundamentals.explorers import doe, metamodel, optimization, pareto_doe, pareto_metamodel, pareto_optimization
from statistical_fundamentals.explorers.game import TEACHER
from statistical_fundamentals.explorers.lab import Lab
from statistical_fundamentals.functions import many

LABS = {
    "doe": doe.SamplingLab,
    "metamodel": metamodel.MetamodelLab,
    "optimization": optimization.OptimizationLab,
}

MANY = {                              # a bench of several responses: the laboratory of each step
    "doe": pareto_doe.ParetoSamplingLab,
    "metamodel": pareto_metamodel.ParetoMetamodelLab,
    "optimization": pareto_optimization.ParetoLab,
}

def lab_for(step: str, function: str, mode: str = TEACHER) -> Lab:
    """A new laboratory of a step on the bench `function`, for a teacher or a student (explorers/game.py), its texts in
    the language chosen: LABS' for a bench of one response, MANY's for a bench of several."""
    return (MANY if many(function) else LABS)[step](function, mode)
