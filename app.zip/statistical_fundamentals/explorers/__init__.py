# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: explorers
# ==============================================================================
"""
The interactive views, without Qt (the window adds the controls and the mouse): LABS, the laboratory of each step of a
study (benches.STEPS: the design of experiments, the metamodel, the optimization), by the step's key. Every laboratory
works on one bench, the key of its response, given when it is made (explorers/lab.py, gui/lab_views.py).
"""
from statistical_fundamentals.explorers import doe, metamodel, optimization
from statistical_fundamentals.explorers.game import TEACHER
from statistical_fundamentals.explorers.lab import Lab

LABS = {
    "doe": doe.SamplingLab,
    "metamodel": metamodel.MetamodelLab,
    "optimization": optimization.OptimizationLab,
}

def lab_for(step: str, function: str, mode: str = TEACHER) -> Lab:
    """A new laboratory of a step on the bench `function`, for a teacher or a student (explorers/game.py), its texts in
    the language chosen."""
    return LABS[step](function, mode)
