# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: study.py
# ==============================================================================
"""
The study of a bench, without Qt: which of its steps (benches.STEPS) is on screen, and what each step handed to the
next one. The result of a step is the input of the next: the design of experiments hands its Experiment to the
metamodel, the metamodel hands its Surrogate to the optimization (the laboratories' Lab.output and Lab.receive).

    step 1 (doe) --Experiment--> step 2 (metamodel) --Surrogate--> step 3 (optimization)

A step opens only when the one before handed its result (enabled); a step whose result was handed and then changed
loses it, and with it everything the later steps were given (changed): they lock again until the reader advances. This
is CAE Fundamentals' rule for its stages, a result belonging to the input it was computed from. What a step hands is a
frozen value compared with ==, so a change that leaves the result as it was (the query point of step 2)
discards nothing.

The window draws a pill per step from states: the step on screen (CURRENT), a step whose result was handed (DONE), a
step that may be opened (OPEN) and one that waits for the step before (LOCKED). A Study is a frozen value: every
function returns a new one, so the window keeps it in the snapshot of its bench as it is.
"""
from dataclasses import dataclass, replace
from typing import Any

from statistical_fundamentals.benches import STEPS

CURRENT, DONE, OPEN, LOCKED = "current", "done", "open", "locked"

@dataclass(frozen=True)
class Study:
    step: int = 0                                           # the step on screen: an index of benches.STEPS
    handed: tuple = (None,) * (len(STEPS) - 1)              # handed[k]: what step k handed to step k + 1, or None

def enabled(study: Study, step: int) -> bool:
    """Whether a step may be opened: the first one always, another once the step before handed its result."""
    return step == 0 or (0 < step < len(STEPS) and study.handed[step - 1] is not None)

def states(study: Study) -> tuple[str, ...]:
    """The state of each step's pill. The last step hands nothing, so it is never DONE."""
    def state(step: int) -> str:
        if step == study.step:
            return CURRENT
        if not enabled(study, step):
            return LOCKED
        return DONE if step < len(study.handed) and study.handed[step] is not None else OPEN
    return tuple(state(step) for step in range(len(STEPS)))

def shown(study: Study, step: int) -> Study:
    """The study with another step on screen; a step that is locked is not opened."""
    return replace(study, step=step) if enabled(study, step) else study

def changed(study: Study, output: Any) -> tuple[Study, bool]:
    """The study after the step on screen changed, `output` being its result now (Lab.output). A result already handed
    that is no longer the step's is discarded, with everything handed after it; the second value says whether anything
    was discarded."""
    step = study.step
    if step >= len(study.handed) or study.handed[step] is None or study.handed[step] == output:
        return study, False
    return replace(study, handed=study.handed[:step] + (None,) * (len(study.handed) - step)), True

def advanced(study: Study, output: Any) -> Study:
    """The study after the step on screen handed `output` and the reader went to the next step. Nothing to hand (None),
    or no next step: the study as it is. A result equal to the one already handed leaves the later steps as they were;
    another one discards what they were given."""
    step = study.step
    if output is None or step >= len(study.handed):
        return study
    if study.handed[step] == output:
        return replace(study, step=step + 1)
    handed = study.handed[:step] + (output,) + (None,) * (len(study.handed) - step - 1)
    return Study(step + 1, handed)
