# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: game.py
# ==============================================================================
"""
The rules of the game a bench is played by, without Qt: the two ways of using the application and what it takes to
complete a bench. A bench is passed or not (the owner's word of 2026-11-21: no levels, no stars): what a study cost no
longer decides anything, the window only says whether the validated result completes the bench.

TEACHER: every bench open, every command offered, and first settings that already give a very good study (pressing
only the forward buttons completes the bench). STUDENT: the benches open in order (a bench opens when the one before is
complete), step 1 opens on the free sampling with no point placed (the algorithms' N comes empty), the metamodel is
calibrated by hand (no optimal prognosis, no Best command) and the bench is complete only when the student finds the minimum.

A bench is COMPLETE when the optimum found on the metamodel, x*, validated with one simulation, f(x*), is

    close to a global minimum BY PLACE    its distance to one, in the unit hypercube, at most REACH, or
    close to it BY VALUE                  f(x*) - f* at most SHARE of the spread of f on the design space,

the same rules whatever the number d of inputs: the distance is the Euclidean one of the d coordinates in the unit
hypercube (in four inputs the ball of radius REACH is a far smaller share of the design space than the disc of two: the
bench's lesson, not another rule), and the spread is measured on a grid of the design space, GRID points per axis for
two inputs, GRID_MANY for more (the largest value of a response of the beam on its design space is at a corner, which
every such grid holds),

and, in both cases, f(x*) is below the best design of step 1: the metamodel completes the bench, never a design that
fell near a minimum by chance. The way by value is for a response whose floor is nearly flat, where a good metamodel
gives the value of the minimum long before its place; in the sweeps of the three benches (Latin hypercubes of seeds 27
to 36, the three optimizers: Branin at N = 10 to 100, 296 completions; the beam, 2026-11-18; the beam on four
cross-beams, 199 completions) no completion was by value alone: every one was by place.

The sweeps also set the teacher's first experiment (doe.FIRST_POINTS): an N at which most of ten Latin hypercubes
complete the bench with the best of the three optimizers, on a grid of N in steps of 5 (Branin: the sweep of
2026-11-15, half of the ten first complete at N = 45, the teacher's 60).

The beam has its own sweep (2026-11-18: Latin hypercubes of seeds 27 to 36, the winner of the optimal prognosis, the
best of the three optimizers): the share of the ten samples completing at N = 10, 15, ..., 65 is 1, 2, 2, 3, 3, 4, 8,
7, 9, 7, 9, 9 of 10, half first reached at N = 40 (the teacher's 50). Its response is a
maximum over the spans of the beam, so its minimum sits on a kink, where the spans' largest deflections tie: a
metamodel of high CoP (0.98 from N = 20) smooths the kink and does not locate it; in that sweep every completion of the
beam was by place, none by value.

The beam on four cross-beams has its own (2026-11-19, the same way): its response is the RMS deflection along the beam,
not the largest deflection, because the largest is a maximum over the spans again and its minimum on four cross-beams
a kink where three spans tie, which no metamodel of N <= 100 locates in four inputs (0 of 10 at every N), while the RMS
deflection is smooth. The share of the ten samples completing at N = 45, 50, ..., 100 is 0, 1, 2, 2, 5, 8, 6, 9, 9, 8,
9, 8 of 10 (Kriging the winner of the optimal prognosis in 119 of the 120 studies; the same counts with NLPQL's first
step h at 1e-8, 1e-7 and 1e-6, the bench's first, optimization.FIRST_STEPS), half first reached at N = 65 (the
teacher's 85); every completion by place. In four inputs the ball of radius REACH is a far smaller share of the design
space than the disc of two: the place is the bench's lesson.

The teacher's first settings (N = 60, 50 and 85, one validation) complete their benches by the forward buttons alone.

A bench of TWO OBJECTIVES (several responses, functions.Response.outputs: the beam on two cross-beams sized, beam_pareto)
has no single minimum to come near: its answer is a front of compromises, and it is measured by the HYPERVOLUME of the
front a study holds, the area of the objective plane that front dominates (pareto.hypervolume). The study's front is
what an engineer holds at the end: of EVERY design it simulated (the experiment's N designs and every design validated),
the feasible ones (every constraint within its limit, exactly: explorers/outputs.feasible) that no other one dominates
(outputs.front_of). Its objectives are normalized by the true front's IDEAL and NADIR points, (f - ideal) / (nadir -
ideal) in each, and the area is bounded by the reference point (REFERENCE, REFERENCE) = (1.1, 1.1), the nadir plus 10 %
of each range. The true front is the bench's stored data (functions.Response.front, fronts.py: 101 designs evenly spaced
along it, found beforehand by a search and checked by SciPy in the tests), simulated once (front): "known only because
this simulation is cheap". The bench is COMPLETE (front_completed) when the share of the study's hypervolume in the true
front's (share) is at least SHARE_FRONT = 0.94 and above the experiment's own share: the validation added to the front,
as x* must be below the best design of step 1 on the other benches. The table's own hypervolume (0.864169) is 0.9950 of
a dense front's of 2216 designs (0.868526), so a share against it reads about 0.5 % high (0.94 here is about 0.935 of the
dense front): K designs of the table, evenly spaced along it, hold 0.860 (5), 0.943 (10), 0.966 (15) and 0.976 (20) of
the table's hypervolume; K designs evenly spaced along the dense front hold 0.855, 0.939, 0.962 and 0.972 of the dense
front's; so the front's shape asks for many good designs, not a few.

Its sweep (2026-11-21: Latin hypercubes of seeds 27 to 36, N = 5 to 100; the winners of the optimal prognosis for every
response; NSGA-II with mu = 40 for 30 generations on the metamodels, its predicted front the feasible first front of the
final population; K designs of it validated, evenly spaced along it; shares against the 101-design table, as share
measures them: the teacher's 0.9572 is the sweep's to the digits it wrote) sets the numbers so
that the metamodels complete the bench, never the experiment by chance: no experiment alone reaches 0.94 (the best of
every N and seed 0.889); a study with every metamodel linear never does with 20 validations (best 0.901); nor do
experiments of 5, 10 or 15 designs with 20 validations (best 0.920). With K = 20 the share of the ten samples completing
at N = 45, 50, ..., 100 is 7, 8, 9, 7, 9, 9, 9, 9, 9, 10, 10, 10 of 10; with K = 10 almost never (one and two samples at
N = 85 and 90), with K = 5 never. The cheapest cells where at least half of ten complete are N = 45 with K = 20 (7 of
10) and N = 50 with K = 15 (6 of 10); the teacher's first settings, N = 70 and K = 20, complete it. The rules of one
minimum (spread, tolerance, distance, by_place, by_value, complete) refuse such a bench (ValueError): it has no
minimum, only its front.
"""
import math
from dataclasses import dataclass
from functools import cache

import numpy as np

from statistical_fundamentals import pareto
from statistical_fundamentals.explorers import outputs
from statistical_fundamentals.functions import RESPONSES, many

TEACHER, STUDENT = "teacher", "student"
MODES = (TEACHER, STUDENT)
REACH = 0.05                          # by place: the distance to a global minimum, in the unit hypercube (the square of two)
SHARE = 1e-4                          # by value: f(x*) - f*, as a share of the spread of f on the design space
GRID = 201                            # samples per axis of the grid the spread is measured on (its corners included)
GRID_MANY = 9                         # the same for a response of more than two inputs (9^4 = 6561 points for four)
SHARE_FRONT = 0.94                    # two objectives: the least share of the true front's hypervolume that completes
REFERENCE = 1.1                       # two objectives: each coordinate of the reference point, in the objectives normalized
                                      # by the true front's ideal (0) and nadir (1)

def one_minimum(function: str) -> None:
    """A rule of one minimum asked of a bench of several responses: refused, loudly (its rule is front_completed)."""
    if many(function):
        raise ValueError(f"the bench {function!r} has several responses and no minimum: its rule is front_completed")

@cache
def spread(function: str) -> float:
    """The largest value of the response on a grid of its design space, less its global minimum: GRID x GRID for two
    inputs, GRID_MANY per axis for more."""
    one_minimum(function)
    response = RESPONSES[function]
    if response.d == 2:
        (a1, b1), (a2, b2) = response.bounds
        x1, x2 = np.meshgrid(np.linspace(a1, b1, GRID), np.linspace(a2, b2, GRID))
        return float(np.max(response.f(x1, x2))) - float(response.minimum)
    axes = np.meshgrid(*(np.linspace(a, b, GRID_MANY) for a, b in response.bounds), indexing="ij")
    return float(np.max(response.f(*axes))) - float(response.minimum)

def tolerance(function: str) -> float:
    """By value: the largest f(x*) - f* of a completed bench."""
    one_minimum(function)
    return SHARE * spread(function)

def distance(function: str, point: tuple[float, ...]) -> float:
    """From a point of the unit hypercube (d coordinates) to the nearest global minimum of the response, the Euclidean
    distance in the unit hypercube."""
    one_minimum(function)
    bounds = RESPONSES[function].bounds
    return min(math.dist(point, [(x - a) / (b - a) for x, (a, b) in zip(minimum, bounds, strict=True)])
               for minimum in RESPONSES[function].minima)

def by_place(function: str, point: tuple[float, ...]) -> bool:
    one_minimum(function)
    return distance(function, point) <= REACH

def by_value(function: str, value: float) -> bool:
    one_minimum(function)
    return value - float(RESPONSES[function].minimum) <= tolerance(function)

def complete(function: str, point: tuple[float, ...], value: float, best: float) -> bool:
    """The bench is complete: x* (`point`, in the unit hypercube) with its simulated value f(x*) (`value`) is close to a
    global minimum by place or by value, and below `best`, the lowest simulated value of step 1's designs."""
    one_minimum(function)
    return value < best and (by_place(function, point) or by_value(function, value))

# ------------------------------------------------------------------------------ two objectives: the front
@dataclass(frozen=True)
class Front:
    """The true front of a bench of two objectives: the objectives of its stored designs (simulated, in their order),
    its ideal and nadir points (the least and the largest of each objective along it) and its own hypervolume, in the
    objectives normalized by those two points, bounded by (REFERENCE, REFERENCE)."""
    points: tuple[tuple[float, ...], ...]
    ideal: tuple[float, ...]
    nadir: tuple[float, ...]
    hypervolume: float

@cache
def stored(response) -> Front:
    """The Front of a Response (cached by it, so that a bench registered again is simulated again)."""
    function = response.key
    if len(outputs.objectives(function)) != 2 or not response.front:
        raise ValueError(f"the bench {function!r} has no stored front of two objectives")
    points = tuple(outputs.objective_values(function, row) for row in outputs.simulate(function, list(response.front)))
    ideal = tuple(min(column) for column in zip(*points))
    nadir = tuple(max(column) for column in zip(*points))
    whole = pareto.hypervolume([scaled(point, ideal, nadir) for point in points], (REFERENCE, REFERENCE))
    return Front(points, ideal, nadir, whole)

def front(function: str) -> Front:
    """The true front of the bench (two objectives): its designs (functions.Response.front) simulated once."""
    return stored(RESPONSES[function])

def scaled(point, ideal, nadir) -> tuple[float, ...]:
    return tuple((f - low) / (high - low) for f, low, high in zip(point, ideal, nadir, strict=True))

def normalized(function: str, objectives) -> tuple[float, ...]:
    """A point of the objectives normalized by the true front's ideal (0) and nadir (1), (f - ideal) / (nadir - ideal)."""
    found = front(function)
    return scaled(objectives, found.ideal, found.nadir)

def hypervolume_of(function: str, rows) -> float:
    """The hypervolume of the feasible designs that no other one dominates, among rows of simulated outputs (every
    output of each design: outputs.front_of), in the objectives normalized by the true front (normalized), bounded by
    (REFERENCE, REFERENCE)."""
    points = [normalized(function, outputs.objective_values(function, rows[i])) for i in outputs.front_of(function, rows)]
    return pareto.hypervolume(points, (REFERENCE, REFERENCE))

def share(function: str, rows) -> float:
    """The study's hypervolume (hypervolume_of) as a share of the true front's own."""
    return hypervolume_of(function, rows) / front(function).hypervolume

def front_completed(study: float, experiment: float) -> bool:
    """A bench of two objectives is COMPLETE: the study's share of the true front's hypervolume (its N designs and every
    design validated) is at least SHARE_FRONT AND above the experiment's own share (its N designs alone): the validation
    added to the front. The form the rule "x* below the best design of step 1" takes with a front: the metamodels complete
    the bench, never an experiment that already held the share (the free sampling of designs placed on the true front by
    hand, about ten for 0.943, could otherwise complete with any validation)."""
    return study >= SHARE_FRONT and study > experiment
