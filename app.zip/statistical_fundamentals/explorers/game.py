# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: game.py
# ==============================================================================
"""
The rules of the game a bench is played by, without Qt: the two ways of using the application and what it takes to
complete a bench.

TEACHER: every bench open, every command offered, and first settings that already give a very good study (pressing
only the forward buttons completes the bench). STUDENT: the benches open in order (a bench opens when the one before is
complete), step 1 opens on the free sampling with no point placed (the algorithms' N comes empty), the metamodel is
calibrated by hand (no optimal prognosis, no Best command) and the bench is complete only when the student finds the minimum.

A bench is COMPLETE when the optimum found on the metamodel, x*, validated with one simulation, f(x*), is

    close to a global minimum BY PLACE    its distance to one, in the unit square, at most REACH, or
    close to it BY VALUE                  f(x*) - f* at most SHARE of the spread of f on the design space,

and, in both cases, f(x*) is below the best design of step 1: the metamodel completes the bench, never a design that
fell near a minimum by chance. The two ways are needed: Rosenbrock's valley floor is nearly flat, so a good metamodel
gives the value of the minimum long before its place (a sweep of N from 10 to 100 over ten samples, 2026-11-15: with
the place alone, at most 4 of the 10 complete it at any N).

The STARS a completed bench is worth come from what it cost: the N simulations of step 1 and one more for every
distinct x* validated on that experiment (a validation is a simulation; validating the same x* again costs nothing).
Three at or below N + 1 for the N at which at least half of ten Latin hypercubes complete the bench with the best of the
three optimizers, on a grid of N in steps of 5 (the same sweep, and its second pass for Branin: N = 45, 30 and 30), two
up to one and a half times that, one above. The teacher's first settings (N = 60, 40 and 40, one validation: 61, 41,
41) are worth two: the third asks for a study cheaper than the teacher's.
"""
import math
from functools import cache

import numpy as np

from statistical_fundamentals.functions import RESPONSES

TEACHER, STUDENT = "teacher", "student"
MODES = (TEACHER, STUDENT)
REACH = 0.05                          # by place: the distance to a global minimum, in the unit square
SHARE = 1e-4                          # by value: f(x*) - f*, as a share of the spread of f on the design space
GRID = 201                            # samples per axis of the grid the spread is measured on (its corners included)
STARS = {"branin": (46, 69), "himmelblau": (31, 46), "rosenbrock": (31, 46)}    # the largest cost worth three stars, and two
MOST = 3                              # the stars of the cheapest studies

@cache
def spread(function: str) -> float:
    """The largest value of the response on a GRID x GRID grid of its design space, less its global minimum."""
    response = RESPONSES[function]
    (a1, b1), (a2, b2) = response.bounds
    x1, x2 = np.meshgrid(np.linspace(a1, b1, GRID), np.linspace(a2, b2, GRID))
    return float(np.max(response.f(x1, x2))) - float(response.minimum)

def tolerance(function: str) -> float:
    """By value: the largest f(x*) - f* of a completed bench."""
    return SHARE * spread(function)

def distance(function: str, point: tuple[float, float]) -> float:
    """From a point of the unit square to the nearest global minimum of the response, in the unit square."""
    (a1, b1), (a2, b2) = RESPONSES[function].bounds
    return min(math.hypot(point[0] - (x1 - a1) / (b1 - a1), point[1] - (x2 - a2) / (b2 - a2))
               for x1, x2 in RESPONSES[function].minima)

def by_place(function: str, point: tuple[float, float]) -> bool:
    return distance(function, point) <= REACH

def by_value(function: str, value: float) -> bool:
    return value - float(RESPONSES[function].minimum) <= tolerance(function)

def complete(function: str, point: tuple[float, float], value: float, best: float) -> bool:
    """The bench is complete: x* (`point`, in the unit square) with its simulated value f(x*) (`value`) is close to a
    global minimum by place or by value, and below `best`, the lowest simulated value of step 1's designs."""
    return value < best and (by_place(function, point) or by_value(function, value))

def stars(function: str, cost: int) -> int:
    """The stars of a bench completed at `cost` simulations (N and every distinct x* validated): 3, 2 or 1."""
    three, two = STARS[function]
    return MOST if cost <= three else MOST - 1 if cost <= two else MOST - 2
