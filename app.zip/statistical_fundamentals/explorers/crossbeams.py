# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: crossbeams.py
# ==============================================================================
"""
The card of the cross-beams, "The cross-beams" / "As travessas" (the owner's decisions of 2026-11-21: bench 4's band
draws only the GEOMETRY of the design in focus, its cross-beams at their places and their square sections named "A₁ =
225 cm²"; what each section GIVES goes into a card of the left column, in STEP 1 ONLY, between the controls and the
table of the designs, where the areas are chosen (his letter A, in step 1 only); steps 2 and 3 have no card, their own
block comes up), without Qt. Only a bench whose cross-beams are SIZED has it (sized: functions.Response.places names the
places, the other inputs are the areas A of the cross-beams' solid square sections, Response.size); for any other bench
`card` gives None. Two calls, made to plug into the column's block seam (a Block of key KEY, live: drawn again at every
move of the pointer):

`card(function, focus, pointed=None)`, the CONTENT, a pure function: for the design or the place the band shows (an
explorers/caption.Focus: a simulated design, its outputs its simulation's; a place nobody simulated, value None; or
None, no design: the cross-beams at the middle of their ranges, as the band's empty state draws them; `simulated`
tells which) and the cross-beam under the pointer in the band (live.Pointing.pointed_beam, its index, or None), a
Card: its title, one ROW per cross-beam and, for the cross-beam pointed at, its DETAIL (the owner's B); with none
pointed at, no detail (None): the card shows its table.

`draw(ax, card, function, width=WIDTH, ground)` draws a Card on a matplotlib axes laid out in layout pixels (its data
set to them, y down; the type from panels' roles only, nothing typed here; `ground` the tone it stands on, the column's
raised block's in the window), COMPACT, in one constant height (about 63 layout pixels, laid out for 248, the owner's
column), holding ONE of two contents: with no cross-beam pointed at, the TABLE of the cross-beams (one line each: its
number, the icon of its section, A, a, k, m and σ; headings in symbols, never units); while one is pointed at in the
band, its DETAIL in the table's place (its title, one strip: the elevation at the left, the square section at the
right, R's line in its top band, split about R's arrow: the force at its left, the shortening R/k at its right; or what
is not simulated). The units of the table's columns and the bench's law, the same for every cross-beam, are the TIP of
the block's heading (tip: one line of at most 100 characters, the owner's 2026-11-21, no grey note in the column: A
[cm²], a = √A [mm], k = 4EA²/S³ [MN/m], m = ρAS [kg], σ = 1.5RS/a³ [MPa]; S and E from beam.py, constants(); ρ, which
the line has no room for, is beam.DENSITY). `height(function)` the card's height, CONSTANT for a bench: the larger of
the two contents (upper), so that the column never jumps under a moving pointer.

A Row: the icon of its square section to one scale (`icon`: its side over the largest side of the ranges, so that the
squares compare), its numbers (A, a = sqrt(A) by beam.side, the stiffness k = 4 E A² / S³ and the mass ρ A S, what the
area alone gives, beam.stiffness, beam.mass, at a place too; and the stress, which needs the beam solved: a simulated
design's own output, None at a place nobody simulated or with no design) and its CELLS as the table writes them (A
whole, a whole, k in MN/m to a decimal, m whole, σ by caption.against or a dash where not simulated); `failed`, its
stress past its limit: the cell in the failed colour AND a hollow red ring at the row's end (never colour alone).

A Detail (B: the cross-beam pointed at in the band): the cross-beam's numbers (A, a, k, m, and for a simulated design
the force R it takes from the main beam at its mid-span, its shortening R/k there, which is the main beam's deflection
w at its place by compatibility, and its stress σ), its texts (the title
"Cross-beam 1 · x₁, x₃", the line "R₁ = 74 kN · R₁/k₁ = 11.2 mm" or what is not simulated, and R's name on its arrow),
and its GEOMETRY as plain data (elevation, square: Shapes of points in layout pixels, y down from the top of the box
they are asked for, each with its ROLE; draw gives each its ink). The law in the heading's tip is the bench's, the
same for every cross-beam: the exact formulas (TIP; a³ = A^(3/2), the section modulus a³/6; σ at the force R the
cross-beam takes, which itself grows with A as the spring stiffens: never a power law of A alone) in plain upright
Unicode, and their constants "S = 4 m, E = 210 GPa" (constants(), beam.py's own).

In the window's column (Lab.columned), `Column` is what step 1 of the bench (explorers/pareto_doe.py) mixes in to
stand the card as the FIRST of its blocks, above the table of the designs: beams_block, a Block of key KEY, live,
block_height high (the card's constant height under panels.BLOCK_TOP), its heading's tip `tip`, and draw_beams, the card
of the lab's own focus (its `focused`, the design or the place its band shows) and pointed_beam on the block's own
figure, drawn again only when the Card changes. Steps 2 and 3 never mix it in; not columned (the web), no lab asks for
it.
"""
import math
from dataclasses import dataclass

import numpy as np
from matplotlib.patches import Polygon

from statistical_fundamentals import beam, palette
from statistical_fundamentals.explorers import caption, outputs, panels, section
from statistical_fundamentals.explorers.base import number
from statistical_fundamentals.explorers.lab import Block, size
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.i18n import current_language, get_text

STIFFNESS_SCALE = 1000.0      # kN/m per MN/m (the table's k, in MN/m: the units in the heading's tip)
STIFFNESS_DECIMALS = 1        # 6.6 MN/m
FORCE_UNIT = "kN"             # the force a cross-beam takes (beam.Solution.reactions; SI symbols, every language)
SHORTENING_UNIT = "mm"        # R/k
SHORTENING_DECIMALS = 1
AREA_DECIMALS = 0             # an area written to the cm² (the band's and the readout's)
SPAN_UNIT, MODULUS_UNIT = "m", "GPa"    # the tip's constants: S and E of beam.py
MODULUS_SCALE = 1e6           # kN/m² per GPa (beam.MODULUS is in kN/m²)
TIP = "A [cm²], a = √A [mm], k = 4EA²/S³ [MN/m], m = ρAS [kg], σ = 1.5RS/a³ [MPa]; {constants}"    # the heading's tip:
                              # the table's units and what the area gives, exactly (beam.py; a³ = A^(3/2)): σ at the force
                              # R the cross-beam takes, which grows with A as the spring stiffens
# The roles of a Shape (the widget gives each its ink: the designs' colour for BODY and FORCE of a simulated design, the
# light ink of a place for BODY dashed, the quiet grey for OUTLINE, SUPPORT and GROUND, the structure's for MAIN)
OUTLINE, BODY, SUPPORT, GROUND, MAIN, FORCE, HEAD = "outline", "body", "support", "ground", "main", "force", "head"
DEEP = 0.25                   # the deflected shape stops at this share of the box's height under the cross-beam's top
TOP = 0.5                     # the cross-beam's top, at this share of the box's height (the main beam and R over it)
SUPPORT_HALF, SUPPORT_TALL, GROUND_HALF = 5.0, 8.0, 8.0     # layout pixels: a support's half width, its height, its ground
MAIN_SIDE = 10.0              # the main beam seen end-on, a square of this side on the mid-span
ARROW = (12.0, 3.0, 3.5, 6.0)  # R's arrow: from this far over the main beam to this far; its head's half width and length
STATIONS = 41                 # the points along the cross-beam's deflected shape

@dataclass(frozen=True)
class Shape:
    """A piece of a drawing: its role (OUTLINE, BODY, SUPPORT, GROUND, MAIN, FORCE, HEAD), its points (layout pixels,
    y down), whether it is closed (a polygon) and dashed (a place nobody simulated)."""
    role: str
    points: tuple
    closed: bool = False
    dashed: bool = False

@dataclass(frozen=True)
class Row:
    """One cross-beam of the card: its index, its area (cm²), side a (mm), stiffness k (kN/m), mass (kg) and stress σ
    (MPa; None where nobody simulated it), its icon's side over the largest of the ranges, its cells as the table writes
    them (A, a, k, m, σ) and whether the stress passes its limit."""
    index: int
    area: float
    side: float
    stiffness: float
    mass: float
    stress: float | None
    icon: float
    cells: tuple
    failed: bool = False

@dataclass(frozen=True)
class Detail:
    """One cross-beam in detail (B): its index, area (cm²), side (mm), stiffness (kN/m), mass (kg), the force R (kN),
    its shortening R/k (mm) and its stress (MPa), the last three None at a place nobody simulated; the bench's
    exaggeration of the band (the elevation's); its texts: the title, R's line ("R₂ = 74 kN · R₂/k₂ = 11.2 mm", or what
    is not simulated), and the line's two halves drawn about R's arrow: R's name on its left (force: "R₂ = 74 kN") and
    the shortening on its right (shortened: "R₂/k₂ = 11.2 mm"), both "" unsimulated. The law and its constants are the
    bench's, the same for every cross-beam (tip, constants())."""
    index: int
    area: float
    side: float
    stiffness: float
    mass: float
    reaction: float | None
    shortening: float | None
    stress: float | None
    factor: float
    title: str
    line: str
    force: str = ""
    shortened: str = ""

    @property
    def simulated(self) -> bool:
        """Whether the cross-beam is of a simulated design (a force, a shape, a stress)."""
        return self.reaction is not None

@dataclass(frozen=True)
class Card:
    """The card: its title, its rows (one per cross-beam) and the detail of the cross-beam pointed at (None with none
    pointed at: the table shows)."""
    title: str
    rows: tuple
    detail: Detail | None = None

def layout(function: str) -> tuple[tuple[int, ...], tuple[int, ...]]:
    """The inputs that are the cross-beams' places and those that are their areas, in their order."""
    response = RESPONSES[function]
    places = tuple(range(response.d)) if response.places is None else tuple(response.places)
    return places, tuple(k for k in range(response.d) if k not in places)

def sized(function: str) -> bool:
    """Whether the bench's cross-beams have sections of their own (a card of the cross-beams)."""
    return bool(layout(function)[1])

def numbered(symbol: str, j: int) -> str:
    """A symbol of cross-beam j (0-based): "R₁"."""
    return symbol + section.SUBSCRIPTS[j + 1] if j < 9 else f"{symbol}{j + 1}"

def areas_of(function: str, focus) -> tuple[float, ...]:
    """The areas of the cross-beams of the focus (cm²), or the middles of their ranges with none."""
    _, sizes = layout(function)
    bounds = RESPONSES[function].bounds
    if focus is None:
        return tuple((bounds[k][0] + bounds[k][1]) / 2 for k in sizes)
    return tuple(float(focus.point[k]) for k in sizes)

def largest_side(function: str) -> float:
    """The side of the largest section of the ranges (mm): the icons' and the section's dotted outline."""
    _, sizes = layout(function)
    return float(beam.side(max(RESPONSES[function].bounds[k][1] for k in sizes)))

def simulated(focus) -> bool:
    """Whether the focus is a simulated design (its outputs known): not a place, not the empty state."""
    return focus is not None and focus.value is not None and bool(focus.outputs)

def stress_index(function: str, j: int) -> int:
    """The output of the stress of cross-beam j: the bench's constraints, in the cross-beams' order."""
    return outputs.constraints(function)[j]

def constants() -> str:
    """The law's constants the tip has room for, beam.py's own: "S = 4 m, E = 210 GPa"."""
    return f"S = {number(beam.SPAN, 0)} {SPAN_UNIT}, E = {number(beam.MODULUS / MODULUS_SCALE, 0)} {MODULUS_UNIT}"

def tip() -> str:
    """The tooltip of the block's heading (TIP with constants()): the table's units and the bench's law, one line of
    at most 100 characters, the same in every language (symbols and SI units)."""
    return TIP.format(constants=constants())

def card(function: str, focus, pointed: int | None = None) -> Card | None:
    """The card of the cross-beams for the design or the place in focus (module docstring), with cross-beam `pointed`
    in detail; with none pointed, no detail (the table shows). None for a bench whose cross-beams have no size."""
    if not sized(function):
        return None
    shown = tuple(row(function, focus, j) for j in range(len(layout(function)[1])))
    found = None if pointed is None else detailed(function, focus, pointed)
    return Card(get_text(f"lab.caption.{function}.card.title"), shown, found)

def row(function: str, focus, j: int) -> Row:
    """Cross-beam j's row of the card (module docstring)."""
    area = areas_of(function, focus)[j]
    side, stiffness, mass = float(beam.side(area)), float(beam.stiffness(area)), float(beam.mass(area))
    stress, failed, written = None, False, NONE
    if simulated(focus):
        s = stress_index(function, j)
        stress, limit = float(focus.outputs[s]), outputs.limit(function, s)
        failed, written = stress > limit, caption.against(stress, limit)
    cells = (number(area, AREA_DECIMALS), number(side, 0), number(stiffness / STIFFNESS_SCALE, STIFFNESS_DECIMALS), number(mass, 0),
             written)
    return Row(j, area, side, stiffness, mass, stress, side / largest_side(function), cells, failed)

def detailed(function: str, focus, j: int) -> Detail:
    """Cross-beam j in detail (module docstring): for a simulated design the force R from the beam solved on its
    springs (explorers/caption.solution_of: the band's own solve, cached), its shortening R/k and its stress (its own
    output); else none of the three."""
    places, sizes = layout(function)
    k = sizes[j]
    area = areas_of(function, focus)[j]
    side, stiffness, mass = float(beam.side(area)), float(beam.stiffness(area)), float(beam.mass(area))
    factor = float(caption.factor(function))
    reaction = shortening = stress = None
    force = shortened = ""
    if simulated(focus):
        reaction = float(caption.solution_of(function, focus.point).reactions[j])
        shortening = reaction / stiffness * beam.MM
        stress = float(focus.outputs[stress_index(function, j)])
        force = f"{numbered('R', j)} = {number(reaction, 0)} {FORCE_UNIT}"
        shortened = f"{numbered('R', j)}/{numbered('k', j)} = {number(shortening, SHORTENING_DECIMALS)} {SHORTENING_UNIT}"
        line = f"{force} · {shortened}"
    else:
        said = ", ".join((numbered("R", j), f"{numbered('R', j)}/{numbered('k', j)}", outputs.symbol(function, stress_index(function, j))))
        line = get_text(f"lab.caption.{function}.card.detail_unsimulated", symbols=said)
    title = get_text(f"lab.caption.{function}.card.detail_title", beam=j + 1,
                     inputs=f"{section.symbol(places[j])}, {section.symbol(k)}")
    return Detail(j, area, side, stiffness, mass, reaction, shortening, stress, factor, title, line, force, shortened)

def deflection(detail: Detail, z) -> np.ndarray:
    """The cross-beam's own deflection v(z), m, at places z along its span (m): R z (3 S² − 4 z²) / (48 E I) up to the
    mid-span, symmetric about it, I = A² / 12; zero where nobody simulated it."""
    z = np.asarray(z, dtype=float)
    if detail.reaction is None:
        return np.zeros_like(z)
    rigidity = beam.MODULUS * (detail.area * beam.CM2) ** 2 / 12
    half = np.minimum(z, beam.SPAN - z)
    return detail.reaction * half * (3 * beam.SPAN ** 2 - 4 * half ** 2) / (48 * rigidity)

def elevation(detail: Detail, wide: float, high: float) -> tuple[Shape, ...]:
    """The cross-beam in elevation in a box `wide` x `high` (layout pixels, y down from its top): the span across the
    box (GROUND_HALF kept at each end), its depth a at the same scale, its undeformed outline dotted (OUTLINE), the
    cross-beam itself (BODY: deflected `factor` times, stopped at DEEP of the box; straight and dashed where nobody
    simulated it), its two supports and grounds, the main beam end-on on its mid-span (MAIN) and, for a simulated
    design, the arrow of R over it (FORCE and its HEAD)."""
    left = GROUND_HALF
    span = max(wide - 2 * left, 1.0)
    scale = span / beam.SPAN                                         # layout pixels per m, along and across alike
    depth = detail.side / beam.MM * scale
    top = TOP * high
    z = np.linspace(0.0, beam.SPAN, STATIONS)
    v = np.minimum(deflection(detail, z) * detail.factor * scale, DEEP * high)
    x = left + z * scale
    dashed = not detail.simulated
    shapes = [Shape(OUTLINE, ((left, top), (left + span, top), (left + span, top + depth), (left, top + depth)), True),
              Shape(BODY, tuple((float(a), float(b)) for a, b in [*zip(x, top + v), *zip(x[::-1], top + depth + v[::-1])]), True,
                    dashed)]
    under = top + depth
    for end in (left, left + span):
        shapes.append(Shape(SUPPORT, ((end, under), (end - SUPPORT_HALF, under + SUPPORT_TALL), (end + SUPPORT_HALF, under + SUPPORT_TALL)),
                            True))
        shapes.append(Shape(GROUND, ((end - GROUND_HALF, under + SUPPORT_TALL + 2), (end + GROUND_HALF, under + SUPPORT_TALL + 2))))
    middle, sag = left + span / 2, float(v[len(v) // 2])
    shapes.append(Shape(MAIN, ((middle - MAIN_SIDE / 2, top + sag - MAIN_SIDE), (middle + MAIN_SIDE / 2, top + sag - MAIN_SIDE),
                               (middle + MAIN_SIDE / 2, top + sag), (middle - MAIN_SIDE / 2, top + sag)), True))
    if detail.simulated:
        far, near, half, length = ARROW
        tip = top + sag - MAIN_SIDE - near
        shapes.append(Shape(FORCE, ((middle, top + sag - MAIN_SIDE - far), (middle, tip - length))))
        shapes.append(Shape(HEAD, ((middle - half, tip - length), (middle + half, tip - length), (middle, tip)), True))
    return tuple(shapes)

def square(detail: Detail, function: str, scale: float) -> tuple[Shape, ...]:
    """The cross-beam's square section a x a at `scale` (layout pixels per mm), from the top left of its box: the
    dotted outline of the range's largest (OUTLINE) and the section on its foot (BODY; dashed where nobody simulated
    the design)."""
    largest = largest_side(function) * scale
    side = detail.side * scale
    low = largest - side
    return (Shape(OUTLINE, ((0.0, 0.0), (largest, 0.0), (largest, largest), (0.0, largest)), True),
            Shape(BODY, ((0.0, low), (side, low), (side, largest), (0.0, largest)), True, not detail.simulated))

# ------------------------------------------------------------------------------
# The card drawn: a small figure in panels' type, laid out in layout pixels
# ------------------------------------------------------------------------------
KEY = "beams"                 # the card's key among a lab's blocks (the column's seam)
WIDTH = 248.0                 # layout pixels: the column's block width the card is laid out for
NONE = "—"                    # a cell of what nobody simulated (the stress at a place)
HEADINGS = ("$A$", "$a$", "$k$", "$m$", r"$\sigma$")     # the table's headings: symbols in STIX, the units in the tip
FONT = panels.TABLE_SIZE      # points: the table's numbers (the monospace role), its headings TABLE_HEADING larger
TABLE_HEADING = 1.5
HEAD_ROW = 16.0               # layout pixels: the headings' line (STIX symbols stand tall)
TABLE_ROW = 17.0              # a cross-beam's line
NUMBER_RIGHT = 7.0            # the cross-beam's number, right-aligned here
ICON_LEFT, ICON = 11.0, 13.0  # its icon: the largest section's side, every icon to its scale
CELLS_LEFT = 32.0             # the first column of numbers starts here
MARK_ROOM = 12.0              # the column of a failed stress's ring, at the right
CELL_GAP_LEAST = 4.0          # between two columns, at least
FAILED_RING = 30.0            # points²: the ring of a stress past its limit (the designs' infeasible mark)
DETAIL_TITLE = 11.0           # the detail's title: its baseline, in the table's headings' place
STRIP_TOP = 15.0              # the detail's strip starts here: the elevation at the left, the section at the right
STRIP = 44.0                  # its height
DESCENT = 4.0                 # room under the upper room (a stroke's half and a descender of the detail's texts)
SECTION_ROOM = 40.0           # the section's box: the range's largest side drawn this wide
STRIP_GAP = 12.0              # between the elevation and the section
DETAIL_FORCE = 7.0            # R's name ends this far left of its arrow, the shortening starts this far right of it
DETAIL_FORCE_DROP = 8.0       # their baseline this far under the arrow's tail (a place's line: under the strip's top)
FILL = 0.45                   # a section's fill: its ink at this share over the card
DASH = (0, (2.0, 1.4))        # the body of a cross-beam nobody simulated
OUTLINE_DASH = (0, (1.5, 1.5))    # the dotted outline of the largest section, the undeformed cross-beam

def upper(function: str) -> float:
    """The upper room of the card (layout pixels): the larger of its two contents, the table (its headings and a line
    per cross-beam) and the detail (its title and its strip, R's line inside it)."""
    count = len(layout(function)[1])
    return max(HEAD_ROW + count * TABLE_ROW, STRIP_TOP + STRIP)

def height(function: str) -> float:
    """The card's height in layout pixels, constant for a bench (any width, any language, whatever is pointed at): the
    upper room (upper) and DESCENT under it."""
    return upper(function) + DESCENT

def columns(function: str, rows, width: float) -> tuple[float, ...]:
    """The right edges of the table's five columns of numbers in a card `width` wide: each as wide as its widest cell
    may be (every digit an 8: the largest section's numbers, a stress of three digits, and the cells on show, a
    stress near its limit written with its decimals) or its heading, measured in the face drawn (panels.number_width,
    panels.text_width), the room left shared out between them from CELLS_LEFT to MARK_ROOM before the right."""
    eights = str.maketrans("0123456789", "8888888888")
    _, sizes = layout(function)
    largest = max(RESPONSES[function].bounds[k][1] for k in sizes)
    widest = [number(largest, AREA_DECIMALS), number(float(beam.side(largest)), 0),
              number(float(beam.stiffness(largest)) / STIFFNESS_SCALE, STIFFNESS_DECIMALS), number(float(beam.mass(largest)), 0), "888"]
    widest = [text.translate(eights) for text in widest]
    for row_ in rows:
        widest = [max(wide, cell.translate(eights), key=len) for wide, cell in zip(widest, row_.cells)]
    widths = [max(panels.number_width(text, FONT), panels.text_width(name, FONT + TABLE_HEADING))
              for text, name in zip(widest, HEADINGS)]
    room = width - MARK_ROOM - CELLS_LEFT
    gap = max((room - sum(widths)) / len(widths), CELL_GAP_LEAST)
    rights, x = [], CELLS_LEFT
    for wide in widths:
        x += gap + wide
        rights.append(x)
    return tuple(rights)

def draw(ax, card_: Card, function: str, width: float = WIDTH, ground: str = panels.CARD_TONE) -> list:
    """The card on `ax` (its data set to layout pixels, `width` x height(function), y down; no ticks, no frame,
    transparent on the tone it stands on, `ground`: a figure's card, or the column's raised block, panels.BLOCK_TONE):
    the table (draw_table) with no cross-beam pointed at, else the detail of the one pointed at in its place
    (draw_detail). Returns the artists drawn."""
    ax.set_xlim(0.0, width)
    ax.set_ylim(height(function), 0.0)
    ax.set_axis_off()
    ax.patch.set_visible(False)
    ax.set_navigate(False)
    if card_.detail is None:
        drawn = draw_table(ax, card_, function, width)
    else:
        drawn = draw_detail(ax, card_.detail, function, width, ground)
    return drawn

def draw_table(ax, card_: Card, function: str, width: float = WIDTH) -> list:
    """The table of the cross-beams from the card's top (module docstring: the headings muted in STIX over a hairline,
    each cross-beam's number muted, its icon to one scale inside the dotted outline of the range's largest, dashed where
    nobody simulated the design, its numbers in the monospace, right-aligned, a stress past its limit in the failed
    colour with a hollow red ring at the row's end). Returns the artists drawn."""
    rights = columns(function, card_.rows, width)
    heading = panels.HEADING | {"fontsize": FONT + TABLE_HEADING}
    figures = panels.NUMBER | {"fontsize": FONT}
    drawn = [ax.text(x, HEAD_ROW / 2, name, ha="right", va="center", **heading) for x, name in zip(rights, HEADINGS)]
    drawn += ax.plot([0.0, width], [HEAD_ROW, HEAD_ROW], color=palette.DARK_GREY, linewidth=0.6)
    for r, row_ in enumerate(card_.rows):
        middle = HEAD_ROW + (r + 0.5) * TABLE_ROW
        ink = panels.LEGEND_INK if row_.stress is None else palette.BLUE
        top, side = middle - ICON / 2, row_.icon * ICON
        drawn.append(ax.text(NUMBER_RIGHT, middle, str(row_.index + 1), ha="right", va="center", color=palette.GREY, **figures))
        drawn.append(ax.add_patch(Polygon([(ICON_LEFT, top), (ICON_LEFT + ICON, top), (ICON_LEFT + ICON, top + ICON),
                                           (ICON_LEFT, top + ICON)], closed=True, facecolor="none", edgecolor=palette.GREY,
                                          linewidth=0.6, linestyle=OUTLINE_DASH)))
        drawn.append(ax.add_patch(Polygon([(ICON_LEFT, top + ICON - side), (ICON_LEFT + side, top + ICON - side),
                                           (ICON_LEFT + side, top + ICON), (ICON_LEFT, top + ICON)], closed=True,
                                          facecolor=panels.tint(ink, FILL), edgecolor=ink, linewidth=0.9,
                                          linestyle=DASH if row_.stress is None else "solid")))
        for k, (x, cell) in enumerate(zip(rights, row_.cells)):
            stressed = k == len(rights) - 1
            colour = palette.RED if stressed and row_.failed else panels.MUTED_INK if cell == NONE else palette.WHITE
            drawn.append(ax.text(x, middle, cell, ha="right", va="center", color=colour, **figures))
        if row_.failed:                                               # never colour alone: the designs' infeasible ring
            drawn.append(ax.scatter([width - MARK_ROOM / 2], [middle], s=FAILED_RING, facecolors="none", edgecolors=palette.RED,
                                    linewidths=1.1))
    return drawn

def draw_detail(ax, detail: Detail, function: str, width: float = WIDTH, ground: str = panels.CARD_TONE) -> list:
    """The detail of the cross-beam pointed at, in the table's place: its title (the light ink, NOTE) on the headings'
    line, one strip STRIP high from STRIP_TOP, its elevation at the left (elevation's shapes) with R's name by its arrow,
    its square section at the right (square, the range's largest SECTION_ROOM wide), and R's line in the strip's top
    band, split about R's arrow (force at its left, shortened at its right, the light ink), or for a place nobody
    simulated what is not (the line, muted) from the strip's left; TAG, plain upright text in the figure's face. A
    simulated design's cross-beam in the designs' colour, a place's in the light ink, dashed; the supports filled with
    the tone the card stands on (`ground`). Returns the artists drawn."""
    ink = palette.BLUE if detail.simulated else panels.LEGEND_INK
    inks = {OUTLINE: palette.GREY, SUPPORT: palette.GREY, GROUND: palette.GREY, MAIN: panels.MUTED_INK, FORCE: panels.LEGEND_INK,
            HEAD: panels.LEGEND_INK, BODY: ink}
    faces = {BODY: panels.tint(ink, FILL), SUPPORT: ground, MAIN: panels.tint(panels.MUTED_INK, 0.35), HEAD: panels.LEGEND_INK}
    drawn = [ax.text(0.0, DETAIL_TITLE, detail.title, ha="left", va="baseline", color=panels.LEGEND_INK, **panels.NOTE)]

    def paint(shapes, dx, dy):
        for shape in shapes:
            points = [(x + dx, y + dy) for x, y in shape.points]
            if shape.closed:
                style = OUTLINE_DASH if shape.role == OUTLINE else (DASH if shape.dashed else "solid")
                drawn.append(ax.add_patch(Polygon(points, closed=True, facecolor=faces.get(shape.role, "none"), edgecolor=inks[shape.role],
                                                  linewidth=0.6 if shape.role == OUTLINE else 1.0, linestyle=style)))
            else:
                xs, ys = zip(*points)
                drawn.extend(ax.plot(xs, ys, color=inks[shape.role], linewidth=1.1 if shape.role == FORCE else 0.9))
    top = STRIP_TOP
    wide = width - SECTION_ROOM - STRIP_GAP
    shapes = elevation(detail, wide, STRIP)
    paint(shapes, 0.0, top)
    if detail.force:
        tail = next(shape for shape in shapes if shape.role == FORCE).points[0]
        base = top + tail[1] + DETAIL_FORCE_DROP
        drawn.append(ax.text(tail[0] - DETAIL_FORCE, base, detail.force, ha="right", va="baseline", color=panels.LEGEND_INK,
                             **panels.TAG))
        drawn.append(ax.text(tail[0] + DETAIL_FORCE, base, detail.shortened, ha="left", va="baseline", color=panels.LEGEND_INK,
                             **panels.TAG))
    else:
        drawn.append(ax.text(0.0, top + DETAIL_FORCE_DROP, detail.line, ha="left", va="baseline", color=panels.MUTED_INK, **panels.TAG))
    scale = SECTION_ROOM / largest_side(function)
    paint(square(detail, function, scale), width - SECTION_ROOM, top + (STRIP - SECTION_ROOM) / 2)
    return drawn

# ------------------------------------------------------------------------------
# The card as the first block of a laboratory's column (Lab.columned: Lab.blocks, Lab.draw_block)
# ------------------------------------------------------------------------------
def block_height(function: str) -> int:
    """The block's height in layout pixels: the card's (height, constant, laid out for WIDTH) under the block's own top
    (panels.BLOCK_TOP), rounded up; the same whatever the focus and the pointer, so that the column never moves."""
    return math.ceil(height(function) + panels.BLOCK_TOP)

class Column:
    """The card of the cross-beams as the FIRST block of the column of a laboratory of a bench sized (mixed in by step 1
    of bench 4 alone, before its parent: class ParetoSamplingLab(crossbeams.Column, SamplingLab)), above the table of the
    designs. A lab that mixes it in has `function`, `focused(state, hovered)` (the Focus its band shows: the
    card shows the same design or place) and live.Pointing's `pointed_beam` (the cross-beam under the pointer in the
    band, its detail). beams_block names the block (KEY, live: drawn again at every move of the pointer, its height
    block_height, least and most alike); draw_beams draws it on its own figure, on the block's tone, its axes in
    Lab.block_axes[KEY] (never the figure's), made again only when the figure, its size, its density or the language
    changes, and the card drawn again only when the card itself changes (what it shows: the rows, the detail): a move of
    the pointer that changes nothing of it draws nothing (False)."""

    def beams_block(self, width: float) -> Block:
        """The block of the cross-beams for a column content `width` layout pixels wide (the seam's; the card is laid
        out for WIDTH, its height the same at any): its title the card's, no note, the units and the law its heading's
        tip (tip)."""
        tall = block_height(self.function)
        return Block(KEY, get_text(f"lab.caption.{self.function}.card.title"), least=tall, most=tall, live=True, tip=tip())

    def draw_beams(self, figure, state, hovered) -> bool:
        """The card for the design or the place the band shows (focused; none without a state) and the cross-beam
        pointed at in the band (pointed_beam), on `figure` (module docstring); whether anything changed."""
        width, tall = size(figure)
        layout = (id(figure), round(width), round(tall), figure.dpi, current_language())
        kept = self.__dict__.get("_beams_kept")
        ax = self.block_axes.get(KEY)
        if kept is None or kept["layout"] != layout or ax is None or ax.figure is not figure:
            figure.clear()
            figure.set_facecolor(panels.BLOCK_TONE)
            room = height(self.function)
            ax = figure.add_axes((0.0, max(1.0 - (room + panels.BLOCK_TOP) / max(tall, 1.0), 0.0), 1.0, min(room / max(tall, 1.0), 1.0)))
            self.block_axes[KEY] = ax
            kept = self.__dict__["_beams_kept"] = {"layout": layout, "card": None}
        focus = None if state is None else self.focused(state, hovered)
        made = card(self.function, focus, getattr(self, "pointed_beam", None))
        if made is None or made == kept["card"]:
            return False
        ax.clear()
        draw(ax, made, self.function, width, panels.BLOCK_TONE)
        kept["card"] = made
        return True
