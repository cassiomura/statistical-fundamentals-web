# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: outputs.py
# ==============================================================================
"""
The responses of a bench as the laboratories read them, without Qt and drawing nothing (no figure here: matplotlib is
imported only through the package, whose laboratories and explorers.base draw): what each response of one
simulation is (an objective or a constraint, its symbol, its unit, its name, its limit), which designs are FEASIBLE and
which of them no other one beats, and the control that chooses the response on screen. One rule is said once and kept
everywhere:

    a bench of ONE response      is read as a bench of a single objective standing for the response itself, y = f(x),
                                 its symbol y (its metamodel's ŷ), its unit the response's, no constraint: the identity;
    a bench of SEVERAL           is read through functions.Response.outputs, in their order (the index k is
                                 doe.Experiment.output): beam_pareto's mass m, RMS deflection δ, stresses σ₁ and σ₂.

A ROW is what one simulation of one design gives: the values of every output, in their order (rows(columns) turns
doe.Simulated.outputs, a column per output, into one row per design; simulate(function, points) simulates designs of
the bounds, one call for all of them through Response.together when the bench has it).

    feasible(function, row)       every constraint within its limit, g <= limit: an exact comparison, no tolerance
                                  (a design at 120.2 MPa is not feasible, however little it passes);
    violation(function, row)      the sum over the constraints of max(0, g / limit - 1), each constraint as a share of
                                  its own limit (pareto.py's normalization: the stresses weigh alike whatever their
                                  unit); 0 for a feasible design;
    objective_values(function, row)   the objectives of the row, in their order;
    front_of(function, rows)      the indices of the feasible rows that no other feasible row dominates (pareto.nondominated
                                  on their objectives; equal rows all kept), in the rows' order: the study's front;
    compromise(function, rows)    among those, the index of the one nearest the IDEAL point, each objective normalized
                                  by that set's own ends, (f - least) / (largest - least), a range of zero counting as 1,
                                  the distance Euclidean, a tie to the earlier row; None when no row is feasible. It is
                                  the design in focus when nothing is pointed at, and the place of the automatic slice.

The names: of(function) the Outputs (functions.Output) of the bench, a single objective for one response (cached by the
Response, so that a bench registered again is read again); many, objectives and constraints (indices), symbol(function,
k, hat) ("m", "δ", "σ₁", "σ₂"; with hat the metamodel's form, the circumflex on the letter before any subscript: m̂, δ̂,
σ̂₁, σ̂₂, ŷ), unit, limit (None for an objective) and name(function, k, short) in the language chosen: the catalog's
"bench.<key>.output.<output>.name" ("RMS deflection", "flecha RMS") and ".short" (a button's and a legend's: "deflection",
"flecha"), the symbol where the catalog has none (a bench of one response). functions.py keeps no symbol of beam_pareto
(its cores are written in plain ASCII): SYMBOLS here, by the output's key, unless the Output carries its own.

The control "response on screen" (key RESPONSE): control(function), buttons over the indices of the outputs, each named
by its short name and wearing the icon of gui/assets/icons named by the output's key (mass, deflection, stress_1,
stress_2), by value; first(function) its first value, 0, the first objective. A bench of one response has none:
control gives None and controls (the tuple a lab puts in its column) gives (). Its label and its tip are the catalog's
bench.output.control and bench.output.control_tip (bench.json, with the names).
"""
import math
import unicodedata
from functools import cache

import numpy as np

from statistical_fundamentals import functions, pareto
from statistical_fundamentals.explorers.base import Control
from statistical_fundamentals.functions import RESPONSES, Output
from statistical_fundamentals.i18n import DEFAULT_LANGUAGE, get_text, has_text

RESPONSE = "response"                 # the settings key of the response on screen (an index of the outputs)
SINGLE = "y"                          # the symbol of the response of a bench of one
SYMBOLS = {"mass": "m", "deflection": "δ", "stress_1": "σ₁", "stress_2": "σ₂"}    # by the output's key
HAT = "\u0302"                        # the combining circumflex: the metamodel's symbol

@cache
def single(response) -> tuple[Output, ...]:
    """The one Output of a bench of one response: an objective standing for the response itself."""
    return (Output(SINGLE, response.f, "objective", response.units[-1], None, SINGLE),)

def of(function: str) -> tuple[Output, ...]:
    """The Outputs of the bench `function`, in their order: its own, or the single objective of a bench of one."""
    response = RESPONSES[function]
    return response.outputs if response.outputs else single(response)

def many(function: str) -> bool:
    """Whether the bench has several responses (functions.many)."""
    return functions.many(function)

def objectives(function: str) -> tuple[int, ...]:
    """The indices of the objectives, in their order."""
    return tuple(k for k, output in enumerate(of(function)) if output.role == "objective")

def constraints(function: str) -> tuple[int, ...]:
    """The indices of the constraints, in their order (none for a bench of one response)."""
    return tuple(k for k, output in enumerate(of(function)) if output.role == "constraint")

def symbol(function: str, k: int, hat: bool = False) -> str:
    """The symbol of output k ("δ"), or its metamodel's (hat: "δ̂"; the circumflex on the first letter, before a
    subscript: "σ̂₁"; "ŷ" composed)."""
    output = of(function)[k]
    plain = output.symbol or SYMBOLS.get(output.key, output.key)
    return unicodedata.normalize("NFC", plain[0] + HAT + plain[1:]) if hat else plain

def unit(function: str, k: int) -> str:
    return of(function)[k].unit

def limit(function: str, k: int) -> float | None:
    """The limit of a constraint g <= limit; None for an objective."""
    return of(function)[k].limit

def shared_limit(function: str) -> float:
    """The one limit, in one unit, every constraint of the bench shares (bench 4's two stresses: 120 MPa), which the
    figure and the texts write once ("σ₁, σ₂ ≤ 120 MPa", "σ = 79 · 75 MPa ≤ 120", "σ̂₁ or σ̂₂ > 120"); refused
    (ValueError) where the constraints' limits or units differ, or where there is no constraint: those texts would then
    say something false."""
    found = constraints(function)
    if not found or len({(limit(function, k), unit(function, k)) for k in found}) != 1:
        raise ValueError(f"the constraints of {function!r} share no one limit: the figure writes one")
    return limit(function, found[0])

def name(function: str, k: int, short: bool = False) -> str:
    """The name of output k in the language chosen ("RMS deflection"; short: "deflection", a button's and a legend's),
    the symbol where the catalogs have none."""
    key = f"bench.{function}.output.{of(function)[k].key}.{'short' if short else 'name'}"
    return get_text(key) if has_text(key, DEFAULT_LANGUAGE) else symbol(function, k)

def rows(columns) -> list[tuple[float, ...]]:
    """The rows of a simulated experiment, one per design, from its columns (doe.Simulated.outputs)."""
    return [tuple(float(value) for value in row) for row in zip(*columns)]

def simulate(function: str, points) -> list[tuple[float, ...]]:
    """One simulation of each design (points in the bounds, d coordinates each): the row of every output of each,
    from one call for all of them (Response.together) when the bench has it, else each output's f at each design."""
    response = RESPONSES[function]
    if not points:
        return []
    arrays = [np.array([x[k] for x in points], dtype=float) for k in range(response.d)]
    if response.outputs and response.together is not None:
        return rows(np.asarray(column, dtype=float) for column in response.together(*arrays))
    return rows(np.asarray(output.f(*arrays), dtype=float).reshape(len(points)) for output in of(function))

def violation(function: str, row) -> float:
    """The sum over the constraints of max(0, g / limit - 1): 0 for a feasible design."""
    return pareto.violation([row[k] / limit(function, k) - 1 for k in constraints(function)])

def feasible(function: str, row) -> bool:
    """Every constraint of the row within its limit, g <= limit, exactly."""
    return all(row[k] <= limit(function, k) for k in constraints(function))

def objective_values(function: str, row) -> tuple[float, ...]:
    return tuple(row[k] for k in objectives(function))

def front_of(function: str, rows) -> list[int]:
    """The indices of the feasible rows that no other feasible row dominates, in the rows' order."""
    kept = [i for i, row in enumerate(rows) if feasible(function, row)]
    found = pareto.nondominated([objective_values(function, rows[i]) for i in kept])
    return [kept[j] for j in found]

def compromise(function: str, rows) -> int | None:
    """Among the front of the rows (front_of), the index of the row nearest the ideal point, the objectives normalized
    by that front's own ends (a range of zero counts as 1); None when no row is feasible."""
    front = front_of(function, rows)
    if not front:
        return None
    values = [objective_values(function, rows[i]) for i in front]
    least = [min(column) for column in zip(*values)]
    width = [max(column) - low or 1.0 for column, low in zip(zip(*values), least)]
    distances = [math.hypot(*((v - low) / w for v, low, w in zip(point, least, width))) for point in values]
    return front[distances.index(min(distances))]

def control(function: str) -> Control | None:
    """The control of the response on screen: a button per output, its short name and its icon (by value); None for a
    bench of one response."""
    if not many(function):
        return None
    outputs = of(function)
    return Control(RESPONSE, get_text("bench.output.control"), tuple(range(len(outputs))), first(function),
                   names=tuple(name(function, k, short=True) for k in range(len(outputs))),
                   tip=get_text("bench.output.control_tip"), icons={k: output.key for k, output in enumerate(outputs)})

def controls(function: str) -> tuple[Control, ...]:
    """The control of the response on screen as a lab's column takes it: (control,), or () for one response."""
    made = control(function)
    return () if made is None else (made,)

def first(function: str) -> int:
    """The response a lab opens on: the first objective."""
    return objectives(function)[0]
