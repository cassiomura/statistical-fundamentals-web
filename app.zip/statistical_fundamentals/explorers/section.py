# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: section.py
# ==============================================================================
"""
The view of a bench of d inputs, without Qt: which two inputs the figure's axes show (the PAIR, the input across and
the input up) and at which values the other d - 2 are HELD. The figure of every step stays the figure of two inputs,
read through that pair, by one rule said once and kept everywhere:

    a mark is a PROJECTION       a design, a point of a search, the start, x*, a minimum of f is drawn at its two
                                 coordinates of the pair (project), the fainter the farther it is from the slice in
                                 the inputs held, and told by its size too (never colour alone): THE FADE below;
    a surface is a SLICE         f, y^ and a method's own model are computed on a grid of the pair with the other
                                 inputs held at the values written on the figure (grid, mesh, note): nothing is drawn
                                 that was not computed.

THE FADE, one law for the three steps, for a bench of more than two inputs (a lab of two draws its marks as it always
did, never through it): a mark at the unit point u has the closeness c = exp(-(r / NEAR)^2) to the slice, r its
distance in the inputs held (the MLS weight's Gaussian, NEAR = 0.4), and is drawn with the opacity FAINT + (1 - FAINT) c
(nearness: 1 on the slice, FAINT = 0.45 far from it); NEAR GROWS rather than far shrinks for the designs of the plane
(grown: the two-input area far from the slice, twice it on it, never past GROWN_MOST, a free point's size), while a mark
that must not grow, a design in the 3D view or a mark of a search, keeps its area on the slice and half of it far
(shrunk: area (0.5 + 0.5 c)); a projected design's dark edge is EDGE_THIN.

With two inputs the slice is the whole design space: the pair is (0, 1), nothing is held, project and lift are the
identity, distance is 0 and closeness and nearness 1 for every point, and grid and mesh give exactly the points and
arrays the labs computed before the view existed (the same values in the same order, bit for bit). A bench of two inputs
has no view controls and no view keys in its settings (first gives {}), so benches 1 and 2 do not change.

The Section (frozen, hashable) holds d, the pair and `held`, a unit point of d coordinates the slice passes through (the
coordinates of the pair in it are not used: lift sets them; adjusted reads them, the value an input takes when it leaves
the axes). Its key (d, the pair and the values held on the other inputs) is what a cache of a slice and a lab's scene
are keyed by, so that two Sections that differ only in the pair's coordinates of `held` are one slice; from_key makes a
Section of a key again. Its methods: project(u) -> (p, q), the pair's two coordinates of a point (of the unit hypercube
or of the bounds alike); lift(p, q) -> the unit point with p and q on the pair and the held values elsewhere (a click on
the plane, a dragged point); distance(u), the Euclidean distance from u to the slice in the inputs held; closeness(u)
and nearness(u), the fade's c and opacity (opacity, grown and shrunk are its functions of c); grid(axis), the rows of
unit points of the slice on that axis of each input of the pair; mesh(across, up, point), the d NumPy arrays to call
f(*arrays) on a grid of the pair. The helpers of the three steps: mapped(bounds, u) and unit(bounds, x), a point of
the unit hypercube in the bounds and back; pair_bounds(bounds, cut), the bounds of the pair on the axes;
projected(cut, points), points at their projections.

The view's settings (a lab keeps them with its own; the window and the page carry CARRIED, the pair and `held`, from the
step left to the step entered and keep them in the bench's snapshot and through Restore: a VIEW, as the 3D angle, never
a change of the study; the sliders' keys only mirror each step's own slice):

    across, up          the input on the horizontal axis and the input on the vertical one (indices 0 .. d - 1;
                        first 0 and 1): two controls of d buttons, x1 .. xd, each with its icon input_k; choosing for
                        an axis the input the other axis shows swaps the two (never a locked option: adjusted);
    held                None, AUTOMATIC: the slice passes through the unit point the lab gives as `auto` (steps 1 and
                        2 the best design, the middle for the free sampling or no design; step 3 x*); or a unit point
                        of d coordinates, PINNED by a slider;
    held_1 .. held_d    the sliders, one per input, each shown only while its input is off the axes (its `visible`),
                        over SLIDER (0 to 1 by 0.01 of the range), reading "x3 = 5.68 m". Each slider edits its own key
                        (the column edits one key at a time); adjusted then PINS held: the slice it stood at (auto's,
                        while automatic) with that coordinate replaced. The slider keys only say where each slider
                        stands (the window needs a number there); of never reads them. While held is None they may be
                        stale: synced puts them back on the automatic point.

The chip (chip(place), key CHIP) returns the slice to the step's own place, released(settings): held None again; it is
named by that place ("Slice at the best design", "Slice at the middle", "Slice at x*", "Slice at the compromise
design": PLACES, the lab chooses, and may rename it by its state with Lab.naming), and is worth offering only while
pinned(settings). A place is added by its name in PLACES and its two texts lab.view.slice.<place> and _tip; the places
a bench's chip may take are places(function) (ONE_PLACES for a bench of one response, MANY_PLACES for one of several:
bench 4's three steps name it by the compromise design, or the middle), and the window reserves the chip the widest of
those names, so that bench 3's band keeps the room it had.

How a lab uses it: it mixes in Viewing (class SamplingLab(section.Viewing, Lab)) and gives its own automatic(settings),
the point its slice passes through while nothing is pinned (None: the middle of the ranges); Viewing gives it
slice_of(settings), the Section the settings show (of), viewed(settings), the settings with the sliders on it
(synced, after every settings the lab returns), its showing hook (showing) and adjust_view(settings, key, old), the
first lines of its adjust hook (after, for a key of the view; nothing of the study follows: a view never discards,
never undoes a validation, never closes a competition). Its controls start with controls(function) (empty for two
inputs: the window draws them in the band over the figure, not in the column), its commands hold chip(place); the heads
of the plane and of the 3D view write note(function, section), "x3 = 5.68 m · x4 = 6.94 m" (names and numbers, no
sentence), each input with the decimals of its range (decimals: about a hundredth of it, a slider's step; the places of
a few metres to the centimetre, bench 4's areas of 175 cm² whole, "x₃ = 262 cm²"), as the sliders' texts write it
(the band's sliders naming a size by what it is, called: "A₁ = 262 cm²", its tip lab.view.held_size_tip naming x₃ too:
"x₃ = A₁ = 262 cm²" broke the band in two lines at 1280 x 720 and took the beam's band away).
The texts are the catalog lab_view.json (namespace lab.view.). A bench of more than MOST inputs has no view (controls
refuses it).
"""
import itertools
import math
from dataclasses import dataclass
from functools import cache

import numpy as np

from statistical_fundamentals.explorers.base import Control
from statistical_fundamentals.explorers.lab import Action
from statistical_fundamentals.functions import RESPONSES, many
from statistical_fundamentals.i18n import current_language, get_text

MOST = 4                              # the inputs a view has controls for (the icons input_1 .. input_4)
SLIDER = tuple(round(k / 100, 2) for k in range(101))      # a held value: 0 to 1 of its input's range, by 0.01
MIDDLE = 0.5                          # where the sliders and an automatic slice with nothing to pass through stand
FAINT = 0.45                          # the least opacity: a mark far from the slice is faint, never lost (0.3, with its area
                                      # shrunk too, left the 85 designs of step 1 specks under a dark edge: the look review)
NEAR = 0.4                            # the distance from the slice (unit hypercube) at which the closeness is 1/e: the
                                      # Gaussian of the MLS weight, exp(-(r / NEAR)^2); a typical design is about 0.6 off it
GROWN_MOST = 70.0                     # points^2: a design of the plane grows near the slice up to this, a free point's size
EDGE_THIN = 0.5                       # points: the dark edge of a projected design (0.9 ate a small dot)
ACROSS, UP, HELD = "across", "up", "held"
CHIP = "slice"                        # the chip's key: back to the automatic slice
PLACES = ("best", "middle", "optimum", "compromise")   # where the chip returns the slice: the best design, the middle,
                                      # x*, the compromise design (a bench of several responses: explorers/outputs.compromise)
ONE_PLACES = ("best", "middle", "optimum")             # the places a bench of one response's chip is named by (places)
MANY_PLACES = ("compromise", "middle")                 # and a bench of several responses' (bench 4's three steps)
SUBSCRIPTS = "₀₁₂₃₄₅₆₇₈₉"
DIGITS = 2                            # an input of a range of order one is written with this many decimals (decimals)

def slider_key(k: int) -> str:
    """The settings key of the slider of input k (0-based): "held_1" for x1."""
    return f"held_{k + 1}"

KEYS = (ACROSS, UP, HELD) + tuple(slider_key(k) for k in range(MOST))     # every key a view of at most MOST inputs has
CARRIED = (ACROSS, UP, HELD)          # the view's truth, which the window and the page carry from a step to the next (the
                                      # sliders' keys only mirror each step's own slice: synced)

def symbol(k: int) -> str:
    """The plain name of input k (0-based), as the figure and the column write it: "x₁"."""
    return "x" + "".join(SUBSCRIPTS[int(digit)] for digit in str(k + 1))

def physical(function: str, k: int) -> str:
    """The physical name of input k where the bench names what its sizes are (functions.Response.size: the inputs
    that are not places, numbered by their cross-beam): "A₁" for bench 4's x₃; "" for a place or a bench without."""
    response = RESPONSES[function]
    if not response.size or response.places is None or k in response.places:
        return ""
    sizes = [j for j in range(response.d) if j not in response.places]
    return response.size + "".join(SUBSCRIPTS[int(digit)] for digit in str(sizes.index(k) + 1))

def called(function: str, k: int) -> str:
    """Input k as the view's band names its slider: by what it is where it has a physical name ("A₁"; its tip says
    x₃), else by its symbol ("x₃")."""
    return physical(function, k) or symbol(k)

def span(d: int) -> str:
    """The inputs of a bench of more, as a measure names them all, the same in every step (step 1's strip, step 2's
    received card): "x₁…x₄"."""
    return f"{symbol(0)}…{symbol(d - 1)}"

def keys(function: str) -> tuple[str, ...]:
    """The view's keys in a bench's settings: none for two inputs."""
    d = RESPONSES[function].d
    return () if d == 2 else (ACROSS, UP, HELD) + tuple(slider_key(k) for k in range(d))

def middle(d: int) -> tuple[float, ...]:
    return (MIDDLE,) * d

def mapped(bounds, u) -> tuple[float, ...]:
    """A point of the unit hypercube (d coordinates) in the bounds (d pairs (a, b)): x = a + (b - a) u."""
    return tuple(a + (b - a) * float(v) for v, (a, b) in zip(u, bounds, strict=True))

def unit(bounds, x) -> tuple[float, ...]:
    """A point of the bounds (d coordinates: a minimum of f, a design) in the unit hypercube: u = (x - a) / (b - a)."""
    return tuple((v - a) / (b - a) for v, (a, b) in zip(x, bounds, strict=True))

@dataclass(frozen=True)
class Section:
    """The slice of the design space a figure shows: the pair of inputs on its axes (across, up) and the unit point
    `held` it passes through (d coordinates; the pair's are not used). With d = 2 every method is the identity."""
    d: int
    pair: tuple[int, int] = (0, 1)
    held: tuple[float, ...] = ()

    def __post_init__(self) -> None:
        if len(self.held) != self.d:
            object.__setattr__(self, "held", middle(self.d))

    @property
    def plain(self) -> bool:
        """Two inputs: the slice is the whole design space."""
        return self.d == 2

    @property
    def key(self) -> tuple:
        """What the slice drawn depends on, the key of a cache of a slice or of a scene: d, the pair and the values held
        on the other inputs (the pair's coordinates in `held` are not used, so two Sections that differ only there have
        one key; `held` itself keeps them, which adjusted reads)."""
        return self.d, self.pair, tuple(self.held[k] for k in self.others)

    @classmethod
    def from_key(cls, key: tuple) -> "Section":
        """The Section of a key: its pair, the values held on the other inputs, MIDDLE on the pair (never read)."""
        d, pair, values = key
        held = [MIDDLE] * d
        for k, value in zip((k for k in range(d) if k not in pair), values, strict=True):
            held[k] = value
        return cls(d, tuple(pair), tuple(held))

    @property
    def others(self) -> tuple[int, ...]:
        """The inputs held, in their order."""
        return tuple(k for k in range(self.d) if k not in self.pair)

    def project(self, u) -> tuple:
        """The pair's two coordinates of a point (of the unit hypercube, or of the bounds: the same indices)."""
        return u[self.pair[0]], u[self.pair[1]]

    def lift(self, p, q) -> tuple:
        """The unit point of the slice with p across and q up: the held values on the other inputs."""
        if self.plain and self.pair == (0, 1):
            return p, q
        point = list(self.held)
        point[self.pair[0]] = p
        point[self.pair[1]] = q
        return tuple(point)

    def distance(self, u) -> float:
        """The Euclidean distance from u (unit hypercube) to the slice, over the inputs held: 0 for two inputs."""
        return math.hypot(*(u[k] - self.held[k] for k in self.others))

    def closeness(self, u) -> float:
        """How close u lies to the slice, c = exp(-(r / NEAR)^2) for its distance r (the MLS weight's Gaussian): 1 on
        the slice, towards 0 far from it; 1 for every point of two inputs. The law of the fade reads it (nearness,
        grown, shrunk)."""
        r = self.distance(u)
        return 1.0 if r == 0 else math.exp(-(r / NEAR) ** 2)

    def nearness(self, u) -> float:
        """The opacity of a mark at u: FAINT + (1 - FAINT) c (closeness), 1 on the slice, FAINT far from it, never
        lost; 1 for every point of two inputs."""
        return opacity(self.closeness(u))

    def grid(self, axis, up=None) -> list[list[tuple]]:
        """The unit points of the slice on a grid: a row for each value of `up` (default `axis`), the input up, and in
        it a point for each value of `axis`, the input across: row by row, as the metamodels' surfaces are computed."""
        return [[self.lift(p, q) for p in axis] for q in (axis if up is None else up)]

    def mesh(self, across, up, point=None) -> tuple:
        """The d arrays of a grid of the slice, to call f(*arrays): np.meshgrid(across, up) on the pair, each input held
        a constant array of point's value (default `held`; `across`, `up` and `point` in the same coordinates, the
        unit hypercube or the bounds). For two inputs, the two arrays of np.meshgrid(across, up) themselves."""
        first, second = np.meshgrid(across, up)
        if self.plain and self.pair == (0, 1):
            return first, second
        point = self.held if point is None else point
        arrays = [np.full(first.shape, float(point[k])) for k in range(self.d)]
        arrays[self.pair[0]] = first
        arrays[self.pair[1]] = second
        return tuple(arrays)

def opacity(c: float) -> float:
    """The opacity of a mark of closeness c: FAINT + (1 - FAINT) c."""
    return FAINT + (1 - FAINT) * c

def grown(area: float, c: float) -> float:
    """The area of a design on the plane at closeness c: the two-input size `area` far from the slice, up to twice it
    on it, never past GROWN_MOST (near grows; far keeps the size it has with two inputs)."""
    return min(area * (1 + c), max(area, GROWN_MOST))

def shrunk(area: float, c: float) -> float:
    """The area of a mark that never grows (a design in the 3D view, a mark of a search): its own `area` on the slice,
    half of it far from it, area (0.5 + 0.5 c)."""
    return area * (0.5 + 0.5 * c)

def pair_bounds(bounds, cut: Section) -> tuple[tuple[float, float], tuple[float, float]]:
    """The bounds of the two inputs on the axes (the response's two for a bench of two inputs)."""
    return bounds[cut.pair[0]], bounds[cut.pair[1]]

def projected(cut: Section, points) -> list:
    """Points (of the bounds, or of the unit hypercube) at their projections on the pair, as the plane's data
    coordinates (nearest takes them): the points themselves for two inputs."""
    return list(points) if cut.plain else [cut.project(point) for point in points]

def pair_of(settings: dict, d: int) -> tuple[int, int]:
    """The pair the settings ask for: (across, up), or (0, 1) for two inputs or settings that name no valid pair."""
    if d == 2:
        return 0, 1
    across, up = settings.get(ACROSS, 0), settings.get(UP, 1)
    valid = range(d)
    if across in valid and up in valid and across != up:
        return int(across), int(up)
    return 0, 1

def first(function: str) -> dict:
    """The view's first settings: x1 across, x2 up, the slice automatic, the sliders in the middle; {} for two inputs."""
    d = RESPONSES[function].d
    if d == 2:
        return {}
    return {ACROSS: 0, UP: 1, HELD: None} | {slider_key(k): MIDDLE for k in range(d)}

def of(function: str, settings: dict, auto=None) -> Section:
    """The Section the settings show: their pair, and the held point if pinned, else `auto` (the lab's automatic point,
    d unit coordinates; None, or a point of another length: the middle of the ranges)."""
    d = RESPONSES[function].d
    point = settings.get(HELD) if d > 2 else None
    if point is None or len(point) != d:
        point = auto
    if point is None or len(point) != d:
        point = middle(d)
    return Section(d, pair_of(settings, d), tuple(float(v) for v in point))

def pinned(settings: dict) -> bool:
    """A slider moved the slice: the chip has somewhere to return it."""
    return settings.get(HELD) is not None

def decimals(bounds: tuple[float, float]) -> int:
    """The decimals an input is written with, from its range (a, b): DIGITS less the order of b - a, never fewer than
    none, so that the last digit written is about a hundredth of the range, a slider's step (SLIDER): two for a range
    of a few metres (benches 3 and 4's places: "x₃ = 5.68 m"), none for one of a hundred or more (bench 4's
    areas: "x₃ = 225 cm²")."""
    a, b = bounds
    return max(0, DIGITS - math.floor(math.log10(b - a))) if b > a else DIGITS

def written(k: int, value: float, unit: str, places: int = DIGITS, name: str = "") -> str:
    """'x3 = 5.68 m': an input and its value in its unit (`places` decimals: the input's own, decimals), or alone where
    the response has none; `name`, how the input is called where not by its symbol ("A₁": called)."""
    number = f"{value:.{places}f}".replace("-", "−")
    head = name or symbol(k)
    return f"{head} = {number} {unit}" if unit else f"{head} = {number}"

def value_of(function: str, section: Section, k: int) -> float:
    """The held value of input k, in the bounds."""
    a, b = RESPONSES[function].bounds[k]
    return a + (b - a) * section.held[k]

def note(function: str, section: Section) -> str:
    """What the heads of the plane and of the 3D view write of the slice: "x3 = 5.68 m · x4 = 6.94 m"; "" for two
    inputs (nothing is held)."""
    units, bounds = RESPONSES[function].units, RESPONSES[function].bounds
    return " · ".join(written(k, value_of(function, section, k), units[k], decimals(bounds[k])) for k in section.others)

TITLES = {"plane": ("lab.lhs.plane_title", "lab.mm.plane_title", "lab.opt.plane_title", "lab.opt.plane_title_real"),
          "space": ("lab.lhs.space_title_many", "lab.mm.space_title_many", "lab.opt.space_title_many")}     # the heads that
                                                                  # write the note, in the three steps (their titles)
METHODS = ("lab.opt.method.nlpql", "lab.opt.method.ea", "lab.opt.method.arsm")     # the names step 3's plane title takes
                                                                  # ("NLPQL on the metamodel ŷ"): each one measured

def heading(function: str) -> dict | None:
    """What a plan needs to reserve the note of the slice a line under a title (panels.arrangement's `notes`, which
    measures them): by the panel's name, the three steps' titles of that head (TITLES, in the language chosen) and the
    notes a slice of the bench may write, every pair with each input held at its longest value (the digits of the
    figure's face are of one width), so that the three steps decide alike whatever the slice; None for two inputs (no
    note)."""
    if RESPONSES[function].d == 2:
        return None
    return heads_of(function, current_language())

@cache
def heads_of(function: str, language: str) -> dict:
    """heading's texts, once per bench and language."""
    d = RESPONSES[function].d
    inputs = f"{symbol(0)}, …, {symbol(d - 1)}"
    bounds, units = RESPONSES[function].bounds, RESPONSES[function].units
    longest = [max((written(k, a + (b - a) * v, units[k], decimals((a, b))) for v in SLIDER), key=len)
               for k, (a, b) in enumerate(bounds)]
    notes = tuple(dict.fromkeys(" · ".join(longest[k] for k in range(d) if k not in pair)
                                for pair in itertools.permutations(range(d), 2)))
    methods = tuple(get_text(key) for key in METHODS)                 # step 3's plane is titled by the method on screen
    return {name: (tuple(dict.fromkeys(get_text(key, inputs=inputs, method=method) for key in keys for method in methods)), notes)
            for name, keys in TITLES.items()}

def controls(function: str) -> tuple[Control, ...]:
    """The view's controls, in the column's order: the horizontal axis, the vertical axis (d buttons x1 .. xd, each
    with its icon input_k), then a slider per input, each shown only while its input is off the axes; () for two
    inputs. The window draws them, with the chip, in a band over the figure (gui/lab_views.ViewBand), not in the
    column: the view is how the figure is looked at, never the study. The texts are asked in the language chosen when
    they are made, as a lab's own controls; the axes' tips name the 3D view's floor, or, on a bench of several responses
    (functions.many: no 3D view, the objective space in its place), the design space alone. A response of more than
    MOST inputs is refused (ValueError): KEYS and the icons input_1 .. input_MOST stop there."""
    d = RESPONSES[function].d
    if d == 2:
        return ()
    if d > MOST:
        raise ValueError(f"a view has controls for at most {MOST} inputs (the icons input_1 .. input_{MOST}), not {d}")
    response = RESPONSES[function]
    names = tuple(symbol(k) for k in range(d))
    icons = {k: f"input_{k + 1}" for k in range(d)}
    floor = "_plane" if many(function) else ""                   # no 3D view, no floor: the design space alone
    axes = (Control(ACROSS, get_text("lab.view.across"), tuple(range(d)), 0, names=names, tip=get_text(f"lab.view.across{floor}_tip"),
                    icons=icons),
            Control(UP, get_text("lab.view.up"), tuple(range(d)), 1, names=names, tip=get_text(f"lab.view.up{floor}_tip"), icons=icons))
    sliders = []
    for k in range(d):
        (a, b), unit = response.bounds[k], response.units[k]
        name = physical(function, k)
        sizes = [j for j in range(d) if response.places is not None and j not in response.places]
        tip = (get_text("lab.view.held_size_tip", name=name, symbol=symbol(k), beam=sizes.index(k) + 1) if name
               else get_text("lab.view.held_tip", symbol=symbol(k)))
        head = called(function, k)
        sliders.append(Control(slider_key(k), symbol(k), SLIDER, SLIDER.index(MIDDLE),
                               show=lambda value, k=k, a=a, b=b, unit=unit, head=head: written(k, a + (b - a) * value, unit,
                                                                                               decimals((a, b)), head),
                               tip=tip,
                               visible=lambda settings, k=k, d=d: k not in pair_of(settings, d)))
    return axes + tuple(sliders)

def shown(control: Control, settings: dict) -> bool:
    """Whether a view control is on screen for these settings: the axes always, a slider while its input is held."""
    return control.visible is None or control.visible(settings)

def showing(function: str, settings: dict, key: str, auto=None) -> str:
    """The text beside a slider, the value its input is held at in the slice on screen ("x3 = 5.68 m", a size by what
    it is, "A₁ = 262 cm²": called; the automatic point's while nothing is pinned); "" for any other key."""
    d = RESPONSES[function].d
    if d == 2 or key not in keys(function) or key in (ACROSS, UP, HELD):
        return ""
    k = int(key.rsplit("_", 1)[1]) - 1
    section = of(function, settings, auto)
    return written(k, value_of(function, section, k), RESPONSES[function].units[k], decimals(RESPONSES[function].bounds[k]),
                   called(function, k))

def adjusted(function: str, settings: dict, key: str, value, auto=None) -> dict:
    """The settings after the view's control `key` took `value`, from the settings BEFORE the change (a lab's adjust
    hook has them after it: see after). An axis given the input the other axis shows swaps the two; a slider pins the
    slice, the one on screen (auto's while automatic) with its input's coordinate replaced, and every slider then
    stands at the pinned point. A key that is not the view's, or a bench of two inputs: the value set, nothing more."""
    d = RESPONSES[function].d
    if d == 2 or key not in keys(function) or key == HELD:
        return settings | {key: value}
    if key in (ACROSS, UP):
        across, up = pair_of(settings, d)
        value = int(value)
        if key == ACROSS:
            across, up = value, (across if value == up else up)
        else:
            across, up = (up if value == across else across), value
        return settings | {ACROSS: across, UP: up}
    k = int(key.rsplit("_", 1)[1]) - 1
    held = list(of(function, settings, auto).held)
    held[k] = float(value)
    return settings | {HELD: tuple(held)} | {slider_key(j): held[j] for j in range(d)}

def after(function: str, settings: dict, key: str, old, auto=None) -> dict:
    """adjusted, as a lab's adjust hook is called: `settings` already hold the new value of `key`, `old` the one
    before."""
    return adjusted(function, settings | {key: old}, key, settings[key], auto)

def released(settings: dict) -> dict:
    """The chip: the slice automatic again (held None); the sliders stay where they stood until synced."""
    return settings | {HELD: None}

def synced(function: str, settings: dict, auto=None) -> dict:
    """The settings with every slider standing at the slice on screen (the automatic point while nothing is pinned):
    what the window shows a slider at. The same settings for two inputs."""
    d = RESPONSES[function].d
    if d == 2:
        return settings
    section = of(function, settings, auto)
    return settings | {slider_key(k): section.held[k] for k in range(d)}

class Viewing:
    """What a laboratory does with its view, the same in the three steps: mixed in before Lab (class SamplingLab(Viewing,
    Lab)) by a lab that has `function` (its bench), `d` (its inputs) and automatic(settings), the unit point its slice
    passes through while no slider pinned it (None: the middle of the ranges; always None for two inputs)."""

    def automatic(self, settings: dict) -> tuple[float, ...] | None:
        """The lab's own automatic point: none here (the middle)."""
        return None

    def slice_of(self, settings: dict) -> Section:
        """The slice the settings show (of, through the automatic point while nothing is pinned): the whole design
        space, Section(2), for two inputs."""
        return of(self.function, settings, self.automatic(settings))

    def viewed(self, settings: dict) -> dict:
        """The settings with the view's sliders standing at the slice on screen (synced: the automatic point's while
        nothing is pinned), what the window shows them at; the same settings for two inputs."""
        if self.d == 2:
            return settings
        return synced(self.function, settings, self.automatic(settings))

    def showing(self, key: str, settings: dict) -> str:
        """Beside a slider of the view, the value its input is held at in the slice on screen ("x₃ = 5.68 m"); nothing
        for the lab's own controls."""
        if key in keys(self.function):
            return showing(self.function, settings, key, self.automatic(settings))
        return ""

    def adjust_view(self, settings: dict, key: str, old) -> dict | None:
        """The first lines of the lab's adjust hook: for a key of the view, the settings after it (after: an axis given
        the input the other shows swaps the two, a slider pins the slice there, HELD carried by the window is taken as
        it is), the sliders on the slice (viewed); None for any other key, which is the lab's."""
        if key not in keys(self.function):
            return None
        return self.viewed(after(self.function, settings, key, old, self.automatic(settings)))

def chip(place: str) -> Action:
    """The chip that returns the slice to the step's own place (PLACES: "best", "middle", "optimum" or "compromise"), key
    CHIP; the window draws it at the end of the view's band, not among the lab's chips."""
    return Action(CHIP, get_text(f"lab.view.slice.{place}"), get_text(f"lab.view.slice.{place}_tip"))

def places(function: str) -> tuple[str, ...]:
    """The places the chip of a bench's three steps may be named by (a lab names it by its state, Lab.naming), whose
    widest name the window's band reserves: a bench of one response's ONE_PLACES (the best design, the middle, x*), a
    bench of several responses' MANY_PLACES (the compromise design, the middle)."""
    return MANY_PLACES if RESPONSES[function].outputs else ONE_PLACES
