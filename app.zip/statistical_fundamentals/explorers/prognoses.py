# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                          Title: prognoses.py
# ==============================================================================
"""
Step 2's optimal prognosis for EVERY response of one experiment at once (a bench of several responses: beam_pareto's
mass, RMS deflection and two stresses), without Qt and without matplotlib. The competition of explorers/metamodel.py
is run per response; four of them would cost four times one. What makes them cheaper is a property every metamodel of
the app has: it is LINEAR in the simulated values,

    y^(u) = sum_i a_i(u) y_i,

with weights a_i(u) that depend only on the designs, the model and its parameter, never on y (the cores' `influence`,
the weights step 2 draws). One simulation gives every response at the same designs, and the cross-validation deals
them into the same subsets (the experiment's seed), so the weights of a candidate are the same for every response.

What is shared, and what is not:
- The MOVING LEAST SQUARES, 85 to 90 % of a competition (the search of D: 24 radii, three bases, a new weighted fit at
  every test point): moving_least_squares.influence ONCE per (basis, D, subset of the cross-validation, design left
  out), and once per (basis, D) at the designs and at the points of the computability check (metamodel.checked_grid);
  each response then gets its predictions as sum_i a_i y_i (linear.dot). validations(experiment, order, D) is the
  cross-validation of every response, computable(experiment, order, D) the check of metamodel.fit for every response
  (finite values at the designs and on the check grid, a CoD), each computed once per experiment, basis and D; the
  weights are dropped once they are applied (only the predictions and the CoPs are kept).
- The POLYNOMIALS and KRIGING run the app's own per-response path (metamodel.entry, validation, fit, best_order,
  best_theta on the experiment of each output): their `influence` factors its matrix again at every point asked, so
  sharing them by their weights would cost more than it saves. Kriging's theta is each response's own likelihood's.
No core is changed and none is written twice: the predictions of the moving least squares are the core's weights times
the values, the same numbers as the core's own fit up to rounding (a CoP differs from the per-response path by about
10^-12; every winner, D, theta and refusal the same, as checked when this module was written). A candidate is refused
exactly where the core refuses it: influence factors the same matrix B^T W B as the core's fit.

The competition is the app's, response by response: the three polynomials, the three moving least squares each at
its best D (the slider's values in the order of their CoP, the first that can also be computed on the check grid) and
Kriging at its theta of largest likelihood; the winner the largest CoP, the first of equals (metamodel.winner: no
other tie rule; the mass, exactly linear, ties every candidate at 1.0 and its winner is the linear polynomial).

    competition(experiment)       every response's seven entries and winner, run once per experiment (its output 0:
                                  the experiment of any output asks for the same one) and kept (CONTESTS experiments);
    entry(k, experiment)          candidate k of the competition of the experiment's own output (Experiment.output);
    champion(experiment)          the winner of that output, or None when no candidate can be computed;
    best_radius(order, experiment)  the best D of a basis for that output (the Best D command);
    validation(candidate, experiment)  the cross-validation and CoP of a candidate for that output: the moving least
                                  squares' from the shared weights (the slider's CoP, the check's predictions), the
                                  others' metamodel.validation;
    best_order, best_theta        metamodel's own.
Every number of the moving least squares that a laboratory of a bench of several responses shows in step 2 comes from
here (the competition, Best D, the CoP on screen, the check's predictions), so that the competition never disagrees
with the measures; metamodel.fit(candidate, experiment) stays the model itself (the cores' own fit, which step 3
evaluates). The experiment of output k is dataclasses.replace(experiment, output=k) (outputs: their order). A bench of
one response is a bench of one output here, and its numbers those of metamodel.py up to rounding.

The cost (pure Python, no threads: the window shows its wait cursor): a teacher's first entry runs the four
competitions, about one competition's time (the moving least squares' search is the floor); a student never runs one:
the CoP of a moving least squares he chooses costs one cross-validation for the four responses together. The caches
hold values, never the weights (a few megabytes per basis and D); never mutate what they return.
"""
import math
from dataclasses import dataclass, replace
from functools import lru_cache

from statistical_fundamentals import linear, moving_least_squares
from statistical_fundamentals.explorers import metamodel
from statistical_fundamentals.explorers.doe import Experiment, simulated
from statistical_fundamentals.explorers.metamodel import (CANDIDATES, ORDERS, RADII, REFUSED, Candidate, Entry, Validation,
                                                          checked_grid, sample, truth, winner)
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.prognosis import coefficient_of_determination, coefficient_of_prognosis

CONTESTS = 4                          # the competitions kept (an experiment each, every response): a new one costs seconds
KEPT = 512                            # the cross-validations and checks kept, per (experiment, basis, D): 72 per experiment
MLS = len(ORDERS)                     # candidate k of the competition: 0 to 2 the polynomials, 3 to 5 the moving least
KRIGING = 2 * len(ORDERS)             # squares, 6 Kriging

@dataclass(frozen=True)
class Competition:
    """The optimal prognosis of every response of one experiment: per output (in the outputs' order) its seven entries
    (metamodel.entry's candidates and CoPs) and the index of its winner (None: no candidate can be computed)."""
    entries: tuple[tuple[Entry, ...], ...]
    winners: tuple[int | None, ...]

def base(experiment: Experiment) -> Experiment:
    """The experiment of output 0: the designs and their one simulation, which every output shares."""
    return experiment if experiment.output == 0 else replace(experiment, output=0)

def of(experiment: Experiment, k: int) -> Experiment:
    """The experiment of output k (the same designs, the values of the k-th response)."""
    return experiment if experiment.output == k else replace(experiment, output=k)

def count(experiment: Experiment) -> int:
    """The outputs the experiment's simulation gives (one for a bench of one response)."""
    return len(simulated(base(experiment)).outputs)

def finite(values) -> bool:
    return all(math.isfinite(v) for v in values)

@lru_cache(maxsize=KEPT)
def validations(experiment: Experiment, order: str, D: float) -> tuple[Validation | None, ...]:
    """The cross-validation of the moving least squares of basis `order` and radius D for every output of the
    experiment (its output 0's designs and subsets: metamodel.sample), as metamodel.validation gives it for one: each
    design predicted by the fit without its subset, sum_i a_i(u) y_i with the weights of moving_least_squares.influence
    computed once per subset and design left out and applied to every output; None for an output whose CoP is not
    finite, and for every output where the core refuses a fit (a matrix not positive definite: too few designs within
    reach)."""
    experiment = base(experiment)
    data = sample(experiment)
    columns = [sample(of(experiment, k)).values for k in range(count(experiment))]
    n = len(data.unit)
    made = [[0.0] * n for _ in columns]
    try:
        for subset in data.subsets:
            others = [i for i in range(n) if i not in subset]
            train = [data.unit[i] for i in others]
            seen = [[column[i] for i in others] for column in columns]
            for i in subset:
                a = moving_least_squares.influence(data.unit[i], train, order, D)
                for predictions, values in zip(made, seen):
                    predictions[i] = linear.dot(a, values)
    except REFUSED:
        return (None,) * len(columns)
    return tuple(judged(values, predictions) for values, predictions in zip(columns, made))

def judged(values, predictions) -> Validation | None:
    """A cross-validation's predictions and its CoP, or None where the CoP or a prediction is not finite."""
    try:
        cop = coefficient_of_prognosis(values, predictions)
    except REFUSED:
        return None
    return Validation(tuple(predictions), cop) if math.isfinite(cop) and finite(predictions) else None

@lru_cache(maxsize=KEPT)
def computable(experiment: Experiment, order: str, D: float) -> tuple[bool, ...]:
    """metamodel.fit's test of the moving least squares (order, D) for every output of the experiment: its values at
    the designs and on the check grid (metamodel.checked_grid) finite, by the weights computed once at each of those
    points, and its CoD at the designs (for two inputs, its CoD against f on the grid too) finite; False for every
    output where the core refuses the fit somewhere."""
    experiment = base(experiment)
    data = sample(experiment)
    d = RESPONSES[experiment.function].d
    try:
        at = [moving_least_squares.influence(u, data.unit, order, D) for u in data.unit]
        on = [moving_least_squares.influence(u, data.unit, order, D) for u in checked_grid(d)]
    except REFUSED:
        return (False,) * count(experiment)
    found = []
    for k in range(count(experiment)):
        values = sample(of(experiment, k)).values
        fitted = [linear.dot(a, values) for a in at]
        checked = [linear.dot(a, values) for a in on]
        try:
            cod = coefficient_of_determination(values, fitted)
            whole = coefficient_of_determination(truth(experiment.function, None, k).flat, checked) if d == 2 else 0.0
        except REFUSED:
            found.append(False)
            continue
        found.append(finite(fitted) and finite(checked) and math.isfinite(cod) and math.isfinite(whole))
    return tuple(found)

@lru_cache(maxsize=CONTESTS * 3)
def radii(experiment: Experiment, order: str) -> tuple[float | None, ...]:
    """The best D of a basis for every output of the experiment (its output 0): the slider's values in the order of
    their CoP (the first of equals, RADII's order), the first whose metamodel can also be computed on the check grid
    (computable); None for an output where none can."""
    experiment = base(experiment)
    scored: list[list[tuple[float, float]]] = [[] for _ in range(count(experiment))]
    for D in RADII:
        for k, checked in enumerate(validations(experiment, order, D)):
            if checked is not None:
                scored[k].append((checked.cop, D))
    best = []
    for k, scores in enumerate(scored):
        best.append(next((D for _cop, D in sorted(scores, key=lambda score: -score[0]) if computable(experiment, order, D)[k]),
                         None))
    return tuple(best)

def best_radius(order: str, experiment: Experiment) -> float | None:
    """The D of largest CoP of the basis for the experiment's output (radii): the Best D command's."""
    return radii(base(experiment), order)[experiment.output]

def best_order(experiment: Experiment) -> str | None:
    """The basis of the polynomial of largest CoP for the experiment's output (metamodel.best_order: its own path)."""
    return metamodel.best_order(experiment)

def best_theta(experiment: Experiment) -> float | None:
    """Kriging's theta of largest likelihood for the experiment's output (metamodel.best_theta: its own path)."""
    return metamodel.best_theta(experiment)

def validation(candidate: Candidate, experiment: Experiment) -> Validation | None:
    """The cross-validation of a candidate for the experiment's output and its CoP: a moving least squares' from the
    shared weights (validations), a polynomial's or Kriging's metamodel.validation; None where it cannot be computed."""
    if candidate.model != "mls":
        return metamodel.validation(candidate, experiment)
    if candidate.value is None:
        return None
    return validations(base(experiment), candidate.order, candidate.value)[experiment.output]

def entry(k: int, experiment: Experiment) -> Entry:
    """Candidate k of the competition of the experiment's output: a polynomial and Kriging by metamodel.entry, a moving
    least squares at its best D (best_radius) with its shared CoP."""
    if k < MLS or k == KRIGING:
        return metamodel.entry(k, experiment)
    order = ORDERS[k - MLS]
    candidate = Candidate("mls", order, best_radius(order, experiment))
    if candidate.value is None:
        return Entry(candidate, None)
    checked = validation(candidate, experiment)
    computed = checked is not None and computable(base(experiment), order, candidate.value)[experiment.output]
    return Entry(candidate, checked.cop if computed else None)

def competition(experiment: Experiment) -> Competition:
    """The optimal prognosis of every output of the experiment, run once per experiment (whatever output it is asked
    through: contest, by its output 0) and kept."""
    return contest(base(experiment))

@lru_cache(maxsize=CONTESTS)
def contest(experiment: Experiment) -> Competition:
    """competition's, for the experiment of output 0: the moving least squares basis by basis (their weights shared by
    every output), then each output's seven entries and winner."""
    for order in ORDERS:                                              # the shared search of D, for every output at once
        radii(experiment, order)
    entries = tuple(tuple(entry(j, of(experiment, k)) for j in range(CANDIDATES)) for k in range(count(experiment)))
    return Competition(entries, tuple(winner(row) for row in entries))

def champion(experiment: Experiment) -> Entry | None:
    """The winner of the competition of the experiment's output, the entry of largest CoP (the first of equals); None
    when no candidate can be computed."""
    found = competition(experiment)
    first = found.winners[experiment.output]
    return None if first is None else found.entries[experiment.output][first]
