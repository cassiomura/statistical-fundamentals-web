# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: sketch.py
# ==============================================================================
"""
The drawing of the beam's problem (beam.py) and of ONE design in focus, in two sizes: the HERO, the beam's band over the
figure (explorers/panels.banded: Plan.band; `hero` and `hero_focus`, at the end of this docstring: the design's
geometry only, no shape and no number), and the compact
caption of the 3D view's card where the figure has no room for the band, where the formula of the response stands on
the others (explorers/panels.py: the block Plan.formula, under the card's hairline). No Qt: a laboratory gives it a
matplotlib axes over that block. The beam rests on n cross-beams, one per input of the bench (two on bench 2, four on
bench 3).

Two calls. `problem(ax, wide, high, bounds, empty, focused, factor, kind, pair)`, once per layout, draws what never
changes: the beam as a line (dashed, in the quiet ink: the beam undeformed), its load over it with a discreet scale (the
base load's ends, 8 and 24 kN/m, and what each patch adds, +30, computed from beam.LOAD), the two end supports, and
under the beam the range of each cross-beam (`bounds`, m) as a quiet bar named in its middle (x₁, ..., xₙ; ranges that
share an end each stop short of it). It sets the axes' data to the layout pixels of the block, y down from its top (no
ticks, no frame, transparent on the card's tone) and returns a Sketch, the geometry the second call needs.
`focus(sketch, solution, lines, pair)`, at every change of the design in focus, draws one design (a beam.Solution):
its n cross-beams as springs at its places, standing on their grounds (side by side, touching, wherever neighbours are
closer than a spring is wide: as many springs as cross-beams, never fewer); its deflected shape `factor` times the
beam's own drawing scale; what the response reads on it (`kind`: LARGEST, the largest deflection, a dot, ringed, where
it is; WHOLE, a measure of the whole line such as its RMS, a faint fill between the undeformed axis and the line, no
dot); and the text column at the right, four lines the caller wrote in its language (who the design is, its places, y,
the note), the third in the designs' colour and strong. With no solution (None) it draws the empty state: the beam
whole in the structure's ink, the cross-beams at the middle of their ranges in the structure's ink (never the designs'
colour), no deflected shape, and the four lines that say what y is. It returns the list of the artists it added, and
only them: the caller removes them before the next focus, and the problem's drawing stays.

The pair (`pair`: the indices of the two inputs on the figure's axes, or None): on a bench of more than two inputs the
drawing says which two the figure shows. The two cross-beams of the pair are drawn in the accent (the designs' colour,
or the structure's ink in the empty state) and their ranges in the light ink, a heavier bar; the inputs held, in the
quiet ink, a lighter spring. The ranges belong to the problem's drawing: `focus` paints them again for the pair it is
given (`paint`), the only change it makes to what `problem` drew. With None (two inputs: both on the axes) everything
is drawn as bench 2 always was: every cross-beam in the accent, every range quiet.

The exaggeration (`exaggeration(bounds)`): one factor for every design of a bench, so that designs compare, by one rule.
The block holds a deflection REACH drawn EXAGGERATION times (bench 2's: 100 mm at 5×, over its largest, 95.2 mm at
x1 = 0.5 m, x2 = 9.5 m); a bench's factor is the largest multiple of STEP at which the largest deflection of its design
space, max |w| on a grid of REACH_GRID places per input (beam.response), drawn, stays within that. Bench 2's is 5 by the
rule, but the bench draws 20 (the owner's, explorers/caption.FACTORS: the caller's `factor`, cut where deeper); the beam on
four cross-beams (largest 9.82 mm, at (1, 5, 6.6, 8.41) m) takes 50.

The geometry, in layout pixels (the drawing never grows with the figure, nor with the screen's density: the axes' data
are layout pixels, sizes are points, the type comes from the roles of panels.py). The text column is as wide as the
widest line the caller can give (`empty` and every tuple of `focused`, measured in the face drawn: panels.text_width),
so that the beam keeps the same place and length from a design to another for the same block; the column stands at the
block's right, the beam takes the rest (LEFT_PAD from the block's left, COLUMN_GAP before the column), up to the length
at which the deflection REACH, drawn at EXAGGERATION times the beam's scale, still holds over the ranges' bars (a wide
block keeps the beam and the column together at its left, the room at its right). A block too narrow for a beam of
BEAM_LEAST beside the column (a phone's stack) keeps of the column only a design's y (the empty state's lines left out),
and, narrower still, no column: the beam takes the block's width (LEFT_PAD at each end). One scale for every design of a
bench: per_mm layout pixels per mm of deflection, factor times per_metre / 1000. A design deeper than the room under the
beam has its shape cut at the room's edge (Sketch.room: below). A range too short for its name between its bar's halves keeps its
ticks and its name. The vertical places are fixed from the block's top, HEIGHT the least block the drawing holds; a
taller block leaves its room under the drawing.

Colours keep one meaning (palette.py): the designs' colour (BLUE) for all that belongs to the design in focus, the
muted ink for the structure, the quiet grey for its load, supports and ranges; never colour alone: the dot has a ring,
the pair's ranges are heavier and its springs bolder, and the value is written.

One exaggeration per bench (the caller's `factor`) in the compact caption: a deflected shape deeper than the drawing's
room under the beam (Sketch.room: REACH_ROOM) is CUT at the room's edge, the line clipped and the dot hollow at the cut
(deflected). The place under the pointer (focus's `pointer`: the cross-beams' places of a point nobody simulated) draws
only the cross-beams there, DASHED, the beam straight, no shape and no value (pointed; the column's y line says so).
The compact caption is the web's figure (Lab.hero False there) and the window's with the code panel open or a small
figure: on the web it keeps its shape, its dot and its four lines; in the window (explorers/caption.py's `geometric`)
it follows the band's 1A below, a simulated design drawn by pointed's `simulated`: its cross-beams solid at its places
on the straight beam, who and its places, no shape and no value.

The band (`hero(ax, wide, high, bounds, title, titles, pair)`, once per layout, and `focus` on its Sketch, hero_focus,
at every change of the design in focus), the owner's 1A of 2026-11-21 (the band teaches the parametrization; the
result has one place, step 1's table and the scoreboard, as in optiSLang): the GEOMETRY of the design in focus only.
Once per layout: its title at the top left (panels.TITLE); the load with its values; the beam, solid; the end supports;
each cross-beam's RANGE as a rail under the beam (paint colours the pair's lighter and the held ones quiet); the left
support's line down to the dimension lines. The design in focus adds its springs at its places on the straight beam
(solid in the designs' colour for a simulated design, dashed in the light ink for the place under the pointer), its
place on each rail and a DIMENSION LINE per input from the left support to its cross-beam ("x₁ = 3.68 m" on it:
dimensions), and who it is, quiet ("best design · design 20 of 50", WHO), on the title's line at the band's right,
ending WHO_END_GAP before the load's right value (where the band is too narrow for it there, after the title, as
before, a "·" then before it: a separator only between two items): so the who never shortens the beam. No deflected
shape, no dot, no cut, no readout: the band never shows a number of a simulation. The cross-beam the pointer is on in
the band (its range, or on bench 4 its spring and section: hero_focus's `lit`, live.Pointing.lit_beam) is drawn in the
window's accent, heavier (LIT, LIT_WIDTH: never colour alone), its section too: the band answers the pointer. Its
geometry (layout pixels, the type from panels' roles) takes the longest beam whose springs keep their room: across, from
HERO_PAD (or further right, out from under the title, where the load would crowd it) to HERO_PAD from the band's right;
down, the load at one of LOAD_SCALES (under the who's line where it stands over the load, WHO_CLEAR), the beam, the
springs' room (ROOM_WANT to ROOM_MOST), the grounds, the rails and the dimension lines.
Sketch.place and Sketch.ranged turn a pixel across into a place along the beam and the input whose range holds it.

Cross-beams SIZED (bench 4: two cross-beams whose places x₁, x₂ and the AREAS x₃ = A₁, x₄ = A₂ of their solid square
sections are the design; the caller's `inputs`, `sizes` and `sized`): the ranges, rails and dimension lines are the
places' alone (a size is not a place: no rail, no dimension line, never commanded along the beam; Sketch.ranged names
the input of a place, Sketch.placed turns the figure's pair into the places' indices). In the band, each cross-beam's
SQUARE section seen end-on under its spring (sections: a square of side a = sqrt(A), beam.side, at SECTION_SCALE, one
scale for every section, inside the dotted outline of its range's largest, named "A₁ = 225 cm²", the first at its left,
the others at their right; the spring stands on it, grounded False), the sections' room more between the grounds and the
rails (section_room). What a section gives (its stiffness, its mass, its stress, the cross-beam in detail) and the
design's check are the column's card's, not the band's (explorers/crossbeams.py). The compact caption draws no section
(its 70 pixels have no room): its fourth line is the check, in the light ink or in FAILED's red where a constraint
passes its limit (check_roles; in words too).
"""
from dataclasses import dataclass, replace
from functools import lru_cache

import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.patches import Polygon, Rectangle
from matplotlib.text import Text

from statistical_fundamentals import beam, palette
from statistical_fundamentals.explorers import panels
from statistical_fundamentals.explorers.base import short

HEIGHT = 70.0                 # layout pixels: the least height of the caption's block at which the drawing reads
EXAGGERATION = 5              # bench 2's: the deflected shape this many times the beam's own drawing scale, every design
REACH = 100.0                 # mm: the deflection the drawing holds under the beam at EXAGGERATION (bench 2's largest 95.2)
STEP = 5                      # a bench's exaggeration is a multiple of this (exaggeration)
REACH_GRID = 5                # places per input of the grid on which a design space's largest deflection is found
LARGEST, WHOLE = "largest", "whole"   # the response's kind: the largest deflection (a dot), a measure of the whole line
LOAD_UNIT = "kN/m"            # the unit of the load's scale (an SI symbol, the same in every language)
STRUCTURE = panels.MUTED_INK  # the beam itself: the structure's ink
QUIET = palette.GREY          # its load, its supports, the grounds and the ranges: quieter still
FOCUS = palette.BLUE          # the design in focus: the colour of a simulated design
LIGHT = panels.LEGEND_INK     # the ranges of the pair on the figure's axes: the light ink of a legend's labels
LIT = palette.theme.ACCENT    # the band's cross-beam under the pointer (hero_focus's `lit`): the window's accent, heavier
LIT_WIDTH = 1.7               # its spring's line and its section's edge, in widths of a cross-beam's (never colour alone)
FILL = 0.18                   # the whole line's fill (WHOLE): the designs' colour at this share over the card
# Across, from the block's left (layout pixels)
LEFT_PAD = 8.0                # to the beam's left end: the end support's ground line keeps inside the block
COLUMN_GAP = 22.0             # from the beam's right end to the text column
COLUMN_SLACK = 3.0            # what a line drawn may take beyond its width measured (rounding)
BEAM_LEAST = 120.0            # the shortest beam drawn beside a text column: a narrower block keeps y's line alone, then
                              # no column, the beam across the block (a phone's narrowest stack)
ALL_ROWS, Y_ROW = (0, 1, 2, 3), 2     # the text column's four rows; the row of a design's y
# Down, from the block's top (layout pixels)
LOAD_TOP = 15.0               # the top of the highest load
LOAD_SCALE = 0.46             # layout pixels per kN/m of load
LOAD_GAP = 1.0                # from the load's base down to the beam
TAG_GAP = 1.5                 # from a load's ordinate up to its value
GROUND = 16.0                 # from the beam down to the cross-beams' grounds
BAR = 24.5                    # from the beam down to the ranges' bars
REACH_CLEAR = 8.0             # the deepest deflection (REACH) stays this far over the bars
REACH_ROOM = BAR - REACH_CLEAR    # the deflected shape's room under the beam: a deeper shape is cut there (the dot hollow)
STATIONS_EVERY = 0.5          # m: the hairlines of a distributed load
# The marks (layout pixels; line widths in points)
SUPPORT_HALF, SUPPORT_TALL, SUPPORT_FOOT, SUPPORT_GROUND = 4.5, 7.5, 9.5, 7.0
SPRING_HALF, SPRING_TURNS, SPRING_END = 3.5, 4, 2.0       # half its zigzag's width, its turns, its straight ends
SPRING_WIDTH, HELD_WIDTH = 1.0, 0.8                       # a spring's line; a held input's, lighter
GROUND_HALF, HATCHES, HATCH = 6.0, 4, (2.5, 2.8)            # a cross-beam's ground: its half width, its hatches (across, down)
BAR_TICK, BAR_INSET, NAME_GAP = 2.5, 2.5, 4.0             # a range's end ticks, where two ranges meet, around its name
HALF_LEAST = 3.0                                          # a range's bar keeps its two halves only this long or longer
BEAM_WIDTH, THIN, PAIR_WIDTH = 1.8, 0.8, 1.4                    # PAIR_WIDTH: the bar of a range on the axes
DOT_SIZE, DOT_RING = 6.0, 1.2                             # points: the dot at the largest deflection and its ring

@dataclass(frozen=True)
class Sketch:
    """The geometry `problem` drew, for `focus`: the axes; the beam's left end and its scale (left, per_metre: layout
    pixels per m, so the beam ends at left + per_metre * beam.LENGTH); the beam's line (y, down from the block's top);
    the scale of the deflection (per_mm: layout pixels per mm, the factor times per_metre / 1000); the cross-beams'
    ground (y); the text column's left and its four rows' centres; the places of the empty state's cross-beams (m); the
    rows the column keeps of a design's lines (shown) and of the empty state's (told): all four, or in a narrow block
    y's alone, or none; the response's kind (LARGEST, WHOLE); the ranges drawn (their bars, a LineCollection, the range
    of each of its segments, and their names), which `paint` colours for a pair."""
    ax: object
    left: float
    per_metre: float
    beam: float
    per_mm: float
    ground: float
    column: float
    rows: tuple
    places: tuple
    shown: tuple = (0, 1, 2, 3)
    told: tuple = (0, 1, 2, 3)
    kind: str = LARGEST
    ranges: tuple = (None, (), ())
    room: float = REACH_ROOM      # the deflected shape's room under the beam (layout pixels): a deeper one is cut there;
                                  # the band's: the springs' room (it draws no shape)
    hero: bool = False            # the band's drawing (hero), not the compact caption (problem); its column is where who
                                  # is in focus stands (aligned there: "right", at the band's right; "left", after the
                                  # title), its one row the title's baseline
    rail: float = 0.0             # the hero's: the rails of the ranges (y), and the dimension lines' (y, one per input)
    dims: tuple = ()
    bounds: tuple = ()            # the ranges of the cross-beams (m), one per input
    beside: tuple = ()            # the hero's empty state's dimension labels: the symbols of the inputs
    inputs: tuple = ()            # the input of each cross-beam's place (the response's places); () where every input is
                                  # a place, in their order (benches 2 and 3)
    sizes: tuple = ()             # the cross-beams SIZED (bench 4): the range of each one's section area (cm²), in the
                                  # cross-beams' order; () where the cross-beams have no size of their own
    sized: tuple = ()             # the input of each cross-beam's size (the response's other inputs, in their order)
    aligned: str = "left"         # the hero's who, from its column: "right" (at the band's right), "left" (after the title)

    def at(self, x):
        """The layout pixel across of a place x of the beam (m)."""
        return self.left + self.per_metre * np.asarray(x, dtype=float)

    def place(self, across):
        """The place along the beam (m) of a layout pixel across of the drawing (at's inverse)."""
        return (np.asarray(across, dtype=float) - self.left) / self.per_metre

    def ranged(self, place) -> int | None:
        """The input whose range holds a place along the beam (m): the ranges are disjoint but for a shared end, which
        the first range keeps; None outside every range. The index of the input itself (inputs), where not every input
        is a place."""
        found = next((k for k, (low, up) in enumerate(self.bounds) if low <= place <= up), None)
        return self.inputs[found] if self.inputs and found is not None else found

    def placed(self, pair):
        """The pair of the figure's axes (inputs' indices) as the cross-beams' places take it: the indices of the places
        among the cross-beams whose input is on the axes (inputs); the pair itself where every input is a place, None
        for None."""
        if pair is None or not self.inputs:
            return pair
        return tuple(j for j, k in enumerate(self.inputs) if k in pair)

def exaggeration(bounds) -> int:
    """The factor of a bench's deflected shapes, one for every design: the largest multiple of STEP (at least STEP) at
    which the largest deflection of the design space `bounds` (one (low, high) per cross-beam, m), max |w| on a grid of
    REACH_GRID places per input, drawn, stays within the reach the block holds (REACH at EXAGGERATION)."""
    return reach_factor(tuple((float(low), float(up)) for low, up in bounds))

@lru_cache(maxsize=16)
def reach_factor(bounds: tuple) -> int:
    """exaggeration on bounds made hashable (cached: the grid is solved once per bench)."""
    grid = np.meshgrid(*(np.linspace(low, up, REACH_GRID) for low, up in bounds), indexing="ij")
    largest = float(beam.response(np.stack(grid, axis=-1)).max())
    return STEP * max(1, int(EXAGGERATION * REACH / (STEP * largest)))

def problem(ax, wide, high, bounds, empty, focused, factor=EXAGGERATION, kind=LARGEST, pair=None, inputs=(), sizes=(),
            sized=()):
    """Draw what never changes on `ax`, over a block `wide` x `high` layout pixels (its data set to them, y down): the
    beam, its load and the load's scale, the end supports, the ranges of the cross-beams (`bounds`: (low, high) of each,
    m) with their names, painted for `pair` (the indices of the inputs on the figure's axes; None: all alike). `empty`:
    the four lines of the empty state; `focused`: every four lines a design in focus may show at their widest (the
    caller's candidates), so that the text column, as wide as the widest, never moves. `factor`: the bench's
    exaggeration (exaggeration); `kind`: what the response reads on the deflected line (LARGEST, WHOLE). Where not every
    input is a place (bench 4): `inputs`, the input of each cross-beam's place, `sizes` and `sized`, the ranges and the
    inputs of the cross-beams' sizes (the compact caption draws no section: its fourth line is the design's check).
    Returns the Sketch."""
    ax.set_xlim(0.0, wide)
    ax.set_ylim(high, 0.0)
    ax.set_axis_off()
    ax.patch.set_visible(False)
    ax.set_navigate(False)
    full = max(width(text, role) for lines, roles in [(empty, EMPTY), *((lines, FOCUSED) for lines in focused)]
               for text, role in zip(lines, roles)) + COLUMN_SLACK
    alone = max(width(lines[Y_ROW], FOCUSED[Y_ROW]) for lines in focused) + COLUMN_SLACK
    q = beam.load(np.linspace(0.0, beam.LENGTH, 4 * beam.STATIONS))
    line = LOAD_TOP + LOAD_SCALE * float(q.max()) + LOAD_GAP
    deepest = BAR - REACH_CLEAR                                        # the room for the deflection under the beam
    for shown, told, column in ((ALL_ROWS, ALL_ROWS, full), ((Y_ROW,), (), alone), ((), (), 0.0)):
        room = wide - LEFT_PAD - (column + COLUMN_GAP if shown else LEFT_PAD)     # the beam's, beside the column kept
        if room >= BEAM_LEAST or not shown:                            # a narrow block: the column, then y, left out
            break
    per_metre = max(min(room / beam.LENGTH, 1000.0 * deepest / (EXAGGERATION * REACH)), 1e-3)
    start = LEFT_PAD + per_metre * beam.LENGTH + COLUMN_GAP           # the column: at the block's right, or after the
    rows = tuple((k + 0.5) * HEIGHT / len(EMPTY) for k in range(len(EMPTY)))      # beam where the beam is at its longest
    geometry = Sketch(ax, LEFT_PAD, per_metre, line, factor * per_metre / 1000.0, line + GROUND, start, rows,
                      tuple((low + up) / 2 for low, up in bounds), shown, told, kind, inputs=tuple(inputs), sizes=tuple(sizes),
                      sized=tuple(sized))
    draw_load(geometry)
    ends = (0.0, beam.LENGTH)
    ax.plot(geometry.at(ends), [line, line], color=QUIET, linewidth=THIN, linestyle=(0, (3, 2)), zorder=3)
    for x in geometry.at(ends):
        ax.add_patch(Polygon([(x, line), (x - SUPPORT_HALF, line + SUPPORT_TALL), (x + SUPPORT_HALF, line + SUPPORT_TALL)],
                             closed=True, facecolor=panels.CARD_TONE, edgecolor=QUIET, linewidth=0.9, zorder=5))
    ax.add_collection(LineCollection([[(x - SUPPORT_GROUND, line + SUPPORT_FOOT), (x + SUPPORT_GROUND, line + SUPPORT_FOOT)]
                                      for x in geometry.at(ends)], colors=QUIET, linewidths=0.9, zorder=5))
    sketch = replace(geometry, ranges=draw_ranges(geometry, bounds))
    paint(sketch, sketch.placed(pair))
    return sketch

def draw_load(sketch, scale=LOAD_SCALE, role=panels.SMALL):
    """The load over the beam: its diagram (the base load and its patches summed, as beam.load gives it), hairlines
    every STATIONS_EVERY m, and its scale: the base load's value at each end (the right one with its unit) and each
    patch's own intensity over its middle, signed (+30: what it adds to the base, not the ordinate under it). `scale`:
    layout pixels per kN/m; `role`: the scale's type (the hero's larger)."""
    ax, line = sketch.ax, sketch.beam
    base = line - LOAD_GAP

    def top(x):
        return base - scale * beam.load(np.asarray(x, dtype=float))
    x = np.linspace(0.0, beam.LENGTH, 4 * beam.STATIONS)
    outline = [(sketch.at(0.0), base), *zip(sketch.at(x), top(x)), (sketch.at(beam.LENGTH), base)]
    ax.add_patch(Polygon(outline, closed=True, facecolor=panels.tint(QUIET, 0.16), edgecolor=QUIET, linewidth=THIN, zorder=2))
    hair = np.arange(STATIONS_EVERY / 2, beam.LENGTH, STATIONS_EVERY)
    ax.add_collection(LineCollection([[(u, base), (u, v)] for u, v in zip(sketch.at(hair), top(hair))], colors=QUIET,
                                     linewidths=0.5, alpha=0.6, zorder=2))
    tag = role | {"color": panels.MUTED_INK, "va": "bottom"}
    for place, text, align in load_tags():
        ax.text(sketch.at(place), base - scale * tag_load(place) - TAG_GAP, text, ha=align, **tag)

def load_tags():
    """The load's scale, as draw_load writes it: (the place along the beam, m, its text, its alignment) of the base
    load's value at each end (the right one with its unit) and of each patch's own intensity over its middle, signed."""
    (start, end, polynomial), *patches = beam.LOAD
    ends = np.polynomial.polynomial.polyval(np.array([start, end]), polynomial)
    tags = [(start, short(ends[0]), "left"), (end, f"{short(ends[1])} {LOAD_UNIT}", "right")]
    for low, high, added in patches:
        middle = (low + high) / 2
        tags.append((middle, f"+{short(np.polynomial.polynomial.polyval(middle, added))}", "center"))
    return tags

def tag_load(place):
    """The load under a value of its scale (kN/m): at an end, the load there; over a patch, the highest load across it."""
    for low, high, _ in beam.LOAD[1:]:
        if low <= place <= high:
            return float(beam.load(np.linspace(low, high, 64)).max())
    return float(beam.load(np.asarray([place], dtype=float))[0])

def draw_ranges(sketch, bounds):
    """Under the beam, the range of each cross-beam as a quiet bar with a tick at each end, broken in its middle by its
    name (x₁, ..., xₙ); where two ranges meet, each stops BAR_INSET short of the meeting; a range too short to break
    around its name into halves of HALF_LEAST keeps its ticks and its name (a narrow block's short ranges). Returns
    (the bars' LineCollection, the range of each of its segments, the names), for `paint`."""
    ax = sketch.ax
    y = sketch.beam + BAR
    meets = {low for low, _ in bounds} & {up for _, up in bounds}
    name = panels.TAG | {"color": panels.MUTED_INK, "ha": "center", "va": "center"}
    segments, owners, names = [], [], []
    for k, (low, up) in enumerate(bounds, 1):
        a = float(sketch.at(low)) + (BAR_INSET if low in meets else 0.0)
        b = float(sketch.at(up)) - (BAR_INSET if up in meets else 0.0)
        label = "x" + panels.subscript(k)
        middle = (a + b) / 2
        gap = width(label, panels.TAG) / 2 + NAME_GAP
        halves = [[(a, y), (middle - gap, y)], [(middle + gap, y), (b, y)]] if middle - gap - a >= HALF_LEAST else []
        segments += [*halves, [(a, y - BAR_TICK), (a, y + BAR_TICK)], [(b, y - BAR_TICK), (b, y + BAR_TICK)]]
        owners += [k - 1] * (len(halves) + 2)
        names.append(ax.text(middle, y, label, **name))
    bars = ax.add_collection(LineCollection(segments, colors=QUIET, linewidths=THIN, zorder=3))
    return bars, tuple(owners), tuple(names)

def paint(sketch, pair):
    """Colour the ranges for the pair on the figure's axes: theirs in the light ink with a heavier bar, the inputs held
    quiet, their names too. None (two inputs, both on the axes) leaves them as `draw_ranges` drew them, all quiet."""
    bars, owners, names = sketch.ranges
    if pair is None or bars is None:
        return
    if sketch.hero:                                                   # the band's rails: the pair's lighter, the held quiet
        bars.set_colors([panels.tint(LIGHT, RAIL_ALPHA) if k in pair else panels.tint(QUIET, HELD_ALPHA) for k in owners])
        return
    bars.set_colors([LIGHT if k in pair else QUIET for k in owners])
    bars.set_linewidths([PAIR_WIDTH if k in pair else THIN for k in owners])
    for k, text in enumerate(names):
        text.set_color(LIGHT if k in pair else QUIET)

def focus(sketch, solution, lines, pair=None, pointer=None, labels=(), areas=(), named=(), failed=False):
    """Draw the design in focus (a beam.Solution of the bench's cross-beams) with its four lines (who it is, its places,
    y, the note), or, with no solution (None), the empty state with its four lines (what y is), or, with `pointer` (the
    places, m, of a point under the pointer: not simulated), the cross-beams there, dashed, with no shape (pointed); the
    ranges painted for `pair` (the inputs on the figure's axes; None: two inputs, drawn alike). On a bench whose
    cross-beams are sized (Sketch.sizes) the fourth line is the design's check, in the failed colour where it fails
    (`failed`: in words too, never colour alone). On the band's drawing (Sketch.hero) the geometry only, as hero_focus
    draws it: the cross-beams at the solution's supports (or at `pointer`, dashed), `lines[0]` who it is after the
    title, `labels` the dimension lines' texts, `areas` and `named` the sections of a bench sized; no shape and no
    lines of a readout. Returns the list of the artists added, for the caller to remove before the next focus."""
    if sketch.hero:
        places = pointer if pointer is not None else None if solution is None else list(solution.supports)
        return hero_focus(sketch, places, lines[0] if lines else "", pair, pointer is None, labels, areas, named)
    pair = sketch.placed(pair)
    if solution is None and pointer is not None:
        return pointed(sketch, pointer, lines, pair)
    ax, line = sketch.ax, sketch.beam
    drawn = []
    paint(sketch, pair)
    if solution is None:
        ends = sketch.at((0.0, beam.LENGTH))
        drawn += ax.plot(ends, [line, line], color=STRUCTURE, linewidth=BEAM_WIDTH, solid_capstyle="round", zorder=4)
        supports, ink, roles, rows = sketch.places, STRUCTURE, EMPTY, sketch.told
        tops = [line] * len(supports)
    else:
        drawn += deflected(sketch, solution, BEAM_WIDTH, DOT_SIZE)
        supports = [float(x) for x in solution.supports]
        tops = list(line + sketch.per_mm * np.interp(supports, solution.x, solution.w))
        ink, roles, rows = FOCUS, (check_roles(FOCUSED, failed) if sketch.sizes else FOCUSED), sketch.shown
    drawn += springs(sketch, supports, tops, ink, pair)
    for k in rows:
        drawn.append(ax.text(sketch.column, sketch.rows[k], lines[k], ha="left", va="center", **roles[k]))
    return drawn

def pointed(sketch, places, lines, pair=None, simulated=False):
    """The compact caption's place under the pointer (not simulated): the beam straight in the structure's ink, the
    cross-beams at `places` (m) as DASHED springs, no deflected shape, and the four lines (who, the places, that y is not
    simulated, the note). `simulated`: a simulated design drawn by its GEOMETRY only (the owner's 1A, where the window
    stands the step's block in its column: explorers/caption.py's `geometric`), its cross-beams SOLID in the designs'
    colour on the straight beam, no shape, no value. A line left empty is not written. Returns the artists added."""
    ax, line = sketch.ax, sketch.beam
    paint(sketch, pair)
    drawn = ax.plot(sketch.at((0.0, beam.LENGTH)), [line, line], color=STRUCTURE, linewidth=BEAM_WIDTH, solid_capstyle="round",
                    zorder=4)
    drawn += springs(sketch, [float(x) for x in places], [line] * len(places), FOCUS if simulated else LIGHT, pair,
                     dashed=not simulated)
    roles = FOCUSED if simulated else POINTED
    for k in sketch.shown:
        if lines[k]:
            drawn.append(ax.text(sketch.column, sketch.rows[k], lines[k], ha="left", va="center", **roles[k]))
    return drawn

def deflected(sketch, solution, thick, dot):
    """A simulated design's deflected shape (sketch.per_mm times w, the bench's one factor) and what the response reads
    on it: LARGEST, a dot where the deflection is largest; WHOLE, the line filled to its axis. A shape deeper than the
    drawing's room (Sketch.room) is CUT there: the line and the fill clipped at the room's edge, the dot hollow at the
    cut. The compact caption's only: the band draws no shape. Returns the artists added."""
    ax, line = sketch.ax, sketch.beam
    edge = line + sketch.room
    wide = float(ax.get_xlim()[1])
    shape = line + sketch.per_mm * solution.w
    drawn = ax.plot(sketch.at(solution.x), shape, color=FOCUS, linewidth=thick, solid_capstyle="round", zorder=4)
    drawn[0].set_clip_path(Rectangle((0.0, 0.0), wide, edge, transform=ax.transData))
    if sketch.kind == LARGEST:
        deepest = line + sketch.per_mm * float(np.interp(solution.at, solution.x, solution.w))
        cut = deepest > edge + 1e-9
        drawn += ax.plot([float(sketch.at(solution.at))], [min(deepest, edge)], linestyle="none", marker="o", markersize=dot,
                         markerfacecolor=panels.CARD_TONE if cut else FOCUS, markeredgecolor=FOCUS if cut else palette.WHITE,
                         markeredgewidth=DOT_RING, zorder=6)
    else:
        fill = ax.fill_between(sketch.at(solution.x), line, shape, facecolor=panels.tint(FOCUS, FILL), edgecolor="none",
                               linewidth=0.0, zorder=3)
        fill.set_clip_path(Rectangle((0.0, 0.0), wide, edge, transform=ax.transData))
        drawn.append(fill)
    return drawn

def spread(across, half=SPRING_HALF):
    """The layout pixels across at which springs at `across` are drawn: each at its place, but neighbours closer than a
    spring is wide (2 `half`) side by side, touching, each group centred on the mean of its places (two at the corner
    x1 = x2 the ranges of bench 2 share; any neighbours of a bench of more). Groups that touch after spreading join,
    until none overlaps. The order across is the places' order."""
    order = sorted(range(len(across)), key=lambda k: across[k])
    groups = [[k] for k in order]
    joined = True
    while joined:
        joined = False
        for g in range(len(groups) - 1):
            if laid(groups[g + 1], across, half)[0] - laid(groups[g], across, half)[-1] < 2 * half:
                groups[g:g + 2] = [groups[g] + groups[g + 1]]
                joined = True
                break
    placed = list(across)
    for group in groups:
        for k, x in zip(group, laid(group, across, half)):
            placed[k] = x
    return placed

def laid(group, across, half=SPRING_HALF):
    """The places across of one group of springs side by side, touching, centred on the mean of their places."""
    if len(group) == 1:
        return [across[group[0]]]
    middle = sum(across[k] for k in group) / len(group)
    return [middle + (j - (len(group) - 1) / 2) * 2 * half for j in range(len(group))]

def springs(sketch, supports, tops, ink, pair=None, dashed=False, half=SPRING_HALF, turns=SPRING_TURNS, ground_half=GROUND_HALF,
            thick=SPRING_WIDTH, grounded=True, lit=None):
    """The cross-beams as springs from their grounds up to the beam (each top at the beam's line where it stands), in
    `ink`, and their grounds in the quiet ink. Cross-beams drawn closer than a spring is wide stand side by side,
    touching (spread): as many springs as cross-beams, never fewer. With a `pair` the two inputs on the figure's axes
    keep `ink` and the inputs held are drawn quiet and lighter, a coil of their own: two artists, or three with a pair.
    `dashed`: the place under the pointer, not simulated (its coils dashed); `half`, `turns`, `ground_half`, `thick`:
    the hero's larger springs; `grounded` False: no ground (a sized cross-beam's spring stands on its section); `lit`:
    the cross-beam under the pointer in the band (its index), a coil of its own in LIT, LIT_WIDTH heavier."""
    ax, foot = sketch.ax, sketch.ground - SPRING_END
    coils, grounds, lighted = {}, [], []
    across = spread([float(sketch.at(place)) for place in supports], half)
    for k, (x, top) in enumerate(zip(across, tops)):
        zigzag = lighted if k == lit else coils.setdefault(pair is not None and k not in pair, [])
        bends = np.linspace(min(top + SPRING_END, foot - SPRING_END), foot - SPRING_END, turns + 2)[1:-1]
        zigzag += [(x, top), (x, min(top + SPRING_END, foot - SPRING_END))]
        zigzag += [(x + (half if j % 2 else -half), y) for j, y in enumerate(bends)]
        zigzag += [(x, foot - SPRING_END), (x, foot), (np.nan, np.nan)]
        ground = sketch.ground - 1.0
        grounds.append([(x - ground_half, ground), (x + ground_half, ground)])
        hatches = np.linspace(-ground_half + 1, ground_half - 1, HATCHES)
        grounds += [[(x + h, ground), (x + h - HATCH[0], ground + HATCH[1])] for h in hatches]
    drawn = []
    style = {"linestyle": (0, (2.5, 1.6))} if dashed else {}
    for held in sorted(coils):
        xs, ys = zip(*coils[held])
        drawn += ax.plot(xs, ys, color=QUIET if held else ink, linewidth=HELD_WIDTH if held else thick, zorder=5, **style)
    if lighted:
        xs, ys = zip(*lighted)
        drawn += ax.plot(xs, ys, color=LIT, linewidth=LIT_WIDTH * thick, zorder=5, **style)
    if not grounded:
        return drawn
    return [*drawn, ax.add_collection(LineCollection(grounds, colors=QUIET, linewidths=0.9, zorder=5))]

def width(text, role):
    """The width of a line set in a role of panels.py, in layout pixels: measured in the face drawn, at the role's size
    and weight (as a Text of that role holds them)."""
    font = Text(text=text, **role).get_fontproperties()
    return panels.text_width(text, font.get_size_in_points(), font.get_weight())

# The roles of the text column's four lines: the empty state's (y named, what it is, the inputs, one simulation) and a
# design's in focus (who it is, its places, y in the designs' colour, the note)
EMPTY = (panels.caption(panels.LEGEND_SIZE) | {"color": panels.LEGEND_INK}, panels.NOTE | {"color": panels.MUTED_INK},
         panels.NOTE | {"color": panels.MUTED_INK}, panels.SMALL | {"color": panels.MUTED_INK})
FOCUSED = (panels.NOTE | {"color": panels.MUTED_INK}, panels.NOTE | {"color": panels.LEGEND_INK}, panels.STRONG | {"color": FOCUS},
           panels.SMALL | {"color": panels.MUTED_INK})
POINTED = FOCUSED[:2] + (panels.STRONG | {"color": panels.MUTED_INK},) + FOCUSED[3:]    # the place under the pointer: y not simulated

# ------------------------------------------------------------------------------
# The band's drawing: the beam as the hero
# ------------------------------------------------------------------------------
HERO_PAD = 28.0               # from the band's left to the beam's left end (its support and the load's first value), and
                              # from the beam's right end to the band's right (the room the readout once took is the beam's)
HERO_TITLE_GAP = 18.0         # from the band's title (and who is in focus) to the beam, where the beam starts after them
WHO_GAP = 6.0                 # from the band's title to who is in focus after it, where it stands there (a narrow band)
WHO_END_GAP = 12.0            # from who is in focus, on the title's line at the band's right, to the load's right value
WHO_CLEAR = 31.0              # under the who's baseline (panels.TITLE_DROP) and its descent: the load under it starts lower
START_STEP = 4.0              # the beam's left end is sought from HERO_PAD to after the title, every this many layout pixels
ROOM_WANT, ROOM_MOST = 28.0, 46.0     # the springs' room under the beam (layout pixels): the longest beam that keeps at least
                                      # ROOM_WANT (else the most room any start gives), and never more than ROOM_MOST
HERO_TOP = 6.0                # over the highest value of the load
TAG_HIGH = 12.0               # the height of a value of the load (TAG)
TITLE_CLEAR = 33.0            # under the band's title (its baseline at panels.TITLE_DROP): the load under it starts lower
TAG_SLACK = 16.0              # past the title, how far a value of the load still reaches back under it
GROUND_CLEAR, RAIL_GAP = 3.0, 9.0         # from the deflected shape's room to the grounds; from the grounds to the rails
DIM_FIRST, DIM_HALF, HERO_FOOT = 13.0, 7.0, 4.0     # rails to the first dimension line; a label's half; the band's foot
LOAD_SCALES = (1.2, 1.0, 0.8, 0.6, 0.45)  # layout pixels per kN/m the load may take: the largest that keeps the beam long
PITCHES = (14.0, 13.0, 12.0)              # from a dimension line to the next
HERO_SUPPORT = (7.0, 11.0, 13.0, 10.0)    # an end support: its half width, its height, its ground's depth and half width
HERO_SPRING = (4.0, 6, 8.0, 1.3)          # a spring: its half width, its turns, its ground's half width, its line
HERO_BEAM = 2.2                           # points: the beam
RAIL_WIDTH, RAIL_TICK, RAIL_DOT = 3.0, 5.0, 5.5     # a range's rail (points), its end ticks (layout pixels), a place on it
RAIL_ALPHA, HELD_ALPHA = 0.75, 0.5        # the rails of the inputs on the axes and of the inputs held
DIM_TICK, DIM_OFF = 3.0, 6.0              # a dimension line's end tick; its label's offset from that tick
HERO_SLACK = 8.0                          # a dimension label keeps this off the left support's line
LABEL_BOX = {"boxstyle": "square,pad=0.15", "facecolor": panels.CARD_TONE, "edgecolor": "none"}    # a label on its line
WHO = panels.NOTE | {"color": panels.MUTED_INK}     # who is in focus, after the band's title: quiet, read after the title

def hero(ax, wide, high, bounds, title, titles=(), pair=None, inputs=(), sizes=(), sized=()):
    """The band's drawing of the beam (the owner's 1A of 2026-11-21: the GEOMETRY of the design in focus only), what
    never changes, on `ax` over the band's card `wide` x `high` layout pixels (its data set to them, y down): the band's
    title at its top left (panels.TITLE); the load with its values; the beam itself, solid in the structure's ink; the
    end supports; each cross-beam's range as a rail under the beam (painted for `pair`, as paint does); the left
    support's line down to the dimension lines. `titles`: every text of who may be in focus that hero_focus writes on
    the title's line ("· best design · design 20 of 50", at their widest), so that the load under them keeps clear of
    them for every focus and the beam never moves: at the band's right, right-aligned WHO_END_GAP before the load's
    right value (the load and its values under them start WHO_CLEAR down), or, where that would bring them within
    HERO_TITLE_GAP of the title (a narrow band), after the title as the band always had them. Where not every input is
    a place (bench 4, the cross-beams sized): `inputs`, the input of each cross-beam's place; `sizes` and `sized`, the
    range of each one's section area (cm²) and its input: the sections' room (section_room) more between the grounds
    and the rails, where hero_focus draws the sections.

    The geometry, in layout pixels: the beam ends HERO_PAD from the band's right (no readout stands there) and starts
    anywhere from HERO_PAD to after the title (and its who, where it stands after it; every START_STEP); the load above
    it at one of LOAD_SCALES, under the title's row where the beam starts under the title (line_at); under the beam the
    springs' room, then the grounds, the sections (bench 4), the rails and one dimension line per input (PITCHES apart),
    within `high`. Chosen:
    the longest beam whose springs keep ROOM_WANT (then the most room up to ROOM_MOST, then the largest load and pitch),
    else the most room; the room never more than ROOM_MOST (a taller band leaves the rest at its foot). Returns the
    Sketch (hero)."""
    ax.set_xlim(0.0, wide)
    ax.set_ylim(high, 0.0)
    ax.set_axis_off()
    ax.patch.set_visible(False)
    ax.set_navigate(False)
    d = len(bounds)
    extra = section_room(sizes)                                       # the sections' room: none for benches 2 and 3
    ax.text(panels.RANK_INSET, panels.TITLE_DROP, title, ha="left", va="baseline", **panels.TITLE)
    titled = panels.RANK_INSET + width(title, panels.TITLE)          # the title's right end
    widest = max((width(f"· {text}", WHO) for text in titles if text), default=0.0)
    right = wide - HERO_PAD
    tags = load_tags()                                                # the load's values: (place, its text, its alignment)
    last = right - width(tags[1][1], panels.TAG) - WHO_END_GAP       # the who's right end, before the load's right value
    aligned = "right" if widest and last - widest >= titled + HERO_TITLE_GAP else "left"
    if aligned == "right":                                            # on the title's line at the band's right
        column, after, span = last, titled + HERO_TITLE_GAP, (last - widest, last)
    else:                                                             # a narrow band: after the title, as it always was
        column = titled + WHO_GAP
        after, span = column + widest + HERO_TITLE_GAP, None
    stations = np.linspace(0.0, beam.LENGTH, 4 * beam.STATIONS)
    q = beam.load(stations)

    def line_at(start, scale, per_metre):
        """The beam's line under its load (and under the title, where the load stands under it; under the who at the
        band's right, the load and its values that stand under it)."""
        over = HERO_TOP + TAG_HIGH + TAG_GAP + scale * float(q.max()) + LOAD_GAP
        if start < after:
            reach = (after + TAG_SLACK - start) / per_metre
            under = float(q[stations <= reach].max()) if reach > 0 else 0.0
            over = max(over, TITLE_CLEAR + TAG_HIGH + TAG_GAP + scale * under + LOAD_GAP)
        if span is not None:
            low, high = ((x - start) / per_metre for x in span)
            inside = (stations >= low) & (stations <= high)
            if inside.any():
                over = max(over, WHO_CLEAR + scale * float(q[inside].max()) + LOAD_GAP)
            for place, text, align in tags:                            # a value of the load under the who
                x = start + per_metre * place
                wide_ = width(text, panels.TAG)
                a = x if align == "left" else x - wide_ if align == "right" else x - wide_ / 2
                if a < span[1] and a + wide_ > span[0]:
                    over = max(over, WHO_CLEAR + TAG_HIGH + TAG_GAP + scale * tag_load(place) + LOAD_GAP)
        return over

    def laid_out(start, scale, pitch):
        per_metre = max((right - start) / beam.LENGTH, 1e-3)
        line = line_at(start, scale, per_metre)
        room = high - line - GROUND_CLEAR - RAIL_GAP - DIM_FIRST - (d - 1) * pitch - DIM_HALF - HERO_FOOT - extra
        return per_metre, line, room

    def preferred(found):
        """The longest beam whose springs keep ROOM_WANT, then the most room up to ROOM_MOST (to the pixel), then the
        largest load and pitch; else the most room."""
        per_metre, _, room, _, scale, pitch = found
        if room >= ROOM_WANT - 1e-9:
            return (True, round(per_metre, 6), round(min(room, ROOM_MOST)), scale, pitch)
        return (False, round(room, 6), round(per_metre, 6), scale, pitch)
    starts = [*np.arange(HERO_PAD, max(after, HERO_PAD), START_STEP), max(after, HERO_PAD)]
    best = max(((*laid_out(float(start), scale, pitch), float(start), scale, pitch) for start in starts for scale in LOAD_SCALES
                for pitch in PITCHES), key=preferred)
    per_metre, line, room, left, scale, pitch = best
    room = max(min(room, ROOM_MOST), 1.0)
    ground = line + room + GROUND_CLEAR
    rail = ground + RAIL_GAP + extra
    dims = tuple(rail + DIM_FIRST + k * pitch for k in range(d))
    named = tuple(inputs) if inputs else tuple(range(d))              # the inputs of the places: their symbols
    geometry = Sketch(ax, left, per_metre, line, 0.0, ground, column, (panels.TITLE_DROP,),
                      tuple((low + up) / 2 for low, up in bounds), (0,), (), LARGEST, (None, (), ()), room, True, rail,
                      dims, tuple((float(low), float(up)) for low, up in bounds),
                      tuple("x" + panels.subscript(k + 1) for k in named), tuple(inputs),
                      tuple((float(low), float(up)) for low, up in sizes), tuple(sized), aligned)
    draw_load(geometry, scale, panels.TAG)
    ends = geometry.at((0.0, beam.LENGTH))
    ax.plot(ends, [line, line], color=STRUCTURE, linewidth=HERO_BEAM, solid_capstyle="round", zorder=3)
    half, tall, foot, base = HERO_SUPPORT
    for x in ends:
        ax.add_patch(Polygon([(x, line), (x - half, line + tall), (x + half, line + tall)], closed=True, facecolor=panels.CARD_TONE,
                             edgecolor=QUIET, linewidth=0.9, zorder=5))
    ax.add_collection(LineCollection([[(x - base, line + foot), (x + base, line + foot)] for x in ends], colors=QUIET,
                                     linewidths=0.9, zorder=5))
    ax.plot([ends[0], ends[0]], [line + foot + 3.0, dims[-1] + DIM_TICK], color=QUIET, linewidth=THIN, alpha=0.6, zorder=2)
    rails, ticks, owners = [], [], []
    for k, (low, up) in enumerate(bounds):
        a, b = float(geometry.at(low)), float(geometry.at(up))
        rails.append([(a + 3.0, rail), (b - 3.0, rail)])
        owners.append(k)
        ticks += [[(a + 1.0, rail - RAIL_TICK), (a + 1.0, rail + RAIL_TICK)], [(b - 1.0, rail - RAIL_TICK), (b - 1.0, rail + RAIL_TICK)]]
    bars = ax.add_collection(LineCollection(rails, colors=[panels.tint(QUIET, RAIL_ALPHA)] * len(rails), linewidths=RAIL_WIDTH,
                                            capstyle="round", zorder=2))
    ax.add_collection(LineCollection(ticks, colors=QUIET, linewidths=THIN, zorder=2))
    sketch = replace(geometry, ranges=(bars, tuple(owners), ()))
    paint(sketch, sketch.placed(pair))
    return sketch

def hero_focus(sketch, places=None, who="", pair=None, simulated=True, labels=(), areas=(), named=(), lit=None):
    """The band's design in focus, by its GEOMETRY only (the owner's 1A): its cross-beams as springs at `places` (m,
    one per cross-beam), the beam straight, SOLID in the designs' colour for a simulated design, DASHED in the light ink
    for the place under the pointer (`simulated` False: nobody simulated it); its places on the rails and a dimension
    line per input from the left support with its label (`labels`: "x₁ = 3.68 m"); and who it is on the band's title
    line (`who`, the caller's words: "best design · design 20 of 50", "under the pointer: not simulated"; where hero put
    its column, Sketch.aligned), quiet. No deflected
    shape, no dot, no value, no readout: the band never shows a number of a simulation (y lives in step 1's table and
    the scoreboard). With no places (None), the empty state: the cross-beams at the middle of their ranges in the
    structure's ink, the dimension lines named by their symbols, the title alone. On a bench of more than two inputs the
    pair on the figure's axes in the light ink (the accent for a simulated design), the inputs held quiet. On a bench
    whose cross-beams are sized (Sketch.sizes): each cross-beam's square section under its spring (sections: `areas`,
    cm², of the design or of the place; `named`, their names, "A₁ = 225 cm²"; at the middle of their ranges in the empty
    state). `lit`: the cross-beam the pointer is on in the band (its index; live.Pointing.lit_beam), its spring and its
    section in LIT, heavier: the band answers the pointer (benches 2 to 4); None, as always. Returns the artists added."""
    ax, line = sketch.ax, sketch.beam
    places_pair = sketch.placed(pair)
    paint(sketch, places_pair)
    drawn = []
    if places is None:
        places, ink, dashed = list(sketch.places), STRUCTURE, False
    else:
        places, ink, dashed = [float(x) for x in places], (FOCUS if simulated else LIGHT), not simulated
    half, turns, ground_half, thick = HERO_SPRING
    drawn += springs(sketch, places, [line] * len(places), ink, places_pair, dashed, half, turns, ground_half, thick,
                     grounded=not sketch.sizes, lit=lit)
    if sketch.sizes:                                                  # each cross-beam's square section under its spring
        sizes = list(areas) if areas else [(low + up) / 2 for low, up in sketch.sizes]
        names = named or tuple("x" + panels.subscript(k + 1) for k in sketch.sized)
        inks = [ink if pair is None or k in pair else QUIET for k in sketch.sized]
        drawn += sections(sketch, spread([float(sketch.at(place)) for place in places], half), sizes, inks, names, dashed, lit)
    drawn += dimensions(sketch, places, labels or sketch.beside, places_pair)
    if who:
        said = f"· {who}" if sketch.aligned == "left" else who      # a separator only after the title, never alone
        drawn.append(ax.text(sketch.column, sketch.rows[0], said, ha=sketch.aligned, va="baseline", **WHO))
    return drawn

def dimensions(sketch, places, labels, pair=None):
    """Each input's place on its rail (a dot) and its dimension line from the left support to the cross-beam, a tick
    at its end, a leader from the rail down to it, its label on the line (left of the tick where it holds, else after
    it): the inputs on the figure's axes (all of them on a bench of two) in the light ink, the inputs held quiet."""
    ax = sketch.ax
    start = float(sketch.at(0.0))
    drawn = []
    groups = {True: ([], []), False: ([], [])}
    for k, x in enumerate(places):
        mine = pair is None or k in pair
        across, level = float(sketch.at(x)), sketch.dims[k]
        segments, dots = groups[mine]
        segments += [[(across, sketch.rail + RAIL_TICK), (across, level + DIM_TICK)], [(start, level), (across, level)],
                     [(across, level - DIM_TICK), (across, level + DIM_TICK)]]
        dots.append(across)
        text = labels[k]
        left = across - DIM_OFF - width(text, panels.TAG) >= start + HERO_SLACK
        drawn.append(ax.text(across - DIM_OFF if left else across + DIM_OFF, level, text, ha="right" if left else "left", va="center",
                             color=panels.LEGEND_INK if mine else QUIET, zorder=6, bbox=LABEL_BOX, **panels.TAG))
    for mine, (segments, dots) in groups.items():
        if not dots:
            continue
        ink = LIGHT if mine else QUIET
        drawn.append(ax.add_collection(LineCollection(segments, colors=panels.tint(ink, 0.7), linewidths=THIN, zorder=4)))
        drawn += ax.plot(dots, [sketch.rail] * len(dots), linestyle="none", marker="o", markersize=RAIL_DOT, markerfacecolor=ink,
                         markeredgecolor=panels.CARD_TONE, markeredgewidth=1.2, zorder=6)
    return drawn

# A bench whose cross-beams are SIZED (bench 4): the compact caption's fourth line is the design's check (light, or the
# failed colour); the band shows no check (its geometry only: the check is the column's card's, explorers/crossbeams.py)
FAILED = palette.RED          # a check that fails: said in words ("infeasible") and in the red of what is wrong
CHECK_ROW = 3                 # the row of the check in the compact caption's column

def check_roles(roles: tuple, failed: bool) -> tuple:
    """The roles of a sized bench's compact lines: the fourth the check (a legend's light ink, not the note's muted
    one), or, where the design fails its check, the check in the failed colour."""
    check = roles[CHECK_ROW] | {"color": FAILED if failed else panels.LEGEND_INK}
    return roles[:CHECK_ROW] + (check,) + roles[CHECK_ROW + 1:]

# ------------------------------------------------------------------------------
# The cross-beams' sections (bench 4: the areas of their solid square sections are inputs of the design)
# ------------------------------------------------------------------------------
SECTION_SCALE = 0.12          # layout pixels per mm of a section's side, one scale for every section of every design (its
                              # own: the sections compare with each other, the beam's length is drawn at its own scale):
                              # the largest of [175, 350] cm², a = 187 mm (beam.side), is 22.4 pixels a side, about the
                              # room the band always kept under the springs; the smallest, a = 132 mm, 15.9
SECTION_CLEAR = 3.0           # from the largest section's foot to the rails (layout pixels)
SECTION_GAP = 5.0             # from a section to its name
SECTION_OUTLINE = (0, (1.5, 1.5))     # the outline of the range's largest section, dotted in the quiet ink
SECTION_FILL = 0.45           # a section's fill: its ink at this share over the card

def section_room(sizes) -> float:
    """What the cross-beams' sections take under the grounds, over the rails (layout pixels): the largest section of
    their ranges (areas, cm², drawn as squares: beam.side) and SECTION_CLEAR, from the springs' foot; nothing where the
    cross-beams have no size (benches 2, 3)."""
    if not sizes:
        return 0.0
    return float(beam.side(max(up for _, up in sizes))) * SECTION_SCALE - SPRING_END + SECTION_CLEAR

def sections(sketch, across, areas, inks, names, dashed=False, lit=None) -> list:
    """Each cross-beam's SQUARE section seen end-on (the cross-beam runs across the page), to SECTION_SCALE, under its
    spring's foot at `across` (layout pixels): a square of side a = sqrt(A) (`areas`, cm²: beam.side) filled in a tint of
    its ink (`inks`: the accent, the light ink of the place under the pointer, the structure's ink, or quiet for an
    input held), dashed for a place nobody simulated, inside the dotted outline of its range's largest section, and its
    name beside it (`names`: "A₁ = 225 cm²"), the first cross-beam's at its left, the others' at their right (x₁ < x₂:
    two names never meet); `lit`, the cross-beam under the pointer, in LIT with an edge LIT_WIDTH heavier. Returns the
    artists added."""
    ax = sketch.ax
    top = sketch.ground - SPRING_END
    drawn = []
    for k, (x, area, ink, name, (_, most)) in enumerate(zip(across, areas, inks, names, sketch.sizes, strict=True)):
        largest = float(beam.side(most)) * SECTION_SCALE
        side = float(beam.side(area)) * SECTION_SCALE
        ink, edge = (LIT, LIT_WIDTH) if k == lit else (ink, 1.0)
        drawn.append(ax.add_patch(Rectangle((x - largest / 2, top), largest, largest, facecolor="none", edgecolor=QUIET,
                                            linewidth=0.6, linestyle=SECTION_OUTLINE, zorder=4)))
        drawn.append(ax.add_patch(Rectangle((x - side / 2, top), side, side, facecolor=panels.tint(ink, SECTION_FILL), edgecolor=ink,
                                            linewidth=edge, linestyle=(0, (2.0, 1.4)) if dashed else "solid", zorder=5)))
        left = k == 0
        drawn.append(ax.text(x - largest / 2 - SECTION_GAP if left else x + largest / 2 + SECTION_GAP, top + largest / 2, name,
                             ha="right" if left else "left", va="center", color=panels.LEGEND_INK if ink != QUIET else QUIET,
                             zorder=6, bbox=LABEL_BOX, **panels.TAG))
    return drawn
