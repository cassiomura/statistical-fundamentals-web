# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                              Title: base.py
# ==============================================================================
"""
What every laboratory (explorers/lab.py) is made of, without Qt: the Control a reader moves, the look of its axes, the
mouse's nearest point, and the way its numbers are written.

Colours keep their meaning (palette.py): blue a design point, yellow what is being computed now, teal what is right,
red what is wrong, gold an excess.
"""
import re
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np

from statistical_fundamentals.palette import BACKGROUND, DARK_GREY, GREY

HIT_RADIUS = 11              # pixels: how close the mouse must come to a point to choose it

@dataclass(frozen=True)
class Control:
    """One value the reader chooses: a slider over `values`, buttons when `names` are given, a check box (values
    (False, True)) when `check`, or a number field when `typed` (a number one knows is typed, a quantity one explores
    is dragged: the field takes any of `values`, a number past them is clamped to the nearest end; `empty`: it may also
    hold no number, None, until one is typed). A lab
    (explorers/lab.py) may also offer shortcut values (quick picks beside the field, or before a small slider), or show
    a control only for some settings (`visible`)."""
    key: str
    label: str
    values: tuple
    initial: int                                    # the index of its value in the lab's initial state
    show: Callable[[Any], str] = str                # the text beside the slider for a value
    names: tuple[str, ...] | None = None            # buttons, one per value
    shortcuts: tuple = ()                           # the values offered first, as buttons; the slider is then small
    visible: Callable[[dict], bool] | None = None   # None: always shown
    check: bool = False
    tip: str = ""
    alone: bool = False                             # a lab's control on a line of its own (modes, above their controls)
    typed: bool = False                             # a number one knows (N): a field one types in, its shortcuts beside it
    symbol: str = ""                                # a typed control: its symbol before the field ("N")
    empty: bool = False                             # a typed control that may hold no number yet (its setting None: a
                                                    # student's N): the field then shows a placeholder, and an empty field
                                                    # commits None

    @property
    def buttons(self) -> bool:
        return self.names is not None

# ------------------------------------------------------------------------------
# Drawing helpers
# ------------------------------------------------------------------------------
def style_axes(ax, labels: bool = True) -> None:
    """manim's look: dark background, no box, grey ticks."""
    ax.set_facecolor(BACKGROUND)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(DARK_GREY)
    ax.tick_params(colors=GREY, labelsize=9, length=3)
    if not labels:
        ax.set_xticks([])
        ax.set_yticks([])
        ax.spines["left"].set_visible(False)
        ax.spines["bottom"].set_visible(False)

def nearest(ax, points, event, radius: float = HIT_RADIUS) -> int | None:
    """The index of the point (in data coordinates) within `radius` pixels of the mouse, the closest one."""
    if event is None or event.inaxes is not ax or len(points) == 0:
        return None
    xy = ax.transData.transform(np.asarray(points, dtype=float))
    distance = np.hypot(xy[:, 0] - event.x, xy[:, 1] - event.y)
    distance[~np.isfinite(distance)] = np.inf
    i = int(np.argmin(distance))
    return i if distance[i] <= radius else None

# ------------------------------------------------------------------------------
# Numbers as the laboratories write them
# ------------------------------------------------------------------------------
def sci(value: float, digits: int = 3) -> str:
    """An error: 1.234e-05 written 1.234 × 10⁻⁵ (rich text)."""
    if value == 0:
        return "0"
    if not np.isfinite(value):
        return "∞" if value > 0 else ("−∞" if value < 0 else "nan")
    mantissa, exponent = f"{value:.{digits}e}".split("e")
    exponent = int(exponent)
    if -3 <= exponent <= 3:
        return f"{value:.{max(digits - exponent, 1)}f}".replace("-", "−")
    return f"{mantissa.replace('-', '−')} × 10<sup>{str(exponent).replace('-', '−')}</sup>"

def short(value: float, digits: int = 4) -> str:
    """A value in a few significant digits, with a minus sign."""
    return f"{value:.{digits}g}".replace("-", "−")

def number(value: float, digits: int = 10) -> str:
    """A value: plain decimals with a minus sign, or scientific when very large or small."""
    if value != 0 and (abs(value) >= 1e7 or abs(value) < 1e-4):
        return sci(value, 6)
    return f"{value:.{digits}f}".replace("-", "−")

def minus(text: str) -> str:
    """A hyphen before a number becomes a minus sign; hyphens inside words stay (Gauss-Seidel, Runge-Kutta)."""
    return re.sub(r"(?<![\w.])-(?=[\d.])", "−", text)
