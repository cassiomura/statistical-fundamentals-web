# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: responses.py
# ==============================================================================
"""
The formula of each response y = f(x1, x2) of functions.RESPONSES, the same table for the three steps of a bench, as a
paper sets it: matplotlib mathtext with real fractions (\\dfrac) and the constants inline, in the notation of the
literature (Dixon & Szego 1978 for Branin's constants, those of functions.branin). Each formula is kept as its top-level
terms, joined by " + ": the figure draws it in the block the shared plan keeps over the 3D view (panels.typeset), on
one line or broken in two at one of those "+". The design space is not part of it: it is on the plane's axes and in
step 1's card of the problem. tests/test_labs.py turns each formula back into Python and checks it against
functions.RESPONSES, at every break.
"""
FORMULAS = {                          # the top-level terms of each formula, mathtext without the dollars, joined by " + "
    "branin": (r"f(x_1, x_2) = \left(x_2 - \dfrac{5.1}{4\pi^2}\,x_1^2 + \dfrac{5}{\pi}\,x_1 - 6\right)^2",
               r"10\,\left(1 - \dfrac{1}{8\pi}\right)\cos\,x_1",
               r"10"),
    "himmelblau": (r"f(x_1, x_2) = (x_1^2 + x_2 - 11)^2",
                   r"(x_1 + x_2^2 - 7)^2"),
    "rosenbrock": (r"f(x_1, x_2) = (1 - x_1)^2",
                   r"100\,(x_2 - x_1^2)^2"),
}

def formula(function: str) -> tuple[tuple[str, ...], str]:
    """The formula of a response on one line of mathtext, and no plain line (Lab.formula's form for the key BENCH)."""
    return ("$" + " + ".join(FORMULAS[function]) + "$",), ""
