# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: responses.py
# ==============================================================================
"""
What the reader is told of each response y = f(x1, ..., xd) of functions.RESPONSES, the same for the three steps of a
bench: its title, its facts and its formula.

The title (title): the bench's name in the language chosen, the CONCEPT the bench adds to the one before, as the owner
decided on 2026-11-22 ("bench.<key>.title": "Test function", "Engineering case", "Multidimensional", "Multi-objective",
and their Portuguese in the other catalog); the name of benches.TITLES only where a catalog has none. Every reader of
a bench's title asks here (the cover, the bar, the line of a bench complete, the web's bridge), never Bench.title, so
that the title follows a change of language.

The facts (facts): the line the cover writes under a title, the same three counts for every bench so that reading down
the cards shows what changes ("2 inputs · 1 objective"; "4 inputs · 2 objectives · 2 constraints"). Each number is
counted from the response (its inputs, the roles of its outputs), never typed in a text.

The formula (FORMULAS), as a paper sets it: matplotlib mathtext with real fractions (\\dfrac) and the constants inline,
in the notation of the literature (Dixon & Szego 1978 for Branin's constants, those of functions.branin). Each formula
is kept as its top-level terms, joined by " + ": the figure draws it as the caption of the 3D view's card
(panels.typeset), on one line or broken in two at one of those "+". The design space is not part of it: it is on the
plane's axes and in step 1's card of the problem. tests/test_labs.py turns each formula back into Python and checks it
against functions.RESPONSES, at every break. A response that is a simulation has no formula (the beams: their solution
is analytical, but it is not a line a caption can hold, and the student is not shown it): it has no entry in FORMULAS,
terms gives (), formula no line, and the caption of its 3D view is the drawing of its problem instead
(explorers/caption.py, explorers/sketch.py). has_formula tells the two kinds apart (the caption, its height in the plan,
the card of step 1, and step 3's foot, which says how f* is known).
"""
from statistical_fundamentals.benches import TITLES
from statistical_fundamentals.explorers import outputs
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.i18n import DEFAULT_LANGUAGE, get_text, has_text

FACTS_BETWEEN = " · "               # between two facts of a bench, on the cover

FORMULAS = {                          # the top-level terms of each formula, mathtext without the dollars, joined by " + "
    "branin": (r"f(x_1, x_2) = \left(x_2 - \dfrac{5.1}{4\pi^2}\,x_1^2 + \dfrac{5}{\pi}\,x_1 - 6\right)^2",
               r"10\,\left(1 - \dfrac{1}{8\pi}\right)\cos\,x_1",
               r"10"),
}

def title(function: str) -> str:
    """The bench's title in the language chosen: its catalogs' "bench.<key>.title" where they have one (the language
    chosen, then English), else the name of benches.TITLES; a key no catalog has is never asked for."""
    key = f"bench.{function}.title"
    return get_text(key) if has_text(key, DEFAULT_LANGUAGE) else TITLES[function]

def facts(function: str) -> str:
    """What the cover writes under a bench's title: how many inputs, objectives and (where it has them) constraints,
    each counted from the response and said in the singular or the plural ("2 inputs · 1 objective")."""
    counted = (("inputs", RESPONSES[function].d), ("objectives", len(outputs.objectives(function))),
               ("constraints", len(outputs.constraints(function))))
    return FACTS_BETWEEN.join(get_text(f"bench.facts.{name}.{'one' if n == 1 else 'many'}", n=n) for name, n in counted if n)

def has_formula(function: str) -> bool:
    """Whether the response has a formula (a test function); a simulation (the beam) has none."""
    return function in FORMULAS

def terms(function: str) -> tuple[str, ...]:
    """The top-level terms of the response's formula, () for a response without one."""
    return FORMULAS.get(function, ())

def formula(function: str) -> tuple[tuple[str, ...], str]:
    """The formula of a response on one line of mathtext, and no plain line (Lab.formula's form for the key BENCH); no
    line for a response without a formula."""
    return (("$" + " + ".join(FORMULAS[function]) + "$",) if has_formula(function) else ()), ""
