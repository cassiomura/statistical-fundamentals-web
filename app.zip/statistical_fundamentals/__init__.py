# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: __init__.py
# ==============================================================================
"""Statistical Fundamentals: the statistics behind a design optimization study, as an interactive laboratory with
every method written by hand. It begins with the design of experiments."""
__version__ = "0.2.0"
