# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: cover.py
# ==============================================================================
"""
The pictures of the cover, the page the window opens on: one drawing per bench, the design space of its response as
the study begins. Each is computed here by the functions the application runs (nothing is sketched by hand) and
described as plain marks in the unit square, the design space's own coordinates: gui/cover.py paints them. No Qt here.
A bench of more than two inputs (the beam on four cross-beams) is pictured as its step 1 opens: the pair x1 across and
x2 up (explorers/section.py, section.first), on the slice step 1 shows while nothing is pinned, for a teacher through
the best design of the first experiment (doe.through), for a student through the middle of the ranges; its level lines
are that slice's, every mark the projection of its point on the pair.

    a few level lines of the response (marching squares), the frame of the design space, its global minima as rings
    (a reference a study never has: known only because f is a formula; the window draws the lines and the rings of a
    simulation only once its bench is passed, shows_truth, and a student's picture of it before then is the beam's
    geometry, schematic), and, for a teacher, the laboratory's first
    design of experiments on it (explorers.doe.first_experiment: the bench's own N designs, doe.FIRST_POINTS, where a
    teacher's study simulates first); a student's picture has no designs, since their number is the student's to choose

A bench of SEVERAL responses (two objectives and constraints: bench 4, the beam sized) has no single response to draw
level lines of: its picture is its OBJECTIVE SPACE as the study begins (objective_picture), in the window its
laboratories draw it in: for a teacher the first experiment's FEASIBLE designs at their simulated objectives (small
filled dots; no hollow ring, which is f's minimum on the other cards, and none beyond the window, which the laboratories
count at its edge), and the TRUE front as the reference (a line where the other cards ring f's minima); for a student
the front alone.

A mark has a role, which the cover paints with one colour everywhere: the reference (the minima of the true response;
the true front of a bench of several responses),
the answer (the designs of the experiment), a second object beside it, an auxiliary construction (the level lines) and
an axis (the frame of the design space is its two axes and their opposite sides).

The level lines are found by marching squares (level_lines) on a GRID x GRID grid of the unit square: every vertex of a
line is a crossing of the level on an edge of the grid, at the point a straight line between the response's values at
the two ends of the edge reaches it. Their levels are the response's own: the values below which LEVEL_SHARES of the
grid lie, the same shares for every bench, so that each picture shows its response's basins and valleys at the same
depths whatever the scale of its values (Branin's reach 300, the beams' a few millimetres).
"""
import math
from dataclasses import dataclass
from functools import cache

import numpy as np

from statistical_fundamentals import beam
from statistical_fundamentals.benches import BENCHES
from statistical_fundamentals.explorers import caption, game, objectives, outputs, section
from statistical_fundamentals.explorers.doe import first_experiment, simulated, through
from statistical_fundamentals.explorers.responses import has_formula
from statistical_fundamentals.explorers.section import Section
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.sampling import scaled

REFERENCE, ANSWER, SECOND, GUIDE, AXIS = "reference", "answer", "second", "guide", "axis"
LINE, AREA, DOTS = "line", "area", "dots"
MARGIN = 0.05                   # shown around the unit square: a design drawn on its edge stays whole
GRID = 81                       # the nodes of the grid on each axis, where the level lines are found
LEVEL_SHARES = (0.04, 0.12, 0.28, 0.52)        # of the grid below each level line: the deepest basins first
RING, RING_STEPS = 0.06, 48     # a minimum's ring: its radius in the unit square (wider than a dot, which it leaves in sight), its sides
SCHEMATIC_SIDE, SCHEMATIC_BEAM = 0.06, 0.72    # a beam's schematic (schematic): its ends' inset, the beam's height
SCHEMATIC_FOOT = 0.035          # half a support's base, and half its height
SCHEMATIC_DROP, SCHEMATIC_PITCH = 0.22, 0.1    # from the beam to the first rail, and from a rail to the next

@dataclass(frozen=True)
class Mark:
    kind: str                                   # LINE (a polyline), AREA (a filled polygon) or DOTS
    points: tuple[tuple[float, float], ...]     # in the coordinates of the problem
    role: str
    dashed: bool = False                        # a line
    hollow: bool = False                        # dots: a ring, where a value is taken; filled, where an answer is
    small: bool = False                         # dots: smaller (many designs in a small window: bench 4's objective space)

@dataclass(frozen=True)
class Picture:
    window: tuple[float, float, float, float]   # x from, x to, y from, y to: what the drawing shows
    marks: tuple[Mark, ...]                     # in the order they are painted
    equal: bool = False                         # one unit of x drawn as long as one of y: a design space keeps its shape

def line(points, role: str, dashed: bool = False) -> Mark:
    return Mark(LINE, tuple((float(x), float(y)) for x, y in points), role, dashed=dashed)

def dots(points, role: str, hollow: bool = False, small: bool = False) -> Mark:
    return Mark(DOTS, tuple((float(x), float(y)) for x, y in points), role, hollow=hollow, small=small)

def area(points, role: str) -> Mark:
    return Mark(AREA, tuple((float(x), float(y)) for x, y in points), role)

# ------------------------------------------------------------------------------
# The level lines
# ------------------------------------------------------------------------------
def sampled(key: str, n: int, cut: Section | None = None) -> list[list[float]]:
    """A response on an n x n grid of the unit square: values[a][b] is y at u = (a / (n - 1), b / (n - 1)), the design
    mapped to the bounds of the response by the sampling's own core, and the response called once on the whole grid
    (a response works on NumPy arrays: the beam's simulation, called point by point, would take a second). For a bench
    of more than two inputs, the unit square is the slice `cut` (its pair, the other inputs held at its values: lift)."""
    response = RESPONSES[key]
    cut = Section(response.d) if cut is None else cut
    designs = scaled([list(cut.lift(a / (n - 1), b / (n - 1))) for a in range(n) for b in range(n)], response.bounds)
    y = response.f(*(np.array([x[k] for x in designs]) for k in range(response.d)))
    return [[float(value) for value in y[a * n:(a + 1) * n]] for a in range(n)]

def levels(values: list[list[float]], shares=LEVEL_SHARES) -> tuple[float, ...]:
    """The values below which each share of the grid lies: the k-th smallest of its nodes, k = share x their number."""
    ranked = sorted(value for row in values for value in row)
    return tuple(ranked[min(int(share * len(ranked)), len(ranked) - 1)] for share in shares)

def level_lines(values: list[list[float]], level: float) -> list[list[tuple[float, float]]]:
    """The lines where the response sampled on a grid of the unit square (sampled) equals `level`, by marching squares.
    A cell of the grid is crossed where its corners lie on both sides of the level: on each of its edges whose two ends
    do, at the point a straight line between their values reaches the level. A cell crossed on two edges holds one piece
    of line; a cell crossed on all four (a saddle: the corners alternate) holds two, and the mean of its corners says
    which corners they cut off. Neighbouring cells share their crossings, so the pieces chain into polylines: open ones
    that end on the border of the grid, and closed ones, whose first point is also their last."""
    n = len(values)

    def below(a, b):
        return values[a][b] < level

    def crossing(edge):
        """The point of the level on an edge: ("x", a, b) joins the nodes (a, b) and (a + 1, b), ("y", a, b) the nodes
        (a, b) and (a, b + 1)."""
        kind, a, b = edge
        c, d = (a + 1, b) if kind == "x" else (a, b + 1)
        t = (level - values[a][b]) / (values[c][d] - values[a][b])
        return ((a + t * (c - a)) / (n - 1), (b + t * (d - b)) / (n - 1))

    pieces = []
    for a in range(n - 1):
        for b in range(n - 1):
            corners = ((a, b), (a + 1, b), (a + 1, b + 1), (a, b + 1))
            edges = (("x", a, b), ("y", a + 1, b), ("x", a, b + 1), ("y", a, b))       # edge k joins corners k and k + 1
            crossed = [edges[k] for k in range(4) if below(*corners[k]) != below(*corners[(k + 1) % 4])]
            if len(crossed) == 2:
                pieces.append((crossed[0], crossed[1]))
            elif len(crossed) == 4:
                centre_below = sum(values[i][j] for i, j in corners) / 4 < level
                if centre_below == below(a, b):                     # corners 0 and 2 joined through the centre: 1 and 3 cut off
                    pieces += [(edges[0], edges[1]), (edges[2], edges[3])]
                else:                                               # corners 1 and 3 joined: 0 and 2 cut off
                    pieces += [(edges[3], edges[0]), (edges[1], edges[2])]

    touching = {}                                                   # the pieces through each crossing: one or two
    for index, piece in enumerate(pieces):
        for edge in piece:
            touching.setdefault(edge, []).append(index)
    used = [False] * len(pieces)

    def walk(edge):
        """The crossings beyond `edge`, piece after piece, until the line closes or leaves the grid."""
        path = []
        while True:
            following = [index for index in touching[edge] if not used[index]]
            if not following:
                return path
            used[following[0]] = True
            first, second = pieces[following[0]]
            edge = second if first == edge else first
            path.append(edge)

    lines = []
    for index, (first, second) in enumerate(pieces):
        if not used[index]:
            used[index] = True
            forward = walk(second)
            chain = walk(first)[::-1] + [first, second] + forward
            lines.append([crossing(edge) for edge in chain])
    return lines

def ring(centre: tuple[float, float]) -> Mark:
    """A circle of radius RING around a point of the unit square, as a closed line: it marks the point and leaves in
    sight a dot drawn on it (a ring of the dots would hide it)."""
    x, y = centre
    return line([(x + RING * math.cos(2 * math.pi * k / RING_STEPS), y + RING * math.sin(2 * math.pi * k / RING_STEPS))
                 for k in range(RING_STEPS + 1)], REFERENCE)

def unit(key: str, point: tuple[float, ...], cut: Section | None = None) -> tuple[float, float]:
    """A point of a response's design space in the unit square: the inverse of the sampling's scaled; for a bench of
    more than two inputs, its projection on the pair of the slice `cut` (default x1 and x2)."""
    response = RESPONSES[key]
    return (Section(response.d) if cut is None else cut).project(section.unit(response.bounds, point))

def opening(key: str, designs: bool) -> Section:
    """The slice step 1 opens on (section.first: x1 across, x2 up, nothing pinned): a teacher's through the best design
    of the first experiment (doe.through), a student's through the middle of the ranges; the whole design space for two
    inputs."""
    if RESPONSES[key].d == 2:
        return Section(2)
    auto = through(simulated(first_experiment(key))) if designs else None
    return section.of(key, section.first(key), auto)

# ------------------------------------------------------------------------------
# One picture per bench (the keys of benches.BENCHES)
# ------------------------------------------------------------------------------
@cache
def bench_picture(key: str, designs: bool = True, truth: bool = True) -> Picture:
    """The design space of a bench as its study begins: with `truth` the level lines of its response at LEVEL_SHARES
    (guides), the frame, with `designs` the designs of the laboratory's first experiment (the answer: where a teacher's
    study simulates first, placed without looking at f; a student's picture leaves them out, since it would tell how
    many to take) and, with `truth`, its global minima (rings: the reference), painted last so that no design hides one.
    Without `truth` (a simulation not yet revealed: the frame and the designs alone) nothing of f is drawn. For a bench
    of more than two inputs, the slice step 1 opens on (opening), each design and minimum at its projection. Computed
    once (frozen marks)."""
    if not truth and not designs:                                   # nothing of f, no design: the problem's geometry
        return Picture((-MARGIN, 1.0 + MARGIN, -MARGIN, 1.0 + MARGIN), schematic(key), equal=True)
    cut = opening(key, designs)
    guides, minima = [], []
    if truth:
        values = sampled(key, GRID, cut)
        guides = [line(points, GUIDE) for level in levels(values) for points in level_lines(values, level)]
        minima = [ring(unit(key, point, cut)) for point in RESPONSES[key].minima]
    frame = line([(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0)], AXIS)
    answer = [dots([cut.project(u) for u in simulated(first_experiment(key)).unit], ANSWER)] if designs else []
    return Picture((-MARGIN, 1.0 + MARGIN, -MARGIN, 1.0 + MARGIN), (*guides, frame, *answer, *minima), equal=True)

@cache
def objective_picture(key: str, designs: bool = True, truth: bool = True) -> Picture:
    """The objective space of a bench of several responses as its study begins (bench 4: the mass across, the RMS
    deflection up), in the window its laboratories draw it in (explorers/objectives.window, mapped to the unit square):
    with `designs` the FEASIBLE designs of the laboratory's first experiment at their simulated objectives (the answer:
    small filled dots; an infeasible design is left out, as is one beyond the window: the laboratories ring the one and
    count the other at its edge, which a picture of this size cannot say) and the TRUE front (the reference: the
    bench's stored designs, game.front, a line a real study never has, as the rings of f's minima are on the other
    cards), painted last so that no design hides it. A student's picture has the
    front alone. Without `truth` (the bench not yet passed: a real study never knows its front) the front is left out
    and the window's two axes stand in its place (the mass across, the deflection up). Computed once (frozen marks)."""
    shown = objectives.window(key)
    (x0, x1), (y0, y1) = shown.across, shown.up

    def placed(point) -> tuple[float, float]:
        x, y, _side = shown.placed(point)
        return (x - x0) / (x1 - x0), (y - y0) / (y1 - y0)
    answer = []
    if designs:
        rows = outputs.rows(simulated(first_experiment(key)).outputs)
        inside = [outputs.objective_values(key, row) for row in rows
                  if outputs.feasible(key, row) and shown.placed(outputs.objective_values(key, row))[2] is None]
        answer = [dots([placed(point) for point in inside], ANSWER, small=True)]
    if not truth:
        if not designs:                                             # nothing of f, no design: the problem's geometry
            return Picture((-MARGIN, 1.0 + MARGIN, -MARGIN, 1.0 + MARGIN), schematic(key), equal=True)
        axes = line([(0.0, 1.0), (0.0, 0.0), (1.0, 0.0)], AXIS)
        return Picture((-MARGIN, 1.0 + MARGIN, -MARGIN, 1.0 + MARGIN), (axes, *answer), equal=True)
    front = line([placed(point) for point in sorted(game.front(key).points)], REFERENCE)
    return Picture((-MARGIN, 1.0 + MARGIN, -MARGIN, 1.0 + MARGIN), (*answer, front), equal=True)

def schematic(key: str) -> tuple[Mark, ...]:
    """The geometry of a beam's problem in the unit square, all guides (a student's picture of a simulation before its
    bench is passed: no f, no design): the main beam across (beam.LENGTH, on its two supports), and under it each
    cross-beam's range of places as a dashed rail from its bounds, each cross-beam at the middle of its range, as the
    band's empty state draws them (explorers/caption.layout: the inputs that are places)."""
    response = RESPONSES[key]
    places_ = caption.layout(key)[0]
    left, right, top = SCHEMATIC_SIDE, 1.0 - SCHEMATIC_SIDE, SCHEMATIC_BEAM

    def across(metres: float) -> float:
        return left + (right - left) * metres / beam.LENGTH
    marks = [line([(left, top), (right, top)], GUIDE)]
    for end in (left, right):
        marks.append(area([(end - SCHEMATIC_FOOT, top - 2 * SCHEMATIC_FOOT), (end + SCHEMATIC_FOOT, top - 2 * SCHEMATIC_FOOT),
                           (end, top)], GUIDE))
    for j, k in enumerate(places_):
        low, high = response.bounds[k]
        rail = top - SCHEMATIC_DROP - j * SCHEMATIC_PITCH
        marks.append(line([(across(low), rail), (across(high), rail)], GUIDE, dashed=True))
        middle = across((low + high) / 2)
        marks.append(line([(middle, top), (middle, rail)], GUIDE))
    return tuple(marks)

def any_picture(key: str, designs: bool = True, truth: bool = True) -> Picture:
    """A bench's picture: the objective space for a bench of several responses (objective_picture), else its design
    space (bench_picture)."""
    return objective_picture(key, designs, truth) if RESPONSES[key].outputs else bench_picture(key, designs, truth)

PICTURES = {key: (lambda designs=True, truth=True, key=key: any_picture(key, designs, truth)) for key in BENCHES}   # in order

def picture(bench: str, designs: bool = True, truth: bool = True) -> Picture:
    """The cover's picture of a bench: a teacher's, with the first designs (designs), or a student's, without them;
    with the true response (truth) or without it (shown: shows_truth)."""
    return PICTURES[bench](designs, truth)

def shows_truth(bench: str, passed: bool) -> bool:
    """Whether the window's cover draws a bench's true response (CLAUDE.md, the owner's 2B: on a simulation the truth
    is hidden until it is revealed): always for a test function (responses.has_formula), for a simulation once the
    bench is passed. The web's page keeps it (its labs' `revealed` is True there)."""
    return has_formula(bench) or bool(passed)
