# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: cover.py
# ==============================================================================
"""
The pictures of the cover, the page the window opens on: one drawing per bench, the design space of its response as
the study begins. Each is computed here by the functions the application runs (nothing is sketched by hand) and
described as plain marks in the unit square, the design space's own coordinates: gui/cover.py paints them. No Qt here.

    a few level lines of the response (marching squares), the frame of the design space, its global minima as rings
    (a reference a study never has: known only because f is a formula), and, for a teacher, the laboratory's first
    design of experiments on it (explorers.doe.first_experiment: the bench's own N designs, doe.FIRST_POINTS, where a
    teacher's study simulates first); a student's picture has no designs, since their number is the student's to choose

A mark has a role, which the cover paints with one colour everywhere: the reference (the minima of the true response),
the answer (the designs of the experiment), a second object beside it, an auxiliary construction (the level lines) and
an axis (the frame of the design space is its two axes and their opposite sides).

The level lines are found by marching squares (level_lines) on a GRID x GRID grid of the unit square: every vertex of a
line is a crossing of the level on an edge of the grid, at the point a straight line between the response's values at
the two ends of the edge reaches it. Their levels are the response's own: the values below which LEVEL_SHARES of the
grid lie, the same shares for every bench, so that each picture shows its response's basins and valleys at the same
depths whatever the scale of its values (Rosenbrock's reach 2500, Branin's 300).
"""
import math
from dataclasses import dataclass
from functools import cache

from statistical_fundamentals.benches import BENCHES
from statistical_fundamentals.explorers.doe import first_experiment, simulated
from statistical_fundamentals.functions import RESPONSES
from statistical_fundamentals.sampling import scaled

REFERENCE, ANSWER, SECOND, GUIDE, AXIS = "reference", "answer", "second", "guide", "axis"
LINE, AREA, DOTS = "line", "area", "dots"
MARGIN = 0.05                   # shown around the unit square: a design drawn on its edge stays whole
GRID = 81                       # the nodes of the grid on each axis, where the level lines are found
LEVEL_SHARES = (0.04, 0.12, 0.28, 0.52)        # of the grid below each level line: the deepest basins first
RING, RING_STEPS = 0.06, 48     # a minimum's ring: its radius in the unit square (wider than a dot, which it leaves in sight), its sides

@dataclass(frozen=True)
class Mark:
    kind: str                                   # LINE (a polyline), AREA (a filled polygon) or DOTS
    points: tuple[tuple[float, float], ...]     # in the coordinates of the problem
    role: str
    dashed: bool = False                        # a line
    hollow: bool = False                        # dots: a ring, where a value is taken; filled, where an answer is

@dataclass(frozen=True)
class Picture:
    window: tuple[float, float, float, float]   # x from, x to, y from, y to: what the drawing shows
    marks: tuple[Mark, ...]                     # in the order they are painted
    equal: bool = False                         # one unit of x drawn as long as one of y: a design space keeps its shape

def line(points, role: str, dashed: bool = False) -> Mark:
    return Mark(LINE, tuple((float(x), float(y)) for x, y in points), role, dashed=dashed)

def dots(points, role: str, hollow: bool = False) -> Mark:
    return Mark(DOTS, tuple((float(x), float(y)) for x, y in points), role, hollow=hollow)

def area(points, role: str) -> Mark:
    return Mark(AREA, tuple((float(x), float(y)) for x, y in points), role)

# ------------------------------------------------------------------------------
# The level lines
# ------------------------------------------------------------------------------
def sampled(key: str, n: int) -> list[list[float]]:
    """A response on an n x n grid of the unit square: values[a][b] is y at u = (a / (n - 1), b / (n - 1)), the design
    mapped to the bounds of the response by the sampling's own core."""
    response = RESPONSES[key]
    values = []
    for a in range(n):
        row = []
        for b in range(n):
            ((x1, x2),) = scaled([[a / (n - 1), b / (n - 1)]], response.bounds)
            row.append(float(response.f(x1, x2)))
        values.append(row)
    return values

def levels(values: list[list[float]], shares=LEVEL_SHARES) -> tuple[float, ...]:
    """The values below which each share of the grid lies: the k-th smallest of its nodes, k = share x their number."""
    ranked = sorted(value for row in values for value in row)
    return tuple(ranked[min(int(share * len(ranked)), len(ranked) - 1)] for share in shares)

def level_lines(values: list[list[float]], level: float) -> list[list[tuple[float, float]]]:
    """The lines where the response sampled on a grid of the unit square (sampled) equals `level`, by marching squares.
    A cell of the grid is crossed where its corners lie on both sides of the level: on each of its edges whose two ends
    do, at the point a straight line between their values reaches the level. A cell crossed on two edges holds one piece
    of line; a cell crossed on all four (a saddle: the corners alternate) holds two, and the mean of its corners says
    which corners they cut off. Neighbouring cells share their crossings, so the pieces chain into polylines: open ones
    that end on the border of the grid, and closed ones, whose first point is also their last."""
    n = len(values)

    def below(a, b):
        return values[a][b] < level

    def crossing(edge):
        """The point of the level on an edge: ("x", a, b) joins the nodes (a, b) and (a + 1, b), ("y", a, b) the nodes
        (a, b) and (a, b + 1)."""
        kind, a, b = edge
        c, d = (a + 1, b) if kind == "x" else (a, b + 1)
        t = (level - values[a][b]) / (values[c][d] - values[a][b])
        return ((a + t * (c - a)) / (n - 1), (b + t * (d - b)) / (n - 1))

    pieces = []
    for a in range(n - 1):
        for b in range(n - 1):
            corners = ((a, b), (a + 1, b), (a + 1, b + 1), (a, b + 1))
            edges = (("x", a, b), ("y", a + 1, b), ("x", a, b + 1), ("y", a, b))       # edge k joins corners k and k + 1
            crossed = [edges[k] for k in range(4) if below(*corners[k]) != below(*corners[(k + 1) % 4])]
            if len(crossed) == 2:
                pieces.append((crossed[0], crossed[1]))
            elif len(crossed) == 4:
                centre_below = sum(values[i][j] for i, j in corners) / 4 < level
                if centre_below == below(a, b):                     # corners 0 and 2 joined through the centre: 1 and 3 cut off
                    pieces += [(edges[0], edges[1]), (edges[2], edges[3])]
                else:                                               # corners 1 and 3 joined: 0 and 2 cut off
                    pieces += [(edges[3], edges[0]), (edges[1], edges[2])]

    touching = {}                                                   # the pieces through each crossing: one or two
    for index, piece in enumerate(pieces):
        for edge in piece:
            touching.setdefault(edge, []).append(index)
    used = [False] * len(pieces)

    def walk(edge):
        """The crossings beyond `edge`, piece after piece, until the line closes or leaves the grid."""
        path = []
        while True:
            following = [index for index in touching[edge] if not used[index]]
            if not following:
                return path
            used[following[0]] = True
            first, second = pieces[following[0]]
            edge = second if first == edge else first
            path.append(edge)

    lines = []
    for index, (first, second) in enumerate(pieces):
        if not used[index]:
            used[index] = True
            forward = walk(second)
            chain = walk(first)[::-1] + [first, second] + forward
            lines.append([crossing(edge) for edge in chain])
    return lines

def ring(centre: tuple[float, float]) -> Mark:
    """A circle of radius RING around a point of the unit square, as a closed line: it marks the point and leaves in
    sight a dot drawn on it (a ring of the dots would hide it)."""
    x, y = centre
    return line([(x + RING * math.cos(2 * math.pi * k / RING_STEPS), y + RING * math.sin(2 * math.pi * k / RING_STEPS))
                 for k in range(RING_STEPS + 1)], REFERENCE)

def unit(key: str, point: tuple[float, float]) -> tuple[float, float]:
    """A point of a response's design space in the unit square: the inverse of the sampling's scaled."""
    (a1, b1), (a2, b2) = RESPONSES[key].bounds
    return ((point[0] - a1) / (b1 - a1), (point[1] - a2) / (b2 - a2))

# ------------------------------------------------------------------------------
# One picture per bench (the keys of benches.BENCHES)
# ------------------------------------------------------------------------------
@cache
def bench_picture(key: str, designs: bool = True) -> Picture:
    """The design space of a bench as its study begins: the level lines of its response at LEVEL_SHARES (guides), the
    frame, with `designs` the designs of the laboratory's first experiment (the answer: where a teacher's study simulates
    first, placed without looking at f; a student's picture leaves them out, since it would tell how many to take) and
    its global minima (rings: the reference), painted last so that no design hides one. Computed once (frozen marks)."""
    values = sampled(key, GRID)
    guides = [line(points, GUIDE) for level in levels(values) for points in level_lines(values, level)]
    frame = line([(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0)], AXIS)
    minima = [ring(unit(key, point)) for point in RESPONSES[key].minima]
    answer = [dots(simulated(first_experiment(key)).unit, ANSWER)] if designs else []
    return Picture((-MARGIN, 1.0 + MARGIN, -MARGIN, 1.0 + MARGIN), (*guides, frame, *answer, *minima), equal=True)

PICTURES = {key: (lambda designs=True, key=key: bench_picture(key, designs)) for key in BENCHES}     # the benches, in order

def picture(bench: str, designs: bool = True) -> Picture:
    """The cover's picture of a bench: a teacher's, with the first designs (designs), or a student's, without them."""
    return PICTURES[bench](designs)
