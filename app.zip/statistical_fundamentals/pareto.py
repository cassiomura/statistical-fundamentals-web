# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: pareto.py
# ==============================================================================
"""
The evolutionary algorithm by non-dominance, NSGA-II, the non-dominated sorting genetic algorithm (Deb, Pratap, Agarwal &
Meyarivan 2002): the evolutionary algorithm of the first three benches (evolutionary.py) extended to m objectives to
minimize at once and to constraints. With two objectives in conflict there is no single best design: lowering one
raises the other. The answer is a set, the designs that no other design beats in every objective at once, the Pareto
front; the algorithm moves its whole population towards that set and spreads it along it, in one run.

All designs live in the unit hypercube [0, 1]^d of the d parameters, as in the single-objective algorithm. f(u) is one
simulation and returns two lists: the objectives (f_1, ..., f_m), all to be minimized, and the constraints
(c_1, ..., c_p), each met when c_j <= 0. The caller writes every constraint g_j(x) <= b_j relative to its positive limit,
c_j = g_j(x) / b_j - 1, so that each c_j is a share of its own limit, whatever its unit, and the constraints can be
added: the violation of a design is

    V(u) = sum over j of max(0, c_j(u))            V = 0: feasible

Dominance: a dominates b when a is no worse in every objective and better in at least one,

    a_i <= b_i for every i, and a_i < b_i for some i

Constrained dominance (Deb 2000, Deb et al. 2002), which needs no penalty factor: of two designs,

    a feasible one beats an infeasible one, whatever their objectives;
    of two infeasible ones, the one of the smaller violation V beats the other;
    of two feasible ones, a beats b when a dominates b.

The algorithm is the single-objective one with two things changed, who wins a tournament and who survives:

    start       mu designs, step 1's Latin hypercube in d dimensions; each one simulated
    rank        the non-dominated sort: the first front F1 is the designs that no other design beats; set aside, the
                designs no other one of the rest beats are F2; and so on. A design's rank is the number of its front
    crowding    in each front, the crowding distance of a design: for every objective, the front is sorted by it and
                the design adds the gap between its two neighbours, divided by the front's range of that objective;
                the two ends of every objective get an infinite distance (they are always kept). A large distance
                is a design in a sparse part of the front
    generation  mu children, made in pairs as in evolutionary.py:
                tournament   two designs drawn at random (with replacement); the lower rank wins, and of the same rank
                             the larger crowding distance (the crowded comparison). Done twice, it gives a pair;
                sbx          with probability CROSSOVER, the simulated binary crossover of evolutionary.py; otherwise
                             the children are copies of their parents;
                mutation     the Gaussian step of evolutionary.py, of standard deviation sigma;
                each child is simulated
    survival    the mu parents and the mu children together (2 mu designs) are sorted into fronts again; whole fronts
                are kept in order, F1, F2, ..., while they fit in mu; of the first front that does not fit, the designs
                of the largest crowding distance fill the places left (the algorithm is elitist: a design of F1 is
                lost only to another design of F1, in a less crowded place)
    sigma       the mutation step, going linearly from SIGMA_FIRST to SIGMA_LAST as in evolutionary.py

The result of a run is its final population, the mu survivors of the last generation: in the last record, the designs
whose indices "kept" gives, counted in that record's population followed by its children. Its feasible designs of
rank 1 are the approximation of the Pareto front.

A run costs mu (1 + GENERATIONS) simulations. The random numbers come from a random.Random given by the caller (a seed
makes a run reproducible). The crossover, the mutation, their constants and the schedule of sigma are evolutionary.py's
(this app's choices); NSGA-II's paper uses the same crossover with its own index and a polynomial mutation. The ranks
and crowding distances of a population are computed again at the start of each generation from its designs. A tie in
the tournament goes to the first drawn, a tie of crowding at the survival keeps the earlier design, and duplicate
designs are not removed.

Three functions serve the study around a run, for any set of designs already simulated. nondominated gives the first
front of a set of points of objectives, with no constraint (equal points are all kept). hypervolume measures the
quality of a front of two objectives: the area of the objective plane that the front dominates, bounded by a reference
point r worse than every design compared. A front closer to the true one, or spread wider along it, has a larger
hypervolume. Both objectives are minimized, and a point that is not better than r in both adds nothing and is left
out. Sorted by f_1, the area is a sum of rectangles:

    H = sum over the sorted points k of (r_1 - f_1(k)) (f_2(k-1) - f_2(k))         f_2(0) = r_2

where only the points that lower f_2 count (the others are dominated) and f_2(k-1) is the lowest f_2 before point k.

spaced chooses which designs of a front of two objectives to look at one by one (the app simulates them to check a
predicted front):

    order       the front sorted by f_1 (a tie by the order of the list)
    arc         the length s along it, from its first design, with each objective divided by the front's own range
                (a range of zero counts as 1)
    targets     count values of s evenly spaced from 0 to the whole length, both ends included (one target alone:
                half the length)
    choice      for each target in turn, the design of the nearest s not taken yet (a tie to the earlier one)

A count at least the front's size takes every design; the indices come back in the order of the sorted front.

Readable cores: plain lists and loops, shown in the window as the method's code.

References:
K. Deb, A. Pratap, S. Agarwal & T. Meyarivan, "A fast and elitist multiobjective genetic algorithm: NSGA-II", IEEE
Transactions on Evolutionary Computation 6(2), 182-197, 2002.
K. Deb, "An efficient constraint handling method for genetic algorithms", Computer Methods in Applied Mechanics and
Engineering 186(2-4), 311-338, 2000.
E. Zitzler & L. Thiele, "Multiobjective evolutionary algorithms: a comparative case study and the strength Pareto
approach", IEEE Transactions on Evolutionary Computation 3(4), 257-271, 1999.
"""
import math

from statistical_fundamentals.evolutionary import CROSSOVER, DISTRIBUTION, mutation, sbx, sigma_of
from statistical_fundamentals.sampling import latin_hypercube

GENERATIONS = 30

def violation(constraints):
    """The total violation of a design: the sum of the constraints above zero (0 when feasible)."""
    total = 0.0
    for c in constraints:
        total = total + max(0.0, c)
    return total

def dominates(a, b):
    """True when the objectives a are no worse than b in every one and better in at least one."""
    better = False
    for i in range(len(a)):
        if a[i] > b[i]:
            return False
        if a[i] < b[i]:
            better = True
    return better

def constrained_dominates(a, va, b, vb):
    """Deb's rules: feasible beats infeasible, then the smaller violation, then dominance."""
    if va == 0 and vb == 0:
        return dominates(a, b)
    if va == 0:
        return True
    if vb == 0:
        return False
    return va < vb

def nondominated_sort(objectives, violations):
    """The fronts F1, F2, ...: lists of indices; F1 the designs nobody beats, F2 those only F1 beats, ..."""
    remaining = list(range(len(objectives)))
    fronts = []
    while remaining:
        front = []
        for i in remaining:
            beaten = False
            for j in remaining:
                if constrained_dominates(objectives[j], violations[j],
                                         objectives[i], violations[i]):
                    beaten = True
                    break
            if not beaten:
                front.append(i)
        fronts.append(front)
        remaining = [i for i in remaining if i not in front]
    return fronts

def crowding_distance(objectives, front):
    """The crowding distance of every design of a front, in the front's order (the ends: inf)."""
    distance = {i: 0.0 for i in front}
    for k in range(len(objectives[front[0]])):
        order = sorted(front, key=lambda i: (objectives[i][k], i))
        low = objectives[order[0]][k]
        high = objectives[order[-1]][k]
        distance[order[0]] = math.inf
        distance[order[-1]] = math.inf
        if high == low:
            continue
        for p in range(1, len(order) - 1):
            gap = objectives[order[p + 1]][k] - objectives[order[p - 1]][k]
            distance[order[p]] = distance[order[p]] + gap / (high - low)
    return [distance[i] for i in front]

def ranked(objectives, violations):
    """The fronts, the rank of every design (1 for F1) and its crowding distance in its front."""
    fronts = nondominated_sort(objectives, violations)
    ranks = [0] * len(objectives)
    crowding = [0.0] * len(objectives)
    for r in range(len(fronts)):
        distances = crowding_distance(objectives, fronts[r])
        for i, c in zip(fronts[r], distances):
            ranks[i] = r + 1
            crowding[i] = c
    return fronts, ranks, crowding

def tournament(ranks, crowding, random):
    """The index of a parent: two drawn at random, the lower rank wins, then the larger crowding."""
    a = random.randrange(len(ranks))
    b = random.randrange(len(ranks))
    if ranks[b] < ranks[a]:
        return b
    if ranks[b] == ranks[a] and crowding[b] > crowding[a]:
        return b
    return a

def survivors(fronts, crowding, mu):
    """The mu indices kept, in increasing order: whole fronts in order, then the least crowded of the one
    that overflows."""
    kept = []
    for front in fronts:
        if len(kept) + len(front) <= mu:
            kept = kept + front
        else:
            order = sorted(front, key=lambda i: (-crowding[i], i))
            kept = kept + order[:mu - len(kept)]
            break
    return sorted(kept)

def generation(f, population, objectives, constraints, sigma, random):
    """One generation: mu children by the crowded tournament, SBX and mutation, simulated; the mu
    survivors of the 2 mu."""
    mu = len(population)
    violations = [violation(c) for c in constraints]
    fronts, ranks, crowding = ranked(objectives, violations)
    pairs = []
    crossed = []
    children = []
    while len(children) < mu:
        i = tournament(ranks, crowding, random)
        j = tournament(ranks, crowding, random)
        pairs.append((i, j))
        if random.random() < CROSSOVER:
            c1, c2 = sbx(population[i], population[j], DISTRIBUTION, random)
        else:
            c1, c2 = list(population[i]), list(population[j])
        crossed.append(c1)
        crossed.append(c2)
        children.append(mutation(c1, sigma, random))
        children.append(mutation(c2, sigma, random))
    crossed = crossed[:mu]
    children = children[:mu]
    results = [f(child) for child in children]
    children_objectives = [r[0] for r in results]
    children_constraints = [r[1] for r in results]
    pool_objectives = objectives + children_objectives
    pool_violations = violations + [violation(c) for c in children_constraints]
    pool_fronts, pool_ranks, pool_crowding = ranked(pool_objectives,
                                                    pool_violations)
    kept = survivors(pool_fronts, pool_crowding, mu)
    return {"ranks": ranks, "crowding": crowding, "pairs": pairs,
            "crossed": crossed, "children": children,
            "children_objectives": children_objectives,
            "children_constraints": children_constraints,
            "fronts": pool_fronts, "pool_crowding": pool_crowding,
            "kept": kept, "sigma": sigma}

def nsga2(f, mu, random, d=2):
    """The whole run in d parameters: the start population, then GENERATIONS generations, one
    record each (mu (1 + GENERATIONS) runs)."""
    population = latin_hypercube(mu, d, random)
    results = [f(point) for point in population]
    objectives = [r[0] for r in results]
    constraints = [r[1] for r in results]
    records = [{"population": population, "objectives": objectives,
                "constraints": constraints}]
    for k in range(GENERATIONS):
        sigma = sigma_of(k, GENERATIONS)
        record = generation(f, population, objectives, constraints, sigma, random)
        record["population"] = population
        record["objectives"] = objectives
        record["constraints"] = constraints
        records.append(record)
        pool = population + record["children"]
        pool_objectives = objectives + record["children_objectives"]
        pool_constraints = constraints + record["children_constraints"]
        population = [pool[i] for i in record["kept"]]
        objectives = [pool_objectives[i] for i in record["kept"]]
        constraints = [pool_constraints[i] for i in record["kept"]]
    return records

def nondominated(points):
    """The indices of the points that no other point dominates (equal points are all kept)."""
    front = []
    for i in range(len(points)):
        if not any(dominates(points[j], points[i]) for j in range(len(points))):
            front.append(i)
    return front

def hypervolume(points, reference):
    """The area that the points of two minimized objectives dominate, bounded by the reference."""
    inside = [p for p in points if p[0] < reference[0] and p[1] < reference[1]]
    area = 0.0
    previous = reference[1]
    for p in sorted(inside, key=lambda p: (p[0], p[1])):
        if p[1] < previous:
            area = area + (reference[0] - p[0]) * (previous - p[1])
            previous = p[1]
    return area

def spaced(objectives, count):
    """The indices of count designs evenly spaced along a front of two objectives, in its order."""
    order = sorted(range(len(objectives)), key=lambda i: (objectives[i][0], i))
    if count >= len(order):
        return order
    scale = []
    for k in range(2):
        values = [objectives[i][k] for i in order]
        width = max(values) - min(values)
        scale.append(width if width > 0 else 1.0)
    arc = [0.0]
    for p in range(1, len(order)):
        a = objectives[order[p - 1]]
        b = objectives[order[p]]
        d1 = (b[0] - a[0]) / scale[0]
        d2 = (b[1] - a[1]) / scale[1]
        arc.append(arc[-1] + math.sqrt(d1 ** 2 + d2 ** 2))
    if count == 1:
        targets = [arc[-1] / 2]
    else:
        targets = [arc[-1] * q / (count - 1) for q in range(count)]
    taken = []
    for t in targets:
        best = None
        for p in range(len(order)):
            if p in taken:
                continue
            if best is None or abs(arc[p] - t) < abs(arc[best] - t):
                best = p
        taken.append(best)
    return [order[p] for p in sorted(taken)]
