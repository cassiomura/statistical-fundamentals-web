# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: functions.py
# ==============================================================================
"""
The responses of the laboratories, y = f(x1, ..., xd), each on its design space of d inputs, standing for a simulation
whose output is y, in the order of the benches (RESPONSES): a classic test function of optimization and an engineering
case, of two inputs each, the same engineering case in four inputs, and the case sized, in four inputs too, whose one
simulation gives several responses (two objectives and two constraints). They work on numbers and on NumPy arrays alike
(a surface is one call on a grid): f(*x).

- Branin (Dixon & Szegő, Towards Global Optimisation 2, 1978): a curved valley with three global minima, the usual
  benchmark of designs of experiments and metamodels; its minimum is exactly 5 / (4 pi) = 0.3978873577..., where the
  squared term vanishes and 10 (1 - 1/(8 pi)) cos(x1) + 10 is lowest, at x1 = -pi, pi and 3 pi;
- the beam (beam.py, the simulation): the largest deflection of a main beam of 10 m on two elastic cross-beams at x1
  and x2 (m), in mm; x1 in [0.5, 5], x2 in [5, 9.5]. One global minimum, inside the box, on a kink (where the largest
  deflections of two spans tie), refined with SciPy's Nelder-Mead from thirteen starts, each restarted on smaller
  simplices: every run ends within 1e-11 m of the others, so its place is stored to 1e-10 m, and its value is the
  lowest any run found, 7.0147006605383035 mm, so that no point of the box gives f below it (step 3 shows f(x*) - f*:
  never negative; tests/test_measures.py finds it again and searches a fine grid for a lower value);
- the beam on four cross-beams (BEAM4, beam.f4, the simulation): the same beam and load on four elastic cross-beams at
  x1 in [1, 3.25], x2 in [3.25, 5], x3 in [5, 6.6] and x4 in [6.6, 9] m (ranges that share their ends: the cross-beams
  never swap places), y the RMS deflection along the beam in mm. It is smooth, with one global minimum inside the box,
  refined with SciPy (L-BFGS-B from seventeen starts, the sixteen corners of [0.2, 0.8]^4 of the unit hypercube among
  them, each polished by Nelder-Mead on smaller simplices: tests/test_measures.py finds it again). Every run ends within
  4e-7 m of the mean of their places, where f is flat to 1e-13 mm (a smooth minimum: f - f* grows with the square of the
  distance), so its place is that mean to 1e-7 m, and its value the lowest any run found, 3.227287907552611 mm;
- the beam on two cross-beams SIZED (BEAM_PARETO, beam.sized, the simulation), a bench of SEVERAL responses: the same
  beam and load on two steel cross-beams at x1 in [2, 5] and x2 in [5, 8] m, of solid square sections whose AREAS x3 =
  A1 and x4 = A2 are in [175, 350] cm^2 (these bounds are the one place of that range); one simulation gives four
  responses, the MASS of the cross-beams (kg) and the RMS DEFLECTION of the beam (mm), two objectives to minimize, and
  the STRESS of each cross-beam (MPa), two constraints, sigma <= beam.LIMIT_STRESS = 120 MPa. The stress is signed as
  the cross-beam's reaction (beam.stress) and the constraint bounds it from above only: right because every stress is
  positive over the whole design space (each cross-beam carries the beam down onto it: the least of 100 000 random
  designs is 40.4 MPa, of a 9^4 grid 38.7 MPa; tests/test_beam.py holds it), so that sigma <= 120 is |sigma| <= 120
  here. The two objectives pull apart (more steel, less deflection): no single minimum, a true Pareto front, stored as
  101 designs evenly spaced along it (fronts.BEAM_PARETO), found beforehand by a dense search (SLSQP on
  epsilon-constraint problems, 2216 designs) and written to 1e-7, each feasible as written;
  tests/test_measures.py finds its light end and a dozen of its points again with SciPy. x1 and x2 are places along
  the beam (places), x3 and x4 are not: they size the cross-beams, and Response.size names what they are, A, an area.

Branin's minima are the literature's, checked by the tests. A Response of d inputs (d = len(bounds))
carries d pairs of bounds, its minima as d-tuples and d + 1 units, those of the inputs and then y's, read as units[-1]
(empty for a test function, which has none; "m", "m", "mm" for the beam).

A bench may also have SEVERAL responses of one simulation (Response.outputs, a tuple of Output: each with its key, its
f, called f(*x) as a Response's, its role, an objective to minimize or a constraint g <= limit, its unit and its
symbol); the first three benches have one (outputs empty), and nothing of them changes. Response.together is one call
that gives every output of designs at once (a tuple of arrays, in the order of the outputs), so that a design is
simulated once for all of them; Response.front the designs of the true Pareto front (d-tuples), the reference a bench
of two objectives has in place of its minima; Response.places the inputs that are places along the beam (None: every
input is one) and Response.size the symbol, in ASCII, of what the other inputs are (A: the area of a cross-beam's
section, which the explorers number by the cross-beam, A1 and A2). response_of(key, output) is what a step reads as
"the response" of one output: for a bench of one response the Response itself, for a bench of several a Response of
that output alone (its f, the bench's bounds, the units of the inputs and its own, no minima: None, so that a rule of
one minimum never reads it by mistake). many(key) says whether a bench has several responses. A bench of several holds,
in its own f, minima, minimum and units, its FIRST output read alone: f the first output's (the mass), units those of
the inputs and then the first output's, and no minimum, minima () and minimum None, so that a reader of one minimum
fails loudly (min() of nothing, float(None); explorers/game.py refuses it in words) instead of writing a number
nobody computed. Its symbols (m, delta, sigma) are the explorers' (explorers/outputs.py): the cores are written in plain
ASCII.
"""
import math
from dataclasses import dataclass
from functools import cache
from typing import Callable

import numpy as np

from statistical_fundamentals import beam, fronts

def branin(x1, x2):
    a, b, c = 1.0, 5.1 / (4 * math.pi ** 2), 5 / math.pi
    r, s, t = 6.0, 10.0, 1 / (8 * math.pi)
    return a * (x2 - b * x1 ** 2 + c * x1 - r) ** 2 + s * (1 - t) * np.cos(x1) + s

ROLES = ("objective", "constraint")

@dataclass(frozen=True)
class Output:
    """One response of a simulation of several: its key, its f (called f(*x), on d numbers or on d arrays of a common
    shape), its role (ROLES: an objective, minimized; a constraint, g <= limit), its unit, its limit (a constraint's;
    None for an objective) and its symbol."""
    key: str
    f: Callable
    role: str
    unit: str
    limit: float | None = None
    symbol: str = ""

    def __post_init__(self):
        if self.role not in ROLES:
            raise ValueError(f"an output's role is one of {ROLES}, not {self.role!r}")

@dataclass(frozen=True)
class Response:
    """A response of d inputs on its design space (d pairs of bounds), with the points (d-tuples) and the value of its
    global minimum, and the units of the d inputs and then of y, read as units[-1] (empty: a test function has none).
    f is called f(*x), on d numbers or on d arrays of a common shape. A bench of several responses also has its outputs
    (empty: one response), together (one call for every output at once, a tuple of arrays in their order; None: each
    output's f), the designs of its true Pareto front, the inputs that are places along the beam (None: all) and the
    symbol of what the others are (size: A, an area; "" where every input is a place)."""
    key: str
    f: Callable
    bounds: tuple[tuple[float, float], ...]
    minima: tuple[tuple[float, ...], ...]
    minimum: float
    units: tuple[str, ...] = ("", "", "")
    outputs: tuple = ()
    together: Callable | None = None
    front: tuple = ()
    places: tuple | None = None
    size: str = ""

    @property
    def d(self):
        """The number of inputs."""
        return len(self.bounds)

def many(key):
    """Whether the bench `key` has several responses (outputs)."""
    return bool(RESPONSES[key].outputs)

def response_of(key, output=0):
    """The response of output `output` of the bench `key`: for a bench of one response the Response itself (output 0,
    the only one); for a bench of several, a Response of that output alone (cached: the same object for the same
    bench and output)."""
    response = RESPONSES[key]
    if not response.outputs:
        if output != 0:
            raise IndexError(f"the bench {key!r} has one response, not an output {output}")
        return response
    return alone(response, output)

@cache
def alone(response, output):
    """A Response of one output of a bench of several: its f, the bench's key and bounds, the units of the inputs and
    the output's own, and no minima (minimum None)."""
    chosen = response.outputs[output]
    return Response(response.key, chosen.f, response.bounds, (), None, response.units[:response.d] + (chosen.unit,),
                    places=response.places, size=response.size)

BEAM4 = Response("beam4", beam.f4, ((1.0, 3.25), (3.25, 5.0), (5.0, 6.6), (6.6, 9.0)),
                 ((3.0288446, 3.7647476, 5.6776514, 6.9414858),), 3.227287907552611,
                 units=("m", "m", "m", "m", "mm"))

BEAM_PARETO = Response("beam_pareto", beam.mass_of, ((2.0, 5.0), (5.0, 8.0), (175.0, 350.0), (175.0, 350.0)), (), None,
                       units=("m", "m", "cm²", "cm²", "kg"),
                       outputs=(Output("mass", beam.mass_of, "objective", "kg"),
                                Output("deflection", beam.rms_of, "objective", "mm"),
                                Output("stress_1", beam.stress_1, "constraint", "MPa", limit=beam.LIMIT_STRESS),
                                Output("stress_2", beam.stress_2, "constraint", "MPa", limit=beam.LIMIT_STRESS)),
                       together=beam.sized, front=fronts.BEAM_PARETO, places=(0, 1), size="A")

RESPONSES = {r.key: r for r in (
    Response("branin", branin, ((-5.0, 10.0), (0.0, 15.0)),
             ((-math.pi, 12.275), (math.pi, 2.275), (9.42478, 2.475)), 5 / (4 * math.pi)),
    Response("beam", beam.f, ((0.5, 5.0), (5.0, 9.5)), ((3.4988255764, 5.957561446),), 7.0147006605383035,
             units=("m", "m", "mm")),
    BEAM4,
    BEAM_PARETO,
)}
