# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                           Title: functions.py
# ==============================================================================
"""
The responses of the laboratories: classic test functions of optimization, y = f(x1, x2), each on its usual design
space, standing for a simulation whose output is y. They work on numbers and on NumPy arrays alike (a surface is one
call on a grid). Their minima are the literature's, checked by the tests.

- Branin (Dixon & Szegő, Towards Global Optimisation 2, 1978): a curved valley with three global minima, the usual
  benchmark of designs of experiments and metamodels; its minimum is exactly 5 / (4 pi) = 0.3978873577..., where the
  squared term vanishes and 10 (1 - 1/(8 pi)) cos(x1) + 10 is lowest, at x1 = -pi, pi and 3 pi;
- Himmelblau (Applied Nonlinear Programming, 1972): four minima of the same value;
- Rosenbrock (The Computer Journal 3(3), 1960): a narrow curved valley whose floor descends slowly to the minimum.
"""
import math
from dataclasses import dataclass
from typing import Callable

import numpy as np

def branin(x1, x2):
    a, b, c = 1.0, 5.1 / (4 * math.pi ** 2), 5 / math.pi
    r, s, t = 6.0, 10.0, 1 / (8 * math.pi)
    return a * (x2 - b * x1 ** 2 + c * x1 - r) ** 2 + s * (1 - t) * np.cos(x1) + s

def himmelblau(x1, x2):
    return (x1 ** 2 + x2 - 11) ** 2 + (x1 + x2 ** 2 - 7) ** 2

def rosenbrock(x1, x2):
    return (1 - x1) ** 2 + 100 * (x2 - x1 ** 2) ** 2

@dataclass(frozen=True)
class Response:
    """A test function on its design space, with the points and the value of its global minimum."""
    key: str
    f: Callable
    bounds: tuple[tuple[float, float], tuple[float, float]]
    minima: tuple[tuple[float, float], ...]
    minimum: float

RESPONSES = {r.key: r for r in (
    Response("branin", branin, ((-5.0, 10.0), (0.0, 15.0)),
             ((-math.pi, 12.275), (math.pi, 2.275), (9.42478, 2.475)), 5 / (4 * math.pi)),
    Response("himmelblau", himmelblau, ((-5.0, 5.0), (-5.0, 5.0)),
             ((3.0, 2.0), (-2.805118, 3.131312), (-3.779310, -3.283186), (3.584428, -1.848126)), 0.0),
    Response("rosenbrock", rosenbrock, ((-2.0, 2.0), (-1.0, 3.0)), ((1.0, 1.0),), 0.0),
)}
