# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                            Title: sqp.py
# ==============================================================================
"""
NLPQL, the gradient-based optimizer: sequential quadratic programming on the box [0, 1]^n. At the current design u, one
simulation is one call of f, and each iteration does four things:

1. The gradient, by forward differences: one extra simulation per variable, at u + h e_j (at u - h e_j where u_j + h
   would leave the box: a simulation outside the bounds is not allowed),

       g_j = (f(u + h e_j) - f(u)) / h

   h is a share of the range of each variable. The result is not the gradient but an estimate of it, off by about
   h f''/2 in each component (the truncation), and by the rounding of the two values of f divided by h, about
   eps |f| / h (eps the machine precision; more where f itself carries rounding noise).

2. The quadratic model of f around u, with B the approximation of the matrix of second derivatives (the Hessian), which
   the method learns from the gradients it has seen and starts as the identity (B_0 = I):

       q(d) = g^T d + (1/2) d^T B d

3. The step d that minimizes q while u + d stays in the box, i.e. -u <= d <= 1 - u. This is a quadratic program (QP).
   NLPQL solves its QP with a dual method (Schittkowski's QL); this code finds the same minimum by trying the faces of
   the box, quadratic.box_minimum, which is exact for any n, and short for the few variables of the laboratory (9
   faces for two, 81 for four). With only bounds as constraints,
   NLPQL's Lagrangian and its merit function (the quantity the line search must lower) are f itself, and the
   linearized constraints are the bounds.

4. The line search: how far to go along d. The trial points u + alpha d, alpha = 1, 1/2, 1/4, ... (each one
   simulation), until the first that satisfies the sufficient decrease condition of Armijo,

       f(u + alpha d) <= f(u) + c g^T d alpha,        c = ARMIJO = 10^-4

   that is, the response falls at least by a small share of what the gradient promised. After HALVINGS = 10 halvings
   the search gives up. The trial points stay in the box, which is convex.

Then the matrix learns: with s = u_new - u and y = g_new - g, the damped BFGS update makes B_new s equal to y when that
is safe, and to a mix of y and B s otherwise, so that B stays positive definite and q stays a bowl.

The method stops

- "converged": the step is shorter than TOLERANCE = 10^-6 (at a minimum, or on a bound where the response only rises
  inward, the step is zero);
- "no_decrease": no trial of the line search met the sufficient decrease (Armijo). The method then does what any line
  search does: it stops. The gradient the method uses is the forward difference, which carries the errors above: the
  truncation of about h f''/2, and the rounding of f, about eps |f| / h, which grows as h shrinks. Far from the minimum
  with a large h, or near it where the true gradient tends to zero, that error outweighs the gradient, and the step d is
  no longer downhill, or far less downhill than the estimated gradient promises (some trials may then lower f, but by
  less than Armijo's margin). A large h is one cause, not the only one: a small h with an f whose values carry rounding
  noise is another, and the rounding then dominates (a metamodel near singular: Kriging's weights reach 10^4 on four
  inputs at small theta, so y^ carries noise far above eps |y^|, and its forward differences at h = 10^-8 are off by
  far more than h f''/2); the stop can also come close to the minimum, which the gap to the best value known (shown by
  the laboratory) tells apart;
- "iterations": ITERATIONS = 100 line searches were made without either.

nlpql returns the iterations as dicts, one per iterate u_k: "point", "value" (f there), "gradient" and "probes" (the n
simulations that made it: list of (point, value)), "matrix" (B_k), "step" (d_k), "trials" (list of (point, value), the
line search, empty when the step is below TOLERANCE and in the last record of an "iterations" stop) and "alpha" (the
accepted one; None when no trial was made or none was accepted). The gradient of iteration k is computed right after the
line search of iteration k - 1, so the simulations are called in this order: f(start), the probes of iteration 0, its
trials, the probes of iteration 1, its trials, and so on. The last iteration is the one where the method stopped, and
its point is the result.

References: K. Schittkowski, "NLPQL: A FORTRAN subroutine solving constrained nonlinear programming problems", Annals
of Operations Research 5, 485-500, 1986. J. Nocedal & S. J. Wright, Numerical Optimization, 2nd ed., Springer, 2006
(the sufficient decrease condition, eq. 3.4; backtracking, Algorithm 3.1; the damped BFGS update, Procedure 18.2).
L. Armijo, "Minimization of functions having Lipschitz continuous first partial derivatives", Pacific Journal of
Mathematics 16(1), 1-3, 1966.

Readable cores: plain lists and loops, shown in the window as the method's code.
"""
import math

from statistical_fundamentals.linear import dot
from statistical_fundamentals.quadratic import box_minimum

TOLERANCE = 1e-6
ARMIJO = 1e-4
HALVINGS = 10
ITERATIONS = 100

def forward_difference(f, u, value, h):
    """The gradient of f at u from forward differences, and the simulations it took: (point, value) per variable."""
    n = len(u)
    gradient = [0.0] * n
    probes = []
    for j in range(n):
        delta = h if u[j] + h <= 1 else -h
        point = list(u)
        point[j] = u[j] + delta
        probe = f(point)
        probes.append((point, probe))
        gradient[j] = (probe - value) / delta
    return gradient, probes

def line_search(f, u, value, gradient, d):
    """Backtracking: alpha = 1, 1/2, 1/4, ... until Armijo's sufficient decrease holds; alpha is None after HALVINGS."""
    slope = dot(gradient, d)
    trials = []
    alpha = 1.0
    for halving in range(HALVINGS + 1):
        point = [min(1.0, max(0.0, u[i] + alpha * d[i])) for i in range(len(u))]
        trial = f(point)
        trials.append((point, trial))
        if trial <= value + ARMIJO * alpha * slope:
            return alpha, trials
        alpha = alpha / 2
    return None, trials

def bfgs_update(B, s, y):
    """The damped BFGS update of B (Nocedal & Wright, Procedure 18.2): B_new s = r, r = theta y + (1 - theta) B s."""
    n = len(s)
    Bs = [dot(row, s) for row in B]
    sBs = dot(s, Bs)
    sy = dot(s, y)
    theta = 1.0 if sy >= 0.2 * sBs else 0.8 * sBs / (sBs - sy)
    r = [theta * y[i] + (1 - theta) * Bs[i] for i in range(n)]
    sr = dot(s, r)
    return [[B[i][j] - Bs[i] * Bs[j] / sBs + r[i] * r[j] / sr for j in range(n)]
            for i in range(n)]

def nlpql(f, start, h):
    """The iterations of NLPQL from start with the differentiation step h, and why it stopped."""
    n = len(start)
    u = list(start)
    value = f(u)
    B = [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]
    gradient, probes = forward_difference(f, u, value, h)
    iterations = []
    stop = "iterations"
    for k in range(ITERATIONS + 1):
        step = box_minimum(gradient, B, [-x for x in u], [1 - x for x in u])
        record = {"point": u, "value": value, "gradient": gradient,
                  "probes": probes, "matrix": B, "step": step,
                  "trials": [], "alpha": None}
        iterations.append(record)
        if math.sqrt(dot(step, step)) < TOLERANCE:
            stop = "converged"
            break
        if k == ITERATIONS:
            break
        alpha, trials = line_search(f, u, value, gradient, step)
        record["trials"] = trials
        record["alpha"] = alpha
        if alpha is None:
            stop = "no_decrease"
            break
        new_u, new_value = trials[-1]
        new_gradient, new_probes = forward_difference(f, new_u, new_value, h)
        s = [new_u[i] - u[i] for i in range(n)]
        y = [new_gradient[i] - gradient[i] for i in range(n)]
        B = bfgs_update(B, s, y)
        u, value, gradient, probes = new_u, new_value, new_gradient, new_probes
    return iterations, stop
