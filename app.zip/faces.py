# ==============================================================================
#                    CASSIO MURAKAMI - STATISTICAL METHODS
#                     Project: Statistical Fundamentals
#                             Title: faces.py
# ==============================================================================
"""
The faces of the web's figure: Pyodide's matplotlib knows only its own DejaVu, so the worker (web/shell/worker.js)
registers the open face the page is set in, Selawik (Microsoft, SIL OFL 1.1, the widths of Segoe UI: regular, semibold
and bold, unpacked from app.zip's fonts/), before the bridge first imports explorers/panels.py, which resolves its
faces (panels.SANS: palette.SANS_FACES among the fonts matplotlib finds) once, at import. The figure is then drawn in
Selawik, each glyph Selawik lacks (Greek, subscripts, the minus sign, arrows, stars) in DejaVu Sans, the next face of
the list, as on a desktop without Segoe UI.

register(directory) adds every .ttf of a directory to matplotlib's font manager and says how many it added; a missing
directory or a file matplotlib cannot read is passed over without a word, and the figure falls back to DejaVu.
It runs in the web's runtime only, never on importing the bridge: in CPython the faces are the machine's (Segoe UI on
Windows), and a registration after panels.py is imported would leave panels.SANS behind the font manager's list.
"""
from pathlib import Path

def register(directory) -> int:
    """Every .ttf of `directory` added to matplotlib's font manager, in the order of their names: how many were."""
    from matplotlib import font_manager
    try:
        paths = sorted(Path(directory).glob("*.ttf"))
    except OSError:
        return 0
    added = 0
    for path in paths:
        try:
            font_manager.fontManager.addfont(str(path))
        except Exception:                                           # an unreadable face: the figure keeps DejaVu
            continue
        added += 1
    return added
